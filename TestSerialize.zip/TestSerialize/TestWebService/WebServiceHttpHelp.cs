﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace TestSerialize.TestWebService
{
    /// <summary>
    /// 请求信息帮助
    /// </summary>
    public partial class WebServiceHttpHelp
    {
        private static WebServiceHttpHelp m_Helper;
        /// <summary>
        /// 单例
        /// </summary>
        public static WebServiceHttpHelp Helper
        {
            get { return m_Helper ?? (m_Helper = new WebServiceHttpHelp()); }
        }

        /// <summary>
        /// 获取请求的数据
        /// </summary>
        /// <param name="strUrl">请求地址</param>
        /// <param name="requestMode">请求方式</param>
        /// <param name="parameters">参数</param>
        /// <param name="requestCoding">请求编码</param>
        /// <param name="responseCoding">响应编码</param>
        /// <param name="timeout">请求超时时间（毫秒）</param>
        /// <returns>返回：请求成功响应信息，失败返回null</returns>
        public string GetResponseString(string strUrl, ERequestMode requestMode, Dictionary<string, string> parameters, Encoding requestCoding, Encoding responseCoding, int timeout = 300)
        {
            string url = VerifyUrl(strUrl);
            HttpWebRequest webRequest = (HttpWebRequest)WebRequest.Create(new Uri(url));

            HttpWebResponse webResponse = null;
            switch (requestMode)
            {
                case ERequestMode.Get:
                    webResponse = GetRequest(webRequest, timeout);
                    break;
                case ERequestMode.Post:
                    webResponse = PostRequest(webRequest, parameters, timeout, requestCoding);
                    break;
            }

            if (webResponse != null && webResponse.StatusCode == HttpStatusCode.OK)
            {
                using (Stream newStream = webResponse.GetResponseStream())
                {
                    if (newStream != null)
                        using (StreamReader reader = new StreamReader(newStream, responseCoding))
                        {
                            string result = reader.ReadToEnd();
                            return result;
                        }
                }
            }
            return null;
        }

        /// <summary>
        /// get 请求指定地址返回响应数据
        /// </summary>
        /// <param name="webRequest">请求</param>
        /// <param name="timeout">请求超时时间（毫秒）</param>
        /// <returns>返回：响应信息</returns>
        private HttpWebResponse GetRequest(HttpWebRequest webRequest, int timeout)
        {
            try
            {
                webRequest.Accept = "text/html, application/xhtml+xml, application/json, text/javascript, */*; q=0.01";
                webRequest.Headers.Add("Accept-Language", "zh-cn,en-US,en;q=0.5");
                webRequest.Headers.Add("Cache-Control", "no-cache");
                webRequest.UserAgent = "DefaultUserAgent";
                webRequest.Timeout = timeout;
                webRequest.Method = "GET";

                // 接收返回信息
                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                return webResponse;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        /// <summary>
        /// post 请求指定地址返回响应数据
        /// </summary>
        /// <param name="webRequest">请求</param>
        /// <param name="parameters">传入参数</param>
        /// <param name="timeout">请求超时时间（毫秒）</param>
        /// <param name="requestCoding">请求编码</param>
        /// <returns>返回：响应信息</returns>
        private HttpWebResponse PostRequest(HttpWebRequest webRequest, Dictionary<string, string> parameters, int timeout, Encoding requestCoding)
        {
            try
            {
                // 拼接参数
                string postStr = string.Empty;
                if (parameters != null)
                {
                    parameters.All(o =>
                    {
                        if (string.IsNullOrEmpty(postStr))
                            postStr = string.Format("{0}={1}", o.Key, o.Value);
                        else
                            postStr += string.Format("&{0}={1}", o.Key, o.Value);

                        return true;
                    });
                }

                byte[] byteArray = requestCoding.GetBytes(postStr);
                webRequest.Accept = "text/html, application/xhtml+xml, application/json, text/javascript, */*; q=0.01";
                webRequest.Headers.Add("Accept-Language", "zh-cn,en-US,en;q=0.5");
                webRequest.Headers.Add("Cache-Control", "no-cache");
                webRequest.UserAgent = "DefaultUserAgent";
                webRequest.Timeout = timeout;
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.ContentLength = byteArray.Length;
                webRequest.Method = "POST";

                // 将参数写入流
                using (Stream newStream = webRequest.GetRequestStream())
                {
                    newStream.Write(byteArray, 0, byteArray.Length);
                    newStream.Close();
                }

                // 接收返回信息
                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                return webResponse;
            }
            catch (Exception ex)
            {
                return null;
            }
        }


        /// <summary>
        /// 验证URL
        /// </summary>
        /// <param name="url">待验证 URL</param>
        /// <returns></returns>
        private string VerifyUrl(string url)
        {
            if (string.IsNullOrEmpty(url))
                throw new Exception("URL 地址不可以为空！");

            if (url.StartsWith("http://", StringComparison.CurrentCultureIgnoreCase))
                return url;

            return string.Format("http://{0}", url);
        }
    }

    #region
    public class WebServiceCall
    {
        public static string mUrl = string.Empty;
        public WebServiceCall(string url)
        {
            mUrl = url;
        }

        ///// <summary>
        ///// 调用接口
        ///// </summary>
        ///// <param name="methodName">方法名称</param>
        ///// <param name="param">参数名称</param>
        ///// <returns>返回值</returns>
        //public string callWebService(string methodName, Dictionary<string, string> param)
        //{
        //    ///获取请求数据
        //    byte[] data = getRequestDataJava(methodName, param); // getRequestData(methodName, param);
        //    HttpWebRequest request = (HttpWebRequest)WebRequest.Create(mUrl);
        //    request.Method = "POST";
        //    request.ContentType = "text/xml; charset=utf-8";
        //    string mSoapAction = "http://tempuri.org/" + methodName;
        //    request.Headers.Add("SOAPAction", mSoapAction);
        //    request.ContentLength = data.Length;
        //    Stream rStream = request.GetRequestStream();
        //    rStream.Write(data, 0, data.Length);
        //    rStream.Close();

        //    WebResponse response = request.GetResponse();
        //    Stream dataStream = response.GetResponseStream();
        //    StreamReader reader = new StreamReader(dataStream);
        //    string result = reader.ReadToEnd();

        //    dataStream.Close();
        //    response.Close();
        //    return result;
        //}


        /// <summary>
        /// 获取请求内容(方法1) 适合 .Net
        /// </summary>
        /// <param name="methodName">方法名称</param>
        /// <param name="param">参数</param>
        /// <returns></returns>
        public byte[] getRequestData(string methodName, Dictionary<string, string> param)
        {
            StringBuilder requestData = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
                .Append("<soap:Envelope xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\">")
                .Append("  <soap:Body>")
                .Append("<").Append(methodName)
                .Append(" xmlns=\"http://tempuri.org/\">");
            foreach (KeyValuePair<string, string> item in param)
            {
                requestData.Append("<").Append(item.Key).Append(">")
                .Append(item.Value)
                .Append("</").Append(item.Key).Append(">");
            }
            requestData.Append("</").Append(methodName).Append(">")
            .Append("</soap:Body>")
            .Append("</soap:Envelope>");
            string val = requestData.ToString();
            byte[] data = Encoding.UTF8.GetBytes(val);
            return data;
        }

        /// <summary>
        /// 获取数据(方法2) 兼容所有的(java soap 服务端和.net  soap 服务端)
        /// </summary>
        /// <param name="methodName">方法名称</param>
        /// <param name="param">参数</param>
        /// <returns></returns>
        public byte[] getRequestDataALL(string methodName, Dictionary<string, string> param)
        {
            StringBuilder requestBuider = new StringBuilder();
            requestBuider.Append("<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:icc=\"http://pub.ccgb.so.itf.nc/ICCGBHAService\">");
            requestBuider.Append("<soapenv:Header/>");
            requestBuider.Append("<soapenv:Body>");
            requestBuider.Append("<icc:").Append(methodName).Append(">");
            foreach (KeyValuePair<string, string> item in param)
            {
                requestBuider.Append("<").Append(item.Key).Append(">");
                requestBuider.Append(item.Value);
                requestBuider.Append("</").Append(item.Key).Append(">");
            }
            requestBuider.Append("</icc:").Append(methodName).Append(">");
            requestBuider.Append("</soapenv:Body>");
            requestBuider.Append("</soapenv:Envelope>");
            string val = requestBuider.ToString();
            byte[] data = Encoding.UTF8.GetBytes(val);
            return data;
        }
    }

    #endregion
}
