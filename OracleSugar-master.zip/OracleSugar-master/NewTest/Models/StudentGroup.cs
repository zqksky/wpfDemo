﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace  Models
{
    public class StudentGroup
    {
        public string Sex { get; set; }
        public int Count { get; set; }
    }
}
