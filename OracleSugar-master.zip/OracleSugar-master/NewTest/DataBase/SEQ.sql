﻿ 
CREATE SEQUENCE SEQ;
Alter Sequence SEQ Increment By 1000;
Select SEQ.NextVal From Dual;
Alter Sequence SEQ Increment By 1;
 

CREATE SEQUENCE SEQ2;
Alter Sequence SEQ2 Increment By 1000;
Select SEQ2.NextVal From Dual;
Alter Sequence SEQ2 Increment By 1;
 

CREATE SEQUENCE SEQ3;
Alter Sequence SEQ3 Increment By 1000;
Select SEQ3.NextVal From Dual;
Alter Sequence SEQ3 Increment By 1;
 

CREATE SEQUENCE SEQ4;
Alter Sequence SEQ4 Increment By 1000;
Select SEQ4.NextVal From Dual;
Alter Sequence SEQ4 Increment By 1;
 
 