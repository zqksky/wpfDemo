﻿using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace TestOracle
{
    public partial class frmConfig : Form
    {
        public frmConfig()
        {
            InitializeComponent();
        }

        private void frmConfig_Load(object sender, EventArgs e)
        {
            //Open();
        }

        private void btnOk_Click(object sender, EventArgs e)
        {
            if (txtIP.Text == "")
            {
                MessageBox.Show("ServerIP is not allow null");
                return;
            }
            else if (txtDbName.Text == "")
            {
                MessageBox.Show("DataBase is not allow null");
                return;
            }
            else if (txtUser.Text == "")
            {
                MessageBox.Show("User Name is not allow null");
                return;
            }
            else
            {
                SaveConfig(txtIP.Text, "ServerIP");
                SaveConfig(txtDbName.Text, "Server");
                SaveConfig(txtUser.Text, "user");
                SaveConfig(txtPwd.Text, "password");
                MessageBox.Show("Config Sucessful!", "", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            this.Close();

        }
        private void Open()
        {
            //OracleConnection con = null;
            //// open connection            
            //if (con == null)
            //{
            //    string strcon = "User Id=e3suite;Password=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=e3suite)))";
            string strcon = String.Format("packet size=4096;data source={0};persist security info=True;initial catalog={1};user id={2};password={3}", ConfigurationManager.AppSettings["SQLserverIP"], ConfigurationManager.AppSettings["Server"], ConfigurationSettings.AppSettings["user"], ConfigurationSettings.AppSettings["password"]);
            //    con = new OracleConnection(strcon);
            //    try
            //    {
            //        con.Open();
            //    }
            //    catch (Exception ee)
            //    {
            //        ee.ToString();
            //    }
            //}
        }

        //<addConfig>

        //<add key = "ServerIP" value="127.0.0.1"></add>

        //<add key = "DataBase" value="WarehouseDB"></add>

        //<add key = "user" value="sa"></add>

        //<add key = "password" value="sa"></add>

        //</addConfig>
        private void SaveConfig(string ConnenctionString, string strKey)
        {
            XmlDocument doc = new XmlDocument();            //获得配置文件的全路径            
            string strFileName = AppDomain.CurrentDomain.SetupInformation.ConfigurationFile;
            doc.Load(strFileName);            //找出名称为“add”的所有元素            
            XmlNodeList nodes = doc.GetElementsByTagName("add");
            for (int i = 0; i < nodes.Count; i++)
            {                
                //获得将当前元素的key属性                
                XmlAttribute att = nodes[i].Attributes["key"];                //根据元素的第一个属性来判断当前的元素是不是目标元素                
                if (att.Value == strKey)
                {                    
                    //对目标元素中的第二个属性赋值                    
                    att = nodes[i].Attributes["value"];
                    att.Value = ConnenctionString;
                    break;
                }
            }
            //保存上面的修改            
            doc.Save(strFileName);
            ConfigurationManager.RefreshSection("addConfig");
        }
    }
}
