﻿namespace TestOracle
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.dtpTo_History = new System.Windows.Forms.DateTimePicker();
            this.dtpFrom_History = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv1
            // 
            this.dgv1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv1.Location = new System.Drawing.Point(12, 125);
            this.dgv1.Name = "dgv1";
            this.dgv1.Size = new System.Drawing.Size(767, 375);
            this.dgv1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(625, 50);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dtpTo_History
            // 
            this.dtpTo_History.Location = new System.Drawing.Point(12, 38);
            this.dtpTo_History.Name = "dtpTo_History";
            this.dtpTo_History.Size = new System.Drawing.Size(257, 20);
            this.dtpTo_History.TabIndex = 43;
            this.dtpTo_History.ValueChanged += new System.EventHandler(this.dtpDateTime_History_ValueChanged);
            // 
            // dtpFrom_History
            // 
            this.dtpFrom_History.Location = new System.Drawing.Point(12, 12);
            this.dtpFrom_History.Name = "dtpFrom_History";
            this.dtpFrom_History.Size = new System.Drawing.Size(257, 20);
            this.dtpFrom_History.TabIndex = 42;
            this.dtpFrom_History.Value = new System.DateTime(2018, 10, 24, 9, 58, 1, 0);
            this.dtpFrom_History.ValueChanged += new System.EventHandler(this.dtpDateTime_History_ValueChanged);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 512);
            this.Controls.Add(this.dtpTo_History);
            this.Controls.Add(this.dtpFrom_History);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dgv1);
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dtpTo_History;
        private System.Windows.Forms.DateTimePicker dtpFrom_History;
    }
}

