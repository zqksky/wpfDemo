﻿using Oracle.DataAccess.Client;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestOracle.BaseFun;
using Oracle.ManagedDataAccess.Client;

namespace TestOracle
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            InitDateTime();
            DateTime startTimeTmp = dtpFrom_History.Value;
            DateTime endTimeTmp = dtpTo_History.Value;
            startTime = startTimeTmp.ToString("o");
            endTime = endTimeTmp.ToString("o");

            //startTime = dtpFrom_History.Text.ToString();
            //endTime = dtpTo_History.Text.ToString();

            //string sqlString = "Select a.ID,a.NAME From EES_STATE_DEF a Where a.ID=:id";
            //DataTable dt = OracleHelp.ExecuteDataTable(sqlString, new Oracle.ManagedDataAccess.Client.OracleParameter(":id", 2));
            //int i = OracleHelp.ExecuteNonQuery(sqlString, new Oracle.ManagedDataAccess.Client.OracleParameter(":id", 1));

            //string sqlString = "SELECT * FROM EES_STATE_DEF WHERE ID=1 or id=2 ";
            //string sqlString = "UPDATE EES_STATE_DEF SET NAME='Fixed' WHERE ID=1";//Active
            //string sqlString = "UPDATE EES_STATE_DEF SET NAME='Active' WHERE ID=1";//Active

            //string sqlString = "SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG";
            //string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", Convert.ToDateTime(startTime), Convert.ToDateTime(endTime));
            string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
            //string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP  between " + startTimeTmp +" and "+ endTimeTmp);

            sqlString = "SELECT* FROM ( " + sqlString + ") WHERE ROWNUM <=" + 2;

            DataTable dt = OracleHelp.ExecuteDataTable(sqlString);
            int i = OracleHelp.ExecuteNonQuery(sqlString);
            dgv1.DataSource = dt;

            //OracleHelp.test(sqlString);
        }

        string startTime = string.Empty;
        string endTime = string.Empty;
        private void InitDateTime()
        {
            try
            {
                #region
                //控制日期或时间的显示格式
                this.dtpFrom_History.CustomFormat = "yyyy-MM-dd HH:mm:ss";
                //使用自定义格式
                this.dtpFrom_History.Format = DateTimePickerFormat.Custom;
                //时间控件的启用
                //this.dtpFrom.ShowUpDown = true;

                //控制日期或时间的显示格式
                this.dtpTo_History.CustomFormat = "yyyy-MM-dd HH:mm:ss";
                //使用自定义格式
                this.dtpTo_History.Format = DateTimePickerFormat.Custom;
                #endregion
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void test()
        {
            string connectionString;
            string queryString;

            //connectionString = "Data Source=192.168.150.135/orcl;User ID=e3suite;PassWord=e3suite";
            ////connectionString = "Password=e3suite;User ID=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVER=DEDICATED)(SERVICE_NAME=e3suite)));";

            //Oracle.DataAccess.Client.OracleConnection myConnection = new Oracle.DataAccess.Client.OracleConnection(connectionString);

            using (Oracle.DataAccess.Client.OracleConnection conn = new Oracle.DataAccess.Client.OracleConnection("data source=192.168.150.135/orcl;User Id=e3suite;Password=e3suite;"))
            {
                conn.Open();
            }

            //queryString = "SELECT * FROM YMTC_PH_CONTROL_SEPCS_CONFIG";
            //OracleCommand myORACCommand = myConnection.CreateCommand();
            //myORACCommand.CommandText = queryString;
            //myConnection.Open();
            //OracleDataReader myDataReader = myORACCommand.ExecuteReader();
            //myDataReader.Read();

            ////Console.WriteLine("email: " + myDataReader["EMAIL"]);

            //myDataReader.Close();
            //myConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //frmConfig frm = new frmConfig();
            //frm.ShowDialog();
        }

        private void dtpDateTime_History_ValueChanged(object sender, EventArgs e)
        {
            dgv1.DataSource = null;
            DateTime startTimeTmp = dtpFrom_History.Value;
            DateTime endTimeTmp = dtpTo_History.Value;
            startTime = startTimeTmp.ToString("o");
            endTime = endTimeTmp.ToString("o");
            //string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", Convert.ToDateTime(startTime), Convert.ToDateTime(endTime));
            string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP >='{0}' AND TIMESTAMP<='{1}'", startTime, endTime);
            //string sqlString = string.Format("SELECT * FROM R2R_UI_HISTORY_PROCESS_LOG WHERE TIMESTAMP between " + startTimeTmp + " and " + endTimeTmp);
            sqlString = "SELECT* FROM ( " + sqlString + ") WHERE ROWNUM <=" + 2;
            DataTable dt = OracleHelp.ExecuteDataTable(sqlString);
            int i = OracleHelp.ExecuteNonQuery(sqlString);

            dgv1.DataSource = dt;
        }
    }
}
