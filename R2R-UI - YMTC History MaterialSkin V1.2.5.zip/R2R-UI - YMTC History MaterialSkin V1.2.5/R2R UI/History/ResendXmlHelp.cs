﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R_UI.History
{
    class ResendXmlHelp
    {
        public static void ReSendXml(string strService, string strNetwork, string strDaemon, string strTargetSubject, string strXml)
        {
            //RVPublisher.Proxy proxy = new RVPublisher.Proxy();
            ////MessageBox.Show("0.---" + proxy.ErrMsg);

            ////proxy.Open("7909", null, "tcp:152.135.85.139:7909", "YMTCQATEST.R2R.MES.UI");
            //proxy.Open(strService, strNetwork, strDaemon, strTargetSubject);
            ////MessageBox.Show("1.---" + proxy.ErrMsg);

            //proxy.Send(strXml);
            ////proxy.Send(xmlString1);
            ////proxy.Send(xmlString2);
            ////proxy.Send(xmlString3);
            ////MessageBox.Show("2.---" + proxy.ErrMsg);


            //proxy.Close();
            ////MessageBox.Show("3.---" + proxy.ErrMsg);
        }
    }
}
