﻿namespace R2R_UI.Present.BatchOperation
{
    partial class frmBatchOperation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnOVLModel = new System.Windows.Forms.Button();
            this.btnPMOffset = new System.Windows.Forms.Button();
            this.btnR2RMode = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.cmbTool = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.cmbProduct = new System.Windows.Forms.ComboBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.cmbLayer = new System.Windows.Forms.ComboBox();
            this.panLbl = new System.Windows.Forms.Panel();
            this.lblContext = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.panLbl.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panLbl);
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(564, 213);
            this.panel1.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel4.Controls.Add(this.groupBox2);
            this.panel4.Controls.Add(this.groupBox1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(564, 178);
            this.panel4.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnOVLModel);
            this.groupBox2.Controls.Add(this.btnPMOffset);
            this.groupBox2.Controls.Add(this.btnR2RMode);
            this.groupBox2.Location = new System.Drawing.Point(359, 4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(185, 156);
            this.groupBox2.TabIndex = 9;
            this.groupBox2.TabStop = false;
            // 
            // btnOVLModel
            // 
            this.btnOVLModel.BackColor = System.Drawing.SystemColors.Control;
            this.btnOVLModel.Location = new System.Drawing.Point(25, 17);
            this.btnOVLModel.Name = "btnOVLModel";
            this.btnOVLModel.Size = new System.Drawing.Size(136, 30);
            this.btnOVLModel.TabIndex = 0;
            this.btnOVLModel.Text = "Batch OVL Model";
            this.btnOVLModel.UseVisualStyleBackColor = false;
            this.btnOVLModel.Click += new System.EventHandler(this.btnOVLModel_Click);
            // 
            // btnPMOffset
            // 
            this.btnPMOffset.BackColor = System.Drawing.SystemColors.Control;
            this.btnPMOffset.Enabled = false;
            this.btnPMOffset.Location = new System.Drawing.Point(25, 110);
            this.btnPMOffset.Name = "btnPMOffset";
            this.btnPMOffset.Size = new System.Drawing.Size(136, 30);
            this.btnPMOffset.TabIndex = 2;
            this.btnPMOffset.Text = "Batch PM Offset";
            this.btnPMOffset.UseVisualStyleBackColor = false;
            this.btnPMOffset.Click += new System.EventHandler(this.btnPMOffset_Click);
            // 
            // btnR2RMode
            // 
            this.btnR2RMode.BackColor = System.Drawing.SystemColors.Control;
            this.btnR2RMode.Location = new System.Drawing.Point(25, 64);
            this.btnR2RMode.Name = "btnR2RMode";
            this.btnR2RMode.Size = new System.Drawing.Size(136, 30);
            this.btnR2RMode.TabIndex = 1;
            this.btnR2RMode.Text = "Batch R2R Mode";
            this.btnR2RMode.UseVisualStyleBackColor = false;
            this.btnR2RMode.Click += new System.EventHandler(this.btnR2RMode_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox1);
            this.groupBox1.Controls.Add(this.cmbTool);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.cmbProduct);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.cmbLayer);
            this.groupBox1.Location = new System.Drawing.Point(10, 4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(329, 156);
            this.groupBox1.TabIndex = 8;
            this.groupBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(25, 26);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(55, 13);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "Product";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbTool
            // 
            this.cmbTool.FormattingEnabled = true;
            this.cmbTool.Location = new System.Drawing.Point(86, 117);
            this.cmbTool.Name = "cmbTool";
            this.cmbTool.Size = new System.Drawing.Size(223, 21);
            this.cmbTool.TabIndex = 7;
            this.cmbTool.SelectedIndexChanged += new System.EventHandler(this.cmbTool_SelectedIndexChanged);
            this.cmbTool.SelectedValueChanged += new System.EventHandler(this.cmbContext_SelectedValueChanged);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(25, 120);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(55, 13);
            this.textBox2.TabIndex = 2;
            this.textBox2.Text = "Tool";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbProduct
            // 
            this.cmbProduct.FormattingEnabled = true;
            this.cmbProduct.Location = new System.Drawing.Point(86, 23);
            this.cmbProduct.Name = "cmbProduct";
            this.cmbProduct.Size = new System.Drawing.Size(223, 21);
            this.cmbProduct.TabIndex = 5;
            this.cmbProduct.SelectedIndexChanged += new System.EventHandler(this.cmbProduct_SelectedIndexChanged);
            this.cmbProduct.SelectedValueChanged += new System.EventHandler(this.cmbContext_SelectedValueChanged);
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(25, 74);
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.Size = new System.Drawing.Size(55, 13);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "Layer";
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // cmbLayer
            // 
            this.cmbLayer.FormattingEnabled = true;
            this.cmbLayer.Location = new System.Drawing.Point(86, 71);
            this.cmbLayer.Name = "cmbLayer";
            this.cmbLayer.Size = new System.Drawing.Size(223, 21);
            this.cmbLayer.TabIndex = 6;
            this.cmbLayer.SelectedIndexChanged += new System.EventHandler(this.cmbLayer_SelectedIndexChanged);
            this.cmbLayer.SelectedValueChanged += new System.EventHandler(this.cmbContext_SelectedValueChanged);
            // 
            // panLbl
            // 
            this.panLbl.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panLbl.Controls.Add(this.lblContext);
            this.panLbl.Dock = System.Windows.Forms.DockStyle.Top;
            this.panLbl.Location = new System.Drawing.Point(0, 0);
            this.panLbl.Name = "panLbl";
            this.panLbl.Size = new System.Drawing.Size(564, 35);
            this.panLbl.TabIndex = 0;
            // 
            // lblContext
            // 
            this.lblContext.AutoSize = true;
            this.lblContext.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContext.Location = new System.Drawing.Point(137, 9);
            this.lblContext.Name = "lblContext";
            this.lblContext.Size = new System.Drawing.Size(278, 16);
            this.lblContext.TabIndex = 0;
            this.lblContext.Text = "This is part of UVL UI-Batch Operations";
            // 
            // frmBatchOperation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(564, 277);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmBatchOperation";
            this.Padding = new System.Windows.Forms.Padding(3, 40, 3, 3);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BatchOperation";
            this.Load += new System.EventHandler(this.frmBatchOperation_Load);
            this.SizeChanged += new System.EventHandler(this.frmBatchOperation_SizeChanged);
            this.Resize += new System.EventHandler(this.frmBatchOperation_Resize);
            this.panel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.panLbl.ResumeLayout(false);
            this.panLbl.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panLbl;
        private System.Windows.Forms.Label lblContext;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cmbTool;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ComboBox cmbLayer;
        private System.Windows.Forms.ComboBox cmbProduct;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button btnPMOffset;
        private System.Windows.Forms.Button btnR2RMode;
        private System.Windows.Forms.Button btnOVLModel;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
    }
}