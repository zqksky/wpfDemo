﻿namespace R2R_UI.Present.Common
{
    partial class frmRawMetrology
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.grpRawMetrology = new System.Windows.Forms.GroupBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dgvRawMetrology = new System.Windows.Forms.DataGridView();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblUpperLimit = new System.Windows.Forms.Label();
            this.lblLowerLimit = new System.Windows.Forms.Label();
            this.lblTarget = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.grpRawMetrology.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRawMetrology)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.panel1.Controls.Add(this.grpRawMetrology);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(0, 64);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(801, 400);
            this.panel1.TabIndex = 0;
            // 
            // grpRawMetrology
            // 
            this.grpRawMetrology.Controls.Add(this.panel4);
            this.grpRawMetrology.Controls.Add(this.panel2);
            this.grpRawMetrology.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grpRawMetrology.Location = new System.Drawing.Point(0, 0);
            this.grpRawMetrology.Name = "grpRawMetrology";
            this.grpRawMetrology.Size = new System.Drawing.Size(801, 400);
            this.grpRawMetrology.TabIndex = 2;
            this.grpRawMetrology.TabStop = false;
            this.grpRawMetrology.Text = "LotId";
            // 
            // panel4
            // 
            this.panel4.AutoScroll = true;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.dgvRawMetrology);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(3, 54);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(795, 343);
            this.panel4.TabIndex = 1;
            // 
            // dgvRawMetrology
            // 
            this.dgvRawMetrology.AllowUserToAddRows = false;
            this.dgvRawMetrology.AllowUserToDeleteRows = false;
            this.dgvRawMetrology.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvRawMetrology.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvRawMetrology.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRawMetrology.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgvRawMetrology.Location = new System.Drawing.Point(0, 0);
            this.dgvRawMetrology.Name = "dgvRawMetrology";
            this.dgvRawMetrology.RowTemplate.DefaultCellStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvRawMetrology.Size = new System.Drawing.Size(793, 341);
            this.dgvRawMetrology.TabIndex = 3;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel2.Controls.Add(this.lblUpperLimit);
            this.panel2.Controls.Add(this.lblLowerLimit);
            this.panel2.Controls.Add(this.lblTarget);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(3, 18);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(795, 36);
            this.panel2.TabIndex = 0;
            // 
            // lblUpperLimit
            // 
            this.lblUpperLimit.AutoSize = true;
            this.lblUpperLimit.Location = new System.Drawing.Point(543, 10);
            this.lblUpperLimit.Name = "lblUpperLimit";
            this.lblUpperLimit.Size = new System.Drawing.Size(83, 16);
            this.lblUpperLimit.TabIndex = 5;
            this.lblUpperLimit.Text = "UpperLimit";
            // 
            // lblLowerLimit
            // 
            this.lblLowerLimit.AutoSize = true;
            this.lblLowerLimit.Location = new System.Drawing.Point(343, 10);
            this.lblLowerLimit.Name = "lblLowerLimit";
            this.lblLowerLimit.Size = new System.Drawing.Size(81, 16);
            this.lblLowerLimit.TabIndex = 4;
            this.lblLowerLimit.Text = "LowerLimit";
            // 
            // lblTarget
            // 
            this.lblTarget.AutoSize = true;
            this.lblTarget.Location = new System.Drawing.Point(170, 10);
            this.lblTarget.Name = "lblTarget";
            this.lblTarget.Size = new System.Drawing.Size(54, 16);
            this.lblTarget.TabIndex = 3;
            this.lblTarget.Text = "Target";
            // 
            // frmRawMetrology
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 464);
            this.Controls.Add(this.panel1);
            this.MaximizeBox = false;
            this.Name = "frmRawMetrology";
            this.Padding = new System.Windows.Forms.Padding(3, 40, 3, 3);
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "RawMetrology";
            this.Activated += new System.EventHandler(this.frmRawMetrology_Activated);
            this.Load += new System.EventHandler(this.frmRawMetrology_Load);
            this.panel1.ResumeLayout(false);
            this.grpRawMetrology.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRawMetrology)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dgvRawMetrology;
        private System.Windows.Forms.GroupBox grpRawMetrology;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lblUpperLimit;
        private System.Windows.Forms.Label lblLowerLimit;
        private System.Windows.Forms.Label lblTarget;
        
    }
}