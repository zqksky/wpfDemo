﻿
using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using MaterialSkin;
using MaterialSkin.Controls;

namespace R2R_UI.Present.Common
{
    public partial class frmRawMetrology : MaterialForm
    {
        //private readonly MaterialSkinManager meterialSkinManager;

        public frmRawMetrology()
        {
            InitializeComponent();
        }

        public frmRawMetrology(UIServiceFun.structCOMMON_GetRawMetrology structRawMetrology, string lotId, string strCurrentType)
        {
            InitializeComponent();

            structData = structRawMetrology;
            strLotId = lotId;

            dTarget = structRawMetrology.dTarget;
            dUpperLimit = structRawMetrology.dUpperLimit;
            dLowerLimit = structRawMetrology.dLowerLimit;

            strListWaferIds = new List<string>(structRawMetrology.strListWaferIds);
            strListMeasDataItemNames = new List<string>(structRawMetrology.strListMeasDataItemNames);
            strListMeasSiteCSV = new List<string>(structRawMetrology.strListMeasSiteCSV);
            strListMeasValidityCSV = new List<string>(structRawMetrology.strListMeasValidityCSV);
            strListMeasValueCSV = new List<string>(structRawMetrology.strListMeasValueCSV);

            strServiceType = strCurrentType;

            #region SetSkin
            SkinHelp.SkinSet(this, strServiceType);
            #endregion
        }

        string strServiceType;
        string strLotId;
        double dUpperLimit;
        double dLowerLimit;
        double dTarget;
        List<string> strListWaferIds;
        List<string> strListMeasDataItemNames;
        List<string> strListMeasSiteCSV;
        List<string> strListMeasValidityCSV;
        List<string> strListMeasValueCSV;

        UIServiceFun.structCOMMON_GetRawMetrology structData = new UIServiceFun.structCOMMON_GetRawMetrology();

        private void frmRawMetrology_Load(object sender, EventArgs e)
        {
            ShowFrm();
        }

        private void ShowFrm()
        {
            grpRawMetrology.Text = strLotId;
            lblTarget.Text = "Target : " + dTarget.ToString();
            lblLowerLimit.Text = "LowerLimit : " + dLowerLimit.ToString();
            lblUpperLimit.Text = "Upperlimit : " + dUpperLimit.ToString();

            DataTable dbRawMetrology = new DataTable("RawMetrology");
            dbRawMetrology = DataTableHelp.CreateRawMetrologyTable(structData);
            DataGridViewHelp.InitDgvGrid(dgvRawMetrology, dbRawMetrology);

        }

        private void frmRawMetrology_Activated(object sender, EventArgs e)
        {
            dgvRawMetrology.Focus();
        }
    }
}
