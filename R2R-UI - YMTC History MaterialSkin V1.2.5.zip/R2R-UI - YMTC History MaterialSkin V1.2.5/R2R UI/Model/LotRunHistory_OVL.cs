﻿using R2R_UI.Common;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;
using static R2R_UI.Common.UIServiceFun;

namespace R2R_UI.Model
{
    class LotRunHistory_OVL
    {

        private string strServiceAddress;
        private string strController;
        private List<string> strListR2RContexts = new List<string>();
        structPH_OVL_GetLotRunHistory structData = new structPH_OVL_GetLotRunHistory();
        public string strCurrentR2RMode;
        public string strCurrentOVLModel;
        public string strToolVendor;
        public bool bIsActive;
        public bool bToolVendorASML;
        public bool bLinearMode;
        public bool bHOPCMode;
        public bool bIHOPCMode;
        public bool bCPEMode;
        public bool bNotData;
        public bool bPilotFlag;

        private void Test()
        {
            #region
            //structData.strHOPC_PMTimeStamp = "NA";
            //structData.strHOPC_ResetTimeStamp = "NA";
            //structData.strListHOPC_UsedTimeStamps = new List<string> { "" };
            //structData.strListHOPC_IsValidRecords = new List<string> { ""};
            //structData.strListHOPC_ItemValues_UsedSettings = new List<string> { "" };
            //structData.strListHOPC_ItemNames_PostMetrology = new List<string> { "Tx20","Tx02","Tx11","Tx21","Tx12","Tx30","Tx03","Ty20","Ty02","Ty11","Ty21","Ty12","Ty30","Ty03" };
            //structData.strListHOPC_ItemValues_PostMetrology = new List<string> { "" };
            //structData.strListHOPC_LotIds = new List<string> { "" };
            //structData.iHOPC_OutputSize = 28;

            //structData.strIHOPC_PMTimeStamp = "NA";
            //structData.strIHOPC_ResetTimeStamp = "NA";
            //structData.strListIHOPC_UsedTimeStamps = new List<string> { "" };
            //structData.strListIHOPC_IsValidRecords = new List<string> { "" };
            //structData.strListIHOPC_ItemValues_UsedSettings = new List<string> { "" };

            //structData.strListIHOPC_ItemNames_PostMetrology = new List<string> { "K7","K8","K9","K10","K11","K12","K13","K14","K15","K16","K17","K18","K19","K20" };
            //structData.strListIHOPC_ItemValues_PostMetrology = new List<string> { "" };
            //structData.strListIHOPC_LotIds = new List<string> { "" };
            //structData.iIHOPC_OutputSize = 28;

            //structData.strLinear_PMTimeStamp = "NA";
            //structData.strLinear_ResetTimeStamp = "NA";
            //structData.strListLinear_IsValidRecords = new List<string> { "True" };
            //structData.strListLinear_ItemValues_UsedSettings = new List<string> { "[ 13 14 15 110 18 19 11 12 16 17 113 114 115 120 118 119 111 112 116 17 ]" };
            //structData.strListLinear_ItemNames_PostMetrology = new List<string>{ "EXP_X","EXP_Y","NON_ORT","WFR_ROT","TRANS_X","TRANS_Y","ASYM_MAG","ASYM_ROT","SHT_MAG","SHT_ROT" };
            //structData.strListLinear_ItemValues_PostMetrology = new List<string> { "[ 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 0.0034 ]" };
            //structData.strListLinear_LotIds = new List<string> { "TESTLOT01.01" };
            //structData.iLinear_OutputSize = 20;
            //structData.strListLinear_UsedTimeStamps = new List<string> { "2018-12-06 15:13:28.042" };
            //structData.strToolVendor = "ASML";
            //structData.strCurrentOVLModel = "LINEAR+CPE";
            //structData.strCurrentR2RMode = "Active";

            //structData.bCPEMode = false;
            //structData.bHOPCMode = false;
            //structData.bIHOPCMode = false;
            //structData.bLinearMode = true;
            //structData.bForcePilot = true;
            #endregion

            #region
            structData.strHOPC_PMTimeStamp = "NA";
            structData.strHOPC_ResetTimeStamp = "NA";
            structData.strListHOPC_UsedTimeStamps = new List<string> { "" };
            structData.strListHOPC_IsValidRecords = new List<string> { "" };
            structData.strListHOPC_ItemValues_UsedSettings = new List<string> { "" };
            structData.strListHOPC_ItemNames_PostMetrology = new List<string> { "" };
            structData.strListHOPC_ItemValues_PostMetrology = new List<string> { "" };
            structData.strListHOPC_LotIds = new List<string> { "" };
            structData.iHOPC_OutputSize = 0;

            structData.strIHOPC_PMTimeStamp = "NA";
            structData.strIHOPC_ResetTimeStamp = "NA";
            structData.strListIHOPC_UsedTimeStamps = new List<string> { "" };
            structData.strListIHOPC_IsValidRecords = new List<string> { "" };
            structData.strListIHOPC_ItemValues_UsedSettings = new List<string> { "" };

            structData.strListIHOPC_ItemNames_PostMetrology = new List<string> { "" };
            structData.strListIHOPC_ItemValues_PostMetrology = new List<string> { "" };
            structData.strListIHOPC_LotIds = new List<string> { "" };
            structData.iIHOPC_OutputSize = 0;

            structData.strLinear_PMTimeStamp = "NA";
            structData.strLinear_ResetTimeStamp = "NA";
            structData.strListLinear_IsValidRecords = new List<string> { "False" };
            structData.strListLinear_ItemValues_UsedSettings = new List<string> { "" };
            structData.strListLinear_ItemNames_PostMetrology = new List<string> { "TRANS_X",
"TRANS_Y",
"WFR_ROT_X",
"WFR_ROT_Y",
"WFR_MAG_X",
"WFR_MAG_Y",
"SHT_ROT_X",
"SHT_ROT_Y",
"SHT_MAG_X",
"SHT_MAG_Y" };
            structData.strListLinear_ItemValues_PostMetrology = new List<string> { "" };
            structData.strListLinear_LotIds = new List<string> { "TESTLOT03.01" };
            structData.iLinear_OutputSize = 10;
            structData.strListLinear_UsedTimeStamps = new List<string> { "2018-11-30 13:47:23.118" };
            structData.strToolVendor = "CANON";
            structData.strCurrentOVLModel = "CANON";
            structData.strCurrentR2RMode = "Active";

            structData.bCPEMode = false;
            structData.bHOPCMode = false;
            structData.bIHOPCMode = false;
            structData.bLinearMode = true;
            structData.bForcePilot = false;
            #endregion
        }

        public LotRunHistory_OVL(string strServiceAddress, string strController, List<string> strListR2RContexts,int iListOfRuns)
        {
            this.strServiceAddress = strServiceAddress;
            this.strController = strController;
            this.strListR2RContexts = new List<string>(strListR2RContexts);

            structPH_OVL_GetLotRunHistory structDataNull = new structPH_OVL_GetLotRunHistory();
            structData = R2R_UI_PH_OVL_GetLotRunHistory(strServiceAddress, strController, strListR2RContexts, iListOfRuns);
            if (structData.Equals(structDataNull))
            {
                bNotData = true;
            }
            else
            {
                //Test();

                this.strCurrentR2RMode = structData.strCurrentR2RMode;
                this.strCurrentOVLModel = structData.strCurrentOVLModel;
                this.strToolVendor = structData.strToolVendor;

                this.bIsActive = IsActive(this.strCurrentR2RMode);
                this.bLinearMode = structData.bLinearMode;
                this.bHOPCMode = structData.bHOPCMode;
                this.bIHOPCMode = structData.bIHOPCMode;
                this.bCPEMode = structData.bCPEMode;

                this.bPilotFlag = structData.bForcePilot;
            }
        }
        private bool IsActive(string strR2RMode)
        {
            bool flag = false;
            if (strR2RMode.Equals("Active"))
            {
                flag = true;
            }
            else
            {
                //btnOptReset.Enabled = false;
            }
            return flag;
        }

        private void GetChartParam(ref int iOutputCount, ref int iOutputStartIndex, int iOutputSize, bool bIsChuckOne)
        {
            if (strToolVendor.Equals("ASML"))
            {
                bToolVendorASML = true;
                iOutputCount = iOutputSize / 2;

                iOutputStartIndex = bIsChuckOne ? 0 : iOutputSize / 2;
            }
            else
            {
                bToolVendorASML = false;
                iOutputCount = iOutputSize;
                iOutputStartIndex = 0;
            }
        }

        public DataTable GetTable(int ovlType, bool bIsChuckOne)
        {
            DataTable db = new DataTable();

            int iOutputSize = 0;
            int iOutputCount = 0;
            int iOutputStartIndex = 0;
            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();
            List<string> strListItemNames = new List<string>();
            List<string> strListPostMetrology = new List<string>();
            List<string> strListUsedSettings = new List<string>();

            try
            {
                if (ovlType == 1)
                {
                    iOutputSize = structData.iLinear_OutputSize;
                    strListLotIds = new List<string>(structData.strListLinear_LotIds);
                    strListUsedTimeStamps = new List<string>(structData.strListLinear_UsedTimeStamps);
                    strListItemNames = new List<string>(structData.strListLinear_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListLinear_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListLinear_ItemValues_UsedSettings);
                }
                else if (ovlType == 2)
                {
                    iOutputSize = structData.iHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListHOPC_LotIds);
                    strListUsedTimeStamps = new List<string>(structData.strListHOPC_UsedTimeStamps);
                    strListItemNames = new List<string>(structData.strListHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListHOPC_ItemValues_UsedSettings);
                }
                else if (ovlType == 3)
                {
                    iOutputSize = structData.iIHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListIHOPC_LotIds);
                    strListUsedTimeStamps = new List<string>(structData.strListIHOPC_UsedTimeStamps);
                    strListItemNames = new List<string>(structData.strListIHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListIHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListIHOPC_ItemValues_UsedSettings);
                }

                GetChartParam(ref iOutputCount, ref iOutputStartIndex, iOutputSize, bIsChuckOne);

                db = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps, strListItemNames, strListPostMetrology, strListUsedSettings, iOutputStartIndex, iOutputCount);
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return db;
        }

        public List<Chart> GetChart(int chartType, int ovlType, int valueType, bool bIsChuckOne)
        {
            int iOutputSize = 0;
            int iOutputCount = 0;
            int iOutputStartIndex = 0;
            List<Chart> ctlListChart = new List<Chart>();
            List<List<double>> dGroupListItemValues = new List<List<double>>();
            List<string> strListItemNames = new List<string>();
            List<string> strListPostMetrology = new List<string>();
            List<string> strListUsedSettings = new List<string>();
            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();
            string strPMTimeStamp = "NA";
            string strResetTimeStamps = "NA";

            try
            {
                if (ovlType == 1)
                {
                    iOutputSize = structData.iLinear_OutputSize;
                    strListLotIds = new List<string>(structData.strListLinear_LotIds);
                    strListItemNames = new List<string>(structData.strListLinear_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListLinear_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListLinear_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListLinear_UsedTimeStamps);
                    strPMTimeStamp = structData.strLinear_PMTimeStamp;
                    strResetTimeStamps = structData.strLinear_ResetTimeStamp;
                }
                else if (ovlType == 2)
                {
                    iOutputSize = structData.iHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListHOPC_LotIds);
                    strListItemNames = new List<string>(structData.strListHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListHOPC_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListHOPC_UsedTimeStamps);
                    strPMTimeStamp = structData.strHOPC_PMTimeStamp;
                    strResetTimeStamps = structData.strHOPC_ResetTimeStamp;
                }
                else if (ovlType == 3)
                {
                    iOutputSize = structData.iIHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListIHOPC_LotIds);
                    strListItemNames = new List<string>(structData.strListIHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListIHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListIHOPC_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListIHOPC_UsedTimeStamps);
                    strPMTimeStamp = structData.strIHOPC_PMTimeStamp;
                    strResetTimeStamps = structData.strIHOPC_ResetTimeStamp;
                }

                GetChartParam(ref iOutputCount, ref iOutputStartIndex, iOutputSize, bIsChuckOne);

                dGroupListItemValues.Clear();

                List<List<string>> strGroupListLotIds = new List<List<string>>();
                if (strListUsedTimeStamps.Count > 0 && strListPostMetrology.Count > 0 && strListUsedSettings.Count > 0 && strListLotIds.Count > 0)
                {
                    if (valueType == 1)
                    {
                        dGroupListItemValues = BaseFun.GetOVLItemValues(strListUsedTimeStamps, strListPostMetrology, iOutputStartIndex, iOutputCount, ref strGroupListLotIds, strListLotIds);
                    }
                    else if (valueType == 2)
                    {
                        dGroupListItemValues = BaseFun.GetOVLItemValues(strListUsedTimeStamps, strListUsedSettings, iOutputStartIndex, iOutputCount, ref strGroupListLotIds, strListLotIds);
                    }
                }

                if (dGroupListItemValues.Count > 0)
                {
                    int pmNum = BaseFun.GetPMResetTimeValue(strPMTimeStamp, strListUsedTimeStamps);
                    int resetNum = BaseFun.GetPMResetTimeValue(strResetTimeStamps, strListUsedTimeStamps);
                    ctlListChart = AddControlHelp.GetOVLChart(chartType, valueType, strListItemNames, dGroupListItemValues, strGroupListLotIds, pmNum, resetNum);

                    //AddControlHelp.AddOVLChartToList(ref ctlListChart, chartType, valueType, strListItemNames, dGroupListItemValues, strGroupListLotIds, pmNum, resetNum);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }
            return ctlListChart;
        }

        #region New
        public struct structGroup
        {
            public int ovlType;
            public bool bMode;
            public string strType;
            public DataTable db;
            public List<Chart> ctlListInputChart;
            public List<Chart> ctlListOutputChart;
        };

        public structGroup GetGroup(string strTypeName, int chartType, int valueType, bool bIsChuckOne)
        {
            structGroup structGroupData = new structGroup();

            int iOutputSize = 0;
            int iOutputCount = 0;
            int iOutputStartIndex = 0;

            List<List<double>> dGroupInputItemValues = new List<List<double>>();
            List<List<double>> dGroupOutputItemValues = new List<List<double>>();
            List<string> strListItemNames = new List<string>();
            List<string> strListPostMetrology = new List<string>();
            List<string> strListUsedSettings = new List<string>();
            List<string> strListLotIds = new List<string>();
            List<string> strListUsedTimeStamps = new List<string>();
            string strPMTimeStamp = "NA";
            string strResetTimeStamps = "NA";

            try
            {
                if (strTypeName.Equals("tabPageLinear"))
                {
                    structGroupData.ovlType = 1;
                    structGroupData.bMode = bLinearMode;
                    structGroupData.strType = "PH_OVL_Linear";
                    iOutputSize = structData.iLinear_OutputSize;
                    strListLotIds = new List<string>(structData.strListLinear_LotIds);
                    strListItemNames = new List<string>(structData.strListLinear_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListLinear_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListLinear_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListLinear_UsedTimeStamps);
                    strPMTimeStamp = structData.strLinear_PMTimeStamp;
                    strResetTimeStamps = structData.strLinear_ResetTimeStamp;
                }
                else if (strTypeName.Equals("tabPageHOPC"))
                {
                    structGroupData.ovlType = 2;
                    structGroupData.bMode = bHOPCMode;
                    structGroupData.strType = "PH_OVL_HOPC";
                    iOutputSize = structData.iHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListHOPC_LotIds);
                    strListItemNames = new List<string>(structData.strListHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListHOPC_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListHOPC_UsedTimeStamps);
                    strPMTimeStamp = structData.strHOPC_PMTimeStamp;
                    strResetTimeStamps = structData.strHOPC_ResetTimeStamp;
                }
                else if (strTypeName.Equals("tabPageIHOPC"))
                {
                    structGroupData.ovlType = 3;
                    structGroupData.bMode = bIHOPCMode;
                    structGroupData.strType = "PH_OVL_IHOPC";
                    iOutputSize = structData.iIHOPC_OutputSize;
                    strListLotIds = new List<string>(structData.strListIHOPC_LotIds);
                    strListItemNames = new List<string>(structData.strListIHOPC_ItemNames_PostMetrology);
                    strListPostMetrology = new List<string>(structData.strListIHOPC_ItemValues_PostMetrology);
                    strListUsedSettings = new List<string>(structData.strListIHOPC_ItemValues_UsedSettings);
                    strListUsedTimeStamps = new List<string>(structData.strListIHOPC_UsedTimeStamps);
                    strPMTimeStamp = structData.strIHOPC_PMTimeStamp;
                    strResetTimeStamps = structData.strIHOPC_ResetTimeStamp;
                }

                GetChartParam(ref iOutputCount, ref iOutputStartIndex, iOutputSize, bIsChuckOne);

                structGroupData.db = new DataTable();
                structGroupData.db = DataTableHelp.CreateOVLTable(strListLotIds, strListUsedTimeStamps, strListItemNames, strListPostMetrology, strListUsedSettings, iOutputStartIndex, iOutputCount);

                dGroupInputItemValues.Clear();
                dGroupOutputItemValues.Clear();

                List<List<string>> strGroupInputLotIds = new List<List<string>>();
                List<List<string>> strGroupOutputputLotIds = new List<List<string>>();
                if (strListUsedTimeStamps.Count > 0 && strListPostMetrology.Count > 0  && strListLotIds.Count > 0)
                {
                    dGroupInputItemValues = BaseFun.GetOVLItemValues(strListUsedTimeStamps, strListPostMetrology, iOutputStartIndex, iOutputCount, ref strGroupInputLotIds, strListLotIds);
                }

                if (strListUsedTimeStamps.Count > 0  && strListUsedSettings.Count > 0 && strListLotIds.Count > 0)
                {
                    dGroupOutputItemValues = BaseFun.GetOVLItemValues(strListUsedTimeStamps, strListUsedSettings, iOutputStartIndex, iOutputCount, ref strGroupOutputputLotIds, strListLotIds);
                }

                structGroupData.ctlListInputChart = new List<Chart>();
                structGroupData.ctlListOutputChart = new List<Chart>();

                if (dGroupInputItemValues.Count > 0)
                {
                    int pmNum = BaseFun.GetPMResetTimeValue(strPMTimeStamp, strListUsedTimeStamps);
                    int resetNum = BaseFun.GetPMResetTimeValue(strResetTimeStamps, strListUsedTimeStamps);
                    structGroupData.ctlListInputChart = AddControlHelp.GetOVLChart(chartType, 1, strListItemNames, dGroupInputItemValues, strGroupInputLotIds, pmNum, resetNum);
                }

                if (dGroupOutputItemValues.Count > 0)
                {
                    int pmNum = BaseFun.GetPMResetTimeValue(strPMTimeStamp, strListUsedTimeStamps);
                    int resetNum = BaseFun.GetPMResetTimeValue(strResetTimeStamps, strListUsedTimeStamps);
                    structGroupData.ctlListOutputChart = AddControlHelp.GetOVLChart(chartType, 2, strListItemNames, dGroupOutputItemValues, strGroupOutputputLotIds, pmNum, resetNum);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
            }

            return structGroupData;
        }
        #endregion
    }
}
