﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R_UI.Common
{
    class DataGridViewHelp
    {
        #region fun
        public static void InitDgvGrid(DataGridView ctlDgv, DataTable tb)
        {
            ctlDgv.DataSource = tb;

            //禁止编辑
            ctlDgv.ReadOnly = true;
            for (int i = 0; i < ctlDgv.ColumnCount; i++)
            {
                ctlDgv.Columns[i].ReadOnly = true;
                //ctlDgv.Columns[i].DefaultCellStyle.BackColor = Color.LightGray;
            }
        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb, int colCount)
        {
            ctlDgv.DataSource = tb;

            //ctlDgv.ReadOnly = true;            //禁止编辑
            ctlDgv.ReadOnly = false;
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
            for (int i = 0; i < colCount; i++)
            {
                ctlDgv.Columns[i].ReadOnly = true;
                ctlDgv.Columns[i].DefaultCellStyle.BackColor = Color.LightGray;
            }
        }

        public static void InitDgvSet(DataGridView ctlDgv, DataTable tb, List<int> colListCount)
        {
            BindingSource bs = new BindingSource();
            bs.DataSource = tb;
            ctlDgv.DataSource = bs;
            ctlDgv.EndEdit();
            bs.EndEdit();

            //禁止编辑
            //ctlDgv.ReadOnly = true;
            ctlDgv.ReadOnly = false;
            for (int i = 0; i < colListCount.Count; i++)
            {
                ctlDgv.Columns[colListCount[i]].ReadOnly = true;
                ctlDgv.Columns[colListCount[i]].DefaultCellStyle.BackColor = Color.LightGray;
            }
            ctlDgv.EditMode = DataGridViewEditMode.EditOnEnter;
        }

        public static void SetDgvCmb(DataGridView dgv, int colIndex, List<string> strList, string strColName)
        {
            if (dgv.Columns.Contains(strColName))
            {
                dgv.Columns.Remove(strColName);
            }
            if (dgv.Columns.Contains(strColName))
            {
                dgv.Columns.Remove("New OVLModel");
            }

            DataGridViewColumn myCol = new DataGridViewComboBoxColumn();
            myCol.Name = strColName;
            myCol.HeaderText = strColName;

            dgv.AllowUserToAddRows = false;
            dgv.AutoGenerateColumns = false;

            dgv.Columns.Insert(colIndex, myCol);

            ((DataGridViewComboBoxColumn)dgv.Columns[colIndex]).DataSource = strList;
        }

        public static List<string> GetDgvRowValue(DataGridView dgv, int rowIndex)
        {
            List<string> strList = new List<string>();
            if (rowIndex >= 0)
            {
                for (int i = 0; i < dgv.Columns.Count; i++)
                {
                    strList.Add(dgv.Rows[rowIndex].Cells[i].Value.ToString());
                }
            }
            return strList;
        }

        public static void SetDgvRowColor(DataGridView dgv, int index)
        {
            for (int i = 0; i < dgv.RowCount; i++)
            {
                if (i == index)
                {
                    dgv.Rows[i].DefaultCellStyle.BackColor = Color.Aqua;
                }
                else
                {
                    dgv.Rows[i].DefaultCellStyle.BackColor = Color.White;
                }
            }
        }

        /// <summary>
        /// DataGridView减少闪烁的解决办法 
        /// </summary>
        /// <param name="dgv"></param>
        /// <param name="bSet"></param>
        public static void DoubleBuffered(DataGridView dgv, bool bSet)
        {
            Type dgvType = dgv.GetType();
            PropertyInfo pi = dgvType.GetProperty("DoubleBuffered", BindingFlags.Instance | BindingFlags.NonPublic);
            pi.SetValue(dgv, bSet, null);
        }

        /// <summary>
        /// 自动排序功能禁用
        /// </summary>
        /// <param name="dgv"></param>
        public static void dgvSortModeSet(DataGridView dgv)
        {
            for (int i = 0; i < dgv.Columns.Count; i++)
            {
                dgv.Columns[i].SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }
        #endregion
    }
}
