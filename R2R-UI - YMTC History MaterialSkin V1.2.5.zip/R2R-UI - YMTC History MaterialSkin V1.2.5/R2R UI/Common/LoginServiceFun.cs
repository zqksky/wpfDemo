﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R_UI.Common
{
    class LoginServiceFun
    {
        public const int view = 8;
        public const int save = 32;
        public const int delete = 64;

        /// <summary>
        /// connect Login WebService by zqk 20180724 modify
        /// </summary>
        /// <param name="strServiceAddress"></param>
        /// <param name="strUserId"></param>
        /// <param name="strPwd"></param>
        /// <param name="strDomain"></param>
        /// <param name="bAutoLogin"></param>
        /// <param name="operationType"></param>
        /// <returns></returns>
        public static bool LoginManage(string strServiceAddress, string strUserId, string strPwd, string strDomain, bool bAutoLogin, ref int operationType)
        {
            bool bSuccess = false;
            operationType = 0;
            try
            {
                //string url = @"http://" + "localhost" + @":58251/Adapter/R2R_UILoginService.asmx";
                //string url = @"http://" + "192.168.150.135" + @":58251/Adapter/R2R_UILoginService.asmx";
                string url = @"http://" + strServiceAddress + @":58251/Adapter/R2R_UILoginService.asmx";
                LoginService.R2R_UILoginService cfg = new LoginService.R2R_UILoginService();
                cfg.Url = url;
                LoginService.LoginRequest rq = new LoginService.LoginRequest();
                rq.UserName = strUserId;
                rq.Password = strPwd;
                rq.DomainName = strDomain;
                rq.AppType = "R2R_ModelConfig";
                rq.AutoLogin = bAutoLogin;
                LoginService.LoginReply rly = cfg.Login(rq);
                if (rly.Success)
                {
                    bSuccess = true;
                    operationType = rly.UserOperations;
                }
                else
                {
                    System.Windows.Forms.MessageBox.Show("Invalid login information!");
                    //System.Windows.Forms.MessageBox.Show(rly.Message);
                    //System.Environment.Exit(0);
                }
            }
            catch (Exception err)
            {
                System.Windows.Forms.MessageBox.Show(BaseFun.GetExceptionInformation(err));
                //System.Environment.Exit(0);
            }

            return bSuccess;
        }
    }
}
