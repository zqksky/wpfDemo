﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms.DataVisualization.Charting;

namespace R2R_UI.Common
{
    class ChartHelp
    {
        #region Create Chart
        public static Chart CreateColumnChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series,2);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }

        public static Chart CreateLineChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn)
        {
            Chart chart = new Chart();
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();           
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);
            //chartArea.Area3DStyle.Enable3D = true;

            chart.Series.Clear();
            Series series = new Series("series");
            SetSeries(series);
            series.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(series);

            return chart;
        }

        public static Chart CreateLineChart(string strChartTitle, List<double> dListValue, List<string> strListChartColumn, int pmNum,int resetNum)
        {
            Chart chart = new Chart();
            //chart.Width = 500;
            //chart.Height = 300;
            chart.Titles.Add(strChartTitle);

            ChartArea chartArea = new ChartArea();
            chart.ChartAreas.Add(chartArea);
            SetChartAreaAxisX(chartArea);
            SetChartAreaAxisY(chartArea);

            //double dMax = 0.0;
            //double dMin = 0.0;
            //GetMaxAndMin(dListValue, ref dMax,ref dMin);
            //SetChartAreaAxisY(chartArea,dMax,dMin);
            //chartArea.Area3DStyle.Enable3D = true;

            chart.Series.Clear();
            Series seriesValue = new Series("Value");
            SetSeries(seriesValue);
            seriesValue.Points.DataBindXY(strListChartColumn, dListValue);
            //series.LegendToolTip = "value";//鼠标放到系列上出现的文字 
            chart.Series.Add(seriesValue);

            if (pmNum > 0)
            {
                //AddNewLine(chart, "PMTimeStamp", pmNum, 1);
                AddNewLine(chart, "PMTimeStamp", dListValue.Count, pmNum+0.5, 1);
            }
            else if (pmNum == 0)
            {
                AddNewLine(chart, "PMTimeStamp", dListValue.Count, 0.5, 1);
            }
            if (resetNum > 0)
            {
                //AddNewLine(chart, "ResetTimeStamp", resetNum, 2);
                AddNewLine(chart, "ResetTimeStamp", dListValue.Count, resetNum+0.5, 2);
            }
            else if (resetNum == 0)
            {
                AddNewLine(chart, "ResetTimeStamp", dListValue.Count, 0.5, 2);
            }

            SetLegend(chart, chartArea);
            return chart;
        }
        private static void GetMaxAndMin(List<double> dListValue,ref double dMax, ref double dMin)
        {
            double dCount = 0.0;
            double dtmp = 0.0;
            List<double> dListTmp = new List<double>();
            //List<double> dList = new List<double>() { 3, 8, 10, double.NaN };
            foreach (var d in dListValue)
            {
                if (d.Equals(double.NaN))
                { }
                else
                {
                    dListTmp.Add(d);
                }
            }
            dCount = dListValue.Count;
            dMax = dListTmp.Max();
            dMin = dListTmp.Min();

        }

        private static void AddNewLine(Chart chart, string strLineName,int dotAll, double dotNum, int timeType)
        {
            StripLine stripline = new StripLine();
            stripline.Interval = 0;
            stripline.IntervalOffset = dotNum;
            stripline.StripWidth = 0.01* dotAll;
            if (timeType == 1)
            {
                stripline.BackColor = Color.Red;
            }
            else if (timeType == 2)
            {
                stripline.BackColor = Color.Purple;
            }
            //stripline.Text = strLineName;
            stripline.Tag = strLineName;
            stripline.TextOrientation = TextOrientation.Auto;
            stripline.TextAlignment = StringAlignment.Near;
            stripline.ToolTip = strLineName;

            stripline.BorderDashStyle = ChartDashStyle.Dash;
            chart.ChartAreas[0].AxisX.StripLines.Add(stripline);
        }

        private static void SetLegend(Chart chart, ChartArea chartArea)
        {
            Legend legend = new Legend("legend");//初始化一个图例的实例
            legend.Position = new ElementPosition(0, 95, 100, 5);
            legend.CustomItems.Add(Color.Red, "PMTimeStamp");
            legend.CustomItems.Add(Color.Purple, "ResetTimeStamp"); // 参数：(颜色, 说明)
            foreach (LegendItem item in legend.CustomItems)
            {
                item.ImageStyle = LegendImageStyle.Line; // 设置显示样式，色块、线条等
                item.BorderWidth = 5;
            }

            legend.Alignment = StringAlignment.Far;//设置图表的对齐方式(中间对齐，靠近原点对齐，远离原点对齐)
            //legend.BackColor = Color.Black;//设置图例的背景颜色
            legend.DockedToChartArea = chartArea.Name;//设置图例要停靠在哪个区域上
            legend.Docking = Docking.Bottom;//设置停靠在图表区域的位置(底部、顶部、左侧、右侧)
            legend.Font = new Font("Trebuchet MS", 15F, FontStyle.Regular);//设置图例的字体属性
            legend.IsTextAutoFit = true;//设置图例文本是否可以自动调节大小
            legend.LegendStyle = LegendStyle.Row;//设置显示图例项方式(多列一行、一列多行、多列多行)
            //legend.Name = "l1";//设置图例的名称
            chart.Legends.Add(legend);
        }
        #endregion

        #region Set Chart
        private static void SetChartAreaAxisX(ChartArea chartArea)
        {
            //chartArea.AxisX.Title = strTitle;
            chartArea.AxisX.MajorGrid.Interval = 1;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.IsMarginVisible = true;
            chartArea.AxisX.TitleForeColor = Color.Crimson;
            //chartArea.AxisX.TextOrientation = TextOrientation.Rotated90;
            //chartArea.AxisX.IsInterlaced = true;  //显示交错带 
            //chartArea.AxisX.LabelStyle.Format = "#";                      //设置X轴显示样式

            //显示所有的标签
            //chartArea.AxisX.LabelAutoFitStyle = LabelAutoFitStyles.None;
            //chartArea.AxisX.LabelStyle.Interval = 1;

            //显示所有的标签
            chartArea.AxisX.Interval = 1;

            //显示所有的标签
            //chartArea.AxisX.IntervalAutoMode = IntervalAutoMode.VariableCount;
            //chartArea.AxisX.IsStartedFromZero = true;
            //chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式

            chartArea.AxisX.LabelStyle.Angle = -90;                      //设置X轴显示样式
        }
        private static void SetChartAreaAxisY(ChartArea chartArea)
        {
            //chartArea.AxisY.Title = strTitle;
            //chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.TitleForeColor = Color.Crimson;
            chartArea.AxisY.TextOrientation = TextOrientation.Horizontal;
            chartArea.AxisY.IsStartedFromZero = false;
            chartArea.AxisY.IntervalAutoMode = IntervalAutoMode.FixedCount;
        }

        private static void SetChartAreaAxisY(ChartArea chartArea,double dMax,double dMin)
        {
            //chartArea.AxisY.Title = strTitle;
            //chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.TitleForeColor = Color.Crimson;
            chartArea.AxisY.TextOrientation = TextOrientation.Horizontal;

            chartArea.AxisY.IsStartedFromZero = false;
            //chartArea.AxisY.Interval = dMax * 0.1;
            chartArea.AxisY.IntervalAutoMode = IntervalAutoMode.FixedCount;
            //chartArea.AxisY.Maximum = dMax+ dMax*0.1;
            //chartArea.AxisY.Minimum = dMin- dMin*0.1;
        }

        private static void SetSeries(Series series)
        {
            series.ChartType = SeriesChartType.Line;
            //series.ChartType = SeriesChartType.Column;
            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);

            ////饼图说明设置，这用来设置饼图每一块的信息显示在什么地方
            //series["PieLabelStyle"] = "Outside";//将文字移到外侧
            //series["PieLineColor"] = "Black";//绘制黑色的连线。

            ////柱状图其他设置
            //series["DrawingStyle"] = "Emboss";   //设置柱状平面形状
            //series["PointWidth"] = "0.5"; //设置柱状大小
        }
        private static void SetSeries(Series series,int chartType)
        {
            if (chartType == 1)
            {
                series.ChartType = SeriesChartType.Line;
            }
            else if(chartType == 2)
            {
                series.ChartType = SeriesChartType.Column;
            }

            series.BorderWidth = 3;            //线条粗细
            series.Color = Color.YellowGreen;            //线条颜色

            //series.IsValueShownAsLabel = true;
            //series.Label = "#VAL";                //设置显示X Y的值

            series.ToolTip = "#VAL";     //鼠标移动到对应点显示数值

            SetSeriesMarker(series);
        }
        private static void SetSeriesMarker(Series series)
        {
            series.MarkerBorderColor = Color.Black;            //标记点边框颜色     
            series.MarkerBorderWidth = 3;            //标记点边框大小
            series.MarkerColor = Color.Red;            //标记点中心颜色
            series.MarkerSize = 8;            //标记点大小
            series.MarkerStyle = MarkerStyle.Circle;            //标记点类型    
        }

        private void SetMajorGridX(ChartArea chartArea)
        {
            //设置主刻度线和副刻度线 一般只有主刻度线才有对应标签值。  
            chartArea.AxisX.MajorGrid.Interval = 0.5;
            chartArea.AxisX.MajorGrid.Enabled = true;
            chartArea.AxisX.MinorTickMark.Enabled = false;
            chartArea.AxisX.MajorGrid.Enabled = false;       //X轴上网格
            chartArea.AxisX.MajorGrid.Enabled = false;      //y轴上网格
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorTickMark.Enabled = false;                   //  x轴上突出的小点
            chartArea.AxisX.MajorGrid.LineDashStyle = ChartDashStyle.Dash;   //网格类型 短横线
            chartArea.AxisX.MajorGrid.LineColor = Color.Gray;
            chartArea.AxisX.MajorGrid.LineWidth = 3;
        }
        private void SetMajorGridY(ChartArea chartArea)
        {
            chartArea.AxisY.MajorGrid.Interval = 0.5;
            chartArea.AxisY.MajorGrid.Enabled = true;
            chartArea.AxisY.MinorTickMark.Enabled = false;
        }
        #endregion
    }
}
