﻿using SqlSugar;
using System;
using System.Linq;
using System.Text;

namespace Models
{
    [SugarTable("School")]
    public class SchoolModel
    {
        
     /// <summary>
     /// Desc:地域ID，关联area表 
     /// Default:- 
     /// Nullable:False 
     /// </summary>
        public int Id {get;set;}

     /// <summary>
     /// Desc:- 
     /// Default:- 
     /// Nullable:True 
     /// </summary>
        public string Name {get;set;}

     /// <summary>
     /// Desc:- 
     /// Default:- 
     /// Nullable:True 
     /// </summary>
        public int? AreaId {get;set;}

    }
}
