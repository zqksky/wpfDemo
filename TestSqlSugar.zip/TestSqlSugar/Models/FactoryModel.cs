﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSqlSugar.Models
{
    [SugarTable("Factory")]
    public class FactoryModel
    {
        //指定主键和自增列，当然数据库中也要设置主键和自增列才会有效
        [SugarColumn(IsPrimaryKey = true, IsIdentity = true,ColumnName = "FACTORY_NAME")]
        public string Name { get; set; }

        [SugarColumn(ColumnName = "FACTORY_DESC")]
        public string Desc { get; set; }

        [SugarColumn(ColumnName = "IS_ENABLED")]
        public string Enable { get; set; }

        [SugarColumn(ColumnName = "MODIFIED_DT")]
        public string Date { get; set; }

        [SugarColumn(ColumnName = "MODIFIED_BY")]
        public string User { get; set; }
        
    }
}
