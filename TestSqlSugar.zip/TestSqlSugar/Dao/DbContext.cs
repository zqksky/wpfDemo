﻿using Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestSqlSugar.Models;

namespace TestSqlSugar.Dao
{
    public class DbContext
    {
        public DbContext()
        {
            Db = new SqlSugarClient(new ConnectionConfig()
            {
                //"User Id=e3suite;Password=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=e3suite)))";
                ConnectionString = "Data Source=152.135.85.246/ora11g;User ID=amsadmin;Password=amsadmin",
                DbType = DbType.Oracle,
                InitKeyType = InitKeyType.Attribute,//从特性读取主键和自增列信息
                IsAutoCloseConnection = true,//开启自动释放模式和EF原理一样我就不多解释了

            });
            //调式代码 用来打印SQL 
            Db.Aop.OnLogExecuting = (sql, pars) =>
            {
                sql = sql + "\r\n" + Db.Utilities.SerializeObject(pars.ToDictionary(it => it.ParameterName, it => it.Value));
                //Console.WriteLine(sql + "\r\n" +
                //    Db.Utilities.SerializeObject(pars.ToDictionary(it => it.ParameterName, it => it.Value)));
                //Console.WriteLine();

                System.Windows.Forms.MessageBox.Show(sql);
            };
            
        }
        //注意：不能写成静态的，不能写成静态的
        public SqlSugarClient Db;//用来处理事务多表查询和复杂的操作
        public SimpleClient<FactoryModel> FactoryDb { get { return new SimpleClient<FactoryModel>(Db); } }//用来处理Student表的常用操作

        //public SimpleClient<StudentModel> StudentDb { get { return new SimpleClient<StudentModel>(Db); } }//用来处理Student表的常用操作

    }
}
