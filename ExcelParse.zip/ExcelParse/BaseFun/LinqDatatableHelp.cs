﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelParse.BaseFun
{
    class LinqDatatableHelp
    {
        public static void Test1()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("flightno");
            dt.Columns.Add("flightTime", typeof(DateTime));
            dt.Columns.Add("arrivalTime", typeof(DateTime));
            dt.Columns.Add("passenger");

            dt.Rows.Add("AU123", Convert.ToDateTime("2010-12-20 12:30"), Convert.ToDateTime("2010-12-20 15:30"), "小Q");
            dt.Rows.Add("AU123", Convert.ToDateTime("2010-12-20 12:30"), Convert.ToDateTime("2010-12-20 15:30"), "小T");
            dt.Rows.Add("AU123", Convert.ToDateTime("2010-10-21 12:00"), Convert.ToDateTime("2010-12-21 14:30"), "小N");
            dt.Rows.Add("AU124", Convert.ToDateTime("2010-10-22 12:00"), Convert.ToDateTime("2010-12-22 11:30"), "小F");


            var query = from t in dt.AsEnumerable()
                        group t by new { t1 = t.Field<DateTime>("flightTime"), t2 = t.Field<DateTime>("arrivalTime") } into m
                        select new
                        {
                            flightno = m.First().Field<string>("flightno"),
                            flightTime = m.Key.t1,
                            arrivalTime = m.Key.t2,
                            passenger = string.Join("/", m.Select(n => n.Field<string>("passenger")).ToArray()),
                            rowcount = m.Count()
                        };
            Console.WriteLine(query);

        }

        public void test()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[] { new DataColumn("name", typeof(string)),
                             new DataColumn("sex", typeof(string)),
                             new DataColumn("score", typeof(int)) });

            dt.Rows.Add(new object[] { "张三", "男", 1 });
            dt.Rows.Add(new object[] { "张三", "男", 4 });
            dt.Rows.Add(new object[] { "李四", "男", 100 });
            dt.Rows.Add(new object[] { "李四", "女", 90 });
            dt.Rows.Add(new object[] { "王五", "女", 77 });

            //----------------------------------------------------第3点可以这样子改----------------------------------------------------
            var query = from row in dt.AsEnumerable()
                        group row by row.Field<string>("name") into m
                        select new { name = m.Key, sex = m.FirstOrDefault().Field<string>("sex"), score = m.Sum(n => n.Field<int>("score")) };

            foreach (var item in query)
            {
                Console.WriteLine($"{item.name},{item.sex},{item.score}");
            }
        }
        public static void Test()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[] { new DataColumn("name", typeof(string)),
                             new DataColumn("sex", typeof(string)),
                             new DataColumn("score", typeof(int)) });

            dt.Rows.Add(new object[] { "张三", "男", 1 });
            dt.Rows.Add(new object[] { "张三", "男", 1 });
            dt.Rows.Add(new object[] { "张三", "男", 1 });
            dt.Rows.Add(new object[] { "张三", "男", 4 });
            dt.Rows.Add(new object[] { "李四", "男", 100 });
            dt.Rows.Add(new object[] { "李四", "女", 90 });
            dt.Rows.Add(new object[] { "王五", "女", 77 });
            dt.Rows.Add(new object[] { "王五", "女", 77 });
            dt.Rows.Add(new object[] { "王五", "女", 77 });

            DataTable dtSort = dt.Clone();
            var query = from t in dt.AsEnumerable()
                        group t by new { t1 = t.Field<string>("name"), t2 = t.Field<string>("sex"), t3 = t.Field<int>("score") } into m
                        select new
                        {
                            name = m.Key.t1,
                            sex = m.Key.t2,
                            score=m.Key.t3,
                            rowcount = m.Count()
                        };
            if (query.ToList().Count > 0)
            {
                query.ToList().ForEach(q =>
                {
                    DataRow dr = dtSort.NewRow();
                    dr["name"] = q.name;
                    dr["sex"] = q.sex;
                    dr["score"] = q.score;
                    dtSort.Rows.Add(dr);
                });
            }
        }
    }
}
