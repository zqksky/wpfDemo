﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.IO;
using System.Windows.Forms;
using System.Data;

namespace ExcelParse.BaseFun
{
    class ExcelHelp
    {
        #region
        /// <summary>
        /// COM组件方式解析Excel，返回DataTable
        /// </summary>
        /// <param name="fileName">Excel路径名</param>
        /// <returns></returns>
        public static System.Data.DataTable COMImpExcel(string fileName)
        {
            System.Data.DataTable dt = new System.Data.DataTable();
            try
            {
                Excel.Application app;
                Workbooks wbs;
                Worksheet ws;
                object oMissiong = System.Reflection.Missing.Value;
                app = new Excel.Application();  //lauch excel application
                wbs = app.Workbooks;
                wbs.Open(fileName, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong, oMissiong);
                ws = (Worksheet)app.Worksheets.get_Item(1);    //取得第一个工作薄
                int rows = ws.UsedRange.Rows.Count;
                int columns = ws.UsedRange.Columns.Count;
                dt.TableName = ws.Name;

                for (int i = 1; i <= rows; i++)
                {
                    System.Data.DataRow dr = dt.NewRow();
                    for (int j = 1; j <= columns; j++)
                    {
                        Range range = ws.Range[app.Cells[i, j], app.Cells[i, j]];
                        range.Select();
                        if (i == 1)                                  //读取列头
                        {
                            string colName = app.ActiveCell.Text.ToString();
                            if (dt.Columns.Contains(colName))                      //是否存在重复列名
                            {
                                dt.Columns.Add(colName + j);
                            }
                            else { dt.Columns.Add(colName); }
                        }
                        dr[j - 1] = app.ActiveCell.Text.ToString();
                    }
                    dt.Rows.Add(dr);
                }

                app.Quit(); app = null;
                System.Diagnostics.Process[] procs = System.Diagnostics.Process.GetProcessesByName("excel");
                foreach (System.Diagnostics.Process pro in procs)
                {
                    pro.Kill();    //没有更好的方法,只有杀掉进程
                }
                GC.Collect();
                dt.Rows.RemoveAt(0);       //上面那样写把列名也读进去了，在这里移除一下。也可以在上面把读列名单独出来
                return dt;
            }
            catch (Exception ex)
            {
                //throw new Exception(ex.Message);
                MessageBox.Show(ex.Message);
                return null;
            }
        }

        //根据excle的路径把第一个sheel中的内容放入datatable
        public static System.Data.DataTable ReadExcelToTable(string path)//excel存放的路径
        {
            //string strConn = string.Empty;
            //string version = Path.Substring(Path.Length - 1);
            //if (version.Equals("s"))
            //{
            //    strConn = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + Path + ";" + "Extended Properties=Excel 8.0;";
            //}
            //else
            //{
            //    strConn = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + Path + ";" + "Extended Properties=Excel 8.0;";
            //}
            //OleDbConnection conn = new OleDbConnection(strConn);
            //System.Data.DataSet ds = null;
            try
            {
                //连接字符串
                string connstring = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';"; // Office 07及以上版本 不能出现多余的空格 而且分号注意
                //string connstring = "Provider=Microsoft.JET.OLEDB.4.0;Data Source=" + path + ";Extended Properties='Excel 8.0;HDR=NO;IMEX=1';"; //Office 07以下版本 
                using (OleDbConnection conn = new OleDbConnection(connstring))
                {
                    conn.Open();
                    System.Data.DataTable sheetsName = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "Table" }); //得到所有sheet的名字
                    string firstSheetName = sheetsName.Rows[0][2].ToString(); //得到第一个sheet的名字
                    string sql = string.Format("SELECT * FROM [{0}]", firstSheetName); //查询字符串                    //string sql = string.Format("SELECT * FROM [{0}] WHERE [日期] is not null", firstSheetName); //查询字符串
                    OleDbDataAdapter ada = new OleDbDataAdapter(sql, connstring);
                    DataSet set = new DataSet();
                    ada.Fill(set);
                    return set.Tables[0];
                }
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }

        }

        public static System.Data.DataTable ExcelToDataTable(string strExcelFileName, string strSheetName)
        {
            string strConn = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strExcelFileName + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
            OleDbConnection conn = new OleDbConnection(strConn);
            conn.Open();
            //返回Excel的架构，包括各个sheet表的名称,类型，创建时间和修改时间等　
            System.Data.DataTable dtSheetName = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "Table" });
            //包含excel中表名的字符串数组
            string[] strTableNames = new string[dtSheetName.Rows.Count];
            for (int k = 0; k < dtSheetName.Rows.Count; k++)
            {
                strTableNames[k] = dtSheetName.Rows[k]["TABLE_NAME"].ToString();
            }
            OleDbDataAdapter myCommand = null;
            System.Data.DataTable dt = new System.Data.DataTable();
            //从指定的表明查询数据,可先把所有表明列出来供用户选择
            string strExcel = "select*from[" + strTableNames[0] + "]";
            myCommand = new OleDbDataAdapter(strExcel, strConn);
            dt = new System.Data.DataTable();
            myCommand.Fill(dt);
            return dt;
        }

        public DataSet getData(string strExcelPath, string strExcelSheetName)

        {

            //打开文件

            //OpenFileDialog file = new OpenFileDialog();

            //file.Filter = "Excel(*.xlsx)|*.xlsx|Excel(*.xls)|*.xls";

            //file.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            //file.Multiselect = false;

            //if (file.ShowDialog() == DialogResult.Cancel)

            //    return null;

            ////判断文件后缀

            //var path = file.FileName;

            string fileSuffix = System.IO.Path.GetExtension(strExcelPath);

            if (string.IsNullOrEmpty(fileSuffix))

                return null;


            using (DataSet ds = new DataSet())

            {

                //判断Excel文件是2003版本还是2007版本

                string connString = "";

                if (fileSuffix == ".xls")

                    connString = "Provider=Microsoft.Jet.OLEDB.4.0;" + "Data Source=" + strExcelPath + ";" + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=1\"";

                else

                    connString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=" + strExcelPath + ";" + ";Extended Properties=\"Excel 12.0;HDR=YES;IMEX=1\"";

                //读取文件

                string sql_select = " SELECT * FROM [" + strExcelSheetName + "$]";

                using (OleDbConnection conn = new OleDbConnection(connString))

                using (OleDbDataAdapter cmd = new OleDbDataAdapter(sql_select, conn))

                {

                    conn.Open();

                    cmd.Fill(ds);

                }

                if (ds == null || ds.Tables.Count <= 0) return null;

                return ds;

            }

        }
        #endregion
    }
}
