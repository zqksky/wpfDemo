﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExcelParse.BaseFun
{
    class DatatableHelp
    {
        public static DataTable DistinctDatatable(DataTable db,List<string> strListColName)
        {
            //数据库直接去除重复
            //DataTable dt = db.GetDataTable("select * from 表名");

            DataView dv = new DataView(db);//对db这个表创建一个视图（注意：这里的DataView只能对一个datatable进行创建视图） 
            DataTable dtNew = dv.ToTable(true, db.Columns[0].ColumnName, db.Columns[1].ColumnName, db.Columns[2].ColumnName);//true:去除重复，false 不去除;后面表示需要显示的字段,特别注意：需要将每个栏位用双引号括起来，不然会报错：列“name,age,sex”不属于基础表

            return dtNew;
        }

        public static DataTable SortDatatable(DataTable db)
        {
            db.DefaultView.Sort = db.Columns[0].ColumnName + " asc," + db.Columns[1].ColumnName + " asc," + db.Columns[2].ColumnName + " asc," + db.Columns[3].ColumnName + " asc";//设置dttemp的排序列
            DataTable dtNew = db.DefaultView.ToTable(); //保存在一张新表中

            return dtNew;
        }

        /// <summary>
        /// 分解数据表
        /// </summary>
        /// <param name="OriginalTab">需要分解的表</param>
        /// <param name="rowsNum">每个表包含的数据量</param>
        /// <returns></returns>
        public static DataSet SplitDataTable(DataTable OriginalTab, int rowsNum)
        {
            //获取所需创建的表数量
            int tableNum = OriginalTab.Rows.Count / rowsNum;

            //获取数据余数
            int remainder = OriginalTab.Rows.Count % rowsNum;

            DataSet ds = new DataSet();

            //如果只需要创建1个表，直接将原始表存入DataSet
            if (tableNum == 0)
            {
                ds.Tables.Add(OriginalTab);
            }
            else
            {
                DataTable[] tableSlice = new DataTable[tableNum];

                //Save orginal columns into new table.            
                for (int c = 0; c < tableNum; c++)
                {
                    tableSlice[c] = new DataTable();
                    foreach (DataColumn dc in OriginalTab.Columns)
                    {
                        tableSlice[c].Columns.Add(dc.ColumnName, dc.DataType);
                    }
                }
                //Import Rows
                for (int i = 0; i < tableNum; i++)
                {
                    // if the current table is not the last one
                    if (i != tableNum - 1)
                    {
                        for (int j = i * rowsNum; j < ((i + 1) * rowsNum); j++)
                        {
                            tableSlice[i].ImportRow(OriginalTab.Rows[j]);
                        }
                    }
                    else
                    {
                        for (int k = i * rowsNum; k < ((i + 1) * rowsNum + remainder); k++)
                        {
                            tableSlice[i].ImportRow(OriginalTab.Rows[k]);
                        }
                    }
                }

                //add all tables into a dataset                
                foreach (var dt in tableSlice)
                {
                    ds.Tables.Add(dt);
                }
            }
            return ds;
        }
    }
}
