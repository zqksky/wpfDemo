﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace ConfigManagement
{
    [ValueConversion(typeof(string), typeof(string))]
    public class DataColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
       {
            if (value.Equals("1"))
            {
                return new SolidColorBrush(Colors.Red);
            }
            else
            {
                return new SolidColorBrush(Colors.Black);
                //return new SolidColorBrush(Colors.Red);
            }

            //if (value == null || value.ToString() == "")
            //    return "";

            //if (value.ToString() == "不通过")//这里根据你里面的值自己写判断条件
            //{
            //    try
            //    {
            //        return new SolidColorBrush(Colors.Red);
            //    }
            //    catch
            //    { throw; }
            //}

            //return new SolidColorBrush(Colors.Black);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            //throw new NotImplementedException();

            //string strValue = value.ToString();
            return value;
        }


    }

    //[ValueConversion(typeof(string), typeof(string))]
    //public class MyColorConverter : IMultiValueConverter
    //{
    //    #region Implementation of IMultiValueConverter

    //    public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
    //    {
    //        if (values[1] is DataRow)
    //        {
    //            //Change the background of any cell with 1.0 to light red.
    //            var cell = (DataGridCell)values[0];
    //            var row = (DataRow)values[1];
    //            var columnName = cell.Column.SortMemberPath;

    //            if (row[columnName].IsNumeric() && row[columnName].ToDouble() == 1.0)
    //                return new SolidColorBrush(Colors.LightSalmon);

    //        }
    //        return SystemColors.ControlLight;
    //    }

    //    public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
    //    {
    //        throw new System.NotImplementedException();
    //    }

    //    #endregion
    //}

    //public static class Extensions
    //{
    //    public static bool IsNumeric(this object val)
    //    {
    //        double test;
    //        return double.TryParse(val.ToString(), out test);
    //    }

    //    public static double ToDouble(this object val)
    //    {
    //        return Convert.ToDouble(val);
    //    }
    //}
}


