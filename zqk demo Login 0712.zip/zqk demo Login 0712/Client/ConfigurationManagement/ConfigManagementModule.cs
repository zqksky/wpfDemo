﻿using ConfigManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Service;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagement
{
    public class ConfigManagementModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
            //var regionManager = containerProvider.Resolve<IRegionManager>();
            //regionManager.RegisterViewWithRegion("ContentRegion", typeof(LithoMain));
            ////regionManager.RegisterViewWithRegion("ContentRegion", typeof(SingleLot));

            //regionManager.RegisterViewWithRegion("LithoMainRegion", typeof(LithoMain));
            //regionManager.RegisterViewWithRegion("SingleLotRegion", typeof(SingleLot));
        }


        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<ConfigMain>();
            containerRegistry.RegisterForNavigation<SingleLot>();
            containerRegistry.RegisterForNavigation<LithoMain>();

            containerRegistry.RegisterForNavigation<ViewDraft>();
            containerRegistry.RegisterForNavigation<ViewHistory>();
            containerRegistry.RegisterForNavigation<ViewPendingCR>();

            containerRegistry.RegisterSingleton<IConfigMainService, ConfigMainService>();
            containerRegistry.RegisterSingleton<ISingleLotService, SingleLotService>();
            containerRegistry.RegisterSingleton<ILithoMainService, LithoMainService>();
            containerRegistry.RegisterSingleton<IViewDraftService, ViewDraftService>();
            containerRegistry.RegisterSingleton<IViewHistoryService, ViewHistoryService>();
            containerRegistry.RegisterSingleton<IViewPendingCRService, ViewPendingCRService>();

        }
    }
}
