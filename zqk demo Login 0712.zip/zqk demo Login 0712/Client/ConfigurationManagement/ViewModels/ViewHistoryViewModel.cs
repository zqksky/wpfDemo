﻿using ConfigManagement.Views;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ConfigManagement.ViewModels
{
    public class ViewHistoryViewModel : ViewModelBase
    {
        public ViewHistoryViewModel()
        {
            Title = "View History";
        }

        #region
        private ObservableCollection<ViewHistoryModel> _ViewHistoryList;
        public ObservableCollection<ViewHistoryModel> ViewHistoryList
        {
            get { return _ViewHistoryList; }
            set { SetProperty(ref _ViewHistoryList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _StartDatePickerChangedCommand;
        public DelegateCommand<object> StartDatePickerChangedCommand =>
            _StartDatePickerChangedCommand ?? (_StartDatePickerChangedCommand = new DelegateCommand<object>(OnStartSelectDateChanged));

        private DelegateCommand<object> _EndDatePickerChangedCommand;
        public DelegateCommand<object> EndDatePickerChangedCommand =>
            _EndDatePickerChangedCommand ?? (_EndDatePickerChangedCommand = new DelegateCommand<object>(OnEndSelectDateChanged));

        private DelegateCommand _CRViewCommand;
        public DelegateCommand CRListCommand =>
            _CRViewCommand ?? (_CRViewCommand = new DelegateCommand(OnCRView));
        #endregion

        #region Event Fun
        void OnStartSelectDateChanged(object obj)
        {
            var dp = obj as DatePicker;
            MessageBox.Show(dp.Text);

        }

        void OnEndSelectDateChanged(object obj)
        {
            var dp = obj as DatePicker;
            MessageBox.Show(dp.Text);

        }

        void OnCRView()
        {

        }
        #endregion
    }
}
