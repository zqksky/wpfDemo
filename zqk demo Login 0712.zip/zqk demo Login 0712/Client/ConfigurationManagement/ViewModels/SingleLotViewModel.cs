﻿using ConfigManagement.Views;
using ConfigurationService.Models;
using ConfigurationService.IService;
using Microsoft.Win32;
using ORM.Dao;
using ORM.Models;
using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Prism.Events;
using Prism.Regions;
using System.Windows.Media;

namespace ConfigManagement.ViewModels
{
    public class SingleLotViewModel : ViewModelBase
    {
        public SingleLotViewModel()
        {

        }

        public ISingleLotService SingleLotService { get; set; }
        public SingleLotViewModel(ISingleLotService singleLotService, IEventAggregator ea)
        {
            this.SingleLotService = singleLotService;
            Title = "Single Lot";
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;

                var msg = navigationContext.Parameters["Message"] as SendToSingleLotParam;
                if (msg != null)
                {
                    SendParam = msg;
                    InitSendParam();
                    InitColumnKeysControl();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            var msg = navigationContext.Parameters["Message"] as SendToSingleLotParam;
            return true;
        }

        #region Variable
        string strRequestId;
        string strUserId;
        string strClientVersion;
        string strTableName;
        string strSelectedModel;

        string strCrId = string.Empty;
        string strTimeStamp = string.Empty;
        string strTrackTime = string.Empty;

        bool bIsAdd = false;
        bool bIsRowEndEdit = false;
        bool bIsSaveDraft = false;
        bool bIsSubmit = false;

        CfgGetEntity CurrentEntity = new CfgGetEntity();
        List<string> strListColumnName = new List<string>();
        List<string> strListColumnKey = new List<string>();

        int selectRowIndex = -1;
        string strOperation = string.Empty;
        string strPreEditRow = string.Empty;
        string strEndEditRow = string.Empty;

        CfgOperationRecord OpertionRecord = new CfgOperationRecord();

        DataTable dbSource = new DataTable();
        DataTable dbSourceUpdate = new DataTable();
        #endregion

        #region Init
        void InitSendParam()
        {
            try
            {
                strRequestId = SendParam.RequestId;
                strUserId = SendParam.UserId;
                strClientVersion = SendParam.ClientVersion;
                strTableName = SendParam.TableName;
                strSelectedModel = SendParam.SelectedModel;
                strListColumnKey = new List<string>(SendParam.ColumnKeyName);
                strListColumnName = new List<string>(SendParam.ColumnNameList);
                SingleLotDataTable = new DataView(SendParam.TableStructure);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        void InitColumnKeysControl()
        {
            try
            {
                ColumnKeysControl = new ObservableCollection<ColumnKeyControl>();
                foreach (var name in SendParam.ColumnKeyName)
                {
                    SingleKeyControl = new ColumnKeyControl();
                    SingleKeyControl.KeyName = name;
                    SingleKeyControl.KeyValue = "";
                    SingleKeyControl.KeyValueList = new List<string>() { };

                    ColumnKeysControl.Add(SingleKeyControl);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void InitDefineParameter()
        {
            bIsAdd = false;
            bIsRowEndEdit = false;

            strOperation = string.Empty;
            strPreEditRow = string.Empty;
            strEndEditRow = string.Empty;
        }
        void InitChangeDataTable()
        {
            try
            {
                DataTable db = SingleLotDataTable.ToTable();
                dbSource = db.Clone();
                dbSourceUpdate = db.Clone();
                dbSource.Rows.Clear();
                dbSourceUpdate.Rows.Clear();

                OpertionRecord.dbSource = db.Clone();
                OpertionRecord.dbAdd = db.Clone();
                OpertionRecord.dbEdit = db.Clone();
                OpertionRecord.dbDelete = db.Clone();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Field

        private string _FlagChangeCellColor="0";
        public string FlagChangeCellColor
        {
            get { return this._FlagChangeCellColor; }
            set { SetProperty(ref this._FlagChangeCellColor, value); }
        }

        private SendToSingleLotParam _SendParam;
        public SendToSingleLotParam SendParam
        {
            get { return this._SendParam; }
            set { SetProperty(ref this._SendParam, value); }
        }

        private ColumnKeyControl _SingleKeyControl;
        public ColumnKeyControl SingleKeyControl
        {
            get { return this._SingleKeyControl; }
            set { SetProperty(ref this._SingleKeyControl, value); }
        }

        private ObservableCollection<ColumnKeyControl> _ColumnKeysControl;
        public ObservableCollection<ColumnKeyControl> ColumnKeysControl
        {
            get { return this._ColumnKeysControl; }
            set { SetProperty(ref this._ColumnKeysControl, value); }
        }


        //private SelectedRowEntity selectedRow = new SelectedRowEntity();
        //public SelectedRowEntity SelectedRow
        //{
        //    get { return this.selectedRow; }
        //    set { SetProperty(ref this.selectedRow, value); }
        //}

        private DataRowView selectedRowValue;
        public DataRowView SelectedRowValue
        {
            get { return this.selectedRowValue; }
            set { SetProperty(ref this.selectedRowValue, value); }
        }

        private DataView _SingleLotDataTable;
        public DataView SingleLotDataTable
        {
            get { return _SingleLotDataTable; }
            set { SetProperty(ref _SingleLotDataTable, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _KeySelectionChangedCommand;
        public DelegateCommand<object> KeySelectionChangedCommand =>
            _KeySelectionChangedCommand ?? (_KeySelectionChangedCommand = new DelegateCommand<object>(OnKeySelectionChanged));

        private DelegateCommand _QueryCommand;
        public DelegateCommand QueryCommand =>
            _QueryCommand ?? (_QueryCommand = new DelegateCommand(OnQueryClick));

        private DelegateCommand _ViewDraftCommand;
        public DelegateCommand ViewDraftCommand =>
            _ViewDraftCommand ?? (_ViewDraftCommand = new DelegateCommand(OnViewDraftClick));

        private DelegateCommand _ViewHistoryCommand;
        public DelegateCommand ViewHistoryCommand =>
            _ViewHistoryCommand ?? (_ViewHistoryCommand = new DelegateCommand(OnViewHistoryClick));

        private DelegateCommand _ViewPendingCRCommand;
        public DelegateCommand ViewPendingCRCommand =>
            _ViewPendingCRCommand ?? (_ViewPendingCRCommand = new DelegateCommand(OnViewPendingCRClick));

        private DelegateCommand<object> _TargetUpdatedCommand;
        public DelegateCommand<object> TargetUpdatedCommand =>
            _TargetUpdatedCommand ?? (_TargetUpdatedCommand = new DelegateCommand<object>(OnTest));

        private DelegateCommand<object> _BeginningEditCommand;
        public DelegateCommand<object> BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand<object>(OnBeginningEdit));

        private DelegateCommand<object> _RowEditEndingCommand;
        public DelegateCommand<object> RowEditEndingCommand =>
            _RowEditEndingCommand ?? (_RowEditEndingCommand = new DelegateCommand<object>(OnRowEditEnding));

        private DelegateCommand<object> _RowSelectionChangedCommand;
        public DelegateCommand<object> RowSelectionChangedCommand =>
            _RowSelectionChangedCommand ?? (_RowSelectionChangedCommand = new DelegateCommand<object>(OnRowSelectionChanged));

        private DelegateCommand _AddCommand;
        public DelegateCommand AddCommand =>
            _AddCommand ?? (_AddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _DeleteCommand;
        public DelegateCommand DeleteCommand =>
            _DeleteCommand ?? (_DeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _SaveDraftCommand;
        public DelegateCommand SaveDraftCommand =>
            _SaveDraftCommand ?? (_SaveDraftCommand = new DelegateCommand(OnSaveDraftClick));

        private DelegateCommand _SubmitCommand;
        public DelegateCommand SubmitJobCommand =>
            _SubmitCommand ?? (_SubmitCommand = new DelegateCommand(OnSubmitClick));

        private DelegateCommand _ImportExcelCommand;
        public DelegateCommand ImportExcelCommand =>
            _ImportExcelCommand ?? (_ImportExcelCommand = new DelegateCommand(OnImportExcel));

        private DelegateCommand _ExportExcelCommand;
        public DelegateCommand ExportExcelCommand =>
            _ExportExcelCommand ?? (_ExportExcelCommand = new DelegateCommand(OnExportExcel));
        #endregion

        #region Event Fun
        void OnImportExcel()
        {
            try
            {
                //string strExcelFile = @"C:\zqk\test.xlsx";
                string strExcelFile = string.Empty;
                OpenFileDialog open = new OpenFileDialog();//定义打开文本框实体
                open.Title = "打开文件";//对话框标题
                open.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
                if ((bool)open.ShowDialog().GetValueOrDefault())
                {
                    strExcelFile = System.IO.Path.GetFullPath(open.FileName);

                    DataTable dbSource = SingleLotDataTable.ToTable();
                    DataTable dbImport = DataTableHelp.CreateDataTable(dbSource, ExcelHelp.Inport(strExcelFile));

                    List<DataRow> drAddRow = new List<DataRow>();
                    List<DataRow> drEndEditRow = new List<DataRow>();
                    List<DataRow> drListPreEditRow = new List<DataRow>();
                    DataTable dataTableDistinct = DataTableHelp.GetMerge(dbSource, dbImport, strListColumnKey, ref drListPreEditRow, ref drEndEditRow, ref drAddRow);

                    SingleLotDataTable = new DataView(dataTableDistinct);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnExportExcel()
        {
            try
            {
                //string strExcelFile = @"C:\zqk\test.xlsx";
                string strExcelFile = string.Empty;
                SaveFileDialog save = new SaveFileDialog();//定义打开文本框实体
                save.Title = "打开文件";//对话框标题
                save.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
                if ((bool)save.ShowDialog().GetValueOrDefault())
                {
                    strExcelFile = System.IO.Path.GetFullPath(save.FileName);
                    ExcelHelp.Export(SingleLotDataTable.ToTable(), strExcelFile);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnKeySelectionChanged(object obj)
        {
            try
            {
                //MessageBox.Show("test");
                //MessageBox.Show(obj.ToString());
                string strKey = obj.ToString();
                switch (strKey)
                {
                    //case "cmbModule":
                    //    strSelectedModel = cmb.SelectedValue.ToString();
                    //    this.ProductList = new List<string>() { "Product1", "Product2", "Product3" };
                    //    break;
                    //case "cmbProduct":
                    //    strSelectedProduct = cmb.SelectedValue.ToString();
                    //    this.LayerList = new List<string>() { "Layer1", "Layer2", "Layer3" };
                    //    break;
                    //case "cmbLayer":
                    //    strSelectedLayer = cmb.SelectedValue.ToString();
                    //    this.ToolList = new List<string>() { "Tool1", "Tool2", "Tool3" };
                    //    break;
                    //case "cmbTool":
                    //    strSelectedTool = cmb.SelectedValue.ToString();
                    //    this.RecipeList = new List<string>() { "Recipe1", "Recipe2", "Recipe3" };
                    //    break;
                    //case "cmbRecipe":
                    //    strSelectedRecipe = cmb.SelectedValue.ToString();
                    //    break;
                    //default:
                    //    break;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnQueryClick()
        {
            try
            {
                //strRequestId = "RequestId_86";
                //strUserId = "Administrator";
                //strClientVersion = "7.8.0.43";
                //strSelectedModel = "LITHO";
                //strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

                //string strJson = System.IO.File.ReadAllText(@"C:\zqk\json.txt");

                InitDefineParameter();
                InitChangeDataTable();

                string[] queryContexts = GetColumnKeyContext().ToArray();
                CurrentEntity = this.SingleLotService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strTableName, queryContexts, false);
                if (CurrentEntity != null)
                {
                    SingleLotDataTable = this.SingleLotService.CreateDataTable(CurrentEntity).DefaultView;
                    dbSource = SingleLotDataTable.Table.Copy();
                }


                if (SingleLotDataTable.Count > 0)
                {
                    //var distinctTable = SingleLotDataTable.ToTable(true, strListColumnKey.ToArray());
                    //var dbColumn = SingleLotDataTable.ToTable(true, strListColumnKey[0]);

                    //List<string> keyList = (from d in SingleLotDataTable.ToTable().AsEnumerable() select d.Field<string>(strListColumnKey[0])).Distinct().ToList();

                    foreach (var obj in ColumnKeysControl)
                    {
                        obj.KeyValueList = (from d in SingleLotDataTable.ToTable().AsEnumerable() select d.Field<string>(obj.KeyName)).Distinct().ToList();
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnViewDraftClick()
        {
            try
            {
                CfgChangeRequestManager cm = new CfgChangeRequestManager();
                List<ConfigChangeRequestModel> cfgModels = new List<ConfigChangeRequestModel>();
                cfgModels = cm.GetList();

                var window = new Window();//Windows窗体      
                ViewDraft parameter = new ViewDraft();
                ViewDraftViewModel view = (ViewDraftViewModel)parameter.DataContext;
                view.ViewDraftList = new ObservableCollection<ViewDraftModel>();
                foreach (var m in cfgModels)
                {
                    ViewDraftModel model = new ViewDraftModel();
                    model.CR_Id = m.CrId;
                    model.CR_Comment = m.Comment;
                    model.CR_Category = m.Category;
                    model.FirstDraftTime = m.TimeStamp;
                    model.LastModifiedTime = m.TrackTime;
                    model.TableName = m.TbName;
                    model.Reason = m.Reason;
                    view.ViewDraftList.Add(model);
                }

                //List<ViewDraftModel> sortList = view.ViewDraftList.OrderBy(s => s.FirstDraftTime).ToList<ViewDraftModel>();
                //List<ViewDraftModel> sortList = (from s in view.ViewDraftList orderby s.FirstDraftTime descending select s).ToList<ViewDraftModel>();
                List<ViewDraftModel> sortList = view.ViewDraftList.OrderByDescending(s => s.FirstDraftTime).ToList<ViewDraftModel>();
                view.ViewDraftList = new ObservableCollection<ViewDraftModel>(sortList);

                view.strUserId = strUserId;
                view.strRequestId = strRequestId;
                view.strTableName = strTableName;
                view.strClientVersion = strClientVersion;
                view.strSelectedModel = strSelectedModel;
                view.CurrentEntity = CurrentEntity;
                view.strListColumnKey = new List<string>(strListColumnKey);
                view.strListColumnName = new List<string>(strListColumnName);

                //view.CurrentWindow = window;
                window.Content = parameter;
                window.Title = "View Draft";
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnViewHistoryClick()
        {
            try
            {
                CfgHistoryManager cm = new CfgHistoryManager();
                List<ConfigHistoryModel> cfgModels = new List<ConfigHistoryModel>();
                cfgModels = cm.GetList();

                var window = new Window();//Windows窗体      
                ViewHistory parameter = new ViewHistory();
                ViewHistoryViewModel view = (ViewHistoryViewModel)parameter.DataContext;

                view.ViewHistoryList = new ObservableCollection<ViewHistoryModel>();
                foreach (var m in cfgModels)
                {
                    ViewHistoryModel model = new ViewHistoryModel();
                    model.CR_Id = m.CrId;
                    model.TimeStamp = m.TimeStamp;
                    model.User_Id = m.UserId;
                    model.TableName = m.TbName;
                    model.Action = m.Action;
                    view.ViewHistoryList.Add(model);
                }

                window.Content = parameter;
                window.Title = "View History";
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnViewPendingCRClick()
        {
            try
            {
                var window = new Window();//Windows窗体      
                ViewPendingCR parameter = new ViewPendingCR();
                ViewPendingCRViewModel view = (ViewPendingCRViewModel)parameter.DataContext;
                window.Content = parameter;
                window.Title = "View PendingCR";
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
                window.ShowDialog();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnTest(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;
                MessageBox.Show("OnTest");
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnBeginningEdit(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;

                SelectedRowValue.BeginEdit();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        #region 选中单元格变色或编辑单元格后变色
        //void CellEditChangColor(DataGrid dgv)
        //{
        //    int colindex = -1;
        //    int rowindex = -1;

        //    colindex = dgv.CurrentCell.Column.DisplayIndex;//获取选中单元格列号
        //    rowindex = dgv.SelectedIndex;//获取选中单元格行号
        //    DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowindex);//获取选中单元格所在行
        //    DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);//函数调用，获取行中所有单元格的集合
        //    DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);//锁定选中单元格（重点）
        //    if (cell != null)
        //    {
        //        dgv.ScrollIntoView(row, dgv.Columns[colindex]);
        //        cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);
        //        cell.Focus();
        //        cell.Background = new SolidColorBrush(Colors.DarkOrange);//OK!问题解决，选中单元格变色
        //        cell.Focusable = false;
        //    }
        //}
        ////获取行中所有单元格集合的函数
        //public static T GetVisualChild<T>(Visual parent) where T : Visual
        //{
        //    T childContent = default(T);
        //    int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
        //    for (int i = 0; i < numVisuals; i++)
        //    {
        //        Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
        //        childContent = v as T;
        //        if (childContent == null)
        //        {
        //            childContent = GetVisualChild<T>(v);
        //        }
        //        if (childContent != null)
        //        { break; }
        //    }
        //    return childContent;
        //}
        #endregion

        void OnRowEditEnding(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;

                DataRow dataRow = SelectedRowValue.Row;
                selectRowIndex = SingleLotDataTable.Table.Rows.IndexOf(SelectedRowValue.Row);
                selectRowIndex = dgv.SelectedIndex;
                if (bIsAdd)
                {
                    //selectRowIndex = SingleLotDataTable.Count - 1;
                    strPreEditRow = string.Empty;
                }
                else
                {
                    strPreEditRow = JsonHelp.SerializeObject(dataRow.ItemArray);
                }

                //DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromItem(dgv.SelectedItem);//获取选中单元格所在行
                //row.Background = new SolidColorBrush(Colors.Red);

        
                ////row.IsFocused
                ////row.IsSelected
                ////row.IsEditing

                SelectedRowValue.EndEdit();
                SelectedRowValue.Row.AcceptChanges();

                bIsRowEndEdit = true;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnRowSelectionChanged(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;

                if (bIsRowEndEdit)
                {
                    strOperation = bIsAdd ? "Add" : "Edit";

                    bIsAdd = false;
                    bIsRowEndEdit = false;

                    //DataRow rowSelect = SingleLotDataTable.ToTable().Rows[selectRowIndex];
                    strEndEditRow = JsonHelp.SerializeObject(SingleLotDataTable.Table.Rows[selectRowIndex].ItemArray);

                    if (strPreEditRow.Equals(strEndEditRow))
                    {
                        FlagChangeCellColor = "0";
                    }
                    else
                    {
                        //DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(selectRowIndex);//获取选中单元格所在行
                        //row.Background = new SolidColorBrush(Colors.Red);

                        FlagChangeCellColor = "1";
                    }

                    bIsSaveDraft = true;
                    bIsSubmit = true;

                    SingleLotDataTable.RowStateFilter = DataViewRowState.CurrentRows;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnAddClick()
        {
            try
            {
                bIsAdd = true;
                DataRowView dvRow = SingleLotDataTable.AddNew();
                SelectedRowValue = dvRow;
                DataRow row = this.SelectedRowValue.Row;
                SelectedRowValue.EndEdit();
                SelectedRowValue.Row.AcceptChanges();

                SingleLotDataTable.ToTable().AcceptChanges();
                //SelectedRowIndex = ConfigDataTable.Count;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnSaveDraftClick()
        {
            try
            {
                if (bIsSaveDraft)
                {
                    strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
                    strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                    strTrackTime = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

                    DataTable dbChanged = DataTableHelp.CompareDataTable(dbSource, SingleLotDataTable.Table, strListColumnKey);
                    if (dbChanged.Rows.Count > 0)
                    {
                        DataTable dbEdit = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "New");
                        DataTable dbAdd = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Add");
                        DataTable dbDelete = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Delete");

                        string strJson = GetChangeDataToJson(dbChanged);
                        SaveChangeDataToHistory("SaveDraft");
                        SaveChangeDataToChangeRequest(strJson, "Draft");

                        bIsSaveDraft = false;
                    }                   
                }
                else
                {

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnSubmitClick()
        {
            SaveChangeDataToE3();
        }

        void OnDeleteClick()
        {
            try
            {
                if (this.selectedRowValue == null)
                {
                    MessageBox.Show("Row is not selected!");
                    return;
                }

                SelectedRowValue.Row.Delete();

                bIsSaveDraft = true;
                bIsSubmit = true;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region
        List<string> GetColumnKeyContext()
        {
            List<string> strList = new List<string>();
            try
            {
                string strKeyValue = string.Empty;
                foreach (var obj in ColumnKeysControl)
                {
                    //strKeyValue += obj.KeyValue + ";";
                    strList.Add(obj.KeyValue);
                }
                //MessageBox.Show(strKeyValue);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        string GetChangeDataToJson(DataTable dbChange)
        {
            string strJson = string.Empty;
            try
            {
                DataTable dbOld = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Old");
                DataTable dbEdit = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Edit");
                DataTable dbAdd = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Add");
                DataTable dbDelete = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Delete");

                dbEdit.Merge(dbOld, false);

                string strSort = string.Empty;
                foreach (var str in strListColumnKey)
                {
                    strSort += str + ",";
                }
                strSort = strSort + "Status DESC";
                dbEdit.DefaultView.Sort = strSort;
                dbEdit = dbEdit.DefaultView.ToTable();

                OpertionRecord.dbAdd = dbAdd.Copy();
                OpertionRecord.dbEdit = dbEdit.Copy();
                OpertionRecord.dbDelete = dbDelete.Copy();
                OpertionRecord.dbSource = dbSource.Copy();

                strJson = JsonHelp.SerializeObject(OpertionRecord);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strJson;
        }

        void SaveChangeDataToE3()
        {
            string contentAdd = string.Empty;
            string contentModify = string.Empty;
            string contentDelete = string.Empty;
            try
            {
                DataTable dbChanged = DataTableHelp.CompareDataTable(dbSource, SingleLotDataTable.Table, strListColumnKey);

                DataTable dbEdit = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Edit");
                DataTable dbAdd = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Add");
                DataTable dbDelete = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Delete");

                contentAdd = GetChangedJson(dbAdd);
                contentModify = GetChangedJson(dbEdit);
                contentDelete = GetChangedJson(dbDelete);
                if (contentAdd.Equals("") && contentModify.Equals("") && contentDelete.Equals(""))
                {
                }
                else
                {
                    bool flag = this.SingleLotService.R2R_UI_Config_Update(strRequestId, strUserId, strClientVersion, strSelectedModel, strTableName, contentModify, contentAdd, contentDelete);

                    if (flag)
                    {
                        if (bIsSubmit)
                        {
                            strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
                            strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                            strTrackTime = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

                            string strJson = GetChangeDataToJson(dbChanged);
                            SaveChangeDataToHistory("Submit");
                            SaveChangeDataToChangeRequest(strJson, "Submit");

                            bIsSubmit = false;
                        }
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

        }

        void SaveChangeDataToHistory(string strAction)
        {
            try
            {
                CfgHistoryManager cmHistory = new CfgHistoryManager();
                ConfigHistoryModel cfgHistoryModel = new ConfigHistoryModel();
                cfgHistoryModel.CrId = strCrId;
                cfgHistoryModel.Module = strSelectedModel;
                cfgHistoryModel.TbName = strTableName;
                cfgHistoryModel.TimeStamp = strTimeStamp;
                cfgHistoryModel.UserId = strUserId;
                cfgHistoryModel.Action = strAction;
                cmHistory.Insert(cfgHistoryModel);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void SaveChangeDataToChangeRequest(string strJson, string strStatus)
        {
            try
            {
                CfgChangeRequestManager cmChangeRequest = new CfgChangeRequestManager();
                ConfigChangeRequestModel cfgChangModel = new ConfigChangeRequestModel();
                cfgChangModel.CrId = strCrId;
                cfgChangModel.Module = strSelectedModel;
                cfgChangModel.TbName = strTableName;
                cfgChangModel.UserId = strUserId;
                cfgChangModel.TimeStamp = strTimeStamp;
                cfgChangModel.SubTb1 = strTableName;
                cfgChangModel.Json1 = strJson;
                cfgChangModel.SubTb2 = "";
                cfgChangModel.Json2 = "";
				cfgChangModel.Detail = "";
                cfgChangModel.Category = "Test";
                cfgChangModel.Comment = "MyTest";
                cfgChangModel.Status = strStatus;
                cfgChangModel.TrackTime = strTrackTime;
                cfgChangModel.UserModify = "zqk";
                cfgChangModel.Reason = "Test";
                cmChangeRequest.Insert(cfgChangModel);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        string GetChangedJson(DataTable db)
        {
            string json = string.Empty;
            try
            {
                if (db.Rows.Count > 0)
                {
                    CurrentEntity.ColumnData = this.SingleLotService.DataTableConvert(db, strListColumnName);
                    json = JsonHelp.SerializeObject(CurrentEntity);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return json;
        }

        DataView GetAllUpdate()
        {
            DataView dvUpdate = new DataView();

            try
            {
                SingleLotDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;

                dvUpdate = new DataView(SingleLotDataTable.ToTable());

                SingleLotDataTable.RowStateFilter = DataViewRowState.CurrentRows;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return dvUpdate;
        }
        #endregion
    }
}
