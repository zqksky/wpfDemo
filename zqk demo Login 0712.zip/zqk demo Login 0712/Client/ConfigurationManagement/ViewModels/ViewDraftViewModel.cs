﻿using ConfigManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Models;
using Microsoft.Win32;
using ORM.Dao;
using ORM.Models;
using Prism.Commands;
using Prism.Events;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ConfigManagement.ViewModels
{
    public class ViewDraftViewModel : ViewModelBase
    {
        public ViewDraftViewModel()
        {

        }

        public ISingleLotService SingleLotService { get; set; }
        public ViewDraftViewModel(ISingleLotService singleLotService, IEventAggregator ea)
        {
            this.SingleLotService = singleLotService;
            Title = "View Draft";
        }

        #region Filed
        private ViewDraftModel _SelectedViewDraftRow;
        public ViewDraftModel SelectedViewDraftRow
        {
            get { return this._SelectedViewDraftRow; }
            set { SetProperty(ref this._SelectedViewDraftRow, value); }
        }

        private string _CtlFlag;
        public string CtlFlag
        {
            get { return this._CtlFlag; }
            set { SetProperty(ref this._CtlFlag, value); }
        }

        private string _SelectedViewDraftRowDetail;
        public string SelectedViewDraftRowDetail
        {
            get { return this._SelectedViewDraftRowDetail; }
            set { SetProperty(ref this._SelectedViewDraftRowDetail, value); }
        }

        private ObservableCollection<ViewDraftModel> _ViewDraftList;
        public ObservableCollection<ViewDraftModel> ViewDraftList
        {
            get { return _ViewDraftList; }
            set { SetProperty(ref _ViewDraftList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _DeleteDraftCommand;
        public DelegateCommand DeleteDraftCommand =>
            _DeleteDraftCommand ?? (_DeleteDraftCommand = new DelegateCommand(OnDeleteDraftClick));

        private DelegateCommand<object> _SelectRowDoubleClickCommand;
        public DelegateCommand<object> SelectRowDoubleClickCommand =>
            _SelectRowDoubleClickCommand ?? (_SelectRowDoubleClickCommand = new DelegateCommand<object>(OnSelectRowDoubleClick));
        #endregion

        #region Event Fun
        void OnDeleteDraftClick()
        {
            try
            {
                //MessageBox.Show(SelectedViewDraftRow.TableName);

                CfgChangeRequestManager cmChangeRequest = new CfgChangeRequestManager();
                cmChangeRequest.CfgChangeRequestDb.Delete(it => it.CrId == SelectedViewDraftRow.CR_Id && it.TbName == SelectedViewDraftRow.TableName);
                //cmChangeRequest.CfgChangeRequestDb.AsDeleteable();

                ViewDraftList.Remove(SelectedViewDraftRow);
                SingleLotDataTable.Table.Rows.Clear();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnSelectRowDoubleClick(object obj)
        {
            try
            {
                var model = obj as ViewDraftModel;
                //MessageBox.Show(model.CR_Id);

                CfgChangeRequestManager cmChangeRequest = new CfgChangeRequestManager();
                var result = cmChangeRequest.CfgChangeRequestDb.GetSingle(it => it.CrId == model.CR_Id && it.TbName == model.TableName);//根据条件查询一条

                GetSelectViewDraftRowDetail(result);

                string json = result.Json1;
                GetDetailDatable(json);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Fun
        void GetSelectViewDraftRowDetail(ConfigChangeRequestModel model)
        {
            try
            {
                SelectedViewDraftRowDetail = string.Empty;

                SelectedViewDraftRowDetail += "TableName: " + model.TbName + ",  " + "User-Id: " + model.UserId + ",  "
                    + "First Draft Time: " + model.TimeStamp + "\r\n" + "CR-Category: " + model.Category + ",  "
                    + "CR-Comment: " + model.Comment + ",  " + "Last Modify Time: " + model.TrackTime + ",  "
                    + "Last Modife Reason: " + model.Reason;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void GetDetailDatable(string strJson)
        {
            //var result = cmChangeRequest.CfgChangeRequestDb.AsQueryable().Where(it => it.CrId == model.CR_Id && it.TbName == model.TableName).ToList();
            //string json = result[0].Json1;
            try
            {
                CfgOperationRecord eneity = JsonHelp.DeserializeJsonToObject<CfgOperationRecord>(strJson);
                dbSource = eneity.dbSource;

                DataTable db = eneity.dbSource.Clone();
                db.Columns.Add("Status", Type.GetType("System.String")).SetOrdinal(0);
                db.Merge(eneity.dbEdit, false);
                db.Merge(eneity.dbAdd, false);
                db.Merge(eneity.dbDelete, false);

                SingleLotDataTable = new DataView(db);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Variable
        public string strRequestId;
        public string strUserId;
        public string strClientVersion;
        public string strTableName;
        public string strSelectedModel;
        public CfgGetEntity CurrentEntity = new CfgGetEntity();
        public List<string> strListColumnName = new List<string>();
        public List<string> strListColumnKey = new List<string>();

        string strCrId = string.Empty;
        string strTimeStamp = string.Empty;
        string strTrackTime = string.Empty;

        bool bIsAdd = false;
        bool bIsRowEndEdit = false;
        bool bIsSaveDraft = false;
        bool bIsSubmit = false;

      

        int selectRowIndex = -1;
        string strOperation = string.Empty;
        string strPreEditRow = string.Empty;
        string strEndEditRow = string.Empty;

        DataTable dbSource = new DataTable();
        CfgOperationRecord OpertionRecord = new CfgOperationRecord();
        #endregion

        #region Init
        void InitDefineParameter()
        {
            bIsAdd = false;
            bIsRowEndEdit = false;

            strOperation = string.Empty;
            strPreEditRow = string.Empty;
            strEndEditRow = string.Empty;
        }
        void InitChangeDataTable()
        {
            try
            {
                DataTable db = SingleLotDataTable.ToTable();
                dbSource = db.Clone();
                dbSource.Rows.Clear();

                OpertionRecord.dbSource = db.Clone();
                OpertionRecord.dbAdd = db.Clone();
                OpertionRecord.dbEdit = db.Clone();
                OpertionRecord.dbDelete = db.Clone();
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region Field
        private string _FlagChangeCellColor;
        public string FlagChangeCellColor
        {
            get { return this._FlagChangeCellColor; }
            set { SetProperty(ref this._FlagChangeCellColor, value); }
        }

        private DataRowView selectedRowValue;
        public DataRowView SelectedRowValue
        {
            get { return this.selectedRowValue; }
            set { SetProperty(ref this.selectedRowValue, value); }
        }

        private DataView _SingleLotDataTable;
        public DataView SingleLotDataTable
        {
            get { return _SingleLotDataTable; }
            set { SetProperty(ref _SingleLotDataTable, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _BeginningEditCommand;
        public DelegateCommand<object> BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand<object>(OnBeginningEdit));

        private DelegateCommand<object> _RowEditEndingCommand;
        public DelegateCommand<object> RowEditEndingCommand =>
            _RowEditEndingCommand ?? (_RowEditEndingCommand = new DelegateCommand<object>(OnRowEditEnding));

        private DelegateCommand<object> _RowSelectionChangedCommand;
        public DelegateCommand<object> RowSelectionChangedCommand =>
            _RowSelectionChangedCommand ?? (_RowSelectionChangedCommand = new DelegateCommand<object>(OnRowSelectionChanged));

        private DelegateCommand _AddCommand;
        public DelegateCommand AddCommand =>
            _AddCommand ?? (_AddCommand = new DelegateCommand(OnAddClick));

        private DelegateCommand _DeleteCommand;
        public DelegateCommand DeleteCommand =>
            _DeleteCommand ?? (_DeleteCommand = new DelegateCommand(OnDeleteClick));

        private DelegateCommand _SaveDraftCommand;
        public DelegateCommand SaveDraftCommand =>
            _SaveDraftCommand ?? (_SaveDraftCommand = new DelegateCommand(OnSaveDraftClick));

        private DelegateCommand _SubmitCommand;
        public DelegateCommand SubmitJobCommand =>
            _SubmitCommand ?? (_SubmitCommand = new DelegateCommand(OnSubmitClick));
        #endregion

        #region Event Fun
        void OnBeginningEdit(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;
                //MessageBox.Show("BeginningEdit");

                selectedRowValue.BeginEdit();
                DataRow dataRow = selectedRowValue.Row;

                //MessageBox.Show(dgv.CurrentColumn.Header.ToString());

                //int rowIndex = dgv.SelectedIndex;//获取选中单元格行号
                //DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowIndex);//获取选中单元格所在行
                //row.Background = new SolidColorBrush(Colors.Red);

                //CellEditChangColor(dgv);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        #region 选中单元格变色或编辑单元格后变色
        //void CellEditChangColor(DataGrid dgv)
        //{
        //    int colindex = -1;
        //    int rowindex = -1;

        //    colindex = dgv.CurrentCell.Column.DisplayIndex;//获取选中单元格列号
        //    rowindex = dgv.SelectedIndex;//获取选中单元格行号
        //    DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowindex);//获取选中单元格所在行
        //    DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);//函数调用，获取行中所有单元格的集合
        //    DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);//锁定选中单元格（重点）
        //    if (cell != null)
        //    {
        //        dgv.ScrollIntoView(row, dgv.Columns[colindex]);
        //        cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);
        //        cell.Focus();
        //        cell.Background = new SolidColorBrush(Colors.DarkOrange);//OK!问题解决，选中单元格变色
        //        cell.Focusable = false;
        //    }
        //}
        ////获取行中所有单元格集合的函数
        //public static T GetVisualChild<T>(Visual parent) where T : Visual
        //{
        //    T childContent = default(T);
        //    int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
        //    for (int i = 0; i < numVisuals; i++)
        //    {
        //        Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
        //        childContent = v as T;
        //        if (childContent == null)
        //        {
        //            childContent = GetVisualChild<T>(v);
        //        }
        //        if (childContent != null)
        //        { break; }
        //    }
        //    return childContent;
        //}
        #endregion

        void OnRowEditEnding(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;
                DataRow dataRow = selectedRowValue.Row;

                selectRowIndex = SingleLotDataTable.Table.Rows.IndexOf(selectedRowValue.Row);

                if (bIsAdd)
                {
                    //selectRowIndex = SingleLotDataTable.Count - 1;
                    strPreEditRow = string.Empty;
                }
                else
                {
                    strPreEditRow = JsonHelp.SerializeObject(dataRow.ItemArray);
                }

                selectedRowValue.EndEdit();
                selectedRowValue.Row.AcceptChanges();

                bIsRowEndEdit = true;

                //CellEditChangColor(dgv);

                FlagChangeCellColor = "1";
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnRowSelectionChanged(object obj)
        {
            try
            {
                var dgv = obj as DataGrid;
                //MessageBox.Show("SelectionChanged");
                if (bIsRowEndEdit)
                {
                    strOperation = bIsAdd ? "Add" : "Edit";

                    bIsAdd = false;
                    bIsRowEndEdit = false;

                    //ConfigDataTable.ToTable().AcceptChanges();
                    DataRow rowSelect = SingleLotDataTable.ToTable().Rows[selectRowIndex];
                    strEndEditRow = JsonHelp.SerializeObject(SingleLotDataTable.Table.Rows[selectRowIndex].ItemArray);

                    //DataRow r = SelectedRowValue.Row;
                    //ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;


                    bIsSaveDraft = true;
                    bIsSubmit = true;

                    SingleLotDataTable.RowStateFilter = DataViewRowState.CurrentRows;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnAddClick()
        {
            try
            {
                bIsAdd = true;
                DataRowView dvRow = SingleLotDataTable.AddNew();
                selectedRowValue = dvRow;
                DataRow row = this.selectedRowValue.Row;

                selectedRowValue.EndEdit();
                selectedRowValue.Row.AcceptChanges();
                SingleLotDataTable.ToTable().AcceptChanges();
                //SelectedRowIndex = ConfigDataTable.Count;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnSaveDraftClick()
        {
            try
            {
                if (bIsSaveDraft)
                {
                    strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
                    strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                    strTrackTime = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

                    DataTable dbChanged = SingleLotDataTable.Table;
                    DataTable dbEdit = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "New");
                    DataTable dbAdd = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Add");
                    DataTable dbDelete = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Delete");

                    string strJson = GetChangeDataToJson(dbChanged);
                    SaveChangeDataToHistory("SaveDraft");
                    SaveChangeDataToChangeRequest(strJson, "Draft");

                    bIsSaveDraft = false;
                }
                else
                {

                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnSubmitClick()
        {
            SaveChangeDataToE3();
        }

        void OnDeleteClick()
        {
            try
            {
                if (this.selectedRowValue == null)
                {
                    MessageBox.Show("Row is not selected!");
                    return;
                }

                selectedRowValue.Row.Delete();

                bIsSaveDraft = true;
                bIsSubmit = true;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region
        string GetChangeDataToJson(DataTable dbChange)
        {
            string strJson = string.Empty;
            try
            {
                DataTable dbOld = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Old");
                DataTable dbEdit = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Edit");
                DataTable dbAdd = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Add");
                DataTable dbDelete = DataTableHelp.GetChangedDataTableToJson(dbChange, "Status", "Delete");

                dbEdit.Merge(dbOld, false);

                string strSort = string.Empty;
                foreach (var str in strListColumnKey)
                {
                    strSort += str + ",";
                }
                strSort = strSort + "Status DESC";
                dbEdit.DefaultView.Sort = strSort;
                dbEdit = dbEdit.DefaultView.ToTable();

                OpertionRecord.dbAdd = dbAdd.Copy();
                OpertionRecord.dbEdit = dbEdit.Copy();
                OpertionRecord.dbDelete = dbDelete.Copy();
                OpertionRecord.dbSource = dbSource.Copy();

                strJson = JsonHelp.SerializeObject(OpertionRecord);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strJson;
        }

        void SaveChangeDataToE3()
        {
            string contentAdd = string.Empty;
            string contentModify = string.Empty;
            string contentDelete = string.Empty;
            try
            {
                DataTable dbChanged = SingleLotDataTable.Table;

                DataTable dbEdit = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Edit");
                DataTable dbAdd = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Add");
                DataTable dbDelete = DataTableHelp.GetChangedDataTable(dbChanged, "Status", "Delete");

                //dbDelete = DataTableHelp.GetExist(dbSource, dbDelete);

                contentAdd = GetChangedJson(dbAdd);
                contentModify = GetChangedJson(dbEdit);
                contentDelete = GetChangedJson(dbDelete);
                if (contentAdd.Equals("") && contentModify.Equals("") && contentDelete.Equals(""))
                {
                }
                else
                {
                    bool flag = this.SingleLotService.R2R_UI_Config_Update(strRequestId, strUserId, strClientVersion, strSelectedModel, strTableName, contentModify, contentAdd, contentDelete);

                    if (flag)
                    {
                        if (bIsSubmit)
                        {
                            strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
                            strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
                            strTrackTime = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

                            string strJson = GetChangeDataToJson(dbChanged);
                            SaveChangeDataToHistory("Submit");
                            SaveChangeDataToChangeRequest(strJson, "Submit");

                            bIsSubmit = false;
                        }
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

        }

        void SaveChangeDataToHistory(string strAction)
        {
            try
            {
                CfgHistoryManager cmHistory = new CfgHistoryManager();
                ConfigHistoryModel cfgHistoryModel = new ConfigHistoryModel();
                cfgHistoryModel.CrId = strCrId;
                cfgHistoryModel.Module = strSelectedModel;
                cfgHistoryModel.TbName = strTableName;
                cfgHistoryModel.TimeStamp = strTimeStamp;
                cfgHistoryModel.UserId = strUserId;
                cfgHistoryModel.Action = strAction;
                cmHistory.Insert(cfgHistoryModel);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void SaveChangeDataToChangeRequest(string strJson, string strStatus)
        {
            try
            {
                CfgChangeRequestManager cmChangeRequest = new CfgChangeRequestManager();
                ConfigChangeRequestModel cfgChangModel = new ConfigChangeRequestModel();
                cfgChangModel.CrId = strCrId;
                cfgChangModel.Module = strSelectedModel;
                cfgChangModel.TbName = strTableName;
                cfgChangModel.UserId = strUserId;
                cfgChangModel.TimeStamp = strTimeStamp;
                cfgChangModel.SubTb1 = strTableName;
                cfgChangModel.Json1 = strJson;
                cfgChangModel.SubTb2 = "";
                cfgChangModel.Json2 = "";
                cfgChangModel.Category = "Test";
                cfgChangModel.Comment = "MyTest";
                cfgChangModel.Status = strStatus;
                cfgChangModel.TrackTime = strTrackTime;
                cfgChangModel.UserModify = "zqk";
                cfgChangModel.Reason = "Test";
                cmChangeRequest.Insert(cfgChangModel);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        string GetChangedJson(DataTable db)
        {
            string json = string.Empty;
            try
            {
                if (db.Rows.Count > 0)
                {
                    CurrentEntity.ColumnData = this.SingleLotService.DataTableConvert(db, strListColumnName);
                    json = JsonHelp.SerializeObject(CurrentEntity);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return json;
        }
        #endregion
    }
}
