﻿using ConfigManagement.ViewModels;
using ConfigManagement.Views;
using ConfigurationService.Models;
using ConfigurationService.IService;
using Microsoft.Win32;
using ORM.Dao;
using ORM.Models;
using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using R2R.Common.Data.CommonEntity;
using Prism.Ioc;
using Prism.Regions;
using Prism.Events;
using R2R.Client.Framework.Events;

namespace ConfigManagement.ViewModels
{
    public class ConfigMainViewModel : ViewModelBase
    {
        public ConfigMainViewModel()
        {

        }

        IRegionManager _regionManager;
        public ISingleLotService SingleLotService { get; set; }
        public IConfigMainService ConfigMainService { get; set; }
        public ConfigMainViewModel(IConfigMainService configMainService, ISingleLotService singleLotService, IRegionManager regionManager)
        {
            _regionManager = regionManager;

            this.SingleLotService = singleLotService;
            this.ConfigMainService = configMainService;

            Title = "ConfigMain";

            //this.moduleList = configMainService.GetModuleList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
            this.moduleList = new List<string>() { "LITHO", "ETCH", "CMP" };
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            try
            {
                _journal = navigationContext.NavigationService.Journal;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        public override bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        void InitParam()
        {
            TableNameList = new List<string>();
            strTableName = string.Empty;
            ColumnNameList = new List<string>();
            keyColumnList = new List<string>();
            dbStructure = new DataTable();
        }

        #region Variable
        string strRequestId;
        string strUserId;
        string strClientVersion;
        string strSelectedModel;
        string strTableName;
        List<string> keyColumnList = new List<string>();
        List<string> ColumnNameList = new List<string>();
        List<Type> ColumnTypeList = new List<Type>();
        DataTable dbStructure = new DataTable("dbStructure");
        #endregion

        #region Field
        private SendToSingleLotParam _SendParam;
        public SendToSingleLotParam SendParam
        {
            get { return this._SendParam; }
            set { SetProperty(ref this._SendParam, value); }
        }

        private string module;
        public string Module
        {
            get { return this.module; }
            set { SetProperty(ref this.module, value); }
        }

        private List<string> moduleList;
        public List<string> ModuleList
        {
            get { return this.moduleList; }
            set { SetProperty(ref this.moduleList, value); }
        }

        private string _SelectTableName;
        public string SelectTableName
        {
            get { return this._SelectTableName; }
            set { SetProperty(ref this._SelectTableName, value); }
        }

        private List<string> _TableNameList;
        public List<string> TableNameList
        {
            get { return this._TableNameList; }
            set { SetProperty(ref this._TableNameList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _ModuleSelectionChangedCommand;
        public DelegateCommand ModuleSelectionChangedCommand =>
            _ModuleSelectionChangedCommand ?? (_ModuleSelectionChangedCommand = new DelegateCommand(OnModuleSelectionChanged));

        private DelegateCommand _TableNameSelectionChangedCommand;
        public DelegateCommand TableNameSelectionChangedCommand =>
            _TableNameSelectionChangedCommand ?? (_TableNameSelectionChangedCommand = new DelegateCommand(OnTableNameSelectionChanged));

        //private DelegateCommand _LithoMainCommand;
        //public DelegateCommand LithoMainCommand =>
        //    _LithoMainCommand ?? (_LithoMainCommand = new DelegateCommand(OnLithoMainClick));

        //private DelegateCommand _SingleLotCommand;
        //public DelegateCommand SingleLotCommand =>
        //    _SingleLotCommand ?? (_SingleLotCommand = new DelegateCommand(OnSingleLotClick));
        #endregion

        #region Event Fun
        void OnModuleSelectionChanged()
        {
            try
            {
                InitParam();
                strClientVersion = "7.8.0.43";
                strUserId = "Administrator";
                strRequestId = "RequestId_23";
                strSelectedModel = module;
                CfgGetTableListResult result = new CfgGetTableListResult();
                result = ConfigMainService.R2R_UI_Config_Get_TableList(strUserId, strClientVersion, strRequestId, strSelectedModel);
                if (result != null && result.ReturnCode.Equals("0"))
                {
                    TableNameList = result.TableList.ToList();
                }
                else
                {
                    SetSendParam();
                    ShowSingleLotView();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnTableNameSelectionChanged()
        {
            if (SelectTableName != null)
            {
                GetTableStructure();
                SetSendParam();
            }
            ShowSingleLotView();
        }

        void OnLithoMainClick()
        {
            SetSendParam();
            ShowLithoMainView();
        }

        void OnSingleLotClick()
        {
            SetSendParam();
            ShowSingleLotView();
        }

        #endregion

        #region
        void ShowLithoMainView()
        {
            try
            {
                var parameters = new NavigationParameters();
                parameters.Add("Message", SendParam);

                _regionManager.RequestNavigate("ContentRegion", "LithoMain", parameters);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void ShowSingleLotView()
        {
            try
            {
                var parameters = new NavigationParameters();
                parameters.Add("Message", SendParam);

                _regionManager.RequestNavigate("ContentRegion", "SingleLot", parameters);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void GetTableStructure()
        {
            strRequestId = "RequestId_86";
            strUserId = "Administrator";
            strClientVersion = "7.8.0.43";
            strSelectedModel = "LITHO";
            strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";
            strSelectedModel = module;
            strTableName = SelectTableName;

            try
            {
                ColumnNameList.Clear();
                keyColumnList.Clear();
                ColumnTypeList.Clear();
                dbStructure = new DataTable();

                CfgGetEntity eneity = new CfgGetEntity();
                List<string> queryContextsTmp = new List<string>();
                string[] queryContexts = queryContextsTmp.ToArray();
                eneity = this.SingleLotService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strTableName, queryContexts, true);

                if (eneity != null)
                {
                    ColumnNameList = this.SingleLotService.GetColumnName(eneity.ColumnFormat);
                    keyColumnList = this.SingleLotService.GetColumnKeyName(eneity.ColumnFormat);
                    ColumnTypeList=this.SingleLotService.GetColumnType(eneity.ColumnFormat);

                    dbStructure = DataTableHelp.CreateDataTable(ColumnNameList, ColumnTypeList);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void SetSendParam()
        {
            try
            {
                SendParam = new SendToSingleLotParam();
                SendParam.RequestId = strRequestId;
                SendParam.UserId = strUserId;
                SendParam.ClientVersion = strClientVersion;
                SendParam.SelectedModel = strSelectedModel;
                SendParam.TableName = strTableName;
                SendParam.ColumnNameList = ColumnNameList;
                SendParam.ColumnKeyName = keyColumnList;
                SendParam.TableStructure = dbStructure;
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
