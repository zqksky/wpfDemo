﻿using ConfigurationService.Models;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagement.ViewModels
{
    public class ViewPendingCRViewModel : ViewModelBase
    {
        public ViewPendingCRViewModel()
        {
            Title = "View PendingCR";
        }

        #region
        private ObservableCollection<ViewPendingCRModel> _ViewPendingCRList;
        public ObservableCollection<ViewPendingCRModel> ViewPendingCRList
        {
            get { return _ViewPendingCRList; }
            set { SetProperty(ref _ViewPendingCRList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _RollbackCommand;
        public DelegateCommand CRDetailCommand =>
            _RollbackCommand ?? (_RollbackCommand = new DelegateCommand(OnRollback));
        #endregion

        #region Event Fun
        void OnRollback()
        {

        }
        #endregion
    }
}
