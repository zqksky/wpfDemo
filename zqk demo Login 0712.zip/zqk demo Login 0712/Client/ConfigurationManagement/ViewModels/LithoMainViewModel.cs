﻿using ConfigurationService.IService;
using ConfigurationService.Models;
using ConfigurationService.Models;
using Prism.Regions;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigManagement.ViewModels
{
    public class LithoMainViewModel : ViewModelBase
    {
        public LithoMainViewModel()
        {

        }

        public ILithoMainService LithoMainService { get; set; }
        public LithoMainViewModel(ILithoMainService lithoMainService)
        {
            this.LithoMainService = lithoMainService;
            Title = "LithoMain";

            this.ToolList = new List<string>() { "Tool1", "Tool2", "Tool3" };
            this.ProductList = new List<string>() { "Product1", "Product2", "Product3" };
            this.LayerList = new List<string>() { "Layer1", "Layer2", "Layer3" };
            this.ReticleList = new List<string>() { "Reticle1", "Reticle2", "Reticle3" };

            LithoMainInfoList = new ObservableCollection<LithoMainModel>();
            LithoMainInfoList.Add(new LithoMainModel() {Tool="Tool", Product="Product",Layer="Layer",Reticle="Reticle"});
        }

        IRegionNavigationJournal _journal;
        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            _journal = navigationContext.NavigationService.Journal;

            var m = navigationContext.Parameters["Message"] as SendToSingleLotParam;
            if (m != null)
                SendParam = m;
        }

        #region Field
        private SendToSingleLotParam _SendParam;
        public SendToSingleLotParam SendParam
        {
            get { return this._SendParam; }
            set { SetProperty(ref this._SendParam, value); }
        }

        private string product;
        public string Product
        {
            get { return this.product; }
            set { SetProperty(ref this.product, value); }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private string layer;
        public string Layer
        {
            get { return this.layer; }
            set { SetProperty(ref this.layer, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string tool;
        public string Tool
        {
            get { return this.tool; }
            set { SetProperty(ref this.tool, value); }
        }

        private List<string> toolList;
        public List<string> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }

        private string reticle;
        public string Reticle
        {
            get { return this.reticle; }
            set { SetProperty(ref this.reticle, value); }
        }

        private List<string> reticleList;
        public List<string> ReticleList
        {
            get { return this.reticleList; }
            set { SetProperty(ref this.reticleList, value); }
        }

        private LithoMainModel _SelectedKeyRow;
        public LithoMainModel SelectedKeyRow
        {
            get { return this._SelectedKeyRow; }
            set { SetProperty(ref this._SelectedKeyRow, value); }
        }

        private ObservableCollection<LithoMainModel> _LithoMainInfoList;
        public ObservableCollection<LithoMainModel> LithoMainInfoList
        {
            get { return _LithoMainInfoList; }
            set { SetProperty(ref _LithoMainInfoList, value); }
        }
        #endregion
    }
}
