﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;

namespace ConfigurationManagement
{
    public class SetValidationRule : ValidationRule
    {
        public static string errormessage = string.Empty;
        public override ValidationResult Validate(object value,  System.Globalization.CultureInfo cultureInfo)
        {
            errormessage = "";
            if (value is BindingGroup)
            {
                BindingGroup group = (BindingGroup)value;
                //foreach (var item in group.Items)
                //{
                //    DataRowView row = item as DataRowView;
                //    if (string.IsNullOrEmpty(st.Name.Trim()) || string.IsNullOrEmpty(st.Sex.Trim()) || string.IsNullOrEmpty(st.Num.Trim()))
                //    {
                //        errormessage = "姓名、性别、成绩都不能为空！";
                //        return new ValidationResult(false, "姓名、性别、成绩都不能为空！");
                //    }
                //    //Num为A或B则通过，为C则为不通过。
                //    if ((st.Num.Equals("C") && st.Chek) || ((st.Num.Equals("A") || st.Num.Equals("B")) && !st.Chek))
                //    {
                //        errormessage = "分数等级与是否通过不符！";
                //        return new ValidationResult(false, "分数等级与是否通过不符！");
                //    }
                //}              
            }
            return ValidationResult.ValidResult;
        }
    }
}
