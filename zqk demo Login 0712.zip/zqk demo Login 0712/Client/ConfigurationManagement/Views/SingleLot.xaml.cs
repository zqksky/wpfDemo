﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConfigManagement.Views
{
    /// <summary>
    /// Interaction logic for SingleLot.xaml
    /// </summary>
    public partial class SingleLot : UserControl
    {
        public SingleLot()
        {
            InitializeComponent();
        }


        private void grd_CellEditEndingChanged(object sender, DataGridCellEditEndingEventArgs e)
        {
            //var dgv = sender as DataGrid;

            //int rowIndex = -1;

            //rowIndex = dgv.SelectedIndex;//获取选中单元格行号
            //DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowIndex);//获取选中单元格所在行
            //row.Background = new SolidColorBrush(Colors.Red);


            //CellEditChangColor(dgv);
        }

        #region 选中单元格变色或编辑单元格后变色
        void CellEditChangColor(DataGrid dgv)
        {
            int colindex = -1;
            int rowindex = -1;

            colindex = dgv.CurrentCell.Column.DisplayIndex;//获取选中单元格列号
            rowindex = dgv.SelectedIndex;//获取选中单元格行号
            DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowindex);//获取选中单元格所在行
            DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);//函数调用，获取行中所有单元格的集合
            DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);//锁定选中单元格（重点）
            if (cell != null)
            {
                dgv.ScrollIntoView(row, dgv.Columns[colindex]);
                cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);
                cell.Focus();
                cell.Background = new SolidColorBrush(Colors.DarkOrange);//OK!问题解决，选中单元格变色
                cell.Focusable = false;
            }
        }
        //获取行中所有单元格集合的函数
        public static T GetVisualChild<T>(Visual parent) where T : Visual
        {
            T childContent = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                childContent = v as T;
                if (childContent == null)
                {
                    childContent = GetVisualChild<T>(v);
                }
                if (childContent != null)
                { break; }
            }
            return childContent;
        }
        #endregion
    }
}
