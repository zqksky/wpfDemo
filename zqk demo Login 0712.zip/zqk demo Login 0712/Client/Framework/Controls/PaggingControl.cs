﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Collections.ObjectModel;
using System.Windows.Data;
using System.Windows.Input;
using R2R.Client.Framework.Interfaces;
using System.Collections;
using System.Threading;
using System.Windows.Threading;

namespace R2R.Client.Framework.Controls
{
    //,
    //TemplatePart(Name = "PART_PageSizesCombobox", Type = typeof(ComboBox))
    //
    //
    [
    TemplatePart(Name = "PART_FirstPageButton", Type = typeof(Button)),
    TemplatePart(Name = "PART_PreviousPageButton", Type = typeof(Button)),
    TemplatePart(Name = "PART_NextPageButton", Type = typeof(Button)),
    TemplatePart(Name = "PART_LastPageButton", Type = typeof(Button))]
    public class PaggingControl : Control
    {
        #region CUSTOM CONTROL VARIABLES

        protected Button btnFirstPage, btnPreviousPage, btnNextPage, btnLastPage;
        // protected TextBox txtPage;
        //protected ComboBox cmbPageSizes;

        #endregion

        #region PROPERTIES

        public static readonly DependencyProperty ItemsSourceProperty;
        public static readonly DependencyProperty PageProperty;
        public static readonly DependencyProperty SelectedPageSizeProperty;
        public static readonly DependencyProperty TotalPagesProperty;
        public static readonly DependencyProperty TotalRecordsProperty;
        //public static readonly DependencyProperty PageSizesProperty;
        public static readonly DependencyProperty PageContractProperty;
        public static readonly DependencyProperty FilterTagProperty;

        public ObservableCollection<object> ItemsSource
        {
            get
            {
                return GetValue(ItemsSourceProperty) as ObservableCollection<object>;
            }
            protected set
            {
                SetValue(ItemsSourceProperty, value);
            }
        }

        public uint Page
        {
            get
            {
                return (uint)GetValue(PageProperty);
            }
            set
            {
                SetValue(PageProperty, value);
            }
        }

        public uint SelectedPageSize
        {
            get
            {
                return (uint)GetValue(SelectedPageSizeProperty);
            }
            set
            {
                SetValue(SelectedPageSizeProperty, value);
            }
        }

        public uint TotalPages
        {
            get
            {
                return (uint)GetValue(TotalPagesProperty);
            }
            protected set
            {
                SetValue(TotalPagesProperty, value);
            }
        }

        public uint TotalRecords
        {
            get
            {
                return (uint)GetValue(TotalRecordsProperty);
            }
            protected set
            {
                SetValue(TotalRecordsProperty, value);
            }
        }

        //public ArrayList PageSizes
        //{
        //    get
        //    {
        //        return GetValue(PageSizesProperty) as ArrayList;
        //    }
        //    set
        //    {
        //        SetValue(PageSizesProperty, value);
        //    }
        //}

        public IPageController PageContract
        {
            get
            {
                return GetValue(PageContractProperty) as IPageController;
            }
            set
            {
                SetValue(PageContractProperty, value);
            }
        }

        public object FilterTag
        {
            get
            {
                return GetValue(FilterTagProperty);
            }
            set
            {
                SetValue(FilterTagProperty, value);
            }
        }

        #endregion

        #region EVENTS

        public delegate void PageChangedEventHandler(object sender, PageChangedEventArgs args);

        public static readonly RoutedEvent PreviewPageChangeEvent;
        public static readonly RoutedEvent PageChangedEvent;

        public event PageChangedEventHandler PreviewPageChange
        {
            add
            {
                AddHandler(PreviewPageChangeEvent, value);
            }
            remove
            {
                RemoveHandler(PreviewPageChangeEvent, value);
            }
        }

        public event PageChangedEventHandler PageChanged
        {
            add
            {
                AddHandler(PageChangedEvent, value);
            }
            remove
            {
                RemoveHandler(PageChangedEvent, value);
            }
        }

        #endregion

        #region CONTROL CONSTRUCTORS

        static PaggingControl()
        {
            ItemsSourceProperty = DependencyProperty.Register("ItemsSource", typeof(ObservableCollection<object>), typeof(PaggingControl), new PropertyMetadata(new ObservableCollection<object>()));
            PageProperty = DependencyProperty.Register("Page", typeof(uint), typeof(PaggingControl));
            SelectedPageSizeProperty = DependencyProperty.Register("SelectedPageSize", typeof(uint), typeof(PaggingControl));
            TotalPagesProperty = DependencyProperty.Register("TotalPages", typeof(uint), typeof(PaggingControl));
            TotalRecordsProperty = DependencyProperty.Register("TotalRecords", typeof(uint), typeof(PaggingControl));

            PageContractProperty = DependencyProperty.Register("PageContract", typeof(IPageController), typeof(PaggingControl));
            FilterTagProperty = DependencyProperty.Register("FilterTag", typeof(object), typeof(PaggingControl), new PropertyMetadata(OnFilterTagChanged));

            PreviewPageChangeEvent = EventManager.RegisterRoutedEvent("PreviewPageChange", RoutingStrategy.Bubble, typeof(PageChangedEventHandler), typeof(PaggingControl));
            PageChangedEvent = EventManager.RegisterRoutedEvent("PageChanged", RoutingStrategy.Bubble, typeof(PageChangedEventHandler), typeof(PaggingControl));
        }

        private static void OnFilterTagChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var paggingControl = d as PaggingControl;
            if (paggingControl.FilterTag != null)
            {
                paggingControl.Reset();
            }
        }

        public PaggingControl()
        {
        }

        ~PaggingControl()
        {
            UnregisterEvents();
        }

        #endregion

        #region EVENTS


        void btnFirstPage_Click(object sender, RoutedEventArgs e)
        {
            Navigate(PageChanges.First);
        }

        void btnPreviousPage_Click(object sender, RoutedEventArgs e)
        {
            Navigate(PageChanges.Previous);
        }

        void btnNextPage_Click(object sender, RoutedEventArgs e)
        {
            Navigate(PageChanges.Next);
        }

        void btnLastPage_Click(object sender, RoutedEventArgs e)
        {
            Navigate(PageChanges.Last);
        }

        void cmbPageSizes_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            Navigate(PageChanges.Current);
        }

        #endregion

        #region INTERNAL METHODS

        public override void OnApplyTemplate()
        {
            btnFirstPage = this.Template.FindName("PART_FirstPageButton", this) as Button;
            btnPreviousPage = this.Template.FindName("PART_PreviousPageButton", this) as Button;
            btnNextPage = this.Template.FindName("PART_NextPageButton", this) as Button;
            btnLastPage = this.Template.FindName("PART_LastPageButton", this) as Button;
            //txtPage = this.Template.FindName("PART_PageTextBox", this) as TextBox;

            if (btnFirstPage == null ||
                btnPreviousPage == null ||
                btnNextPage == null ||
                btnLastPage == null )
            {
                throw new Exception("Invalid Control template.");
            }

            if (!DesignModeHelper.IsInDesignMode)
            {
                if (Template == null)
                {
                    throw new Exception("Control template not assigned.");
                }

                if (PageContract != null)
                {
                    RegisterEvents();
                    SetDefaultValues();
                }
            }
            base.OnApplyTemplate();
        }


        private void RegisterEvents()
        {
            btnFirstPage.Click += new RoutedEventHandler(btnFirstPage_Click);
            btnPreviousPage.Click += new RoutedEventHandler(btnPreviousPage_Click);
            btnNextPage.Click += new RoutedEventHandler(btnNextPage_Click);
            btnLastPage.Click += new RoutedEventHandler(btnLastPage_Click);
            //txtPage.KeyDown += TxtPage_KeyDown;
        }

        //private void TxtPage_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        //{
        //    if (e.Key == System.Windows.Input.Key.Enter)
        //    {
        //        uint currentPage = Page;
        //        bool isSuccess = UInt32.TryParse(txtPage.Text, out currentPage);
        //        if (isSuccess)
        //        {
        //            Page = currentPage;
        //            Navigate(PageChanges.Current);
        //        }
        //        else
        //        {
        //            txtPage.Text = Page.ToString();
        //            txtPage.SelectAll();
        //        }
        //    }
        //}

        private void UnregisterEvents()
        {
            btnFirstPage.Click -= btnFirstPage_Click;
            btnPreviousPage.Click -= btnPreviousPage_Click;
            btnNextPage.Click -= btnNextPage_Click;
            btnLastPage.Click -= btnLastPage_Click;
            //txtPage.KeyDown -= TxtPage_KeyDown;
        }

        private void SetDefaultValues()
        {
            ItemsSource = new ObservableCollection<object>();
        }


        private void RaisePageChanged(uint OldPage, uint NewPage)
        {
            PageChangedEventArgs args = new PageChangedEventArgs(PageChangedEvent, OldPage, NewPage, TotalPages);
            RaiseEvent(args);
        }

        private void RaisePreviewPageChange(uint OldPage, uint NewPage)
        {
            PageChangedEventArgs args = new PageChangedEventArgs(PreviewPageChangeEvent, OldPage, NewPage, TotalPages);
            RaiseEvent(args);
        }

        public void Reset()
        {
            StartDelayTimer();
        }

        DispatcherTimer _resetDelayTimer;

        private void StartDelayTimer()
        {
            if (_resetDelayTimer == null)
            {
                _resetDelayTimer = new DispatcherTimer();
                _resetDelayTimer.Tick += _resetDelayTimer_Tick;
                _resetDelayTimer.Interval = TimeSpan.FromMilliseconds(10);
                _resetDelayTimer.Start();
            }
            else
            {
                _resetDelayTimer.Stop();
                _resetDelayTimer.Start();
            }
        }

        private void StopDelayTimer()
        {
            if (_resetDelayTimer != null)
            {
                _resetDelayTimer.Stop();
                _resetDelayTimer.Tick -= _resetDelayTimer_Tick;
                _resetDelayTimer = null;
            }
        }

        private void _resetDelayTimer_Tick(object sender, EventArgs e)
        {
            StopDelayTimer();
            ItemsSource = new ObservableCollection<object>();
            Page = 0;
            Navigate(PageChanges.First);
        }

        private void Navigate(PageChanges change)
        {
            uint newPageSize;

            if (PageContract == null)
            {
                return;
            }


            TotalRecords = PageContract.GetTotalCount(FilterTag);
            newPageSize = SelectedPageSize;

            if (TotalRecords == 0)
            {
                ItemsSource.Clear();
                TotalPages = 1;
                Page = 1;
            }
            else
            {
                TotalPages = (TotalRecords / newPageSize) + (uint)((TotalRecords % newPageSize == 0) ? 0 : 1);
            }

            uint newPage = 1;

            switch (change)
            {
                case PageChanges.First:
                    if (Page == 1)
                    {
                        return;
                    }
                    break;
                case PageChanges.Previous:
                    newPage = (Page - 1 > TotalPages) ? TotalPages : (Page - 1 < 1) ? 1 : Page - 1;
                    break;
                case PageChanges.Current:
                    newPage = (Page > TotalPages) ? TotalPages : (Page < 1) ? 1 : Page;
                    break;
                case PageChanges.Next:
                    newPage = (Page + 1 > TotalPages) ? TotalPages : Page + 1;
                    //(Page + 1) < 1 ? 1 :
                    break;
                case PageChanges.Last:
                    if (Page == TotalPages)
                    {
                        return;
                    }
                    newPage = TotalPages;
                    break;
                default:
                    break;
            }

            uint startRowNo = (newPage - 1) * newPageSize + 1;

            uint oldPage = Page;
            RaisePreviewPageChange(Page, newPage);

            Page = newPage;
            ItemsSource.Clear();

            using (new BusyIndicator())
            {
                var fetchData = PageContract.GetRecordsBy(startRowNo, newPageSize, FilterTag);
                if (fetchData == null)
                {
                    ItemsSource = new ObservableCollection<object>();
                }
                else
                {
                    var newSource = new ObservableCollection<object>();
                    newSource.AddRange(fetchData);
                    ItemsSource = newSource;
                }
            }

            RaisePageChanged(oldPage, Page);
        }

        #endregion
    }

    public enum PageChanges
    {
        First,
        Previous,
        Current,
        Next,
        Last
    }

    public class PageChangedEventArgs : RoutedEventArgs
    {
        #region PRIVATE VARIABLES

        private uint _OldPage, _NewPage, _TotalPages;

        #endregion

        #region PROPERTIES

        public uint OldPage
        {
            get
            {
                return _OldPage;
            }
        }

        public uint NewPage
        {
            get
            {
                return _NewPage;
            }
        }

        public uint TotalPages
        {
            get
            {
                return _TotalPages;
            }
        }

        #endregion

        #region CONSTRUCTOR

        public PageChangedEventArgs(RoutedEvent EventToRaise, uint OldPage, uint NewPage, uint TotalPages)
            : base(EventToRaise)
        {
            _OldPage = OldPage;
            _NewPage = NewPage;
            _TotalPages = TotalPages;
        }

        #endregion
    }
}
