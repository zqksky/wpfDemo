﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace R2R.Client.Framework.Controls
{
    public class AnimatedContentControl : ContentControl
    {
        public static readonly RoutedEvent SelectionChangingEvent = EventManager.RegisterRoutedEvent(
            "SelectionChanging", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(AnimatedContentControl));

        private DispatcherTimer timer;

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
        }
    }
}
