﻿namespace R2R.Client.Framework
{
    public class ClientInfo
    {
        public static string CurrentUser { get; set; }
        public static string CurrentVersion { get; set; }
        public static string CurrentServer { get; set; }
    }
}