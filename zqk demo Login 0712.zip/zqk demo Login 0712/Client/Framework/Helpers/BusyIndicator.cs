﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace R2R.Client.Framework
{

    /// <summary>
    /// A busy indicator that can be used in a Using block to wrap some time-consuming codes.
    /// It will change the cursor to Wait cursor in application level when using begins, and restore the original cursor
    /// when using ends.
    /// NOTE: don't let any popup (error processing or MessageWindow show) happen inside the using, 
    /// because the cursor will always be wait cursor inside the using.
    /// </summary>
    public class BusyIndicator : IDisposable
    {
        private Cursor _previousCursor;

        /// <summary>
        /// A busy indicator that can be used in a Using block to wrap some time-consuming codes.
        /// It will change the cursor to Wait cursor in application level when using begins, and restore the original cursor
        /// when using ends.
        /// NOTE: don't let any popup (error processing or MessageWindow show) happen inside the using, 
        /// because the cursor will always be wait cursor inside the using.
        /// </summary>
        public BusyIndicator()
        {
            try
            {
                _previousCursor = Mouse.OverrideCursor;

                Mouse.OverrideCursor = Cursors.Wait;
            }
            catch
            { }
        }

        #region IDisposable Members

        public void Dispose()
        {
            try
            {
                Mouse.OverrideCursor = _previousCursor;
            }
            catch
            { }
        }

        #endregion
    }
}
