﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.Framework.Constants
{
    public class Formats
    {
        // default datetime format
        public const string FACTORYworksDateFormat = "yyyyMMdd HHmmssfff";


    }
}
