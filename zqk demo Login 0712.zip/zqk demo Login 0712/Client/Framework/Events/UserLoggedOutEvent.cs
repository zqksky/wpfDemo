﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prism.Events;

namespace R2R.Client.Framework.Events
{
    public class UserLoggedOutEvent : PubSubEvent<string>
    {
    }
}
