﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using R2R.Client.Common;
using R2R.Common.Data;
using CommonServiceLocator;
using Prism;
using Prism.Commands;
using Prism.Events;
using Prism.Ioc;
using Prism.Mvvm;
using Prism.Regions;
using R2R.Common.DAL;
using R2R.Client.Framework.Interfaces;

namespace R2R.Client.Framework
{
    public abstract class ViewModelBase : BindableBase, INavigationAware, IActiveAware
    {
        public IEventAggregator EventAggregator { get; private set; }
        public IRegionManager RegionManager { get; private set; }
        public IErrorHandler ErrorHandler { get; private set; }

        private bool closeButtonEnalbed = true;
        public bool CloseButtonEnabled
        {
            get { return closeButtonEnalbed; }
            set { SetProperty(ref closeButtonEnalbed, value); }
        }

        private DelegateCommand closeViewCommand;
        public DelegateCommand CancelCommand =>
            closeViewCommand ?? (closeViewCommand = new DelegateCommand(CloseView));

        protected virtual void CloseView()
        {
            var view = NavigationContext.NavigationService.Region.Views.Single((v) => v is FrameworkElement && ((FrameworkElement)v).DataContext == this);

            var cancelEventArgs = new CancelEventArgs();
            OnPreviewClosing(cancelEventArgs);

            if(!cancelEventArgs.Cancel)
            {
                OnCleanUp();
                NavigationContext.NavigationService.Region.Remove(view);
            }
        }

        protected virtual void OnCleanUp()
        {

        }

        protected virtual void OnPreviewClosing(CancelEventArgs e)
        {

        }


        private DelegateCommand _submitCommand;
        public DelegateCommand SubmitCommand =>
            _submitCommand ?? (_submitCommand = new DelegateCommand(OnSubmit));

        protected virtual void OnSubmit()
        {

        }

        public ViewModelBase()
        {
            EventAggregator = ServiceLocator.Current.GetInstance<IEventAggregator>();
            RegionManager = ServiceLocator.Current.GetInstance<IRegionManager>();
            ErrorHandler = ServiceLocator.Current.GetInstance<IErrorHandler>();
        }

        private string _title = "New Page";

        #region IActiveAware members
        public event EventHandler IsActiveChanged;
        bool _isActive;
        public bool IsActive
        {
            get { return _isActive; }
            set
            {
                _isActive = value;
                OnIsActiveChanged();
            }
        }
        private void OnIsActiveChanged()
        {
            IsActiveChanged?.Invoke(this, new EventArgs());
        }
        #endregion

        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        public NavigationContext NavigationContext { get; private set; }

        #region INavigationAware methods
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        //
        // Note: RequestNavigate must have call back to handle exceptions that may be thrown in the methods of these region.
        //
        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        public virtual void OnNavigatedTo(NavigationContext navigationContext)
        {
            // base method is empty. no need to call.
            NavigationContext = navigationContext;
        }

        public virtual bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public virtual void OnNavigatedFrom(NavigationContext navigationContext)
        {
            // base method is empty. no need to call.
        }
        #endregion

        protected void SetStatusText(string statusText)
        {
            EventAggregator.GetEvent<StatusUpdatedEvent>().Publish(statusText);
        }
    }
}
