﻿using System.Reflection;
using R2R.Client.Common;
using R2R.Common.Library;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using R2R.Client.Shell.Views;

namespace R2R.Client.Shell
{
    public class ShellModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {

        }        
    }
}