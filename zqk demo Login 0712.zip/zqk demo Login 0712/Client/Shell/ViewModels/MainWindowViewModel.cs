﻿using System.Windows;
using R2R.Client.Common;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Library;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using R2R.Client.Shell.Views;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using R2R.Common.Data;
using LoginManagement;
using LoginManagement.ViewModels;
using LoginManagement.Views;
using Prism.Ioc;
using LoginService.Models;
using LoginManagement.Event;

namespace R2R.Client.Shell.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        #region
        IEventAggregator ea;
        IContainerExtension _container;
        IRegionManager _regionManager;
        IRegion _region;
        Login loginView;

        public DelegateCommand LoadDataCommand { get; private set; }

        public MainWindowViewModel(IContainerExtension Container, IRegionManager regionManager, IEventAggregator eventAggregator)
        {
            Title = "R2R Client";
            VersionText = "Version:1.0.0";
            UserName = "Test";
            CurrentServer = "Localhost";
            EventAggregator.GetEvent<StatusUpdatedEvent>().Subscribe(OnStatusUpdatedEvent);

            _regionManager = regionManager;
            _container = Container;
            LoadDataCommand = new DelegateCommand(loadData);

            #region 接受登陆消息
            ea = eventAggregator;
            ea.GetEvent<LoginSentEvent>().Subscribe(MessageReceived);
            #endregion
        }

        private void MessageReceived(LoginInfo info)
        {
            if (info.LoginState==1)
            {
                _region.Deactivate(loginView);

                Title = "Client";
                Width = "1440";
                Height = "900";
                LoginVisiable = Visibility.Collapsed;
                MenuVisiable = Visibility.Visible;
                WinState = WindowState.Maximized;

                UserName = info.UserName;
                Password = info.Password;
                DomainName = info.DomainName;
                ServerAddress = info.ServerAddress;

                ClientInfo.CurrentServer = info.ServerAddress;
                ClientInfo.CurrentUser = info.UserName;
                ClientInfo.CurrentVersion = VersionText;
            }
            else if (info.LoginState == 2)
            {

            }
            else if(info.LoginState == 3)
            {
                Application.Current.MainWindow.Close();
            }
        }

        private void loadData()
        {
            _region = _regionManager.Regions["MainRegionLogin"];
            loginView = _container.Resolve<Login>();

            Title = "Login";
            Width = "500";
            Height = "400";
            _region.Add(loginView);
        }
        #endregion

        #region
        private string _title = "Prism Unity Application";
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        private string _Width = "500";
        public string Width
        {
            get { return _Width; }
            set { SetProperty(ref _Width, value); }
        }

        private string _Height = "400";
        public string Height
        {
            get { return _Height; }
            set { SetProperty(ref _Height, value); }
        }

        private WindowState _WinState = WindowState.Normal;
        public WindowState WinState
        {
            get { return _WinState; }
            set { SetProperty(ref _WinState, value); }
        }

        private Visibility _LoginVisiable = Visibility.Visible;
        public Visibility LoginVisiable
        {
            get{ return _LoginVisiable; }
            set{ SetProperty(ref _LoginVisiable, value); }
        }

        private Visibility _menuVisiable = Visibility.Collapsed;
        public Visibility MenuVisiable
        {
            get{ return _menuVisiable; }
            set{ SetProperty(ref _menuVisiable, value); }
        }
        #endregion

        #region field
        private string dateTimeText;
        public string DateTimeText
        {
            get { return dateTimeText; }
            set { SetProperty(ref dateTimeText, value); }
        }

        private string _versionText;
        public string VersionText
        {
            get { return _versionText; }
            set { SetProperty(ref _versionText, value); }
        }

        private string _statusText;
        public string StatusText
        {
            get { return _statusText; }
            set { SetProperty(ref _statusText, value); }
        }

        private string _ServerAddress;
        public string ServerAddress
        {
            get { return _ServerAddress; }
            set { SetProperty(ref _ServerAddress, value); }
        }
        
        private string _CurrentServer;
        public string CurrentServer
        {
            get { return _CurrentServer; }
            set { SetProperty(ref _CurrentServer, value); }
        }

        private string _UserName;
        public string UserName
        {
            get { return _UserName; }
            set { SetProperty(ref _UserName, value); }
        }

        private string _Password;
        public string Password
        {
            get { return _Password; }
            set { SetProperty(ref _Password, value); }
        }

        private string _DomainName;
        public string DomainName
        {
            get { return _DomainName; }
            set { SetProperty(ref _DomainName, value); }
        }
        #endregion field

        #region command
        private DelegateCommand _exitCommand;
        public DelegateCommand ExitCommand =>
            _exitCommand ?? (_exitCommand = new DelegateCommand(OnExit));

        private DelegateCommand<string> _navigateToCommand;
        public DelegateCommand<string> NavigateToCommand =>
            _navigateToCommand ?? (_navigateToCommand = new DelegateCommand<string>(OnNavigateTo));
        #endregion command

        #region Fun
        private void OnVersionUpdatedEvent(string version)
        {
            VersionText = "Version:" + version;
        }

        private void OnStatusUpdatedEvent(string status)
        {
            StatusText = status;
        }

        void OnExit()
        {
            Application.Current.MainWindow.Close();
        }
        void OnNavigateTo(string functionName)
        {
            try
            {
                MyLogger.PerformanceStart();
                RegionManager.Regions[RegionNames.MainRegion].RequestNavigate(functionName, (nr) =>
                {
                    if (nr.Error != null)
                    {
                        MyLogger.Error(nr.Error);
                        MessageBox.Show(nr.Error.ToString(), "Navigation failed!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                });
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
        }
        #endregion private function
    }
}
