﻿using LoginManagement.Event;
using LoginService.IService;
using LoginService.Models;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace LoginManagement.ViewModels
{
    public class LoginViewModel : ViewModelBase
    {
        IEventAggregator _ea;

        public ILoginManageService LoginService { get; set; }
        public LoginViewModel(ILoginManageService loginService, IEventAggregator ea)
        {
            _ea = ea;
            this.LoginService = loginService;
            Title = "Login";

            DomainNameList = this.LoginService.GetDomainName(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
            ServerAddressList = this.LoginService.GetServerAddress(Environment.CurrentDirectory + "\\LoginConfigFile.xml");
        }


        #region Filed
        private string _UserName;
        public string UserName
        {
            get { return this._UserName; }
            set { SetProperty(ref this._UserName, value); }
        }

        private string _Password;
        public string Password
        {
            get { return this._Password; }
            set { SetProperty(ref this._Password, value); }
        }

        private string _DomainName;
        public string DomainName
        {
            get { return this._DomainName; }
            set { SetProperty(ref this._DomainName, value); }
        }

        private List<string> _DomainNameList;
        public List<string> DomainNameList
        {
            get { return this._DomainNameList; }
            set { SetProperty(ref this._DomainNameList, value); }
        }

        private ServerAddressInfo _ServerAddress;
        public ServerAddressInfo ServerAddress
        {
            get { return this._ServerAddress; }
            set { SetProperty(ref this._ServerAddress, value); }
        }

        private List<ServerAddressInfo> __ServerAddressList;
        public List<ServerAddressInfo> ServerAddressList
        {
            get { return this.__ServerAddressList; }
            set { SetProperty(ref this.__ServerAddressList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _BtnOkCommand;
        public DelegateCommand BtnOkCommand =>
            _BtnOkCommand ?? (_BtnOkCommand = new DelegateCommand(OnBtnOnClick));

        private DelegateCommand _BtnCancelCommand;
        public DelegateCommand BtnCancelCommand =>
            _BtnCancelCommand ?? (_BtnCancelCommand = new DelegateCommand(OnBtnCancelClick));

        #endregion

        #region Event Fun
        void OnBtnOnClick()
        {
            try
            {
                LoginInfo info = new LoginInfo();
                int result = -1;
                //result = this.LoginService.Login(UserName, Password, DomainName);
                result = 0;
                if (result==0)
                {
                    //登陆操作                   
                    info.LoginState = 1;
                }
                else
                {
                    info.LoginState = 2;
                }

                info.DomainName = DomainName;
                info.UserName = UserName;
                info.Password = Password;
                info.ServerAddress = ServerAddress.Value;

                //登陆操作成功后，发送消息
                _ea.GetEvent<LoginSentEvent>().Publish(info);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        void OnBtnCancelClick()
        {
            try
            {
                LoginInfo info = new LoginInfo();
                info.LoginState = 3;
                _ea.GetEvent<LoginSentEvent>().Publish(info);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion
    }
}
