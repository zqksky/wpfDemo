﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class CDEntity
    {

        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string Energy { get; set; }
        public string Focus { get; set; }
        public string CtlFlag { get; set; }
        public string LastEstiTime { get; set; }
    }
}
