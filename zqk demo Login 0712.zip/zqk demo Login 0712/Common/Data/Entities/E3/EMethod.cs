﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum EMethod
    {
        Login,

        GetContextRowsCD,
        GetContextRowsOVL,
        GetLayerList,
        GetModeColumnList,
        GetProductList
    }
}