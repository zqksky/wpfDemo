﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public interface IProfileService
    {
        List<Factory> GetFactories(List<QueryParameter> parameters, OrderSettings orderSettings);
        void AddFactory(List<Factory> factoryLst);
        void ModifyFactory(Factory factory);
        void DeleteFactory(string factoryName);
        void EnableFactory(string factoryName);
        void DisableFactory(string factoryName);
    }
}
