﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public enum EProperty
    {
        // Login Property
        UserName,
        DomainName,
        Password,
        AppType,
        AutoLogin,

        //Config
        ClientMachine,
        RequestId,
        Layer,
        Module,
        Product,
        Recipe,
        ClienetVersion,
        TableName,
        QueryContexts,
        GetTableStructureOnly,
        Reticle,
        Content_Add,
        Content_Modify,
        Content_Delete,
        Content,

        // Litho Property
        UserID,
        ClientVersion,
        ProductId,
        LayerId,
        ToolId,
        ToolType

    }
}
