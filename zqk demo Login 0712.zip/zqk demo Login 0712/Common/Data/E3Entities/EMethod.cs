﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum EMethod
    {
        R2R_UI_Config_Get,
        R2R_UI_Config_Get_PH_Main,
        R2R_UI_Config_Get_TableList,
        R2R_UI_Config_Update,
        R2R_UI_GetModules,

        Login,

        GetContextRowsCD,
        GetContextRowsOVL,
        GetLayerList,
        GetModeColumnList,
        GetProductList,

        GetContextContentCD,
        GetContextContentOVL      
    }
}