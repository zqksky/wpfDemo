﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public sealed class ColumnMappingAttribute : Attribute
    {
        #region Define private member variables
        private readonly bool _isPrimaryKey;
        private readonly string _columnName;
        #endregion

        #region Define Datetime format for converting datetime
        // default datetime format
        // TO_DO : in future, this should be passed through IFormatProvider class for supporting dynamic custom format of datetime.
        #endregion

        #region Define Constructor
        public ColumnMappingAttribute()
        {
        }

        public ColumnMappingAttribute(string name)
            : this(name, false)
        {
        }


        public ColumnMappingAttribute(string name, bool isPrimaryKey)
        {
            _columnName = name;
            _isPrimaryKey = isPrimaryKey;
        }

        #endregion

        #region Property Definition of ColumnMappingAttribute
        //This is really the column name of in the DB table
        /// <summary>
        /// property definition
        /// </summary>
        public string ColumnName { get => _columnName; }

        public bool IsKeyColumn { get => _isPrimaryKey; }
        public string ColumnFormat { get; internal set; }

        #endregion
    }
}
