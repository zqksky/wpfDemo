﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetPHMainResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        private string contentDoseParam;
        public string ContentDoseParam
        {
            get { return contentDoseParam; }
            set { contentDoseParam = value; }
        }

        private string contentOvlMode;
        public string ContentOvlMode
        {
            get { return contentOvlMode; }
            set { contentOvlMode = value; }
        }

        private string contentRecipeSetting;
        public string ContentRecipeSetting
        {
            get { return contentRecipeSetting; }
            set { contentRecipeSetting = value; }
        }

        public CfgGetPHMainResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            contentDoseParam = "";
            contentOvlMode = "";
            contentRecipeSetting = "";
        }
    }
}
