﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    /// <summary>
    /// 枚举
    /// </summary>
    public enum ECRState
    {
        New,
        Approving,
        Approved,
        Rejected
    }

    /// <summary>
    /// 枚举
    /// </summary>
    public enum EOperationState
    {
        Add,
        Edit,
        Delete
    }

    /// <summary>
    /// 枚举
    /// </summary>
    public enum EActionState
    {
        Save,
        Deleted,
        Rollback
    }
}
