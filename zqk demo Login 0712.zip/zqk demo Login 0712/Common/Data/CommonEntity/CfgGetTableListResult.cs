﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.CommonEntity
{
    public class CfgGetTableListResult
    {
        string requestId;
        public string RequestId
        {
            get { return requestId; }
            set { requestId = value; }
        }

        string returnCode;
        public string ReturnCode
        {
            get { return returnCode; }
            set { returnCode = value; }
        }

        string returnText;
        public string ReturnText
        {
            get { return returnText; }
            set { returnText = value; }
        }

        private string mainTable;
        public string MainTable
        {
            get { return mainTable; }
            set { mainTable = value; }
        }

        private string[] tableList;
        public string[] TableList
        {
            get { return tableList; }
            set { tableList = value; }
        }

        private bool requester;
        public bool Requester
        {
            get { return requester; }
            set { requester = value; }
        }

        private bool approver;
        public bool Approver
        {
            get { return approver; }
            set { approver = value; }
        }

        private bool rollbacker;
        public bool Rollbacker
        {
            get { return rollbacker; }
            set { rollbacker = value; }
        }

        public CfgGetTableListResult()
        {
            requestId = "";
            returnCode = "0";
            returnText = "";
            mainTable = "";
            requester = false;
            Approver = false;
            rollbacker = false;
        }
    }
}
