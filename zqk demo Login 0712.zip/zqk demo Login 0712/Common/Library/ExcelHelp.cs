﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace R2R.Common.Library
{
    public class ExcelHelp
    {
        #region
        public static List<List<string>> Inport(string strFileName)
        {
            List<List<string>> collection = new List<List<string>>();

            FileInfo existingFile = new FileInfo(strFileName);
            try
            {
                using (ExcelPackage package = new ExcelPackage(existingFile))
                {
                    int vSheetCount = package.Workbook.Worksheets.Count; //获取总Sheet页

                    ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页

                    int maxColumnNum = worksheet.Dimension.End.Column;//最大列
                    int minColumnNum = worksheet.Dimension.Start.Column;//最小列

                    int maxRowNum = worksheet.Dimension.End.Row;//最小行
                    int minRowNum = worksheet.Dimension.Start.Row;//最大行

                    for (int n = 2; n <= maxRowNum; n++)
                    {
                        List<string> strListRow = new List<string>();
                        for (int m = 1; m <= maxColumnNum; m++)
                        {
                            strListRow.Add(worksheet.Cells[n, m].Value.ToString());
                        }
                        collection.Add(strListRow);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return collection;
        }

        /// <summary>
        /// 使用EPPlus导出Excel(xlsx)
        /// </summary>
        /// <param name="sourceTable">数据源</param>
        /// <param name="strFileName">xlsx文件名(不含后缀名)</param>
        public static void Export(DataTable sourceTable, string strFileName)
        {
            try
            {
                strFileName = @"C:\zqk\test.xlsx";

                FileInfo newFile = new FileInfo(strFileName);
                if (newFile.Exists)
                {
                    newFile.Delete();
                    newFile = new FileInfo(strFileName);
                }

                using (ExcelPackage package = new ExcelPackage(newFile))
                {
                    //Create the worksheet
                    string sheetName = string.IsNullOrEmpty(sourceTable.TableName) ? "Sheet1" : sourceTable.TableName;
                    ExcelWorksheet ws = package.Workbook.Worksheets.Add(sheetName);

                    //Load the datatable into the sheet, starting from cell A1. Print the column names on row 1
                    ws.Cells["A1"].LoadFromDataTable(sourceTable, true);

                    //Format the row
                    ExcelBorderStyle borderStyle = ExcelBorderStyle.Thin;
                    Color borderColor = Color.FromArgb(155, 155, 155);

                    using (ExcelRange rng = ws.Cells[1, 1, sourceTable.Rows.Count + 1, sourceTable.Columns.Count])
                    {
                        rng.Style.Font.Name = "宋体";
                        rng.Style.Font.Size = 10;
                        rng.Style.Fill.PatternType = ExcelFillStyle.Solid;                      //Set Pattern for the background to Solid
                        rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(255, 255, 255));

                        rng.Style.Border.Top.Style = borderStyle;
                        rng.Style.Border.Top.Color.SetColor(borderColor);

                        rng.Style.Border.Bottom.Style = borderStyle;
                        rng.Style.Border.Bottom.Color.SetColor(borderColor);

                        rng.Style.Border.Right.Style = borderStyle;
                        rng.Style.Border.Right.Color.SetColor(borderColor);
                    }

                    //Format the header row
                    using (ExcelRange rng = ws.Cells[1, 1, 1, sourceTable.Columns.Count])
                    {
                        rng.Style.Font.Bold = true;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(234, 241, 246));  //Set color to dark blue
                        rng.Style.Font.Color.SetColor(Color.FromArgb(51, 51, 51));
                    }

                    // 保存
                    package.Save();
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }
        #endregion

        #region
        //public static DataTable ToDataTable<T>(IEnumerable<T> collection)
        //{
        //    var props = typeof(T).GetProperties();
        //    var dt = new DataTable();
        //    dt.Columns.AddRange(props.Select(p => new DataColumn(p.Name, p.PropertyType)).ToArray());
        //    if (collection.Count() > 0)
        //    {
        //        for (int i = 0; i < collection.Count(); i++)
        //        {
        //            ArrayList tempList = new ArrayList();

        //            foreach (PropertyInfo pi in props)
        //            {
        //                object obj = pi.GetValue(collection.ElementAt(i), null);
        //                tempList.Add(obj);
        //            }
        //            object[] array = tempList.ToArray();
        //            dt.LoadDataRow(array, true);
        //        }
        //    }

        //    return dt;
        //}

        ///// <summary>
        ///// 将List转换成DataTable
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="data"></param>
        ///// <returns></returns>
        //public static DataTable ToDataTable<T>(this IList<T> data)
        //{
        //    PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(typeof(T));
        //    DataTable dt = new DataTable();
        //    for (int i = 0; i < properties.Count; i++)
        //    {
        //        PropertyDescriptor property = properties[i];
        //        dt.Columns.Add(property.Name, property.PropertyType);
        //    }
        //    object[] values = new object[properties.Count];
        //    foreach (T item in data)
        //    {
        //        for (int i = 0; i < values.Length; i++)
        //        {
        //            values[i] = properties[i].GetValue(item);
        //        }
        //        dt.Rows.Add(values);
        //    }
        //    return dt;
        //}

        //public static List<List<string>> Inport(string strFileName)
        //{
        //    List<List<string>> collection = new List<List<string>>();

        //    FileInfo existingFile = new FileInfo(strFileName);
        //    try
        //    {
        //        using (ExcelPackage package = new ExcelPackage(existingFile))
        //        {
        //            int vSheetCount = package.Workbook.Worksheets.Count; //获取总Sheet页

        //            ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页

        //            int maxColumnNum = worksheet.Dimension.End.Column;//最大列
        //            int minColumnNum = worksheet.Dimension.Start.Column;//最小列

        //            int maxRowNum = worksheet.Dimension.End.Row;//最小行
        //            int minRowNum = worksheet.Dimension.Start.Row;//最大行

        //            for (int n = 2; n <= maxRowNum; n++)
        //            {
        //                List<string> strListRow = new List<string>();
        //                for (int m = 1; m <= maxColumnNum; m++)
        //                {
        //                    strListRow.Add(worksheet.Cells[n, m].Value.ToString());
        //                }
        //                collection.Add(strListRow);
        //            }
        //        }
        //    }
        //    catch (Exception vErr)
        //    {

        //    }

        //    return collection;
        //}

        //public static void Export<T>(IEnumerable<T> Collection,string strFileName)
        //{
        //    strFileName = @"C:\zqk\test.xlsx";

        //    FileInfo newFile = new FileInfo(strFileName);
        //    if (newFile.Exists)
        //    {
        //        newFile.Delete();
        //        newFile = new FileInfo(strFileName);
        //    }

        //    using (var package = new ExcelPackage(newFile))
        //    {
        //        ExcelWorksheet ws = package.Workbook.Worksheets.Add("Results");

        //        //Load the datatable into the sheet, starting from cell A1. Print the column names on row 1
        //        //ws.Cells["A1"].LoadFromDataTable(sourceTable, true);
        //        ws.Cells["A1"].LoadFromCollection(Collection, true);

        //        ws.Cells.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;//水平居中
        //        ws.Cells.Style.VerticalAlignment = ExcelVerticalAlignment.Center;//垂直居中
        //        ws.Cells.AutoFitColumns();

        //        ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页

        //        int maxColumnNum = worksheet.Dimension.End.Column;//最大列
        //        int minColumnNum = worksheet.Dimension.Start.Column;//最小列

        //        int maxRowNum = worksheet.Dimension.End.Row;//最小行
        //        int minRowNum = worksheet.Dimension.Start.Row;//最大行

        //        ////Format the row
        //        //ExcelBorderStyle borderStyle = ExcelBorderStyle.Thin;
        //        //Color borderColor = Color.FromArgb(155, 155, 155);

        //        //using (ExcelRange rng = ws.Cells[1, 1, maxRowNum + 1, maxColumnNum])
        //        //{
        //        //    rng.Style.Font.Name = "宋体";
        //        //    rng.Style.Font.Size = 10;
        //        //    rng.Style.Fill.PatternType = ExcelFillStyle.Solid;                      //Set Pattern for the background to Solid
        //        //    rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(255, 255, 255));

        //        //    rng.Style.Border.Top.Style = borderStyle;
        //        //    rng.Style.Border.Top.Color.SetColor(borderColor);

        //        //    rng.Style.Border.Bottom.Style = borderStyle;
        //        //    rng.Style.Border.Bottom.Color.SetColor(borderColor);

        //        //    rng.Style.Border.Right.Style = borderStyle;
        //        //    rng.Style.Border.Right.Color.SetColor(borderColor);
        //        //}

        //        ////Format the header row
        //        //using (ExcelRange rng = ws.Cells[1, 1, 1, maxColumnNum])
        //        //{
        //        //    rng.Style.Font.Bold = true;
        //        //    rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
        //        //    rng.Style.Fill.BackgroundColor.SetColor(Color.FromArgb(234, 241, 246));  //Set color to dark blue
        //        //    rng.Style.Font.Color.SetColor(Color.FromArgb(51, 51, 51));
        //        //}

        //        // 保存
        //        package.Save();
        //    }
        //}
        #endregion
    }
}
