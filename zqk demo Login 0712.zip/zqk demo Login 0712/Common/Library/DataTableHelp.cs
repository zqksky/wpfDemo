﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace R2R.Common.Library
{
    public class DataTableHelp
    {
        #region 
        public static DataTable GetExist(DataTable dbSource, DataTable db)
        {
            DataTable dbResult = db.Clone();
            try
            {
                bool flag = false;
                foreach (DataRow row in db.Rows)
                {
                    flag = IsExistRow(dbSource, row);
                    if (flag)
                    {
                        dbResult.ImportRow(row);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return dbResult;
        }

        public static bool IsExistRow(DataTable db, DataRow row)
        {
            bool flag = false;
            try
            {
                foreach (DataRow r in db.Rows)
                {
                    if (CompareRowValue(r, row))
                    {
                        flag = true;
                        break;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return flag;
        }
        public static DataTable GetChangedDataTableToJson(DataTable dbChanged, string strStatusColumnName, string strStatus)
        {
            DataTable dbResult = dbChanged.Clone();

            try
            {
                DataRow[] drArr = dbChanged.Select(strStatusColumnName + "= '" + strStatus + "'");

                for (int i = 0; i < drArr.Length; i++)
                {
                    dbResult.ImportRow(drArr[i]);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        public static DataTable GetChangedDataTable(DataTable dbChanged, string strStatusColumnName, string strStatus)
        {
            DataTable dbResult = dbChanged.Clone();

            try
            {
                DataRow[] drArr = dbChanged.Select(strStatusColumnName + "= '" + strStatus + "'");

                for (int i = 0; i < drArr.Length; i++)
                {
                    dbResult.ImportRow(drArr[i]);
                }
                dbResult.Columns.Remove(strStatusColumnName);
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        public static DataTable CompareDataTable(DataTable dbOld, DataTable dbNew, List<string> ColumnKeyList)
        {
            DataTable dbResult = new DataTable("dbResult");
            DataTable dbOldExcept = new DataTable("dbOldExcept");
            DataTable dbNewExcept = new DataTable("dbNewExcept");
            try
            {
                if (dbOld != null || dbNew != null)
                {
                    dbResult = dbOld.Clone();
                    if (dbResult.Columns.Contains("Status"))
                    {
                    }
                    else
                    {
                        dbResult.Columns.Add("Status", Type.GetType("System.String")).SetOrdinal(0);
                    }

                    //获取两个数据源的差集
                    IEnumerable<DataRow> queryOld = dbOld.AsEnumerable().Except(dbNew.AsEnumerable(), DataRowComparer.Default);
                    if (queryOld.Count() > 0)
                    {
                        dbOldExcept = queryOld.CopyToDataTable();
                    }

                    //获取两个数据源的差集
                    IEnumerable<DataRow> queryNew = dbNew.AsEnumerable().Except(dbOld.AsEnumerable(), DataRowComparer.Default);
                    if (queryNew.Count() > 0)
                    {
                        dbNewExcept = queryNew.CopyToDataTable();
                    }

                    foreach (DataRow row in dbOldExcept.Rows)
                    {
                        string str = GetSelectKey(row, ColumnKeyList);
                        if (dbNewExcept.Rows.Count > 0)
                        {
                            DataRow[] rows = dbNewExcept.Select(str);
                            if (rows.Length > 0)
                            {
                                //bool flag = CompareRowValue(row, rows[0]);

                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Old";

                                dbResult.ImportRow(rows[0]);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Edit";
                            }
                            else
                            {
                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Delete";
                            }
                        }
                        else
                        {
                            dbResult.ImportRow(row);
                            dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Delete";
                        }
                    }

                    foreach (DataRow row in dbNewExcept.Rows)
                    {
                        string str = GetSelectKey(row, ColumnKeyList);
                        if (dbOldExcept.Rows.Count > 0)
                        {
                            DataRow[] rows = dbOldExcept.Select(str);
                            if (rows.Length > 0)
                            {

                            }
                            else
                            {
                                dbResult.ImportRow(row);
                                dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Add";
                            }
                        }
                        else
                        {
                            dbResult.ImportRow(row);
                            dbResult.Rows[dbResult.Rows.Count - 1]["Status"] = "Add";
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }
        #endregion

        #region
        public static DataTable CreateDataTable(List<string> ColumnList)
        {
            DataTable db = new DataTable("dbName");
            try
            {
                foreach (var str in ColumnList)
                {
                    db.Columns.Add(str, Type.GetType("System.String"));
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CreateDataTable(List<string> ColumnList,List<Type> TypeList)
        {
            DataTable db = new DataTable("dbName");
            try
            {
                for (int i = 0; i < ColumnList.Count; i++)
                {
                    db.Columns.Add(ColumnList[i], TypeList[i]);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static DataTable CreateDataTable(DataTable dbStructure, List<List<string>> rowData)
        {
            DataTable db = dbStructure.Clone();
            try
            {
                for (int i = 0; i < rowData.Count; i++)
                {
                    db.Rows.Add();
                    for (int n = 0; n < rowData[0].Count; n++)
                    {
                        db.Rows[i][n] = rowData[i][n];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public static void SetColumnValue(DataTable dt, string ColumnName, string ColumnValue, int rowIndex)
        {
            try
            {
                for (int i = rowIndex; i < dt.Rows.Count; i++)
                {
                    //为新添加的列进行赋值
                    dt.Rows[i][ColumnName] = ColumnValue;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        static string GetSelectKey(DataRow row, List<string> strListColumnKey)
        {
            string str = string.Empty;
            try
            {
                foreach (var s in strListColumnKey)
                {
                    str += s + "= '" + row[s] + "' " + "and ";
                }
                str = str.Trim();
                str = str.TrimEnd(new char[] { 'a', 'n', 'd' });
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return str;
        }

        static bool CompareRowValue(DataRow row1, DataRow row2)
        {
            bool flag = false;
            string str1 = string.Empty;
            string str2 = string.Empty;

            try
            {
                str1 = JsonHelp.SerializeObject(row1.ItemArray);
                str2 = JsonHelp.SerializeObject(row2.ItemArray);

                if (str1.Equals(str2))
                {
                    flag = true;
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            //flag = CompareObject(row1.ItemArray, row2.ItemArray);
            return flag;
        }

        public static List<string> GetColumnName(DataTable dt)
        {
            List<string> strList = new List<string>();
            try
            {
                foreach (DataColumn column in dt.Columns)
                {
                    strList.Add(column.ColumnName);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        public static DataTable GetMerge(DataTable db1, DataTable db2, List<string> strListColumnKey, ref List<DataRow> strListRowEdit, ref List<DataRow> strListRowChanged, ref List<DataRow> strListRowAdded)
        {
            DataTable dbResult = db1.Copy();
            strListRowEdit = new List<DataRow>();
            strListRowChanged = new List<DataRow>();
            strListRowAdded = new List<DataRow>();
            try
            {
                foreach (DataRow row in db2.Rows)
                {
                    string str = GetSelectKey(row, strListColumnKey);
                    DataRow[] rows = dbResult.Select(str);
                    if (rows.Length > 0)
                    {
                        bool flag = CompareRowValue(row, rows[0]);
                        if (flag)
                        {

                        }
                        else
                        {
                            DataTable dbTmp = db1.Clone();
                            DataRow rowEdit = dbTmp.NewRow();
                            rowEdit.ItemArray = rows[0].ItemArray;

                            strListRowEdit.Add(rowEdit);
                            strListRowChanged.Add(row);
                            dbResult.Rows.Remove(rows[0]);
                            dbResult.ImportRow(row);
                        }
                    }
                    else
                    {
                        strListRowAdded.Add(row);
                        dbResult.ImportRow(row);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return dbResult;
        }

        /// <summary>
        /// dataRow比较
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="drB"></param>
        /// <param name="columnNames">需要比较的列名称</param>
        /// <returns></returns>
        public static bool DataRowCompare(DataRow drA, DataRow drB, string[] columnNames)
        {
            bool flag = false;
            try
            {
                //DataRow 中需要比较的列排序
                ColumnSort(drA, columnNames);
                ColumnSort(drB, columnNames);
                foreach (DataColumn dcA in drA.Table.Columns)
                {
                    if (columnNames.Contains(dcA.ColumnName))
                    {
                        foreach (DataColumn dcB in drB.Table.Columns)
                        {
                            if (columnNames.Contains(dcB.ColumnName))
                            {
                                if (dcB.ColumnName == dcA.ColumnName)//列名比较
                                {
                                    //类型比较
                                    if (dcB.DataType != dcA.DataType)
                                    {
                                        flag = false;
                                        break;
                                    }
                                    //值比较
                                    else if (CompareObject(drA[dcB.ColumnName], drB[dcB.ColumnName]))
                                    {
                                        flag = true;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }
        /// <summary>
        /// 按照数组中列名顺序排序
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="columnNames">按照数组中列名顺序排序</param>
        private static void ColumnSort(DataRow drA, string[] columnNames)
        {
            try
            {
                //drA 排序
                int i = 0;
                foreach (string columnName in columnNames)
                {
                    if (drA.Table.Columns.Contains(columnName))
                    {
                        drA.Table.Columns[columnName].SetOrdinal(i);
                        i++;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
        }

        /// <summary>
        /// 引用对象比较
        /// </summary>
        /// <param name="objA"></param>
        /// <param name="objB"></param>
        /// <returns></returns>
        public static bool CompareObject(object objA, object objB)
        {
            bool flag = false;
            try
            {
                if (objA == null || objB == null)
                {
                    flag = false;
                }
                else if (objA == DBNull.Value && objB != DBNull.Value)
                {
                    flag = false;
                }
                else if (objA != DBNull.Value && objB == DBNull.Value)
                {
                    flag = false;
                }
                else if (objA == DBNull.Value && objB == DBNull.Value)
                {
                    //objA objB 对应的列类型已经比较过 类型已判断 值一致
                    flag = true;
                }
                else if (objA.GetType() != objB.GetType())
                {
                    flag = false;
                }
                else if (objA is int || objA is short || objA is long || objA is float || objA is double || objA is decimal)
                {
                    //int 01与1      
                    if (objA is int)
                    {
                        if ((int)objA == (int)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is short)
                    {
                        if ((short)objA == (short)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is long)
                    {
                        if ((long)objA == (long)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is float)
                    {
                        if ((float)objA == (float)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is double)
                    {
                        if ((double)objA == (double)objB)
                        {
                            flag = true;
                        }
                    }
                    else if (objA is decimal)
                    {
                        if ((decimal)objA == (decimal)objB)
                        {
                            flag = true;
                        }
                    }
                }
                else
                {
                    string strA = JsonHelp.SerializeObject(objA);
                    string strB = JsonHelp.SerializeObject(objB);

                    if (strA.Equals(strB))
                    {
                        flag = true;
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return flag;
        }
        #endregion

        #region Test
        void test(DataTable dt1, DataTable dt2)
        {
            //比较两个数据源的交集
            IEnumerable<DataRow> query1 = dt1.AsEnumerable().Intersect(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt3 = query1.CopyToDataTable();

            //获取两个数据源的并集
            IEnumerable<DataRow> query2 = dt1.AsEnumerable().Union(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt4 = query2.CopyToDataTable();

            //获取两个数据源的差集
            IEnumerable<DataRow> query3 = dt1.AsEnumerable().Except(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt5 = query3.CopyToDataTable();
        }

        public struct StructCompareRow
        {
            public string columnNmae;
            public string oldValue;
            public string newValue;
        };

        public static List<StructCompareRow> CompareRowValue(string strOldRow, string strNewRow, List<string> columnName)
        {
            List<StructCompareRow> structList = new List<StructCompareRow>();

            List<string> oldRowList = new List<string>();
            List<string> newRowList = new List<string>();

            oldRowList = JsonHelp.DeserializeJsonToObject<List<string>>(strOldRow);
            newRowList = JsonHelp.DeserializeJsonToObject<List<string>>(strNewRow);

            for (int i = 0; i < columnName.Count; i++)
            {
                if (oldRowList[i].Equals(newRowList[i]))
                {
                    continue;
                }
                else
                {
                    StructCompareRow structData = new StructCompareRow();
                    structData.columnNmae = columnName[i];
                    structData.oldValue = oldRowList[i];
                    structData.newValue = newRowList[i];

                    structList.Add(structData);
                }
            }

            return structList;
        }
        #endregion
    }
}
