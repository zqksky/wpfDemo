﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using NLog;
using NLog.Config;
using NLog.Targets;

namespace R2R.Common.Library
{
    public class MyLogger
    {
        static Logger _logger;

        static MyLogger()
        {
            _logger = LogManager.GetLogger("MyLogger");
        }


        //
        // Summary:
        //     Writes the diagnostic message at the Trace level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Trace([Localizable(false)] string message = "")
        {
            _logger.Trace(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Trace level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Trace([Localizable(false)] string message, params object[] args)
        {
            _logger.Trace(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Trace level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Trace(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Trace(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Trace level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Trace(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Trace(exception, message, args);
        }


        //
        // Summary:
        //     Writes the diagnostic message at the Debug level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Debug([Localizable(false)] string message)
        {
            _logger.Debug(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Debug level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Debug([Localizable(false)] string message, params object[] args)
        {
            _logger.Debug(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Debug level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Debug(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Debug(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Debug level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Debug(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Debug(exception, message, args);
        }



        //
        // Summary:
        //     Writes the diagnostic message at the Info level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Info([Localizable(false)] string message)
        {
            _logger.Info(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Info level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Info([Localizable(false)] string message, params object[] args)
        {
            _logger.Info(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Info level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Info(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Info(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Info level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Info(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Info(exception, message, args);
        }



        //
        // Summary:
        //     Writes the diagnostic message at the Warn level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Warn([Localizable(false)] string message)
        {
            _logger.Warn(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Warn level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Warn([Localizable(false)] string message, params object[] args)
        {
            _logger.Warn(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Warn level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Warn(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Warn(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Warn level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Warn(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Warn(exception, message, args);
        }


        //
        // Summary:
        //     Writes the diagnostic message at the Error level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Error([Localizable(false)] string message)
        {
            _logger.Error(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Error level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Error([Localizable(false)] string message, params object[] args)
        {
            _logger.Error(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Error level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Error(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Error(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Error level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Error(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Error(exception, message, args);
        }


        //
        // Summary:
        //     Writes the diagnostic message at the Fatal level.
        //
        // Parameters:
        //   message:
        //     Log message.
        public static void Fatal([Localizable(false)] string message)
        {
            _logger.Fatal(message);
        }

        //
        // Summary:
        //     Writes the diagnostic message at the Fatal level using the specified parameters.
        //
        // Parameters:
        //   message:
        //     A string containing format items.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Fatal([Localizable(false)] string message, params object[] args)
        {
            _logger.Fatal(message, args);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Fatal level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        public static void Fatal(Exception exception, [Localizable(false)] string message = "")
        {
            _logger.Fatal(exception, message);
        }

        //
        // Summary:
        //     Writes the diagnostic message and exception at the Fatal level.
        //
        // Parameters:
        //   message:
        //     A string to be written.
        //
        //   exception:
        //     An exception to be logged.
        //
        //   args:
        //     Arguments to format.
        [MessageTemplateFormatMethod("message")]
        public static void Fatal(Exception exception, [Localizable(false)] string message, params object[] args)
        {
            _logger.Fatal(exception, message, args);
        }


        #region PerformanceRecord

        /// <summary>
        /// 性能计数开始
        /// <remarks>性能计数本身会消耗性能，在想统计性能的方法段的开始调用该方法，在末尾调用PerformanceStop()方法可输出日志，两者必须匹配</remarks>
        /// </summary>
        public static void PerformanceStart(object key)
        {
            if (key != null && !string.IsNullOrEmpty(key.ToString()))
            {
                PerformanceHelper.StartPerformance(key.ToString());
            }
        }

        /// <summary>
        /// 性能计数开始
        /// <remarks>性能计数本身会消耗性能，在想统计性能的方法段的开始调用该方法，在末尾调用PerformanceStop()方法可输出日志，两者必须匹配</remarks>
        /// </summary>
        public static void PerformanceStart()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            var stackFrame = new StackFrame(1, true);
            var fileName = stackFrame.GetFileName();
            var methodName = stackFrame.GetMethod().Name;

            stopWatch.Stop();

            PerformanceHelper.StartPerformance(fileName, methodName, stopWatch.ElapsedTicks);
        }

        /// <summary>
        /// 性能计数结束
        /// <remarks>性能计数本身会消耗性能，在想统计性能的方法段的开始调用该方法，在末尾调用PerformanceStop()方法可输出日志，两者必须匹配</remarks>
        /// </summary>
        public static void PerformanceStop(object key)
        {
            if (key != null && !string.IsNullOrEmpty(key.ToString()))
            {
                PerformanceHelper.StopPerformance(key.ToString());
            }
        }

        /// <summary>
        /// 性能计数结束
        /// <remarks>性能计数本身会消耗性能，在想统计性能的方法段的开始调用该方法，在末尾调用PerformanceStop()方法可输出日志，两者必须匹配</remarks>
        /// </summary>
        public static void PerformanceStop()
        {
            var stopWatch = new Stopwatch();
            stopWatch.Start();

            var stackFrame = new StackFrame(1, true);
            var fileName = stackFrame.GetFileName();
            var methodName = stackFrame.GetMethod().Name;

            stopWatch.Stop();

            PerformanceHelper.StopPerformance(fileName, methodName, stopWatch.ElapsedTicks);
        }

        #endregion
    }


    /// <summary>
    /// 性能计数辅助
    /// </summary>
    internal class PerformanceHelper
    {
        private readonly static Logger _performanceHelperLog;

        private readonly static Dictionary<string, PerformanceCounterHistoryInfo> _performanceCounterHistory;

        private readonly static Dictionary<string, PerformanceCounter> _performanceCounterCache;

        private readonly static Dictionary<string, PerformanceCounter> _performanceCounterCacheByCustomKey;

        internal static long FrequencyMilliseconds;

        static PerformanceHelper()
        {
            _performanceHelperLog = LogManager.GetLogger("PerformanceLogger");
            FrequencyMilliseconds = (long)Math.Round(Stopwatch.Frequency / 1000d);
            _performanceCounterCache = new Dictionary<string, PerformanceCounter>();
            _performanceCounterHistory = new Dictionary<string, PerformanceCounterHistoryInfo>();
            _performanceCounterCacheByCustomKey = new Dictionary<string, PerformanceCounter>();
        }

        /// <summary>
        /// 按用户指定键值启动对应计时器
        /// </summary>
        /// <param name="key">用户自定义键</param>
        internal static void StartPerformance(string key)
        {
            if (_performanceCounterCacheByCustomKey.ContainsKey(key))
            {
                if (!_performanceCounterCacheByCustomKey[key].IsRunning)
                {
                    //已经停止，重新开始计时
                    _performanceCounterCacheByCustomKey[key].ReStart();
                }
                else
                {
                    //如果正在运行则抛弃，应为还未停止上一次计时就启动下一次了
                    _performanceHelperLog.Warn(string.Format("用户自定义计时器[{0}]被启动多次", key));
                    return;
                }
            }
            else
            {
                _performanceCounterCacheByCustomKey.Add(key, new PerformanceCounter(key));
            }
            _performanceHelperLog.Info("[PERFORMANCE START] {Key}", _performanceCounterCacheByCustomKey[key].ShortName);
        }

        /// <summary>
        /// 开始计时
        /// </summary>
        /// <param name="filePath">来源的文件路径</param>
        /// <param name="methodName">方法名</param>
        /// <param name="extraElapsedTicks">额外消耗的性能计时</param>
        internal static void StartPerformance(string filePath, string methodName, long extraElapsedTicks = 0)
        {
            var name = string.Concat(filePath, filePath, Thread.CurrentThread.ManagedThreadId);

            if (_performanceCounterCache.ContainsKey(name))
            {
                if (!_performanceCounterCache[name].IsRunning)
                {
                    //已经停止，重新开始计时
                    _performanceCounterCache[name].ReStart();
                    _performanceCounterCache[name].ExtraElapsedTicks = extraElapsedTicks;
                }
                else
                {
                    //如果正在运行则抛弃，应为还未停止上一次计时就启动下一次了
                    _performanceHelperLog.Warn(
                        string.Format("{0}计时器被启动多次", _performanceCounterCache[name].ShortName));
                }
            }
            else
            {
                _performanceCounterCache.Add(name, new PerformanceCounter(filePath, methodName, Thread.CurrentThread.ManagedThreadId));
                _performanceCounterCache[name].ExtraElapsedTicks = extraElapsedTicks;
            }
        }

        /// <summary>
        /// 停止并输出用户指定的计时器
        /// </summary>
        /// <param name="key">用户自定义键</param>
        internal static void StopPerformance(string key)
        {
            if (_performanceCounterCacheByCustomKey.ContainsKey(key))
            {
                if (_performanceCounterCacheByCustomKey[key].IsRunning)
                {
                    var elapsedMilliseconds = _performanceCounterCacheByCustomKey[key].Stop();
                    var historyInfo = AddHistoryInfo(_performanceCounterCacheByCustomKey[key]);

                    _performanceHelperLog.Info(
                        "[PERFORMANCE STOP] {Key} ElapsedTime: {ElapsedTime} [STATISTICS:] TotalInvokeCount: {TotalInvokeCount} TotalElapsedTime: {TotalElapsedTime}", 
                        _performanceCounterCacheByCustomKey[key].ShortName, 
                        elapsedMilliseconds / FrequencyMilliseconds, 
                        historyInfo.NumberOfInvokeTimes, 
                        historyInfo.TotalElapsedTicks / FrequencyMilliseconds);
                }
                else
                {
                    _performanceHelperLog.Warn(string.Format("用户自定义计时器[{0}]还未启动就停止", key));
                }
            }
            else
            {
                _performanceHelperLog.Warn(string.Format("用户自定义计时器[{0}]还未启动就停止", key));
            }
        }

        /// <summary>
        /// 停止计时
        /// </summary>
        /// <param name="filePath">来源的文件路径</param>
        /// <param name="methodName">方法名</param>
        /// <param name="extraElapsedTicks">额外消耗的性能计时</param>
        internal static void StopPerformance(string filePath, string methodName, long extraElapsedTicks = 0)
        {
            var name = string.Concat(filePath, filePath, Thread.CurrentThread.ManagedThreadId);

            if (_performanceCounterCache.ContainsKey(name))
            {
                if (_performanceCounterCache[name].IsRunning)
                {
                    _performanceCounterCache[name].ExtraElapsedTicks += extraElapsedTicks;
                    var elapsedMilliseconds = _performanceCounterCache[name].Stop();
                    var historyInfo = AddHistoryInfo(_performanceCounterCache[name]);

                    _performanceHelperLog.Info(
                        string.Format(
                            "{0} 耗时：{1} 【总量统计】共调用次数：{2} 共消耗时间：{3}",
                            string.Format("{0} {1}", _performanceCounterCache[name].FilePath, _performanceCounterCache[name].MethodName),
                            elapsedMilliseconds / FrequencyMilliseconds,
                            historyInfo.NumberOfInvokeTimes,
                            historyInfo.TotalElapsedTicks / FrequencyMilliseconds));
                }
                else
                {
                    _performanceHelperLog.Warn(string.Format("{0}还未启动就停止", name));
                }
            }
            else
            {
                _performanceHelperLog.Warn(string.Format("{0}还未启动就停止", name));
            }
        }

        private static PerformanceCounterHistoryInfo AddHistoryInfo(PerformanceCounter performanceCounter)
        {
            lock (_performanceCounterHistory)
            {
                if (_performanceCounterHistory.ContainsKey(performanceCounter.ShortName))
                {

                    _performanceCounterHistory[performanceCounter.ShortName].NumberOfInvokeTimes++;
                    _performanceCounterHistory[performanceCounter.ShortName].TotalElapsedTicks +=
                        performanceCounter.LastElapsedTicks;
                }
                else
                {
                    _performanceCounterHistory.Add(
                        performanceCounter.ShortName,
                        new PerformanceCounterHistoryInfo(
                            performanceCounter.ShortName,
                            performanceCounter.LastElapsedTicks));
                }

                return _performanceCounterHistory[performanceCounter.ShortName];
            }
        }
    }

    /// <summary>
    /// 性能统计实例，只会有单线程操作内部东西，安全
    /// </summary>
    internal class PerformanceCounter
    {
        /// <summary>
        /// 总时间计时器
        /// </summary>
        private Stopwatch TotalStopwatch { get; set; }

        /// <summary>
        /// 名称：文件名 + 方法名 + 线程Id，匹配单次调用的唯一性
        /// </summary>
        internal string Name { get; private set; }

        /// <summary>
        /// 短名称：除去线程Id的名称，匹配方法调用的唯一性
        /// </summary>
        internal string ShortName { get; private set; }

        /// <summary>
        /// 文件名
        /// </summary>
        internal string FilePath { get; private set; }

        /// <summary>
        /// 方法名
        /// </summary>
        internal string MethodName { get; private set; }

        /// <summary>
        /// 调用线程Id
        /// </summary>
        internal int ThreadId { get; private set; }

        /// <summary>
        /// 最后一次调用耗时
        /// </summary>
        internal long LastElapsedTicks
        {
            get
            {
                return TotalStopwatch.ElapsedTicks + ExtraElapsedTicks;
            }
        }

        internal long ExtraElapsedTicks { get; set; }

        /// <summary>
        /// 是否正在计时
        /// </summary>
        internal bool IsRunning
        {
            get
            {
                if (TotalStopwatch != null)
                {
                    return TotalStopwatch.IsRunning;
                }

                return false;
            }
        }

        private PerformanceCounter()
        {
            TotalStopwatch = new Stopwatch();
            TotalStopwatch.Start();
        }

        internal PerformanceCounter(string key)
            : this()
        {
            Name = key;
            ShortName = key;
        }

        internal PerformanceCounter(string filePath, string methodName, int threadId)
            : this()
        {
            FilePath = filePath;
            MethodName = methodName;
            ThreadId = threadId;
            Name = string.Concat(FilePath, MethodName, ThreadId);
            ShortName = string.Concat(FilePath, MethodName);
        }

        /// <summary>
        /// 重启计时
        /// </summary>
        internal void ReStart()
        {
            TotalStopwatch.Restart();
        }

        /// <summary>
        /// 停止计时并输出本次总时长
        /// </summary>
        /// <returns></returns>
        internal long Stop()
        {
            TotalStopwatch.Stop();
            return LastElapsedTicks;
        }
    }

    /// <summary>
    /// 性能统计的历史记录实体
    /// </summary>
    internal class PerformanceCounterHistoryInfo
    {
        /// <summary>
        /// 名称
        /// </summary>
        internal string Name { get; private set; }

        /// <summary>
        /// 总调用次数
        /// </summary>
        internal int NumberOfInvokeTimes { get; set; }

        /// <summary>
        /// 该方法的总消耗时间
        /// </summary>
        internal long TotalElapsedTicks { get; set; }


        internal PerformanceCounterHistoryInfo(string name, long elapsedTicks)
        {
            Name = name;
            TotalElapsedTicks = elapsedTicks;
            NumberOfInvokeTimes = 1;
        }
    }
}
