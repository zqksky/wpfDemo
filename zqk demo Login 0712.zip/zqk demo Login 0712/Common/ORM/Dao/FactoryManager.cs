﻿using ORM.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Dao
{
    public class FactoryManager : DbContext<FactoryModel>
    {
        #region Query
        public void Query()
        {
            try
            {
                var data1 = FactoryDb.GetById(1);//根据ID查询
                var data2 = FactoryDb.GetList();//查询所有
                var data3 = FactoryDb.GetList(it => it.Name == "aa");  //根据条件查询  
                var data4 = FactoryDb.GetSingle(it => it.Name == "aa");//根据条件查询一条

                var data5 = FactoryDb.AsQueryable().ToJson();//查询所有
                var data6 = FactoryDb.AsQueryable().Take(5).ToList();
                var data7 = FactoryDb.AsQueryable().Take(5).ToList();
                var data8 = FactoryDb.AsQueryable().Where(it => it.User == "" || it.Name == "a").ToList();
                var data9 = FactoryDb.AsQueryable().In(it => it.Name, new string[] { "add", "add2" }).ToList();

                FactoryDb.AsQueryable().Where(x => x.Name == "aa").ToList();

                string[] array = new string[] { "add", "add2" };
                var data10 = FactoryDb.AsQueryable().Where(it => array.Contains(it.Name)).ToList();


                //var p = new PageModel() { PageIndex = 1, PageSize = 2 };// 分页查询
                //var data11 = FactoryDb.GetPageList(it => it.Name == "xx", p);

                //// 分页查询加排序
                //var data12 = FactoryDb.GetPageList(it => it.Name == "xx", p, it => it.Name, OrderByType.Asc);
                ////System.Windows.Forms.MessageBox.Show(p.PageCount.ToString());//返回总数

                ////组装条件查询作为条件实现 分页查询加排序
                //List<IConditionalModel> conModels = new List<IConditionalModel>();
                //conModels.Add(new ConditionalModel() { FieldName = "Name", ConditionalType = ConditionalType.Equal, FieldValue = "add" });//id=1
                //var data13 = FactoryDb.GetPageList(conModels, p, it => it.Name, OrderByType.Asc);

                //var getByWhere = Db.Queryable<FactoryModel>().Where(it => it.User == "" || it.Name == "a").ToList();

                ////指定列查询
                //var in1 = Db.Queryable<FactoryModel>().In(it => it.Name, new string[] { "add", "add2" }).ToList();

                ////指定列查询
                //string[] array = new string[] { "add", "add2" };
                //var in3 = Db.Queryable<FactoryModel>().Where(it => array.Contains(it.Name)).ToList();
            }
            catch (Exception e)
            {
                //System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }
        #endregion

        #region Add
        public void Add()
        {
            try
            {
                var data1 = new FactoryModel() { Name = "add", Desc = "add", Date = DateTime.Now, User = "add", Enable = "Y" };
                FactoryDb.Insert(data1);//插入

                var id = FactoryDb.InsertReturnIdentity(data1);//插入返回自增列

                var obj1 = new FactoryModel() { Name = "add1", Desc = "add1", Date = DateTime.Now, User = "add", Enable = "Y" };
                var obj2 = new FactoryModel() { Name = "add2", Desc = "add2", Date = DateTime.Now, User = "add", Enable = "Y" };
                var objArray = new FactoryModel[] { obj1, obj2 };
                FactoryDb.InsertRange(objArray);//批量插入

                //4.9.7.5我们可以转成 Insertable实现复杂插入
                var obj = new FactoryModel() { Name = "obj", Desc = "obj", Date = DateTime.Now, User = "add", Enable = "Y" };
                FactoryDb.AsInsertable(data1).ExecuteCommand();

                FactoryDb.AsInsertable(objArray).ExecuteCommand();
            }
            catch (Exception e)
            {
                //System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }
        #endregion

        #region Edit
        public void Edit()
        {
            try
            {
                FactoryDb.Update(it => new FactoryModel() { Desc = "a", Date = DateTime.Now, User = "add", Enable = "Y" }, it => it.Name == "a");

                var data1 = new FactoryModel() { Name = "add", Desc = "add", Date = DateTime.Now, User = "add", Enable = "Y" };
                FactoryDb.Update(data1);//根据实体更新

                var obj1 = new FactoryModel() { Name = "add1", Desc = "add1", Date = DateTime.Now, User = "add", Enable = "Y" };
                var obj2 = new FactoryModel() { Name = "add2", Desc = "add2", Date = DateTime.Now, User = "add", Enable = "Y" };
                var objArray = new FactoryModel[] { obj1, obj2 };
                FactoryDb.UpdateRange(objArray);//批量更新

                //4.9.7.5我们可以转成 Insertable实现复杂更新
                var obj = new FactoryModel() { Name = "obj", Desc = "obj", Date = DateTime.Now, User = "add", Enable = "Y" };
                FactoryDb.AsUpdateable(data1).ExecuteCommand();

                FactoryDb.AsUpdateable(objArray).ExecuteCommand();
            }
            catch (Exception e)
            {
                //System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }
        #endregion

        #region Remove
        public void Remove()
        {
            try
            {
                var data1 = new FactoryModel() { Name = "add", Desc = "add", Date = DateTime.Now, User = "add", Enable = "Y" };
                FactoryDb.Delete(data1);//根据实体删除

                var data2 = new FactoryModel() { Name = "add3", Desc = "add" };
                FactoryDb.Delete(data2);//根据实体删除

                FactoryDb.DeleteById(1);//根据主键删除
                FactoryDb.DeleteById(new string[] { "add1", "add2" });//根据主键数组删除
                FactoryDb.Delete(it => it.Name == "add" || it.User == "add");//根据条件删除

                FactoryDb.AsDeleteable();

                //FactoryDb.AsDeleteable();
            }
            catch (Exception e)
            {
                //System.Windows.Forms.MessageBox.Show(e.Message);
            }
        }
        #endregion
    }
}
