﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Models
{
    [SugarTable("R2R_UI_CONFIG_HISTORY")]
    public class ConfigHistoryModel
    {
        //指定主键和自增列，当然数据库中也要设置主键和自增列才会有效
        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "CR_ID")]
        public string CrId { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "MODULE")]
        public string Module { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "TABLE_NAME")]
        public string TbName { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "USER_ID")]
        public string UserId { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "TIMESTAMP")]
        public string TimeStamp { get; set; }

        [SugarColumn(ColumnName = "ACTION")]
        public string Action { get; set; }
    }
}
