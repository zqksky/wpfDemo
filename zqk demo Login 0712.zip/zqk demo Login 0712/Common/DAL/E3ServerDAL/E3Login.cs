﻿using R2R.Common.Data;
using R2R.Common.Library;
using System;
using System.Collections.Specialized;
using System.Configuration;

namespace R2R.Common.DAL
{
    public class E3Login
    {
        private static int _WaitSubRecipe_Timeout;
        private static int _AskSubRecipe_Interval;
        private static R2R_UI_LoginService.LIS_UI_LoginService _LoginService;
        private static E3Login _instance;
        public static E3Login Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new E3Login();
                }
                return _instance;
            }
        }

        #region E3Login
        private E3Login()
        {
            MyLogger.Debug("DataProvider::Initial");

            _LoginService = new R2R_UI_LoginService.LIS_UI_LoginService();
            NameValueCollection procNvc = ConfigurationManager.GetSection("R2R.PROD") as NameValueCollection;

            try
            {
                _WaitSubRecipe_Timeout = int.Parse(procNvc["WaitSubRecipe_Timeout"]) * 1000;
                _AskSubRecipe_Interval = int.Parse(procNvc["AskSubRecipe_Interval"]) * 1000;
                _LoginService.Url = procNvc["E3_LIS_UI_LoginService"];
                _LoginService.Timeout = int.Parse(procNvc["E3Service_Timeout"]) * 1000;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
        #endregion


        public TResult Login(string userId, string password, string domain)
        {
            TResult result = new TResult();
            try
            {
                R2R_UI_LoginService.LoginRequest request = new R2R_UI_LoginService.LoginRequest();
                request.UserName = userId;
                request.Password = password;
                request.DomainName = domain;

                R2R_UI_LoginService.LoginReply reply = _LoginService.Login(request);
                result.ReturnCode = (reply.Success == true ? ReturnCode.LOGINOK : ReturnCode.LOGINFAULT);
                result.ReturnText = reply.Message;
                //result.ReturnMsg = reply.UserOperations;
            }
            catch (Exception ex)
            {
                result.ReturnCode = -1023456789;
                result.ReturnText = ex.Message;
            }
            return result;
        }
    }
}
