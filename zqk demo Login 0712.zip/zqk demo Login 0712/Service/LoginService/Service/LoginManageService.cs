﻿using LoginService.IService;
using LoginService.Models;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace LoginService.Service
{
    public class LoginManageService : ILoginManageService
    {
        public int Login(string username, string password, string domainName)
        {
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserName", username);
            arguDic.Add("Password", password);
            arguDic.Add("DomainName", domainName);
            arguDic.Add("AppType", "R2R_ModelConfig");
            arguDic.Add("AutoLogin", false);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string result = WSHelper.GetResponseString(EMethod.Login, arguDic);
                    LoginResultModel obj = JsonHelp.DeserializeJsonToObject<LoginResultModel>(result);
                    if (obj.Success)
                    {
                        return 0;
                    }
                    else
                    {
                        MessageBox.Show(obj.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("LoginService.Login Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return -1;
        }

        #region 获取xml文件中的数据
        public List<string> GetResendXmlConfig(string xmlPath)
        {
            List<string> strList = new List<string>();

            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ResendConfig").Elements("StrConfig")
                                                 select ele;

                foreach (var ele in elements)
                {
                    string strKey;
                    string strValue;

                    strKey = ele.Attribute("Key").Value;
                    strValue = ele.Attribute("Value").Value;

                    strList.Add(strValue);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strList;
        }

        public List<string> GetDomainName(string xmlPath)
        {
            List<string> strList = new List<string>();

            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("DomainConfig").Elements("DomainName")
                                                 select ele;

                foreach (var ele in elements)
                {
                    string strKey;
                    string strValue;

                    strKey = ele.Attribute("Key").Value;
                    //strValue = ele.Attribute("Value").Value;

                    //if (ele.LastAttribute.Name == "VALUE_TXT")
                    //{
                    //    strValue += ";" + ele.Attribute("VALUE_TXT").Value;
                    //}
                    //MessageBox.Show("strKey=" + strKey + "; strValue=" + strValue);

                    strList.Add(strKey);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return strList;
        }

        public List<ServerAddressInfo> GetServerAddress(string xmlPath)
        {
            List<ServerAddressInfo> infoList = new List<ServerAddressInfo>();
            try
            {
                XElement xe = XElement.Load(xmlPath);

                IEnumerable<XElement> elements = from ele in xe.Elements("Config").Elements("ServerConfig").Elements("ServerAddress")
                                                 select ele;

                foreach (var ele in elements)
                {
                    ServerAddressInfo info = new ServerAddressInfo();

                    info.Name = ele.Attribute("Key").Value;
                    info.Value = ele.Attribute("Value").Value;

                    //if (ele.LastAttribute.Name == "VALUE_TXT")
                    //{
                    //    info.Name += ";" + ele.Attribute("VALUE_TXT").Value;
                    //}
                    //MessageBox.Show("strKey=" + info.Name + "; strValue=" + info.Value);

                    infoList.Add(info);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return infoList;
        }
        #endregion
    }
}
