﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.Models
{
    public class LoginResultModel
    {
        public bool Success;
        public string Message;
        public int UserOperations;
    }
}
