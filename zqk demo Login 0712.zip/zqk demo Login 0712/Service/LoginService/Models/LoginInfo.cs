﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.Models
{
    public class LoginInfo
    {
        public int LoginState;
        public string DomainName;
        public string UserName;
        public string Password;
        public string ServerAddress;
    }
}
