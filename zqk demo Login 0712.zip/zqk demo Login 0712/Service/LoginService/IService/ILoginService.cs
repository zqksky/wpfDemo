﻿using LoginService.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LoginService.IService
{
    public interface ILoginManageService
    {
        int Login(string username, string password, string domainName);
        List<string> GetResendXmlConfig(string xmlPath);
        List<string> GetDomainName(string xmlPath);
        List<ServerAddressInfo> GetServerAddress(string xmlPath);
    }
}
