﻿using ConfigurationService.Models;
using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.IService
{
    public interface ISingleLotService
    {
        CfgGetEntity R2R_UI_Config_Get(string requestId, string userId, string clienetVersion, string moudle, string tableName, string[] queryContexts, bool bGetTableStructureOnly);
        bool R2R_UI_Config_Update(string requestId, string userId, string clientVersion, string moudle,string tableName, string contentModify, string contentAdd,string contentDelete);

        DataTable CreateDataTable(CfgGetEntity entity);
        DataTable CreateDataTable(CfgGetEntity entity, List<List<string>> rowData);
        string[] DataTableConvert(DataTable db, List<string> strColumnName);
        List<string> GetColumnName(string[] arry);
        List<string> GetColumnKeyName(string[] arry);
        List<Type> GetColumnType(string[] arry);
    }
}
