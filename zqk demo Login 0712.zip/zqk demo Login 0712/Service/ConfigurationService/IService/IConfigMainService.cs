﻿using ConfigurationService.Models;
using R2R.Common.Data.CommonEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.IService
{
    public interface IConfigMainService
    {
        List<string> GetModuleList(string userName, string clientVersion);
        CfgGetTableListResult R2R_UI_Config_Get_TableList(string userId, string clientVersion, string requestId, string module);
        CfgGetPHMainResult R2R_UI_Config_Get_PH_Main(string userId, string clientVersion, string requestId, string layer, string product,
                                                            string toolId, string reticle, bool bGetTableStructureOnly);
    }
}
