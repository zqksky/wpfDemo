﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class ViewPendingCRModel
    {
        public string CR_Id { get; set; }
        public string TableName { get; set; }
        public string FirstDraftTime { get; set; }
        public string CR_Category { get; set; }
        public string CR_Comment { get; set; }
        public string LastModifiedTime { get; set; }
        public string Reason { get; set; }
    }
}
