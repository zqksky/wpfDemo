﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class ColumnKeyControl :  INotifyPropertyChanged
    {
        #region Properties
        private string _KeyName;
        public string KeyName
        {
            get { return _KeyName; }
            set
            {
                _KeyName = value;
                OnPropertyChanged();
            }
        }

        private string _keyValue;
        public string KeyValue
        {
            get { return _keyValue; }
            set
            {
                _keyValue = value;
                OnPropertyChanged();
            }
        }

        private List<string> _keyValueList;
        public List<string> KeyValueList
        {
            get { return _keyValueList; }
            set
            {
                _keyValueList = value;
                OnPropertyChanged();
            }
        }
        #endregion //Properties

        #region INotifyPropertyChanged

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName]string propertyname = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }

        #endregion //INotifyPropertyChanged
    }
}
