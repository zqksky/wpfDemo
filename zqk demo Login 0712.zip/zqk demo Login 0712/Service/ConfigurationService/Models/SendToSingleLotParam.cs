﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class SendToSingleLotParam : INotifyPropertyChanged
    {
        #region Properties

        private string _RequestId;
        public string RequestId
        {
            get { return _RequestId; }
            set
            {
                _RequestId = value;
                OnPropertyChanged();
            }
        }

        private string _UserId;
        public string UserId
        {
            get { return _UserId; }
            set
            {
                _UserId = value;
                OnPropertyChanged();
            }
        }

        private string _ClientVersion;
        public string ClientVersion
        {
            get { return _ClientVersion; }
            set
            {
                _ClientVersion = value;
                OnPropertyChanged();
            }
        }

        private string _SelectedModel;
        public string SelectedModel
        {
            get { return _SelectedModel; }
            set
            {
                _SelectedModel = value;
                OnPropertyChanged();
            }
        }

        private string _TableName;
        public string TableName
        {
            get { return _TableName; }
            set
            {
                _TableName = value;
                OnPropertyChanged();
            }
        }

        private List<string> _ColumnKeyName;
        public List<string> ColumnKeyName
        {
            get { return _ColumnKeyName; }
            set
            {
                _ColumnKeyName = value;
                OnPropertyChanged();
            }
        }

        private List<string> _ColumnNameList;
        public List<string> ColumnNameList
        {
            get { return _ColumnNameList; }
            set
            {
                _ColumnNameList = value;
                OnPropertyChanged();
            }
        }

        private DataTable _TableStructure;
        public DataTable TableStructure
        {
            get { return _TableStructure; }
            set
            {
                _TableStructure = value;
                OnPropertyChanged();
            }
        }
        #endregion //Properties

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName]string propertyname = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }

        #endregion //INotifyPropertyChanged
    }

    //public class SendToSingleLotParam
    //{
    //    public string RequestId;
    //    public string UserId;
    //    public string ClientVersion;
    //    public string SelectedModel;
    //    public string TableName;
    //}
}
