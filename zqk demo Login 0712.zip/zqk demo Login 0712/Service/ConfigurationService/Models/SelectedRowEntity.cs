﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class SelectedRowEntity : INotifyPropertyChanged
    {
        #region Properties
        private DataRowView _SelectedRowValue;
        public DataRowView SelectedRowValue
        {
            get { return _SelectedRowValue; }
            set
            {
                _SelectedRowValue = value;
                OnPropertyChanged();
            }
        }

        private bool _FlagEdit;
        public bool FlagEdit
        {
            get { return _FlagEdit; }
            set
            {
                _FlagEdit = value;
                OnPropertyChanged();
            }
        }
        #endregion //Properties

        #region INotifyPropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName]string propertyname = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyname));
        }

        #endregion //INotifyPropertyChanged
    }
}
