﻿using ConfigurationService.Models;
using ConfigurationService.IService;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Service
{
    public class ConfigMainService:IConfigMainService
    {
        #region Webservice Fun
        public List<string> GetModuleList(string userName,string clientVersion)
        {
            MyLogger.Trace("ConfigMainService.GetModuleList :: " +
                            string.Format("UserName<{0}>", userName) +
                            string.Format("clientVersion<{0}>", clientVersion) +
                            string.Format("ClientMachine<{0}>", Environment.MachineName));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserName", userName);
            arguDic.Add("ClientMachine", System.Environment.MachineName);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_GetModules, arguDic);

                    GetModuleResult result = JsonHelp.DeserializeJsonToObject<GetModuleResult>(strResult);
                    MyLogger.Trace("ConfigMainService.GetModuleList Reply :: " +
                                    string.Format("Message<{0}>", result.Message) +
                                    string.Format("Modules<{0}>", result.Modules) +
                                    string.Format("ReturnMsg<{0}>", result.Success));
                    if (result.Success)
                    {
                        strList = result.Modules;
                        return strList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetModuleList Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public CfgGetTableListResult R2R_UI_Config_Get_TableList(string userId, string clientVersion,string requestId,string module)
        {
            MyLogger.Trace("ConfigMainService.R2R_UI_Config_Get_TableList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("RequestId<{0}>", requestId) +
                            string.Format("Module<{0}>", module));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clientVersion);
            arguDic.Add("RequestId", requestId);
            arguDic.Add("Module", module);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Get_TableList, arguDic);
                    CfgGetTableListResult result = JsonHelp.DeserializeJsonToObject<CfgGetTableListResult>(strResult);
                    MyLogger.Trace("ConfigMainService.GetTableList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("MainTable<{0}>", result.MainTable));
                    if (result.ReturnCode.Equals("0"))
                    {
                        //List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        //foreach (ProductEntity product in productList)
                        //{
                        //    strList.Add(product.ProductId);
                        //}
                        //return strList;

                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.R2R_UI_Config_Get_TableList Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public CfgGetPHMainResult R2R_UI_Config_Get_PH_Main(string userId, string clientVersion, string requestId, string layer,string product,
                                                            string toolId,string reticle,bool bGetTableStructureOnly)
        {
            MyLogger.Trace("ConfigMainService.R2R_UI_Config_Get_PH_Main :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("RequestId<{0}>", requestId) +
                            string.Format("Layer<{0}>", layer)+
                            string.Format("Product<{0}>", product) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("Reticle<{0}>", reticle) +
                            string.Format("GetTableStructureOnly<{0}>", bGetTableStructureOnly));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("RequestId", requestId);
            arguDic.Add("Layer", layer);
            arguDic.Add("Product", product);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("Reticle", reticle);
            arguDic.Add("GetTableStructureOnly", bGetTableStructureOnly);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Get_PH_Main, arguDic);
                    CfgGetPHMainResult result = JsonHelp.DeserializeJsonToObject<CfgGetPHMainResult>(strResult);
                    MyLogger.Trace("ConfigMainService.GetTableList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("RequestId<{0}>", result.RequestId));
                    if (result.ReturnCode.Equals("0"))
                    {
                        //List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        //foreach (ProductEntity product in productList)
                        //{
                        //    strList.Add(product.ProductId);
                        //}
                        //return strList;
                        return result;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.R2R_UI_Config_Get_PH_Main Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }
        #endregion
    }
}
