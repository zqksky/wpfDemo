﻿using ConfigurationService.Models;
using ConfigurationService.IService;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;

namespace ConfigurationService.Service
{
    public class SingleLotService : ISingleLotService
    {
        #region Webservice Fun
        public CfgGetEntity R2R_UI_Config_Get(string requestId, string userId, string clienetVersion, string moudle, string tableName, string[] queryContexts, bool bGetTableStructureOnly)
        {
            string strJson = string.Empty;
            CfgGetEntity entity = new CfgGetEntity();
            MyLogger.Trace("SingleLotService.R2R_UI_Config_Get:: " +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clienetVersion) +
                           string.Format("MoudleId<{0}>", moudle) +
                           string.Format("TableName<{0}>", tableName) +
                           string.Format("GetTableStructureOnly<{0}>", bGetTableStructureOnly));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clienetVersion);
            arguDic.Add("Module", moudle);
            arguDic.Add("TableName", tableName);
            arguDic.Add("QueryContexts", queryContexts);
            arguDic.Add("GetTableStructureOnly", bGetTableStructureOnly);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Get, arguDic);
                    CfgGetResult result = JsonHelp.DeserializeJsonToObject<CfgGetResult>(strResult);
                    MyLogger.Trace("ConfigMainService.R2R_UI_Config_Get Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content<{0}>", result.Content));
                    if (!result.ReturnCode.Equals("-1"))
                    {
                        entity = JsonHelp.DeserializeJsonToObject<CfgGetEntity>(result.Content);
                        return entity;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("SingleLotService.R2R_UI_Config_Get Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return null;
        }

        public bool R2R_UI_Config_Update(string requestId, string userId, string clienetVersion, string moudle, string tableName, string contentModify, string contentAdd, string contentDelete)
        {
            bool flag = false;
            string strJson = string.Empty;
            MyLogger.Trace("SingleLotService.R2R_UI_Config_Update :: " +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clienetVersion) +
                           string.Format("Moudle<{0}>", moudle) +
                           string.Format("TableName<{0}>", tableName) +
                           string.Format("ContentModify<{0}>", contentModify) +
                           string.Format("ContentAdd<{0}>", contentAdd) +
                           string.Format("ContentDelete<{0}>", contentDelete));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clienetVersion);
            arguDic.Add("Module", moudle); ;
            arguDic.Add("TableName", tableName);
            arguDic.Add("Content_Modify", contentModify);
            arguDic.Add("Content_Add", contentAdd);
            arguDic.Add("Content_Delete", contentDelete);
            try
            {
                if (true)
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Update, arguDic);
                    CfgGetResult result = JsonHelp.DeserializeJsonToObject<CfgGetResult>(strResult);
                    MyLogger.Trace("ConfigMainService.R2R_UI_Config_Update Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag = true;
                    }
                    else
                    {
                        System.Windows.Forms.MessageBox.Show(result.ReturnText);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("SingleLotService.R2R_UI_Config_Update Error :: " + ex.Message);
                System.Windows.Forms.MessageBox.Show(ex.Message);
            }
            return flag;
        }

        //public bool R2R_UI_Config_Delete(string requestId, string userId, string clienetVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName, string content)
        //{
        //    bool flag = false;
        //    string strJson = string.Empty;
        //    MyLogger.Trace("R2R_UI_Config_Delete :: " +
        //                   string.Format("RequestId<{0}>", requestId) +
        //                   string.Format("UserId<{0}>", userId) +
        //                   string.Format("ClienetVersion<{0}>", clienetVersion) +
        //                   string.Format("MoudleId<{0}>", moudleId) +
        //                   string.Format("ProductId<{0}>", productId) +
        //                   string.Format("LayerId<{0}>", layerId) +
        //                   string.Format("ToolId<{0}>", toolId) +
        //                   string.Format("RecipeId<{0}>", recipeId) +
        //                   string.Format("TableName<{0}>", tableName) +
        //                   string.Format("Content<{0}>", content));
        //    List<string> strList = new List<string>();
        //    Dictionary<string, object> arguDic = new Dictionary<string, object>();
        //    arguDic.Add("RequestId", requestId);
        //    arguDic.Add("UserID", userId);
        //    arguDic.Add("ClienetVersion", clienetVersion);
        //    arguDic.Add("Module", moudleId);
        //    arguDic.Add("Product", productId);
        //    arguDic.Add("Layer", layerId);
        //    arguDic.Add("ToolId", toolId);
        //    arguDic.Add("Recipe", recipeId);
        //    arguDic.Add("TableName", tableName);
        //    arguDic.Add("Content", content);
        //    try
        //    {
        //        if (!CommonHelp.ArgumentIsNull(arguDic))
        //        {
        //            string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Delete, arguDic);
        //            CfgGetResult result = JsonHelp.DeserializeJsonToObject<CfgGetResult>(strResult);
        //            MyLogger.Trace("SingleLotService..Config_R2R_PH_CONTROL_SPECS_CONFIG_Delete Reply :: " +
        //                            string.Format("RequesteId<{0}>", result.RequestId) +
        //                            string.Format("ReturnCode<{0}>", result.ReturnCode) +
        //                            string.Format("ReturnText<{0}>", result.ReturnText));
        //            if (result.ReturnCode.Equals("0"))
        //            {
        //                flag = true;
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MyLogger.Error("SingleLotService..R2R_UI_Config_Delete Error :: " + ex.Message);
        //        System.Windows.Forms.MessageBox.Show(ex.Message);
        //    }
        //    return flag;
        //}
        #endregion

        #region
        List<StructColumn> GetColumnFormat(string[] arry)
        {
            List<StructColumn> structData = new List<StructColumn>();
            try
            {
                foreach (var str in arry)
                {
                    string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    StructColumn column = new StructColumn();
                    column.columnName = sArray[0];
                    column.columnType = GetTypeByString(sArray[1]);
                    column.columnAttribute = sArray[2];
                    structData.Add(column);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return structData;
        }

        Type GetTypeByString(string type)
        {
            //string sType = "System." + type.Substring(0, 1).ToUpper() + type.Substring(1);
            switch (type.ToLower())
            {
                case "bool":
                    return Type.GetType("System.Boolean", true, true);
                case "byte":
                    return Type.GetType("System.Byte", true, true);
                case "sbyte":
                    return Type.GetType("System.SByte", true, true);
                case "char":
                    return Type.GetType("System.Char", true, true);
                case "decimal":
                    return Type.GetType("System.Decimal", true, true);
                case "double":
                    return Type.GetType("System.Double", true, true);
                case "float":
                    return Type.GetType("System.Single", true, true);
                case "int":
                    return Type.GetType("System.Int32", true, true);
                case "uint":
                    return Type.GetType("System.UInt32", true, true);
                case "long":
                    return Type.GetType("System.Int64", true, true);
                case "ulong":
                    return Type.GetType("System.UInt64", true, true);
                case "object":
                    return Type.GetType("System.Object", true, true);
                case "short":
                    return Type.GetType("System.Int16", true, true);
                case "ushort":
                    return Type.GetType("System.UInt16", true, true);
                case "string":
                    return Type.GetType("System.String", true, true);
                case "date":
                case "datetime":
                    return Type.GetType("System.DateTime", true, true);
                case "guid":
                    return Type.GetType("System.Guid", true, true);
                default:
                    return Type.GetType(type, true, true);
            }
        }

        List<List<string>> GetColumnData(string[] arry)
        {
            List<List<string>> columnData = new List<List<string>>();
            try
            {
                foreach (var str in arry)
                {
                    string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                    columnData.Add(sArray.ToList());
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return columnData;
        }

        List<List<string>> GetRowData(List<List<string>> columnData)
        {
            List<List<string>> rowData = new List<List<string>>();
            try
            {
                for (int n = 0; n < columnData[0].Count; n++)
                {
                    List<string> strList = new List<string>();
                    for (int i = 0; i < columnData.Count; i++)
                    {
                        strList.Add(columnData[i][n]);
                    }
                    rowData.Add(strList);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }

            return rowData;
        }

        public List<string> GetColumnKeyName(string[] arry)
        {
            List<string> strList = new List<string>();
            try
            {
                List<StructColumn> structColumn = new List<StructColumn>();

                structColumn = GetColumnFormat(arry);

                foreach (var st in structColumn)
                {
                    if (st.columnAttribute.ToUpper().Equals("KEY"))
                    {
                        strList.Add(st.columnName);
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        public List<string> GetColumnName(string[] arry)
        {

            List<string> strList = new List<string>();
            try
            {
                List<StructColumn> structColumn = new List<StructColumn>();
                structColumn = GetColumnFormat(arry);


                foreach (var st in structColumn)
                {
                    strList.Add(st.columnName);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        public List<Type> GetColumnType(string[] arry)
        {
            List<Type> strList = new List<Type>();
            try
            {
                List<StructColumn> structColumn = new List<StructColumn>();
                structColumn = GetColumnFormat(arry);

                foreach (var st in structColumn)
                {
                    strList.Add(st.columnType);
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList;
        }

        public DataTable CreateDataTable(CfgGetEntity entity, List<List<string>> rowData)
        {
            DataTable db = new DataTable(entity.TableName);
            try
            {
                List<StructColumn> structData = new List<StructColumn>();
                structData = GetColumnFormat(entity.ColumnFormat);
                foreach (var st in structData)
                {
                    //string strType = "System.String";
                    db.Columns.Add(st.columnName, st.columnType);
                }

                for (int i = 0; i < rowData.Count; i++)
                {
                    db.Rows.Add();
                    for (int n = 0; n < rowData[0].Count; n++)
                    {
                        db.Rows[i][n] = rowData[i][n];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public DataTable CreateDataTable(CfgGetEntity entity)
        {
            DataTable db = new DataTable(entity.TableName);
            try
            {
                List<StructColumn> structData = new List<StructColumn>();
                structData = GetColumnFormat(entity.ColumnFormat);
                foreach (var st in structData)
                {
                    //strType = "System.String";
                    db.Columns.Add(st.columnName, st.columnType);
                }

                List<List<string>> columnData = new List<List<string>>();
                columnData = GetColumnData(entity.ColumnData);

                List<List<string>> rowData = new List<List<string>>();
                rowData = GetRowData(columnData);

                for (int i = 0; i < rowData.Count; i++)
                {
                    db.Rows.Add();
                    for (int n = 0; n < rowData[0].Count; n++)
                    {
                        db.Rows[i][n] = rowData[i][n];
                    }
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return db;
        }

        public string[] DataTableConvert(DataTable db, List<string> strColumnName)
        {
            List<string> strList = new List<string>();
            try
            {
                foreach (var str in strColumnName)
                {
                    string strTmp = string.Empty;

                    foreach (DataRow dr in db.Rows)
                    {
                        strTmp += dr[str].ToString() + ":";
                    }

                    //List<string> strListColumn = new List<string>();
                    //strListColumn = (from d in dv.ToTable().AsEnumerable() select d.Field<string>(str)).ToList();

                    strList.Add(strTmp.TrimEnd(':'));
                }
            }
            catch (Exception ee)
            {
                MessageBox.Show(ee.Message);
            }
            return strList.ToArray();
        }
        #endregion
    }
}
