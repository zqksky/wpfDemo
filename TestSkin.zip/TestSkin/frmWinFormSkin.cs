﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormSkin;
using WinFormSkin.Controls;

namespace TestSkin
{
    public partial class frmWinFormSkin : WinForm
    {
        private readonly WinFormSkinManager winFormSkinManager;
        public frmWinFormSkin()
        {
            InitializeComponent();

            #region
            winFormSkinManager = WinFormSkinManager.Instance;
            winFormSkinManager.AddFormToManage(this);
            winFormSkinManager.Theme = WinFormSkinManager.Themes.LIGHT;
            winFormSkinManager.ColorScheme = new ColorScheme(Primary.BlueGrey800, Primary.BlueGrey900, Primary.BlueGrey500, Accent.LightBlue200, TextShade.WHITE);
            winFormSkinManager.ColorScheme = new ColorScheme(Primary.Indigo500, Primary.Indigo700, Primary.Indigo100, Accent.Pink200, TextShade.WHITE);
            winFormSkinManager.ColorScheme = new ColorScheme(Primary.Green600, Primary.Green700, Primary.Green200, Accent.Red100, TextShade.WHITE);

            #endregion
        }

        private void frmWinFormSkin_Load(object sender, EventArgs e)
        {

        }
    }
}
