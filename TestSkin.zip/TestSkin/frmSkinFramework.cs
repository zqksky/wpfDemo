﻿using SkinFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestSkin
{
    public partial class frmSkinFramework : Form
    {
        #region
        //To enable the skinning in your application, do these three simple steps:
        //1.Add an instance of the SkinningManager component to your Form 
        //2.Set the ParentForm property to the owner Form 
        //3.Set the DefaultSkin property to load any default skin, or load any custom Skin using the SkinningManager.LoadSkin(SkinBase) method
        #endregion

        public frmSkinFramework()
        {
            InitializeComponent();

        }

        private void frmSkinFramework_Load(object sender, EventArgs e)
        {
            DefaultSkin skin = DefaultSkin.Office2007Luna;
            skin = DefaultSkin.Office2007Luna;
            skin = DefaultSkin.Office2007Silver;
            skin = DefaultSkin.Office2007Obsidian;
            skinningManager1.DefaultSkin = skin;

            //skinningManager1.LoadDefaultSkin(skin);
        }
    }
}
