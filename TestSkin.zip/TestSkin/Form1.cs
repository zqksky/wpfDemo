﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TestSkin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnWinFormSkin_Click(object sender, EventArgs e)
        {
            frmWinFormSkin frm = new frmWinFormSkin();
            frm.ShowDialog();
        }


        private void btnMaterialSkin_Click(object sender, EventArgs e)
        {
            frmMaterialSkin frm = new frmMaterialSkin();
            frm.ShowDialog();
        }

        private void btnSkinFramework_Click(object sender, EventArgs e)
        {
            frmSkinFramework frm = new frmSkinFramework();
            frm.ShowDialog();
        }

        private void btnMetroframework_Click(object sender, EventArgs e)
        {
            frmMetroframework frm = new frmMetroframework();
            frm.ShowDialog();
        }
    }
}
