﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TestSqlLite.BaseFun;

namespace TestSqlLite
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //SQLiteHelp.Test();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            //TestTrainTime();
            //HtmlAgilityPackHelp.ReadUrl();
            HtmlAgilityPackHelp.Test();
        }

        private void TestWeather()
        {
            List<string> strList= WebServiceHelp.GetWeatherbyCityName(this.txtTest.Text);
            this.rtxtTest.Text = "";
            if (strList.Count <= 0)
            {
                this.rtxtTest.Text = "无" + this.txtTest.Text + "城市的天气信息";
                return;
            }
            foreach (string i in strList)
            {
                this.rtxtTest.Text += i;
            }
        }

        private void TestTrainTime()
        {
            List<string> strList = WebServiceHelp.GetStationName();
            this.rtxtTest.Text = "";
            foreach (string i in strList)
            {
                this.rtxtTest.Text += i;
            }
        }
    }
}
