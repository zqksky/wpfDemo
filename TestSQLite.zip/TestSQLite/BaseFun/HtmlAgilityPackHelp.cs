﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSqlLite.BaseFun
{
    class HtmlAgilityPackHelp
    {
        private static string url = "http://www.baidu.com";

        public static void Test()
        {
            List<string> strList = new List<string>();
            // The HtmlWeb class is a utility class to get the HTML over HTTP
            HtmlWeb htmlWeb = new HtmlWeb();

            // Creates an HtmlDocument object from an URL
            HtmlAgilityPack.HtmlDocument document = htmlWeb.Load(url);

            // Targets a specific node
            HtmlNode someNode = document.GetElementbyId("css_index");

            // If there is no node with that Id, someNode will be null
            if (someNode != null)
            {
                // Extracts all links within that node
                IEnumerable<HtmlNode> allLinks = someNode.Descendants("a");

                // Outputs the href for external links
                foreach (HtmlNode link in allLinks)
                {
                    // Checks whether the link contains an HREF attribute
                    if (link.Attributes.Contains("href"))
                    {
                        // Simple check: if the href begins with "http://", prints it out
                        if (link.Attributes["href"].Value.StartsWith("http://"))
                        {
                            strList.Add(link.Attributes["href"].Value);
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 获取页面标签值
        /// </summary>
        public static void ReadUrl()
        {
            HtmlWeb web = new HtmlWeb();
            HtmlAgilityPack.HtmlDocument doc = web.Load(url);
            //1.取网页内容
            var node = doc.DocumentNode;

            //查找id为dfTitle的值
            HtmlNodeCollection nodes = node.SelectNodes("//*[@id=\"dfTitle\"]");
            if (nodes != null)
            {
                //InnerText取整个网页内容,不包含html标签
                var title = nodes.FirstOrDefault().InnerText;
                //InnerText取整个网页内容,包含html标签
                var content = nodes.FirstOrDefault().InnerHtml;

            }

            //取网页特定值
            //表示先从html查找table里的a标签，div[2]表示2层div
            string xpathstring = "/html/body/div[2]/div/table/tr/td/a";
            HtmlNodeCollection nodes2 = doc.DocumentNode.SelectNodes(xpathstring);
            if (nodes != null)
            {
                foreach (var htmlNode in nodes2)
                {
                    var phref = htmlNode.Attributes["href"].Value;
                }
            }
        }
    }
}
