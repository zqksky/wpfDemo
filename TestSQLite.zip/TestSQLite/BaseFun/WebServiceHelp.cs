﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestSqlLite.BaseFun
{
    class WebServiceHelp
    {
        #region 常用的Webservice
        //引用时  http://webservice.webxml.com.cn/WebServices/StockInfoWS.asmx 
        //变为    http://www.webxml.com.cn/WebServices/StockInfoWS.asmx 

        //商业和贸易：

        //1、股票行情数据 WEB 服务（支持香港、深圳、上海基金、债券和股票；支持多股票同时查询）

        //Endpoint: http://webservice.webxml.com.cn/WebServices/StockInfoWS.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/StockInfoWS.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/WebServices/StockInfoWS.asmx?wsdl 

        //支持香港股票、深圳、上海封闭式基金、债券和股票；支持多股票同时查询。数据即时更新。此中国股票行情数据 WEB 服务仅作为用户获取信息之目的，并不构成投资建议。支持使用 | 符号分割的多股票查询。

        //2、中国开放式基金数据 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ChinaOpenFundWS.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ChinaOpenFundWS.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ChinaOpenFundWS.asmx?wsdl

        //中国开放式基金数据 WEB 服务，数据每天15：30以后及时更新。输出数据包括：证券代码、证券简称、单位净值、累计单位净值、前单位净值、净值涨跌额、净值增长率(%)、净值日期。只有商业用户可获得此中国开放式基金数据Web Services的全部功能，若有需要测试、开发和使用请QQ：8698053 或 联系我们

        //3、中国股票行情分时走势预览缩略图 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/webservices/ChinaStockSmallImageWS.asmx 

        //Disco: http://webservice.webxml.com.cn/webservices/ChinaStockSmallImageWS.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/webservices/ChinaStockSmallImageWS.asmx?wsdl

        //中国股票行情分时走势预览缩略图 WEB 服务（支持深圳和上海股市的全部基金、债券和股票），数据即时更新。返回数据：2种大小可选择的股票GIF分时走势预览缩略图字节数组和直接输出该预览缩略图。

        //4、外汇-人民币即时报价 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ForexRmbRateWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ForexRmbRateWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ForexRmbRateWebService.asmx?wsdl

        //外汇-人民币即时报价 WEB 服务， 报价数据即时更新。外汇-人民币即时报价 WEB 服务仅作为用户获取信息之目的，并不构成投资建议。支持人民币对：美元、欧元、英镑、日元、港币、加拿大元、新西兰元、新加坡元、瑞士法郎、瑞典克朗、泰国铢、挪威克朗、澳门元、澳大利亚元、丹麦克朗、菲律宾比索、清算瑞士法郎 等的兑换即时报价。

        //5、即时外汇汇率数据 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ExchangeRateWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ExchangeRateWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ExchangeRateWebService.asmx?wsdl

        //即时外汇汇率数据 WEB 服务，数据即时更新。此外汇汇率数据 WEB 服务支持29种以上基本汇率和交叉汇率即时外汇汇率数据，返回包括：代码、货币名称、最新价、涨跌%、涨跌金额、开盘价、最高价、最低价、震幅%、买入价、卖出价、涨跌颜色和数据时间。实例

        //6、中国股票行情数据 WEB 服务（支持深圳和上海股市的基金、债券和股票）

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ChinaStockWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ChinaStockWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/WebServices/ChinaStockWebService.asmx?wsdl

        //中国股票行情数据 WEB 服务，数据即时更新。输出GIF分时走势图、日/周/月K线图、及时行情（股票名称、行情时间、最新价、昨收盘、今开盘、涨跌额、最低、最高、涨跌幅、成交量、成交额、竞买价、竞卖价、委比、买一 - 买五、卖一 - 卖五）。

        //通讯和通信

        //1、国内手机号码归属地查询WEB服务


        //Endpoint: http://webservice.webxml.com.cn/WebServices/MobileCodeWS.asmx

        //Disco: http://webservice.webxml.com.cn/WebServices/MobileCodeWS.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/MobileCodeWS.asmx?wsdl 

        //国内手机号码归属地查询WEB服务，提供最新的国内手机号码段归属地数据，每月更新。包括最新的电信天翼189号段和最新移动152号段、TD-SCDMA188号段。数据更全更准确，是目前国内最新最全的手机号码段数据库！

        //2、腾讯QQ在线状态 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/webservices/qqOnlineWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/webservices/qqOnlineWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/webservices/qqOnlineWebService.asmx?wsdl

        //通过输入QQ号码（String）检测QQ在线状态。返回数据（String）Y = 在线；N = 离线 ；E = QQ号码错误......需要技术支持请：联系我们，欢迎技术交流。 QQ：8698053

        //3、Email 电子邮件地址验证 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ValidateEmailWebService.asmx

        //Disco: http://webservice.webxml.com.cn/WebServices/ValidateEmailWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ValidateEmailWebService.asmx?wsdl

        //Email 电子邮件地址验证 Web Service，通过查找给定的电子邮件域的邮件服务器和通过向邮件服务器发送数据来判断电子邮件地址正确与否。此Email地址验证Web Service请不要用于任何商业目的，若有需要请联系我们

        //图像与多媒体

        //1、验证码图片 WEB 服务 支持中文、字母、数字

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ValidateCodeWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ValidateCodeWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ValidateCodeWebService.asmx?wsdl

        //验证码图片 WEB 服务，输出PNG高品质格式的验证码图片和字节流，字符和字符之间的间距和高度随机产生，提高了验证码的安全性。支持中文、字母、数字验证码图片。[演示1]
        //[演示2]

        //公用事业

        //1、2500多个城市天气预报 WEB服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/WeatherWS.asmx?wsdl

        //2500多个城市天气预报Web服务，包含2400个以上中国城市和100个以上国外城市天气预报数据。数据每2.5小时左右自动更新一次，准确可靠。为让更多的开发人员学习WEB服务开发，此服务支持免费用户使用。为支持多种平台开发，此WEB服务接口提供了多种返回类型可选择。

        //2、国内飞机航班时刻表 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/webservices/DomesticAirline.asmx 

        //Disco: http://webservice.webxml.com.cn/webservices/DomesticAirline.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/webservices/DomesticAirline.asmx?wsdl 

        //国内飞机航班时刻表 Web Service 提供：通过出发城市和到达城市查询飞机航班、出发机场、到达机场、出发和到达时间、飞行周期、航空公司、机型等信息。

        //3、中国电视节目预告（电视节目表） WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/webservices/ChinaTVprogramWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/webservices/ChinaTVprogramWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/webservices/ChinaTVprogramWebService.asmx?wsdl 

        //中国电视节目预告 Web 服务，数据准确可靠，提供全国近800个电视拼道一个星期以上的节目预告数据。一、获得支持的省市（地区）和分类电视列表；二、通过省市ID或分类电视ID获得电视台列表；三、通过电视台ID获得该电视台频道名称；四、通过频道ID获得该频道节目列表。实例

        //4、火车时刻表 WEB 服务 （第六次提速最新列车时刻表）

        //Endpoint: http://webservice.webxml.com.cn/WebServices/TrainTimeWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/TrainTimeWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/WebServices/TrainTimeWebService.asmx?wsdl 

        //火车时刻表 WEB 服务提供：站站查询；车次查询；车站所有车次查询。数据来源时间：2008-04-15 第六次提速最新列车时刻表。本火车时刻表 WEB 服务提供的列车时刻表数据仅供参考，如有异议以当地铁路部门颁布为准。实例

        //5、400个国内外主要城市天气预报Web服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/WeatherWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/WeatherWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/WeatherWebService.asmx?wsdl

        //400个国内外主要城市天气预报Web服务，每个城市天气预报数据每0.5小时左右自动更新一次，（原来为每个城市2.5小时更新，为了保证已经引用此服务的部分用户不再重新更新已编写的程序，所以 Endpoint 上的说明没有更改），数据准确可靠。包括 340 多个中国主要城市和 60 多个国外主要城市三日内的天气预报数据。实例

        //获取标准数据

        //1、[新]
        //中文<->英文双向翻译WEB服务

        //Endpoint: http://fy.webxml.com.cn/webservices/EnglishChinese.asmx 

        //Disco: http://fy.webxml.com.cn/webservices/EnglishChinese.asmx?disco

        //WSDL: http://fy.webxml.com.cn/webservices/EnglishChinese.asmx?wsdl 

        //新中文<->英文双向翻译WEB服务，永久免费。提供翻译、音标（拼音）、解释、相关词条、例句、读音MP3支持（英文Only）、候选词等功能。比原来的中英文双向翻译WEB服务提供更多更强大的功能。帮助文档

        //2、中文 <-> 英文双向翻译 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/TranslatorWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/TranslatorWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/TranslatorWebService.asmx?wsdl 

        //中文 <-> 英文双向翻译 WEB 服务，本词典库中大部分单词是由程序根据词频和英<->中单词间相互关联程度自动生成，难免存在有解释错误和牵强的地方请大家谅解。

        //3、中国邮政编码 <-> 地址信息双向查询/搜索 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/ChinaZipSearchWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/ChinaZipSearchWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/ChinaZipSearchWebService.asmx?wsdl

        //中国邮政编码搜索 WEB 服务包含中国全部邮政编码共计187285条记录，是目前最完整的邮政编码数据，精确到乡镇级、城市精确到街道，支持邮政编码<->城市、乡镇、街道的双向查询。此邮政编码查询仅供参考，如邮政编码或地址有变动请以当地邮局为准，也请及时通知我们进行更正。

        //4、IP地址来源搜索 WEB 服务（是目前最完整的IP地址数据）

        //Endpoint: http://webservice.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx

        //Disco: http://webservice.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/WebServices/IpAddressSearchWebService.asmx?wsdl 

        //IP地址搜索 WEB 服务包含中国和国外已知的IP地址数据，是目前最完整的IP地址数据，记录数量现已超过30万条并还在不断更新和增加中，感谢纯真网络提供IP地址数据来源。因IP地址在不断变化，此IP地址数据查询仅供参考。

        //其他服务

        //1、中文简体字<->繁体字转换 WEB 服务

        //Endpoint:http://webservice.webxml.com.cn/WebServices/TraditionalSimplifiedWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/TraditionalSimplifiedWebService.asmx?disco 

        //WSDL: http://webservice.webxml.com.cn/WebServices/TraditionalSimplifiedWebService.asmx?wsdl

        //中文简体字<->繁体字转换 WEB 服务，此Web Services请不要用于任何商业目的，若有需要请联系我们，欢迎技术交流。使用本站 WEB 服务请注明或链接本站：http://www.webxml.com.cn/ 感谢大家的支持！

        //2、随机英文、数字和中文简体字 WEB 服务

        //Endpoint: http://webservice.webxml.com.cn/WebServices/RandomFontsWebService.asmx 

        //Disco: http://webservice.webxml.com.cn/WebServices/RandomFontsWebService.asmx?disco

        //WSDL: http://webservice.webxml.com.cn/WebServices/RandomFontsWebService.asmx?wsdl

        //随机英文、数字和中文简体字 WEB 服务，可用于验证码[演示1] [演示2]及其他方面，这里支持最多不超过8个随机中文简体字，10个随机英文、数字输出（一般也够了:P），如需要更多输出请联系我们。

        #endregion

        #region WorldWeather
        public static void TestWorldWeather()
        {
            GetRegionCountry();
        }

        //getRegionCountry
        //获得国外国家名称和与之对应的ID
        //输入参数：无，
        //返回数据：一维字符串数组。
        public static List<string> GetRegionCountry()
        {
            List<string> strList = new List<string>();
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            string[] strValue = ws.getRegionCountry();
            strList = strValue.ToList();

            return strList;
        }

        //getRegionDataset
        //获得中国省份、直辖市、地区；国家名称（国外）和与之对应的ID
        //输入参数：无，
        //返回数据：DataSet。
        public static DataSet GetRegionDataset()
        {
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            DataSet ds = ws.getRegionDataset();

            return ds;
        }

        //getRegionProvince
        //获得中国省份、直辖市、地区和与之对应的ID
        //输入参数：无，
        //返回数据：一维字符串数组。
        public static List<string> GetRegionProvince()
        {
            List<string> strList = new List<string>();
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            string[] strValue = ws.getRegionProvince();
            strList = strValue.ToList();

            return strList;
        }


        //getSupportCityDataset
        //获得支持的城市/地区名称和与之对应的ID
        //输入参数：theRegionCode = 省市、国家ID或名称，
        //返回数据：DataSet。
        public static DataSet GetSupportCityDataset(string strRegionCode)
        {
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            DataSet ds = ws.getSupportCityDataset(strRegionCode);

            return ds;
        }

        //getSupportCityString
        //获得支持的城市/地区名称和与之对应的ID
        //输入参数：theRegionCode = 省市、国家ID或名称，
        //返回数据：一维字符串数组。
        public static List<string> GetSupportCityString(string strRegionCode)
        {
            List<string> strList = new List<string>();
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            string[] strValue = ws.getSupportCityString(strRegionCode);
            strList = strValue.ToList();

            return strList;
        }

        //getWeather
        //获得天气预报数据
        //输入参数：城市/地区ID或名称，
        //返回数据：一维字符串数组。
        public static List<string> GetWeather(string strCityCode, string strUserId)
        {
            List<string> strList = new List<string>();
            WorldWeatherWebService.WeatherWS ws = new WorldWeatherWebService.WeatherWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWS.asmx";
            string[] strValue = ws.getWeather(strCityCode, strUserId);
            strList = strValue.ToList();

            return strList;
        }

        #endregion

        #region DomesticWeather
        public static void TestDomesticWeather()
        {
        }

        //getSupportProvince()
        //获得本天气预报Web Services支持的洲、国内外省份和城市信息
        //输入参数：无； 返回数据：一个一维字符串数组 String()，内容为洲或国内省份的名称。
        public static List<string> GetSupportProvince()
        {
            List<string> strList = new List<string>();
            WeatherWebService.WeatherWebService ws = new WeatherWebService.WeatherWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getSupportProvince();
            strList = strValue.ToList();

            return strList;
        }

        //getSupportCity(string byProvinceName)
        //查询本天气预报Web Services支持的国内外城市或地区信息
        //输入参数：byProvinceName = 指定的洲或国内的省份，若为ALL或空则表示返回全部城市；返回数据：一个一维字符串数组 String()，结构为：城市名称(城市代码)。
        public static List<string> GetSupportCity(string byProvinceName)
        {
            List<string> strList = new List<string>();
            WeatherWebService.WeatherWebService ws = new WeatherWebService.WeatherWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getSupportCity(byProvinceName);
            strList = strValue.ToList();

            return strList;
        }

        //getSupportDataSet()
        //获得本天气预报Web Services支持的洲、国内外省份和城市信息
        //输入参数：无；返回：DataSet 。DataSet.Tables(0) 为支持的洲和国内省份数据，DataSet.Tables(1) 为支持的国内外城市或地区数据。DataSet.Tables(0).Rows(i).Item("ID") 主键对应 DataSet.Tables(1).Rows(i).Item("ZoneID") 外键。
        //Tables(0)：ID = ID主键，Zone = 支持的洲、省份；Tables(1)：ID 主键，ZoneID = 对应Tables(0)ID的外键，Area = 城市或地区，AreaCode = 城市或地区代码。
        public static DataSet GetSupportDataSet()
        {
            List<string> strList = new List<string>();
            WeatherWebService.WeatherWebService ws = new WeatherWebService.WeatherWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getSupportDataSet();

            return ds;
        }

        //getWeatherbyCityName(string theCityName)
        //根据城市或地区名称查询获得未来三天内天气情况、现在的天气实况、天气和生活指数
        //调用方法如下：输入参数：theCityName = 城市中文名称(国外城市可用英文)或城市代码(不输入默认为上海市)，如：上海 或 58367，如有城市名称重复请使用城市代码查询(可通过 getSupportCity 或 getSupportDataSet 获得)；返回数据： 一个一维数组 String(22)，共有23个元素。
        //String(0) 到 String(4)：省份，城市，城市代码，城市图片名称，最后更新时间。String(5) 到 String(11)：当天的 气温，概况，风向和风力，天气趋势开始图片名称(以下称：图标一)，天气趋势结束图片名称(以下称：图标二)，现在的天气实况，天气和生活指数。String(12) 到 String(16)：第二天的 气温，概况，风向和风力，图标一，图标二。String(17) 到 String(21)：第三天的 气温，概况，风向和风力，图标一，图标二。String(22) 被查询的城市或地区的介绍
        //下载天气图标(包含大、中、小尺寸) 天气图例说明 调用此天气预报Web Services实例下载(VB ASP.net 2.0)
        public static List<string> GetWeatherbyCityName(string strCityName)
        {
            List<string> strList = new List<string>();
            WeatherWebService.WeatherWebService ws = new WeatherWebService.WeatherWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getWeatherbyCityName(strCityName);
            strList = strValue.ToList();

            return strList;
        }

        //getWeatherbyCityNamePro
        //根据城市或地区名称查询获得未来三天内天气情况、现在的天气实况、天气和生活指数（For商业用户）
        public static List<string> GetWeatherbyCityNamePro(string strCityName,string strUserId)
        {
            List<string> strList = new List<string>();
            WeatherWebService.WeatherWebService ws = new WeatherWebService.WeatherWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getWeatherbyCityNamePro(strCityName, strUserId);
            strList = strValue.ToList();

            return strList;
        }

        #endregion

        #region TrainTime
        public static void TestTrainTime()
        {
        }

        //getDetailInfoByTrainCode
        //通过火车车次查询列车经由车站明细 DataSet
        //输入参数：车次代号字符串，空字符串默认上海到北京D32次，UserID = 商业用户ID（普通用户不需要）；
        //返回数据：DataSet，Item.(TrainStation)=车站名称、Item.(ArriveTime)=到站时间、Item.(StartTime)=发车时间、Item.(KM)=里程(KM)
        public static DataSet GetDetailInfoByTrainCode(string strTrainCode,string strUserId)
        {
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getDetailInfoByTrainCode(strTrainCode, strUserId);

            return ds;
        }

        //getStationAndTimeByStationName
        //通过发车站和到达站查询火车时刻表 DataSet
        //输入参数：StartStation = 发车站，ArriveStation = 到达站（支持第一个字匹配模糊查询），空字符串默认发车站上海和到达站北京，UserID = 商业用户ID（普通用户不需要）；
        //返回数据：DataSet，Item.(TrainCode)=车次、Item.(FirstStation)=始发站、Item.(LastStation)=终点站、Item.(StartStation)=发车站、Item.(StartTime)=发车时间、Item.(ArriveStation)=到达站、Item.(ArriveTime)=到达时间、Item.(KM)=里程(KM)、Item.(UseDate)=历时
        public static DataSet GetStationAndTimeByStationName(string strStartStation, string ArriveStation, string strUserId)
        {
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getStationAndTimeByStationName(strStartStation, ArriveStation, strUserId);

            return ds;
        }


        //getStationAndTimeByTrainCode
        //通过火车车次查询火车时刻表 String()
        //输入参数：车次代号字符串，空字符串默认上海到北京D32次，UserID = 商业用户ID（普通用户不需要）；
        //返回数据：一个一维字符串数组 String(9)，String(0)=车次、String(1)=始发站、String(2)=终点站、String(3)=发车站、String(4)=发车时间、String(5)=到达站、String(6)=到达时间、String(7)=里程(KM)、String(8)=历时、String(9)=空字符串(备用)
        public static List<string> GetStationAndTimeByTrainCode(string strTrainCode, string strUserId)
        {
            List<string> strList = new List<string>();
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getStationAndTimeByTrainCode(strTrainCode, strUserId);
            strList = strValue.ToList();

            return strList;
        }


        //getStationAndTimeDataSetByLikeTrainCode
        //通过火车车次查询本火车时刻表（支持模糊查询） DataSet
        //输入参数：车次代号字符串（支持模糊查询），空字符串默认上海到北京D32次，UserID = 商业用户ID（普通用户不需要）；
        //返回数据：DataSet，Item.(TrainCode)=车次、Item.(FirstStation)=始发站、Item.(LastStation)=终点站、Item.(StartStation)=发车站、Item.(StartTime)=发车时间、Item.(ArriveStation)=到达站、Item.(ArriveTime)=到达时间、Item.(KM)=里程(KM)、Item.(UseDate)=历时
        public static DataSet GetStationAndTimeDataSetByLikeTrainCode(string strTrainCode, string strUserId)
        {
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getStationAndTimeDataSetByLikeTrainCode(strTrainCode, strUserId);

            return ds;
        }

        //getStationAndTimeDataSetByTrainCode
        //通过火车车次查询本火车时刻表 DataSet
        //输入参数：车次代号字符串，空字符串默认上海到北京D32次，UserID = 商业用户ID（普通用户不需要）；
        //返回数据：DataSet，Item.(TrainCode)=车次、Item.(FirstStation)=始发站、Item.(LastStation)=终点站、Item.(StartStation)=发车站、Item.(StartTime)=发车时间、Item.(ArriveStation)=到达站、Item.(ArriveTime)=到达时间、Item.(KM)=里程(KM)、Item.(UseDate)=历时
        public static DataSet getStationAndTimeDataSetByTrainCode(string strTrainCode, string strUserId)
        {
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getStationAndTimeDataSetByTrainCode(strTrainCode, strUserId);

            return ds;
        }

        //getStationName
        //获得本火车时刻表Web Services的全部始发站名称
        //输入参数：无，
        //输出参数 String()
        public static List<string> GetStationName()
        {
            List<string> strList = new List<string>();
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string[] strValue = ws.getStationName();
            strList = strValue.ToList();

            return strList;
        }

        //getStationNameDataSet
        //获得本火车时刻表Web Services支持的全部站台名称和拼音缩写 DataSet
        //输入参数：无；
        //返回数据：DataSet 结构为 站台名称、拼音缩写，按拼音缩写升序排列
        public static DataSet GetStationNameDataSet()
        {
            List<string> strList = new List<string>();
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            DataSet ds = ws.getStationNameDataSet();

            return ds;
        }

        //getVersionTime
        //获得本火车时刻表Web Services的数据库版本更新时间
        //输入参数：无，
        //输出参数 String
        public static string GetVersionTime()
        {
            TrainTimeWebService.TrainTimeWebService ws = new TrainTimeWebService.TrainTimeWebService();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/WeatherWebService.asmx";
            string str = ws.getVersionTime();

            return str;
        }

        #endregion

        #region DomesticAirline
        public static void TestDomesticAirline()
        {
        }

        //getDomesticAirlinesTime
        //获得航班时刻表 DataSet
        //输入参数：startCity = 出发城市（中文城市名称或缩写、空则默认：上海）；lastCity = 抵达城市（中文城市名称或缩写、空则默认：北京）；theDate = 出发日期（String 格式：yyyy-MM-dd，如：2007-07-02，空则默认当天）；userID = 商业用户ID（免费用户不需要）
        //返回数据：DataSet，Table(0)结构为 Item(Company)航空公司、Item(AirlineCode)航班号、Item(StartDrome)出发机场、Item(ArriveDrome)到达机场、Item(StartTime)出发时间、Item(ArriveTime)到达时间、Item(Mode)机型、Item(AirlineStop)经停、Item(Week)飞行周期（星期）
        public static DataSet GetDomesticAirlinesTime(string strStartCity,string strLastCity,string strDate,string strUserId)
        {
            DomesticAirlineWebService.DomesticAirline ws = new DomesticAirlineWebService.DomesticAirline();
            //ws.Url = @"http://www.webxml.com.cn/webservices/DomesticAirline.asmx";
            DataSet ds = ws.getDomesticAirlinesTime(strStartCity, strLastCity, strDate, strUserId);

            return ds;
        }

        //getDomesticCity
        //获得这国内飞机航班时刻表Web Services支持的全部城市中英文名称和缩写 DataSet
        //输入参数：无；
        //返回数据：DataSet 结构为 Item(enCityName)城市英文名称、Item(cnCityName)城市中文名称、Item(Abbreviation)缩写，按城市英文名称升序排列
        public static DataSet GetDomesticCity()
        {
            DomesticAirlineWebService.DomesticAirline ws = new DomesticAirlineWebService.DomesticAirline();
            //ws.Url = @"http://www.webxml.com.cn/webservices/DomesticAirline.asmx";
            DataSet ds = ws.getDomesticCity();

            return ds;
        }

        #endregion

        #region MobileCode
        public static void TestMobileCode()
        {
        }

        //getDatabaseInfo
        //获得国内手机号码归属地数据库信息
        //输入参数：无；
        //返回数据：一维字符串数组（省份 城市 记录数量）。
        public static List<string> GetDatabaseInfo()
        {
            List<string> strList = new List<string>();
            MobileCodeWebService.MobileCodeWS ws = new MobileCodeWebService.MobileCodeWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/MobileCodeWS.asmx";
            string[] strValue = ws.getDatabaseInfo();
            strList = strValue.ToList();

            return strList;
        }

        //getMobileCodeInfo
        //获得国内手机号码归属地省份、地区和手机卡类型信息
        //输入参数：mobileCode = 字符串（手机号码，最少前7位数字），userID = 字符串（商业用户ID） 免费用户为空字符串；
        //返回数据：字符串（手机号码：省份 城市 手机卡类型）。
        public static string GetMobileCodeInfo(string strMobileCode, string strUserId)
        {
            MobileCodeWebService.MobileCodeWS ws = new MobileCodeWebService.MobileCodeWS();
            //ws.Url = @"http://www.webxml.com.cn/WebServices/MobileCodeWS.asmx";
            string str = ws.getMobileCodeInfo(strMobileCode, strUserId);

            return str;
        }

        #endregion
    }
}
