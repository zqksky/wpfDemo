﻿using System;
using System.Collections.Generic;
using System.Data;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections.ObjectModel;

namespace R2R.Service.ManualService
{
    public class QueryManualService : IQueryManualService
    {
        public ObservableCollection<ManualDedicationRow> QueryDedicationWaferList4Layer(string userId, string clientVersion, string layerId, out string retMsg)
        {

            retMsg = null;
            MyLogger.Trace("QueryManualService.QueryLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("LayerId{0}", layerId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, 
                        EMethod.QueryDedicationWaferList4Layer, 
                        arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("QueryManualService.QueryLayer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        ObservableCollection<ManualDedicationRow> manualListObs = new ObservableCollection<ManualDedicationRow>();
                            
                        List<ManualDedicationRow> manualList
                            = JsonHelp.DeserializeJsonToList<ManualDedicationRow>(result.ReturnMsg);
                        foreach (ManualDedicationRow temp in manualList)
                        {
                            manualListObs.Add(temp);
                        }
                        return manualListObs;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("QueryManualService.QueryLayer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public ObservableCollection<ManualDedicationRow> QueryDedicationWaferListByRoot(string userId, string clientVersion, string rootId, out string retMsg)
        {

            retMsg = null;
            MyLogger.Trace("QueryManualService.QueryWafer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("RootId{0}", rootId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("RootId", rootId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, 
                        EMethod.QueryDedicationWaferListByRoot, 
                        arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("QueryManualService.QueryWafer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        ObservableCollection<ManualDedicationRow> manualListObs = new ObservableCollection<ManualDedicationRow>();
                        List<ManualDedicationRow> manualList
                            = JsonHelp.DeserializeJsonToList<ManualDedicationRow>(result.ReturnMsg);
                        foreach (ManualDedicationRow temp in manualList)
                        {
                            manualListObs.Add(temp);
                        }
                        return manualListObs;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("QueryManualService.QueryWafer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public bool AddDedicationWafer(string userId, string clientVersion, ManualDedicationRow dedicationWafer, out string retMsg)
        {
            retMsg = null;
            string dedicationWaferJsonStr = JsonHelp.SerializeObject(dedicationWafer);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("DedicationWafer", dedicationWaferJsonStr);
            MyLogger.Trace("QueryManualService.AddDedicationWafer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("DedicationWafer<{0}>", dedicationWaferJsonStr));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, 
                        EMethod.AddDedicationWafer, 
                        arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("QueryManualService.AddDedicationWafer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("QueryManualService.AddDedicationWafer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool DeleteDedicationWafer(string userId, string clientVersion, ManualDedicationRow dedicationWafer, out string retMsg)
        {
            retMsg = null;
            string dedicationWaferJsonStr = JsonHelp.SerializeObject(dedicationWafer);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("DedicationWafer", dedicationWaferJsonStr);
            MyLogger.Trace("QueryManualService.DeleteDedicationWafer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("DedicationWafer<{0}>", dedicationWaferJsonStr));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, 
                        EMethod.DeleteDedicationWafer, 
                        arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("QueryManualService.DeleteDedicationWafer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("QueryManualService.DeleteDedicationWafer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
    }
}
