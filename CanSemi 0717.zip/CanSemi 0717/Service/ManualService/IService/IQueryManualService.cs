﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using System.Collections.ObjectModel;

namespace R2R.Service.ManualService
{
    public interface IQueryManualService
    {
        ObservableCollection<ManualDedicationRow> QueryDedicationWaferList4Layer(string username, string clientVersion, string layerId, out string retMsg);
        ObservableCollection<ManualDedicationRow> QueryDedicationWaferListByRoot(string username, string clientVersion, string rootId, out string retMsg);
        bool AddDedicationWafer(string username, string clientVersion, ManualDedicationRow dedicationWafer, out string retMsg);
        bool DeleteDedicationWafer(string username, string clientVersion, ManualDedicationRow dedicationWafer, out string retMsg);
    }
}