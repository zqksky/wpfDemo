﻿using Newtonsoft.Json;
using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.VO
{
    public class CDInfoModel
    {
        public string Tool { get; set; }
        public string Product { get; set; }
        public string Layer { get; set; }
        public string Reticle { get; set; }
    }
}
