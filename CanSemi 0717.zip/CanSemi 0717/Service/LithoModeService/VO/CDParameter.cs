﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService.VO
{
    public class CDParameter
    {
        public string ParameterName { get; set; }
        public string Value { get; set; }
        public string Lower { get; set; }
        public string Upper { get; set; }
    }
}
