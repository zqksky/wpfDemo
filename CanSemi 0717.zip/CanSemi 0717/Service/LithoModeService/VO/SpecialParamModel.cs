﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService.VO
{
    public class SpecialParamModel
    {
        public string UsedTime { get; set; }
        public string LotId { get; set; }
        public string RunCardId { get; set; }
        public string SplitId { get; set; }

        public string Tool { get; set; }
        public string Product { get; set; }
        public string Layer { get; set; }
        public string Reticle { get; set; }
    }
}