﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;
using R2R.Service.VO;

namespace R2R.Service.LithoModeService
{
    public class ParameterConfigOVLService : IParameterConfigOVLService
    {

        public OVLContextContent GetOVLContext(string userId, 
            string clientVersion,
            string productId,
            string layerId,
            string tool,
            string reticleId,
            string recipeId,
            string preTool,
            string preReticle,
            string chuck,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ParameterConfigOVLService.GetOVLContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle) +
                            string.Format("Chuck<{0}>", chuck));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", tool);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("ReticleId", reticleId);
                    arguDic.Add("RecipeId", recipeId);
                    arguDic.Add("PreTool", preTool);
                    arguDic.Add("PreReticle", preReticle);
                    arguDic.Add("Chuck", chuck);
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigOVLService, EMethod.GetContextContentOVL, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ParameterConfigOVLService.GetOVLContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        OVLContextContent oVLContext = JsonHelp.DeserializeJsonToObject<OVLContextContent>(result.ReturnMsg);
                        if (oVLContext.comment == null)
                            oVLContext.comment = new CommentEntity();
                        if (oVLContext.specConfig == null)
                            oVLContext.specConfig = new OVLSpecConfigContent();
                        if (oVLContext.parametersRows == null)
                            oVLContext.parametersRows = new List<ParameterRow>();
                        return oVLContext;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLithoColumnList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public bool SaveOVLParameters(string userId,
            string clientVersion,
            string chuck, 
            OVLContextContent contextContent,
            OVLContextContent OriContextContent,
            out OVLContextContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null; 
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", contextContent.ProductId);
            arguDic.Add("LayerId", contextContent.LayerId);
            arguDic.Add("ToolId", contextContent.ToolId);
            arguDic.Add("ReticleId", contextContent.ReticleId);
            try
            {
                string jsonParams = JsonHelp.SerializeObject(contextContent);
                string OriJsonParams = JsonHelp.SerializeObject(OriContextContent);
                arguDic.Add("Parameters", jsonParams);
                arguDic.Add("OriParameters", OriJsonParams);
                MyLogger.Trace("ParameterConfigOVLService.SaveOVLParameters :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("Chuck<{0}>", chuck) +
                            string.Format("Parameters<{0}>", jsonParams) +
                            string.Format("OriParameters<{0}>", OriJsonParams));
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("RecipeId", "");
                    arguDic.Add("Chuck", chuck);
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigOVLService, EMethod.SaveContextConfigOVL, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ParameterConfigOVLService.SaveOVLParameters Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<OVLContextContent>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ParameterConfigOVLService.SaveOVLParameters Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }


        public bool ResetHorizonOVL(string userId,
                             string clientVersion,
                             string productId,
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             string preTool,
                             string preReticle,
                             out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", tool);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            try
            {
                MyLogger.Trace("ParameterConfigOVLService.ResetHorizonOVL :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle));
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    //ovl
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigOVLService, EMethod.ResetHorizonOVL, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ParameterConfigOVLService.ResetHorizonOVL Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ParameterConfigOVLService.ResetHorizonOVL Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
    }
}