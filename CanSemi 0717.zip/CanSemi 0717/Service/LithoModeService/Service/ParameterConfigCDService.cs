﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;
using R2R.Service.VO;


namespace R2R.Service.LithoModeService
{
    public class ParameterConfigCDService : IParameterConfigCDService
    {
        public CDContextContent GetCDContext(string userId, string clientVersion, string productId, string layerId, string tool, string reticleId, string recipeId, string chuck, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ParameterConfigCDService.GetCDContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("Chuck<{0}>", chuck));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", tool);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("ReticleId", reticleId);
                    arguDic.Add("RecipeId", recipeId);
                    arguDic.Add("Chuck", chuck);
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigCDService, EMethod.GetContextContentCD, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetLithoColumnList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        CDContextContent cDContext = JsonHelp.DeserializeJsonToObject<CDContextContent>(result.ReturnMsg);
                        if(cDContext.comment == null)
                            cDContext.comment = new CommentEntity();
                        if (cDContext.specConfig == null)
                            cDContext.specConfig = new CDSpecConfigContent();
                        if (cDContext.parametersRows == null)
                            cDContext.parametersRows = new List<ParameterRow>();
                        return cDContext;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLithoColumnList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public bool SaveCDParameters(string userId,
            string clientVersion, 
            string chuck,
            CDContextContent contextContent,
            CDContextContent OriContextContent,
            out CDContextContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", contextContent.ProductId);
            arguDic.Add("LayerId", contextContent.LayerId);
            arguDic.Add("ToolId", contextContent.ToolId);
            arguDic.Add("ReticleId", contextContent.ReticleId);
            arguDic.Add("RecipeId", contextContent.RecipeId);    
            try
            {
                string jsonParams = JsonHelp.SerializeObject(contextContent);
                string OriJsonParams = JsonHelp.SerializeObject(OriContextContent);
                arguDic.Add("Parameters", jsonParams);
                arguDic.Add("OriParameters", OriJsonParams);
                MyLogger.Trace("ParameterConfigCDService.SaveCDParameters :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("Parameters<{0}>", jsonParams) +
                            string.Format("OriParameters<{0}>", OriJsonParams));
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    //cd
                    arguDic.Add("Chuck", chuck);
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigCDService, EMethod.SaveContextConfigCD, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ParameterConfigCDService.SaveCDParameters Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<CDContextContent>(result.ReturnMsg);
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ParameterConfigCDService.SaveCDParameters Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }


        public bool ResetHorizonCD(string userId,
                             string clientVersion,
                             string productId,
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", tool);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            try
            {
                MyLogger.Trace("ParameterConfigCDService.ResetHorizonCD :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) );
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    //cd
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigCDService, EMethod.ResetHorizonCD, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ParameterConfigCDService.ResetHorizonCD Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ParameterConfigCDService.ResetHorizonCD Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
    }
}