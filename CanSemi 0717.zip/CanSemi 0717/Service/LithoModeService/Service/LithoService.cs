﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Service.VO;
using System.Windows.Forms;
using R2R.Common.Data.Litho;
using System.Data;

namespace R2R.Service.LithoModeService
{
    public class LithoService : ILithoService
    {
        private List<ColumnEntity> CDColumns = new List<ColumnEntity>();
        private List<ColumnEntity> OVLColumns = new List<ColumnEntity>();

        public List<DataView> GetLithoColumnList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetLithoColumnList :: " + 
                            string.Format("UserId<{0}>", userId) + 
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<DataView> dataViews = new List<DataView>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetModeColumnList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetLithoColumnList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        LithoModelColumnEntity lithoModelColumns = JsonHelp.DeserializeJsonToObject<LithoModelColumnEntity>(result.ReturnMsg);
                        DataView cdDataView = getCDColumn(lithoModelColumns);
                        DataView ovlDataView = getOVLColumn(lithoModelColumns);
                        dataViews.Add(cdDataView);
                        dataViews.Add(ovlDataView);
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLithoColumnList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return dataViews;
        }

        public List<string> GetProductList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetProductList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> products = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetProductList Reply :: " + 
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        foreach(ProductEntity product in productList)
                        {
                            products.Add(product.ProductId);
                        }
                        return products;
                    }
                }
                
            }
            catch(Exception ex)
            {
                MyLogger.Error("LithoService.GetProductList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<string> GetLayerList(string userId, string clientVersion, string productId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetLayerList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetLayerList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetLayerList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                        foreach (LayerEntity layer in layerList)
                        {
                            layers.Add(layer.LayerId);
                        }
                        return layers;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public DataView GetCDDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetCDDataList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ToolType<{0}>", toolType));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("ToolId", tool);
                    arguDic.Add("ToolType", toolType);
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetContextRowsCD, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetCDDataList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<CDContextRow> cDContextRows = JsonHelp.DeserializeJsonToList<CDContextRow>(result.ReturnMsg);
                        DataTable cdData = getCDTable(cDContextRows, dt);
                        return new DataView(cdData);
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetCDDataList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return new DataView(dt);
        }

        public DataView GetOVLDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetOVLDataList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ToolType<{0}>", toolType));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("ToolId", tool);
                    arguDic.Add("ToolType", toolType);
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetContextRowsOVL, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetOVLDataList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<OVLContextRow> ovlContextRows = JsonHelp.DeserializeJsonToList<OVLContextRow>(result.ReturnMsg);
                        DataTable ovlData = getOVLTable(ovlContextRows, dt);
                        return new DataView(ovlData);
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetCDDataList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return new DataView(dt);
        }


        public bool ResetHorizonByTool(string userId,
            string clientVersion,
            string tool,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.ResetHorizonByTool :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", tool) );
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", tool);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.ResetHorizonByTool, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.ResetHorizonByTool Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.ResetHorizonByTool Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public ToolResetHistory GetLatestResetHistory4Tool(string userId,
            string clientVersion,
            string tool,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.GetLatestResetHistory4Tool :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", tool) );
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", tool);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.GetLatestResetHistory4Tool, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetLatestResetHistory4Tool Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        ToolResetHistory tooResetHistory = JsonHelp.DeserializeJsonToObject<ToolResetHistory>(result.ReturnMsg);
                        return tooResetHistory;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLatestResetHistory4Tool Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<HistoryEntity> QueryCDConfigOperationHist(string userId,
            string clientVersion,
            string tool,
            string product,
            string layer,
            string reticle,
            string recipe,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.QueryCDConfigOperationHist :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ProductId<{0}>", product) +
                            string.Format("LayerId<{0}>", layer) +
                            string.Format("ReticleId<{0}>", reticle) +
                            string.Format("RecipeId<{0}>", recipe));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", tool);
            arguDic.Add("ProductId", product);
            arguDic.Add("LayerId", layer);
            arguDic.Add("ReticleId", reticle);
            arguDic.Add("RecipeId", recipe);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.QueryOVLConfigOperationHist, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.QueryCDConfigOperationHist Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<HistoryEntity> historyList = JsonHelp.DeserializeJsonToList<HistoryEntity>(result.ReturnMsg);
                        return historyList;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.QueryCDConfigOperationHist Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<HistoryEntity> QueryOVLConfigOperationHist(string userId,
                                    string clientVersion,
                                    string tool,
                                    string product,
                                    string layer,
                                    string reticle,
                                    string preLayerTool,
                                    string preLayerReticle,
                                    string recipe,
                                    out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("LithoService.QueryOVLConfigOperationHist :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ProductId<{0}>", product) +
                            string.Format("LayerId<{0}>", layer) +
                            string.Format("ReticleId<{0}>", reticle) +
                            string.Format("PreTool<{0}>", preLayerTool) +
                            string.Format("PreReticle<{0}>", preLayerReticle) +
                            string.Format("RecipeId<{0}>", recipe));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", tool);
            arguDic.Add("ProductId", product);
            arguDic.Add("LayerId", layer);
            arguDic.Add("ReticleId", reticle);
            arguDic.Add("PreTool", preLayerTool);
            arguDic.Add("PreReticle", preLayerReticle);
            arguDic.Add("RecipeId", recipe);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.LithoService, EMethod.QueryOVLConfigOperationHist, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.QueryOVLConfigOperationHist Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<HistoryEntity> historyList = JsonHelp.DeserializeJsonToList<HistoryEntity>(result.ReturnMsg);
                        return historyList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.QueryOVLConfigOperationHist Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        private DataView getCDColumn(LithoModelColumnEntity lithoModel)
        {
            if (lithoModel.CDCols == null || lithoModel.CDCols.Count == 0)
            {
                DataTable cdTable = TTable.CDTable();
                return new DataView(cdTable);
            }
            DataTable dt = new DataTable();
            foreach(ColumnEntity column in lithoModel.CDCols)
            {
                CDColumns.Add(column);
                if (!column.Hidden)
                {
                    dt.Columns.Add(column.ColumnName, System.Type.GetType("System.String"));
                }
            }
            return new DataView(dt);
        }

        private DataView getOVLColumn(LithoModelColumnEntity lithoModel)
        {
            if (lithoModel.OVLCols == null || lithoModel.OVLCols.Count == 0)
            {
                DataTable ovlTable = TTable.OVLTable();
                return new DataView(ovlTable);
            }
            DataTable dt = new DataTable();
            foreach (ColumnEntity column in lithoModel.OVLCols)
            {
                this.OVLColumns.Add(column);
                if (!column.Hidden)
                {
                    dt.Columns.Add(column.ColumnName, System.Type.GetType("System.String"));
                }
            }
            return new DataView(dt);
        }

        private DataTable getCDTable(List<CDContextRow> cDContextRows, DataTable dt)
        {
            if (cDContextRows == null || cDContextRows.Count == 0 || dt == null)
            {
                return null;
            }
            dt.Clear();
            foreach (CDContextRow row in cDContextRows)
            {
                DataRow dr = dt.NewRow();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    foreach(ColumnEntity column in this.CDColumns)
                    {
                        if(dt.Columns[i].ColumnName == column.ColumnName)
                        {
                            dr[column.ColumnName] = CommonHelp.GetModelValue(column.FieldName, row);
                            break;
                        }

                    }
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }

        private DataTable getOVLTable(List<OVLContextRow> ovlContextRows, DataTable dt)
        {
            if (ovlContextRows == null || ovlContextRows.Count == 0 || dt == null)
            {
                return null;
            }
            dt.Clear();
            foreach (OVLContextRow row in ovlContextRows)
            {
                DataRow dr = dt.NewRow();
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    foreach (ColumnEntity column in this.OVLColumns)
                    {
                        if (dt.Columns[i].ColumnName == column.ColumnName)
                        {
                            dr[column.ColumnName] = CommonHelp.GetModelValue(column.FieldName, row);
                        }
                    }
                }
                dt.Rows.Add(dr);
            }
            return dt;
        }

    }
}
