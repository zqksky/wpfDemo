﻿using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R.Service.LithoModeService
{
    public class SpecialJobListViewService: ISpecialJobListViewService
    {
        public List<string> GetToolList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("SpecialJobListViewService.GetToolList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> toolList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.SpecialJobListService, EMethod.GetToolList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.GetToolList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (0 == result.ReturnCode)
                    {
                        List<ToolEntity> toolsList = JsonHelp.DeserializeJsonToList<ToolEntity>(result.ReturnMsg);
                        toolList.Add("NA");
                        foreach (ToolEntity tool in toolsList)
                        {
                            toolList.Add(tool.ToolId);
                        }
                        return toolList;
                    }
                    else
                    {
                        MessageBox.Show(result.ReturnText);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.GetToolList Error :: " + ex.Message);
                MessageBox.Show("Get toolList is fail");
            }
            return null;
        }

        public List<string> GetProductList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("SpecialJobListViewService.GetProductList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> products = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.GetProductList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        products.Add("");
                        foreach (ProductEntity product in productList)
                        {
                            products.Add(product.ProductId);
                        }
                        return products;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.GetProductList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<string> GetLayerList(string userId, string clientVersion, string productId, out string retMsg)
        {
            if (string.IsNullOrEmpty(productId))
            {
                retMsg = "";
                return new List<string>();
            }

            retMsg = null;
            MyLogger.Trace("SpecialJobListViewService.GetLayerList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetLayerList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.GetLayerList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                        foreach (LayerEntity layer in layerList)
                        {
                            layers.Add(layer.LayerId);
                        }
                        return layers;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public List<SpecialJobRow> GetDataList(string userId,
                                                string clientVersion,
                                                string startTime,
                                                string endTime,
                                                string toolId,
                                                string productId,
                                                string layerId,
                                                string lotId,
                                                string reticleId,
                                                string recipeId,
                                                string usedFlag, out string retMsg)
        {
            retMsg = null;

            MyLogger.Trace("SpecialJobListViewService.GetDataList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("StartTime<{0}>", startTime) +
                            string.Format("EndTime<{0}>", endTime) +
                            string.Format("ToolId<{0}>",toolId)+
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("LotId<{0}>", lotId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("UsedFlag<{0}>", usedFlag));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("StartTime", startTime);
            arguDic.Add("EndTime", endTime);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("LotId", lotId);
            
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                if(true)
                {
                    if (arguDic.ContainsKey("ToolId") && string.IsNullOrEmpty(toolId)) arguDic["ToolId"]= "";
                    if (arguDic.ContainsKey("ProductId") && string.IsNullOrEmpty(productId)) arguDic["ProductId"] = "";
                    if (arguDic.ContainsKey("LayerId") && string.IsNullOrEmpty(layerId)) arguDic["LayerId"] = "";
                    if (arguDic.ContainsKey("LotId") && string.IsNullOrEmpty(lotId)) arguDic["LotId"] = "";

                    arguDic.Add("ReticleId", reticleId);
                    arguDic.Add("RecipeId", recipeId);
                    arguDic.Add("UsedFlag", usedFlag);
                    string strResult = WSHelper.GetResponseString(EComponent.SpecialJobListService, EMethod.QuerySpecialJobList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.GetDataList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return JsonHelp.DeserializeJsonToList<SpecialJobRow>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.GetDataList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public SpecialJobRow GetDataParamsList(string userId,
                                        string clientVersion,
                                        string jobId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("SpecialJobListViewService.GetDataParamsList :: " +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("JobId<{0}>", jobId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("JobId", jobId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.SpecialJobListService, EMethod.QuerySpecialJobParameters, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.GetDataParamsList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return JsonHelp.DeserializeJsonToObject<SpecialJobRow>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.GetDataParamsList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool DeleteNewSpecialJob(string userId,
                                        string clientVersion,
                                        string jobId, out string retMsg)
        {
            bool rst = false;
            retMsg = null;
            MyLogger.Trace("SpecialJobListViewService.DeleteNewSpecialJob :: " +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("JobId<{0}>", jobId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("JobId", jobId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.SpecialJobListService, EMethod.DeleteNewSpecialJob, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("SpecialJobListViewService.DeleteNewSpecialJob Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        rst = true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("SpecialJobListViewService.DeleteNewSpecialJob Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return rst;
        }
    }
}
