﻿using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R.Service.LithoModeService
{
    public class CreateSpecialJobViewService : ICreateSpecialJobViewService
    {
        public SpecialJobRow ChangeSpecialJobProperty(string userId,
            string clientVersion, 
            string jobId, 
            string controlModel, 
            bool FEMFlag, 
            bool C2CFlag,
            string toolId,
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.ChangeSpecialJobProperty :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("jobId<{0}>", jobId) +
                            string.Format("controlModel<{0}>", controlModel) +
                            string.Format("FEMFlag<{0}>", FEMFlag) +
                            string.Format("C2CFlag<{0}>", C2CFlag) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("JobId", jobId);
            arguDic.Add("ControlModel", controlModel);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("FEMFlag", FEMFlag);
                    arguDic.Add("C2CFlag", C2CFlag);
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.ChangeSpecialJobProperty, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.QeuryReferences4SpecialJob Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        SpecialJobRow specialJob = JsonHelp.DeserializeJsonToObject<SpecialJobRow>(result.ReturnMsg);
                        
                        return specialJob;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.ChangeSpecialJobProperty Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public SpecialJobRow QeuryReferences4SpecialJob(string userId, string clientVersion, string productId, string layerId, string toolId, string reticleId, string recipeId, string controlModel, bool FEMFlag, bool C2CFlag, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.QeuryReferences4SpecialJob :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("ControlMode<{0}>", controlModel) +
                            string.Format("FEMFlag<{0}>", FEMFlag) +
                            string.Format("C2CFlag<{0}>", C2CFlag));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("ControlModel", controlModel);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("FEMFlag", FEMFlag);
                    arguDic.Add("C2CFlag", C2CFlag);
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.QueryReferences4SpecialJob, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.QeuryReferences4SpecialJob Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        SpecialJobRow specialJob = JsonHelp.DeserializeJsonToObject<SpecialJobRow>(result.ReturnMsg);

                        return specialJob;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.QeuryReferences4SpecialJob Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public bool SaveSpecialJob(string userId, 
            string clientVersion,
            SpecialJobRow speicalJob, 
            SpecialJobRow OriSpeicalJob, 
            out SpecialJobRow returnRst, 
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string jsonParams = JsonHelp.SerializeObject(speicalJob);
            string OriJsonParams = JsonHelp.SerializeObject(OriSpeicalJob);
            MyLogger.Trace("CreateSpecialJobViewService.SaveSpecialJob :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("SpecialJob<{0}>", jsonParams) +
                            string.Format("OriSpecialJob<{0}>", OriJsonParams));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("SpecialJob", jsonParams);
            arguDic.Add("OriSpecialJob", OriJsonParams);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.SaveSpecialJob, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.SaveSpecialJob Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<SpecialJobRow>(result.ReturnMsg);
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.SaveSpecialJob Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool DeleteNewSpecialJob(string userId, string clientVersion, string jobId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.DeleteNewSpecialJob :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("JobId<{0}>", jobId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("JobId", jobId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.DeleteNewSpecialJob, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.DeleteNewSpecialJob Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.DeleteNewSpecialJob Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public List<string> GetToolList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.GetToolList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> tools = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.SpecialJobListService, EMethod.GetToolList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.GetToolList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ToolEntity> toolEntities = JsonHelp.DeserializeJsonToList<ToolEntity>(result.ReturnMsg);
                        foreach (ToolEntity tool in toolEntities)
                        {
                            tools.Add(tool.ToolId);
                        }
                        return tools;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.GetToolList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<string> GetProductList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.GetProductList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> products = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.GetProductList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ProductEntity> productEntities = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        foreach (ProductEntity product in productEntities)
                        {
                            products.Add(product.ProductId);
                        }
                        return products;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.GetProductList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<string> GetLayerList(string userId, string clientVersion, string productId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.GetLayerList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetLayerList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.GetLayerList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                        foreach (LayerEntity layer in layerList)
                        {
                            layers.Add(layer.LayerId);
                        }
                        return layers;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public List<string> GetReticleForLayer(string userId, string clientVersion, string productId, string layerId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.GetReticleForLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId));
            List<string> reticles = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (string.IsNullOrEmpty(layerId) || string.IsNullOrEmpty(productId)) return new List<string>();

                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.GetReticleForLayer, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.GetReticleForLayer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ReticleEntity> reticleEntities = JsonHelp.DeserializeJsonToList<ReticleEntity>(result.ReturnMsg);
                        foreach (ReticleEntity reticle in reticleEntities)
                        {
                            reticles.Add(reticle.ReticleId);
                        }
                        return reticles;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.GetReticleForLayer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public List<string> GetRecipeForLayer(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("CreateSpecialJobViewService.GetRecipeForLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId));
            List<string> recipes = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            try
            {
                if (string.IsNullOrEmpty(layerId) || string.IsNullOrEmpty(productId)) return new List<string>();

                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.CreateSpecialJobService, EMethod.GetRecipeForLayer, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("CreateSpecialJobViewService.GetRecipeForLayer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<RecipeEntity> recipeEntities = JsonHelp.DeserializeJsonToList<RecipeEntity>(result.ReturnMsg);
                        foreach (RecipeEntity recipe in recipeEntities)
                        {
                            recipes.Add(recipe.RecipeId);
                        }
                        return recipes;
                    }
                    else
                    {
                        MessageBox.Show(retMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("CreateSpecialJobViewService.GetRecipeForLayer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
    }
}
