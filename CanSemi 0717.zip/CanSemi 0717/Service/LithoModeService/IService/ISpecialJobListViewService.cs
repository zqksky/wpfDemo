﻿using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface ISpecialJobListViewService
    {
        List<string> GetToolList(string userId, string clientVersion, out string retMsg);
        List<string> GetProductList(string userID, string clientVersion, out string retMsg);
        List<string> GetLayerList(string userID, string clientVersion, string productId, out string retMsg);
        List<SpecialJobRow> GetDataList(string userId, 
                                        string clientVersion, 
                                        string startTime,
                                        string endTime,
                                        string ToolId,
                                        string productId,
                                        string layerId,
                                        string lotId,
                                        string reticleId,
                                        string recipeId,
                                        string usedFlag, out string retMsg);

        SpecialJobRow GetDataParamsList(string userId,
                                        string clientVersion,
                                        string jobId, out string retMsg);

        bool DeleteNewSpecialJob(string userId,
                                        string clientVersion,
                                        string jobId, out string retMs);
    }
}
