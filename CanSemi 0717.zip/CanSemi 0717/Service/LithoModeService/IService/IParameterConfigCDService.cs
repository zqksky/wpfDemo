﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface IParameterConfigCDService
    {
        CDContextContent GetCDContext(string userId, 
                             string clientVersion, 
                             string productId, 
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             string chuck, 
                             out string retMsg);

        bool SaveCDParameters(string userId,
                                 string clientVersion,
                                 string chuck,
                                 CDContextContent contextContent,
                                 CDContextContent OriContextContent,
                                 out CDContextContent returnRst,
                                 out string retMsg);

        bool ResetHorizonCD(string userId,
                             string clientVersion,
                             string productId,
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             out string retMsg);
    }
}
