﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface IParameterConfigOVLService
    {
        OVLContextContent GetOVLContext(string userId,
                             string clientVersion,
                             string productId,
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             string preTool,
                             string preReticle,
                             string chuck,
                             out string retMsg);

        bool SaveOVLParameters(string userId,
                                 string clientVersion,
                                 string chuck,
                                 OVLContextContent contextContent,
                                 OVLContextContent OriContextContent,
                                 out OVLContextContent returnRst,
                                 out string retMsg);

        bool ResetHorizonOVL(string userId,
                             string clientVersion,
                             string productId,
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             string preTool,
                             string preReticle,
                             out string retMsg);
    }
}
