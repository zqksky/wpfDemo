﻿using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface ICreateSpecialJobViewService
    {
        SpecialJobRow ChangeSpecialJobProperty(string userId, string clientVersion, string jobId, string controlModel, bool FEMFlag, bool C2CFlag, 
            string toolId,
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            out string retMsg);
        SpecialJobRow QeuryReferences4SpecialJob(string userId, string clientVersion, string productId, string layerId, string toolId, string reticleId, string recipeId, string controlModel, bool FEMFlag, bool C2CFlag, out string retMsg);
        bool SaveSpecialJob(string userId, 
            string clientVersion, 
            SpecialJobRow speicalJob,
            SpecialJobRow OriSpeicalJob,
            out SpecialJobRow returnRst, 
            out string retMsg);
        bool DeleteNewSpecialJob(string userId, string clientVersion, string jobId, out string retMsg);
        List<string> GetToolList(string userId, string clientVersion, out string retMsg);
        List<string> GetProductList(string userId, string clientVersion, out string retMsg);
        List<string> GetLayerList(string userId, string clientVersion, string productId, out string retMsg);
        List<string> GetReticleForLayer(string userId, string clientVersion, string productId, string layerId, out string retMsg);
        List<string> GetRecipeForLayer(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, out string retMsg);
    }
}
