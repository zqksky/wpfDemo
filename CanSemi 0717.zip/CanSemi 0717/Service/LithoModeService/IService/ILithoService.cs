﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface ILithoService
    {
        List<DataView> GetLithoColumnList(string userId, string clientVersion, out string retMsg);
        List<string> GetProductList(string userId, string clientVersion, out string retMsg);
        List<string> GetLayerList(string userId, string clientVersion, string productId, out string retMsg);
        DataView GetCDDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt, out string retMsg);
        DataView GetOVLDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt, out string retMsg);

        List<HistoryEntity> QueryCDConfigOperationHist(string userId,
            string clientVersion,
            string tool,
            string product,
            string layer,
            string reticle,
            string recipe,
            out string retMsg);

        List<HistoryEntity> QueryOVLConfigOperationHist(string userId, 
            string clientVersion, 
            string tool,
            string product,
            string layer,
            string reticle,
            string preLayerTool,
            string preLayerReticle,
            string recipe,
            out string retMsg);

        bool ResetHorizonByTool(string userId,
            string clientVersion,
            string tool,
            out string retMsg);

        ToolResetHistory GetLatestResetHistory4Tool(string userId,
            string clientVersion,
            string tool,
            out string retMsg);
    }
}
