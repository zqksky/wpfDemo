﻿using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace R2R.Service.ConfigUIService
{
    public class ConfigurationUIService: IConfigurationUIService
    {
        public bool DeleteExistingProduct(string userId, string clientVersion, ProductEntity product, out string retMsg)
        {
            retMsg = null;
            string productJsonStr = JsonHelp.SerializeObject(product);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", productJsonStr);
            MyLogger.Trace("ConfigurationUIService.DeleteExistingLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("Product<{0}>", productJsonStr));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.DeleteExistingProduct, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.DeleteExistingProduct Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.DeleteExistingProduct Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;

        }

        public List<ProductEntity> GetProductList(string userId, string clientVersion, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.GetProductList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> products = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.GetProductList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        return productList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.GetProductList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }

        public List<LayerEntity> GetLayerList(string userId, string clientVersion, string productId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.GetLayerList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId));
            List<string> layers = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetLayerList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.GetLayerList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                        return layerList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public LayerRuntimeConfig GetRuntimeConfig(string userId, string clientVersion, string productId, string layerId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.GetRuntimeConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.GetRuntimeConfig4Layer, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.GetRuntimeConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //LayerRuntimeConfig layerRuntimeConfig = new LayerRuntimeConfig();
                        //layerRuntimeConfig.PreOvlLayer = "PreOvlLayer";
                        //layerRuntimeConfig.DedicationLayer = "DedicationLayer";
                        //layerRuntimeConfig.FeedbackStageOvl = "FeedbackStageOvl";
                        //layerRuntimeConfig.FeedbackStageCd = "FeedbackStageCd";
                        //layerRuntimeConfig.AlignLayer = "AlignLayer";
                        //layerRuntimeConfig.UseMachineStatus = true;
                        //layerRuntimeConfig.NPWFlag = false;
                        //return layerRuntimeConfig;
                        return JsonHelp.DeserializeJsonToObject<LayerRuntimeConfig>(result.ReturnMsg);    
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveRuntimeConfig(string userId,
            string clientVersion, 
            string productId,
            string layerId,
            LayerRuntimeConfig layerRuntime,
            LayerRuntimeConfig oriLayerRuntime,
            out LayerRuntimeConfig returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string runTimeJson = JsonHelp.SerializeObject(layerRuntime);
            string oriRunTimeJson = JsonHelp.SerializeObject(oriLayerRuntime);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("RuntimeConfig", runTimeJson);
            arguDic.Add("OriRuntimeConfig", oriRunTimeJson);
            MyLogger.Trace("ConfigurationUIService.SaveRuntimeValue :: " +
                            string.Format("UserID<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("RuntimeConfig<{0}>", runTimeJson) +
                            string.Format("OriRuntimeConfig<{0}>", oriRunTimeJson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveRuntimeValue, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveRuntimeValue Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<LayerRuntimeConfig>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveRuntimeValue Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool AddNewLayer(string userId, string clientVersion, string productId, LayerEntity layer, out string retMsg)
        {
            retMsg = null;
            string layerJson = JsonHelp.SerializeObject(layer);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("Layer", layerJson);
            MyLogger.Trace("ConfigurationUIService.AddNewLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("Layer<{0}>", layerJson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.AddNewLayer, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveRuntimeValue Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.AddNewLayer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool AddNewProduct(string userId, string clientVersion, ProductEntity product, out string retMsg)
        {
            retMsg = null;
            string productJson = JsonHelp.SerializeObject(product);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("Product", productJson);
            MyLogger.Trace("ConfigurationUIService.AddNewProduct :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("Product<{0}>", productJson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.AddNewProduct, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.AddNewProduct Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.AddNewProduct Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
        public bool AddNewCDContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            MyLogger.Trace("ConfigurationUIService.AddNewCDContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.AddNewCDContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.AddNewCDContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.AddNewCDContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool AddNewOVLContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            MyLogger.Trace("ConfigurationUIService.AddNewOVLContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreReticle<{0}>", preTool) +
                            string.Format("ProductId<{0}>", preReticle));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.AddNewOVLContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.AddNewOVLContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.AddNewOVLContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool DeleteNewLayer(string userId, string clientVersion, string productId, LayerEntity layer, out string retMsg)
        {
            retMsg = null;
            string layerJson = JsonHelp.SerializeObject(layer);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("Layer", layerJson);
            MyLogger.Trace("ConfigurationUIService.DeleteExistingLayer :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("Layer<{0}>", layerJson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.DeleteExistingLayer, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.DeleteExistingLayer Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.DeleteExistingLayer Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public List<CDContextRow> GetExistingCDContext(string userId, string clientVersion, string productId, string layerId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryExistingCDContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryExistingCDContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryExistingCDContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //List<CDContextRow> rows = new List<CDContextRow>();
                        //CDContextRow row = new CDContextRow();
                        //row.ToolId = "ToolId1";
                        //row.ProductId = "ProductId1";
                        //row.LayerId = "LayerId1";
                        //row.ReticleId = "ReticleId1";
                        //row.RecipeId = "RecipeId1";
                        //rows.Add(row);
                        //return rows;
                        return JsonHelp.DeserializeJsonToList<CDContextRow>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryExistingCDContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool DeleteCDContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            MyLogger.Trace("ConfigurationUIService.DeleteExistingCDContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.DeleteExistingCDContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.DeleteExistingCDContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.DeleteExistingCDContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
        public List<OVLContextRow> GetExistingOVLContext(string userId, string clientVersion, string productId, string layerId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryExistingOVLContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryExistingOVLContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    //TResult result = new TResult();
                    //result.ReturnCode = 0;
                    MyLogger.Trace("ConfigurationUIService.QueryExistingOVLContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //List<OVLContextRow> rows = new List<OVLContextRow>();
                        //OVLContextRow row = new OVLContextRow();
                        //row.ToolId = "ToolId1";
                        //row.ProductId = "ProductId1";
                        //row.LayerId = "LayerId1";
                        //row.ReticleId = "ReticleId1";
                        //row.RecipeId = "RecipeId1";
                        //row.PreTool = "PreTool";
                        //row.PreReticle = "PreReticle";
                        //rows.Add(row);
                        //return rows;
                        return JsonHelp.DeserializeJsonToList<OVLContextRow>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryExistingOVLContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool DeleteOVLContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            MyLogger.Trace("ConfigurationUIService.DeleteExistingOVLContext :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreReticle<{0}>", preTool) +
                            string.Format("ProductId<{0}>", preReticle));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.DeleteExistingOVLContext, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.DeleteExistingOVLContext Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.DeleteExistingOVLContext Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public ContextConfigCd GetCDContextConfig(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryCDContextConfig, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //ContextConfigCd cd = new ContextConfigCd();
                        //cd.Dose = 12.3;
                        //cd.Foucs = 13.3;
                        //cd.CDFeature = "CDFeature1";
                        //cd.Sentivity = 14.3;
                        //cd.Target = 15.3;
                        //cd.ReworkBias = 16.3;
                        //cd.CtlFlag = "CtlFlag1";
                        //return cd;
                        return JsonHelp.DeserializeJsonToObject<ContextConfigCd>(result.ReturnMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveCDContextConfig(string userId,
            string clientVersion, 
            string toolId, 
            string productId, 
            string layerId, 
            string reticleId, 
            string recipeId,
            ContextConfigCd config,
            ContextConfigCd oriConfig,
            out ContextConfigCd returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string configjson = JsonHelp.SerializeObject(config);
            string oriConfigjson = JsonHelp.SerializeObject(oriConfig);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("CdConfig", configjson);
            arguDic.Add("OriCdConfig", oriConfigjson);
            MyLogger.Trace("ConfigurationUIService.SaveCDContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("CdConfig<{0}>", configjson) +
                            string.Format("OriCdConfig<{0}>", oriConfigjson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveCDContextConfig, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveCDContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<ContextConfigCd>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveCDContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool saveCDContextValue(string userId,
            string clientVersion, 
            string toolId, 
            string productId,
            string layerId, 
            string reticleId, 
            string recipeId,
            ContextConfigCd value,
            ContextConfigCd oriValue,
            out ContextConfigCd returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string valuejson = JsonHelp.SerializeObject(value);
            string oriValuejson = JsonHelp.SerializeObject(oriValue);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("FixedValue", valuejson);
            arguDic.Add("OriFixedValue", oriValuejson);
            MyLogger.Trace("ConfigurationUIService.SaveCDContextFixedValue :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("FixedValue<{0}>", valuejson) +
                            string.Format("OriFixedValue<{0}>", oriValuejson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveCDContextFixedValue, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveCDContextFixedValue Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<ContextConfigCd>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveCDContextFixedValue Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public ContextConfigOvl GetOVLContextConfig(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryOVLContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    //arguDic.Add("PreTool", "22");
                    //arguDic.Add("PreReticle", "33");
                    arguDic.Add("PreTool", preTool);
                    arguDic.Add("PreReticle", preReticle);
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextConfig, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryOVLContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //ContextConfigOvl ovl = new ContextConfigOvl();
                        //ovl.OVLMode = "OVLMode1";
                        //ovl.DedicationType = "DedicationType1";
                        //ovl.MaxMetrologyDay = 1;
                        //ovl.ChuckControl = true;
                        //ovl.CtlFlag = "CtlFlag1";
                        //return ovl;
                        return JsonHelp.DeserializeJsonToObject<ContextConfigOvl>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryOVLContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveOVLContextConfig(string userId, 
            string clientVersion,
            string toolId,
            string productId, 
            string layerId, 
            string reticleId, 
            string recipeId, 
            string preTool,
            string preReticl,
            ContextConfigOvl config,
            ContextConfigOvl oriConfig,
            out ContextConfigOvl returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string configjson = JsonHelp.SerializeObject(config);
            string oriConfigjson = JsonHelp.SerializeObject(oriConfig);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticl);
            arguDic.Add("OvlConfig", configjson);
            arguDic.Add("OriOvlConfig", oriConfigjson);
            MyLogger.Trace("ConfigurationUIService.SaveOVLContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticl) +
                            string.Format("OvlConfig<{0}>", configjson) +
                            string.Format("OriOvlConfig<{0}>", oriConfigjson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveOVLContextConfig, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveOVLContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<ContextConfigOvl>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveOVLContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public bool saveOVLContextValue(string userId, 
            string clientVersion,
            string toolId, 
            string productId,
            string layerId,
            string reticleId, 
            string recipeId,
            string preTool, 
            string preReticl,
            ContextConfigOvl value,
            ContextConfigOvl oriValue,
            out ContextConfigOvl returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string valuejson = JsonHelp.SerializeObject(value);
            string oriValuejson = JsonHelp.SerializeObject(oriValue);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("FixedValue", valuejson);
            arguDic.Add("OriFixedValue", oriValuejson);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    arguDic.Add("RecipeId", recipeId);
                    arguDic.Add("PreTool", preTool);
                    arguDic.Add("PreReticle", preReticl);
                    MyLogger.Trace("ConfigurationUIService.SaveOVLContextFixedValue :: " +
                                    string.Format("UserId<{0}>", userId) +
                                    string.Format("ClientVersion<{0}>", clientVersion) +
                                    string.Format("ToolId<{0}>", toolId) +
                                    string.Format("ProductId<{0}>", productId) +
                                    string.Format("LayerId<{0}>", layerId) +
                                    string.Format("ReticleId<{0}>", reticleId) +
                                    string.Format("RecipeId<{0}>", recipeId) +
                                    string.Format("PreTool<{0}>", preTool) +
                                    string.Format("PreReticle<{0}>", preReticl) +
                                    string.Format("FixedValue<{0}>", valuejson) +
                                    string.Format("OriFixedValue<{0}>", oriValuejson));
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveOVLContextFixedValue, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveOVLContextFixedValue Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<ContextConfigOvl>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveOVLContextFixedValue Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public SpecMainContent GetCDSpecLimitMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextLimitSettings :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryCDContextLimitSettings, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextLimitSettings Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return JsonHelp.DeserializeJsonToObject<SpecMainContent>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextLimitSettings Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveCDSpecLimitMainContent(string userId, 
            string clientVersion, 
            string recipeId,
            SpecMainContent specMain,
            SpecMainContent oriSpecMain,
            out SpecMainContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string specMainjson = JsonHelp.SerializeObject(specMain);
            string oriSpecMainjson = JsonHelp.SerializeObject(oriSpecMain);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", specMain.ToolId);
            arguDic.Add("ProductId", specMain.ProductId);
            arguDic.Add("LayerId", specMain.LayerId);
            arguDic.Add("ReticleId", specMain.ReticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("LimitSettings", specMainjson);
            arguDic.Add("OriLimitSettings", oriSpecMainjson);
            MyLogger.Trace("ConfigurationUIService.saveCDSpecLimitMainContent :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", specMain.ToolId) +
                            string.Format("ProductId<{0}>", specMain.ProductId) +
                            string.Format("LayerId<{0}>", specMain.LayerId) +
                            string.Format("ReticleId<{0}>", specMain.ReticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("LimitSettings<{0}>", specMainjson) +
                            string.Format("OriLimitSettings<{0}>", oriSpecMainjson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveCDContextLimitSettings, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.saveCDSpecLimitMainContent Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<SpecMainContent>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.saveCDSpecLimitMainContent Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public SpecMainContent GetOVLSpecLimitMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextLimitSettings, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        //SpecMainContent specMain = new SpecMainContent();
                        //specMain.ProductId = "ProductId1";
                        //specMain.ToolId = "ToolId1";
                        //specMain.LayerId = "LayerId1";
                        //specMain.ReticleId = "ReticleId1";
                        //specMain.Controller = "Controller1";
                        //specMain.ModelName = "ModelName1";
                        //List<SpecEntity> specs = new List<SpecEntity>();
                        //SpecEntity spec = new SpecEntity();
                        //spec.ParameterName = "ParameterName1";
                        //spec.Upperlimit = 12.3;
                        //spec.LowerLimit = 163.3;
                        //spec.Delta = 11;
                        //spec.Deadband = 23;
                        //spec.FbLower = 55;
                        //spec.FbDelta = 535;
                        //specs.Add(spec);
                        //specMain.Specs = specs;
                        //return specMain;

                        return JsonHelp.DeserializeJsonToObject<SpecMainContent>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveOVLSpecLimitMainContent(string userId, 
            string clientVersion,
            string recipeId, 
            string preTool, 
            string preReticle,
            SpecMainContent specMain,
            SpecMainContent oriSpecMain,
            out SpecMainContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string specMainjson = JsonHelp.SerializeObject(specMain);
            string oriSpecMainjson = JsonHelp.SerializeObject(oriSpecMain);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", specMain.ToolId);
            arguDic.Add("ProductId", specMain.ProductId);
            arguDic.Add("LayerId", specMain.LayerId);
            arguDic.Add("ReticleId", specMain.ReticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            arguDic.Add("LimitSettings", specMainjson);
            arguDic.Add("OriLimitSettings", oriSpecMainjson);
            MyLogger.Trace("ConfigurationUIService.SaveOVLContextLimitSettings :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", specMain.ToolId) +
                            string.Format("ProductId<{0}>", specMain.ProductId) +
                            string.Format("LayerId<{0}>", specMain.LayerId) +
                            string.Format("ReticleId<{0}>", specMain.ReticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle) +
                            string.Format("LimitSettings<{0}>", specMainjson) +
                            string.Format("OriLimitSettings<{0}>", oriSpecMainjson));
            try
            {

                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveOVLContextLimitSettings, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveOVLContextLimitSettings Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<SpecMainContent>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveOVLContextLimitSettings Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public FixedValueMainContent GetFixedValueMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextFixedValue, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    //TResult result = new TResult();
                    //result.ReturnCode = 0;
                    if (result.ReturnCode == 0)
                    {
                        //FixedValueMainContent fixedValue = new FixedValueMainContent();
                        //fixedValue.ProductId = "ProductId1";
                        //fixedValue.ToolId = "ToolId1";
                        //fixedValue.LayerId = "LayerId1";
                        //fixedValue.ReticleId = "ReticleId1";
                        //fixedValue.PreTool = "PreTool1";
                        //fixedValue.PreReticle = "PreReticle1";
                        //List<ParameterRow> rows = new List<ParameterRow>();
                        //ParameterRow row = new ParameterRow();
                        //row.ParameterName = "ParameterName1";
                        //row.ParameterVaue = "VALUE";
                        //row.ParameterVaue1 = "VALUE1";
                        //rows.Add(row);
                        //fixedValue.FixedValues = rows;
                        //return fixedValue;
          
                        return JsonHelp.DeserializeJsonToObject<FixedValueMainContent>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveFixedValueMainContent(string userId, 
            string clientVersion,
            string recipeId,
            FixedValueMainContent fixedValueMain,
            FixedValueMainContent oriFixedValueMain,
            out FixedValueMainContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string valueJson = JsonHelp.SerializeObject(fixedValueMain);
            string oriValueJson = JsonHelp.SerializeObject(oriFixedValueMain);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", fixedValueMain.ToolId);
            arguDic.Add("ProductId", fixedValueMain.ProductId);
            arguDic.Add("LayerId", fixedValueMain.LayerId);
            arguDic.Add("ReticleId", fixedValueMain.ReticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", fixedValueMain.PreTool);
            arguDic.Add("PreReticle", fixedValueMain.PreReticle);
            arguDic.Add("FixedValue", valueJson);
            arguDic.Add("OriFixedValue", oriValueJson);
            MyLogger.Trace("ConfigurationUIService.saveFixedValueMainContent :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", fixedValueMain.ToolId) +
                            string.Format("ProductId<{0}>", fixedValueMain.ProductId) +
                            string.Format("LayerId<{0}>", fixedValueMain.LayerId) +
                            string.Format("ReticleId<{0}>", fixedValueMain.ReticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", fixedValueMain.PreTool) +
                            string.Format("PreReticle<{0}>", fixedValueMain.PreReticle) +
                            string.Format("FixedValue<{0}>", valueJson) +
                            string.Format("OriFixedValue<{0}>", oriValueJson));
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveOVLContextFixedValue, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.saveFixedValueMainContent Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;

                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<FixedValueMainContent>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.saveFixedValueMainContent Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }

        public OffsetMainContent GetOffsetMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextOffset, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextConfig Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    //TResult result = new TResult();
                    //result.ReturnCode = 0;
                    if (result.ReturnCode == 0)
                    {
                        //OffsetMainContent offsetMain = new OffsetMainContent();
                        //offsetMain.ProductId = "ProductId1";
                        //offsetMain.ToolId = "ToolId1";
                        //offsetMain.LayerId = "LayerId1";
                        //offsetMain.ReticleId = "ReticleId1";
                        //List<ParameterRow> rows = new List<ParameterRow>();
                        //ParameterRow row = new ParameterRow();
                        //row.ParameterName = "ParameterName1";
                        //row.ParameterVaue = "VALUE";
                        //row.ParameterVaue1 = "VALUE1";
                        //rows.Add(row);
                        //offsetMain.FixedValues = rows;
                        //return offsetMain;

                        return JsonHelp.DeserializeJsonToObject<OffsetMainContent>(result.ReturnMsg);
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextConfig Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public bool saveOffsetMainContent(string userId, 
            string clientVersion,
            string recipeId, 
            string preTool, 
            string preReticle,
            OffsetMainContent offsetMain,
            OffsetMainContent oriOffsetMain,
            out OffsetMainContent returnRst,
            out string retMsg)
        {
            retMsg = null;
            returnRst = null;
            string offsetJson = JsonHelp.SerializeObject(offsetMain);
            string oriOffsetJson = JsonHelp.SerializeObject(oriOffsetMain);
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", offsetMain.ToolId);
            arguDic.Add("ProductId", offsetMain.ProductId);
            arguDic.Add("LayerId", offsetMain.LayerId);
            arguDic.Add("ReticleId", offsetMain.ReticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            arguDic.Add("Offset", offsetJson);
            arguDic.Add("OriOffset", oriOffsetJson);
            MyLogger.Trace("ConfigurationUIService.SaveOVLContextOffset :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ToolId<{0}>", offsetMain.ToolId) +
                            string.Format("ProductId<{0}>", offsetMain.ProductId) +
                            string.Format("LayerId<{0}>", offsetMain.LayerId) +
                            string.Format("ReticleId<{0}>", offsetMain.ReticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle) +
                            string.Format("Offset<{0}>", offsetJson) +
                            string.Format("OriOffset<{0}>", oriOffsetJson));
            try
            {
                //return true;
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.SaveOVLContextOffset, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.SaveOVLContextOffset Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    //TResult result = new TResult();
                    //result.ReturnCode = 0;
                    if (result.ReturnCode == 0)
                    {
                        returnRst = JsonHelp.DeserializeJsonToObject<OffsetMainContent>(result.ReturnMsg);
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.SaveOVLContextOffset Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }



        public List<HistoryEntity> QueryCDContextHist(string userId,
            string clientVersion,
            string toolId,
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            string startTime,
            string endTime,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryCDContextHist :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("TooId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("StartTime<{0}>", startTime) +
                            string.Format("EndTime<{0}>", endTime));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("StartTime", startTime);
            arguDic.Add("EndTime", endTime);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextHist, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryCDContextHist Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return JsonHelp.DeserializeJsonToList<HistoryEntity>(result.ReturnMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryCDContextHist Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }

        public List<HistoryEntity> QueryOVLContextHist(string userId,
            string clientVersion,
            string toolId,
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            string preTool,
            string preReticle,
            string startTime,
            string endTime,
            out string retMsg)
        {
            retMsg = null;
            MyLogger.Trace("ConfigurationUIService.QueryOVLContextHist :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("TooId<{0}>", toolId) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("PreTool<{0}>", preTool) +
                            string.Format("PreReticle<{0}>", preReticle) +
                            string.Format("StartTime<{0}>", startTime) +
                            string.Format("EndTime<{0}>", endTime));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("PreTool", preTool);
            arguDic.Add("PreReticle", preReticle);
            arguDic.Add("StartTime", startTime);
            arguDic.Add("EndTime", endTime);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EComponent.ConfigUIService, EMethod.QueryOVLContextHist, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigurationUIService.QueryOVLContextHist Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    retMsg = result.ReturnText;
                    if (result.ReturnCode == 0)
                    {
                        return JsonHelp.DeserializeJsonToList<HistoryEntity>(result.ReturnMsg);
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigurationUIService.QueryOVLContextHist Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
    }
}
