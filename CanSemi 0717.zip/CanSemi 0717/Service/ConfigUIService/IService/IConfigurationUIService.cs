﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.ConfigUIService
{
    public interface IConfigurationUIService
    {
        bool DeleteExistingProduct(string userID, string clientVersion, ProductEntity product, out string retMsg);
        List<ProductEntity> GetProductList(string userId, string clientVersion, out string retMsg);
        List<LayerEntity> GetLayerList(string userId, string clientVersion, string productId, out string retMsg);
        LayerRuntimeConfig GetRuntimeConfig(string userId, string clientVersion, string productId, string layerId, out string retMsg);
        bool saveRuntimeConfig(string userId, 
            string clientVersion, 
            string productId, 
            string layerId, 
            LayerRuntimeConfig layerRuntime,
            LayerRuntimeConfig oriLayerRuntime,
            out LayerRuntimeConfig returnRst,
            out string retMsg);
        bool AddNewLayer(string userId, string clientVersion, string productId, LayerEntity layer, out string retMsg);
        bool DeleteNewLayer(string userId, string clientVersion, string productId, LayerEntity layer, out string retMsg);
        bool AddNewCDContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg);
        bool AddNewOVLContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string PreTool, string PreReticle, out string retMsg);
        bool AddNewProduct(string userId, string clientVersion, ProductEntity product, out string retMsg);
        List<CDContextRow> GetExistingCDContext(string userId, string clientVersion, string productId, string layerId, out string retMsg);
        bool DeleteCDContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg);
        List<OVLContextRow> GetExistingOVLContext(string userId, string clientVersion, string productId, string layerId, out string retMsg);
        bool DeleteOVLContext(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string PreTool, string PreReticle, out string retMsg);
        ContextConfigCd GetCDContextConfig(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg);

        bool saveCDContextConfig(string userId, 
            string clientVersion, 
            string toolId, 
            string productId,
            string layerId,
            string reticleId,
            string recipeId, 
            ContextConfigCd config,
            ContextConfigCd oriConfig,
            out ContextConfigCd returnRst,
            out string retMsg);

        bool saveCDContextValue(string userId, 
            string clientVersion, 
            string toolId,
            string productId,
            string layerId, string reticleId, 
            string recipeId,
            ContextConfigCd value,
            ContextConfigCd oriValue,
            out ContextConfigCd returnRst,
            out string retMsg);

        ContextConfigOvl GetOVLContextConfig(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg);

        bool saveOVLContextConfig(string userId,
            string clientVersion, 
            string toolId,
            string productId, 
            string layerId, 
            string reticleId,
            string recipeId, 
            string preTool,
            string preReticl, 
            ContextConfigOvl config,
            ContextConfigOvl oriConfig,
            out ContextConfigOvl returnRst, 
            out string retMsg);

        bool saveOVLContextValue(string userId, 
            string clientVersion,
            string toolId, 
            string productId, 
            string layerId,
            string reticleId,
            string recipeId, 
            string preTool,
            string preReticl,
            ContextConfigOvl value,
            ContextConfigOvl oriValue,
            out ContextConfigOvl returnRst,
            out string retMsg);

        SpecMainContent GetCDSpecLimitMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, out string retMsg);

        bool saveCDSpecLimitMainContent(string userId, 
            string clientVersion,
            string recipeId, 
            SpecMainContent specMain,
            SpecMainContent oriSpecMain,
            out SpecMainContent returnRst,
            out string retMsg);

        SpecMainContent GetOVLSpecLimitMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg);

        bool saveOVLSpecLimitMainContent(string userId, 
            string clientVersion,
            string recipeId, 
            string preTool,
            string preReticle,
            SpecMainContent specMain,
            SpecMainContent oriSpecMain,
            out SpecMainContent returnRst,
            out string retMsg);

        FixedValueMainContent GetFixedValueMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg);

        bool saveFixedValueMainContent(string userId,
            string clientVersion, 
            string recipeId, 
            FixedValueMainContent fixedValueMain,
            FixedValueMainContent oriFixedValueMain,
            out FixedValueMainContent returnRst,
            out string retMsg);

        OffsetMainContent GetOffsetMainContent(string userId, string clientVersion, string toolId, string productId, string layerId, string reticleId, string recipeId, string preTool, string preReticle, out string retMsg);

        bool saveOffsetMainContent(string userId,
            string clientVersion, 
            string recipeId, 
            string preTool, 
            string preReticle, 
            OffsetMainContent offsetMain,
            OffsetMainContent oriOffsetMain,
            out OffsetMainContent returnRst,
            out string retMsg);

        List<HistoryEntity> QueryCDContextHist(string userId,
            string clientVersion, 
            string tooId, 
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            string startTime,
            string endTime,
            out string retMsg);

        List<HistoryEntity> QueryOVLContextHist(string userId,
            string clientVersion,
            string tooId,
            string productId,
            string layerId,
            string reticleId,
            string recipeId,
            string preTool,
            string preReticle,
            string startTime,
            string endTime,
            out string retMsg);
    }
}
