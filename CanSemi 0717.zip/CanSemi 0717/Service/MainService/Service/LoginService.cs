﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Service.VO;

namespace R2R.Service.MainService
{
    public class LoginService : ILoginService
    {
        public int Login(string username, string password, string domainl)
        {
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserName", username);
            arguDic.Add("Password", password);
            arguDic.Add("DomainName", domainl);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string result = WSHelper.GetResponseString(EComponent.LoginService, EMethod.Login, arguDic);
                    JObject jo = (JObject)JsonConvert.DeserializeObject(result);
                    if (jo.Value<Boolean>("Success"))
                    {
                        return 0;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LoginService.Login Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return -1;
        }
    }
}
