﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.VO
{
    public class OVLInfoModel
    {
        public const string COL_TOOL = "TOOL";

        public const string COL_PRODUCT = "PRODUCT";

        public const string COL_LAYER = "LAYER";

        public const string COL_RETICLE = "RETICLE";

        public const string COL_PRE_TOOL = "PRE_TOOL";

        public const string COL_PRE_RETICLE = "PRE_RETICLE";

        public const string COL_CTL_FLAG = "CTL_FLAG";

        [JsonProperty(PropertyName = COL_TOOL)]
        public string Tool { get; set; }

        [JsonProperty(PropertyName = COL_PRODUCT)]
        public string Product { get; set; }

        [JsonProperty(PropertyName = COL_LAYER)]
        public string Layer { get; set; }

        [JsonProperty(PropertyName = COL_RETICLE)]
        public string Reticle { get; set; }

        [JsonProperty(PropertyName = COL_PRE_TOOL)]
        public string PreTool { get; set; }

        [JsonProperty(PropertyName = COL_PRE_RETICLE)]
        public string PreReticle { get; set; }

        [JsonProperty(PropertyName = COL_CTL_FLAG)]
        public string CtlFlag { get; set; }
    }
}
