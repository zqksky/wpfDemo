﻿using System.Collections.Generic;
using R2R.Common.Data;

namespace R2R.Common.DAL
{
    public interface IMessageManager
    {
        void SendCommand(CommandRequest request);
        Tout SendCommand<Tout>(CommandRequest request) where Tout: new();
        T QuerySingle<T>(QueryRequest request) where T : new();
        List<T> QueryList<T>(QueryRequest request) where T : new();
    }
}
