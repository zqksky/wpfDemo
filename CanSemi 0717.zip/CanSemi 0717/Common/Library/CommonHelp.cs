﻿
using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Library
{
    public class CommonHelp
    {
        public static T DeepCopy<T>(T obj)
        {
            //如果是字符串或值类型则直接返回
            //if (obj == null || obj is string || obj.GetType().IsValueType) return obj;

            //object retval = Activator.CreateInstance(obj.GetType());
            //System.Reflection.FieldInfo[] fields = obj.GetType().GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static);
            //foreach (System.Reflection.FieldInfo field in fields)
            //{
            //    try { field.SetValue(retval, DeepCopy(field.GetValue(obj))); }
            //    catch { }
            //}
            //return (T)retval;


            object retval;
            using (MemoryStream ms = new MemoryStream())
            {
                DataContractSerializer ser = new DataContractSerializer(typeof(T));
                ser.WriteObject(ms, obj);
                ms.Seek(0, SeekOrigin.Begin);
                retval = ser.ReadObject(ms);
                ms.Close();
            }
            return (T)retval;
        }

        public static Boolean ArgumentIsNull(Dictionary<string, object> dic)
        {
            foreach (string key in dic.Keys)
            {
                if ((string)dic[key] == "" || dic[key] == null)
                {
                    MyLogger.Error(string.Format("Argument <{0}> Is Null", key));
                    throw new ArgumentNullException(key);
                }
            }
            return false;
        }

        public static double String2Double(string param)
        {
            try
            {
                return System.Convert.ToDouble(param);
            }
            catch (Exception e)
            {
                return double.NaN;
            }
        }


        public static string Double2String(double param)
        {
            if (double.IsNaN(param))
                return "";
            else
                return param.ToString();
        }

        public static string GetModelValue(string FieldName, object obj)
        {
            try
            {
                Type Ts = obj.GetType();
                PropertyInfo propertyInfo = Ts.GetProperty(FieldName);
                string value = "";
                if (propertyInfo != null)
                {
                    object o = propertyInfo.GetValue(obj, null);
                    value = Convert.ToString(o);
                }
                else
                {
                    object par = Ts.GetProperty("Parameters").GetValue(obj, null);
                    List<ParameterEntity> parameterEntities = (List<ParameterEntity>)par;
                    foreach (var parameter in parameterEntities)
                    {
                        if (parameter.ParameterName == FieldName)
                        {
                            value = parameter.ParameterVaue;
                            break;
                        }
                    }
                }
                if (string.IsNullOrEmpty(value))
                {
                    value = "";
                }
                return value;
            }
            catch(Exception e)
            {
                string str = e.Message;
                return null;
            }
        }
    }
}
