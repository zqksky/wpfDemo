﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class LayerEntity
    {
        public int Id { get; set; }
        public string LayerId { get; set; }
        public string LayerName { get; set; }
        public string PreLayer { get; set; }
        public string AlignLayer { get; set; }
        public string StepName { get; set; }
    }
}
