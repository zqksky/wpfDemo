﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.Litho
{
    public class LithoModelColumnEntity
    {
        public List<ColumnEntity> CDCols { get; set; } 
        public List<ColumnEntity> OVLCols { get; set; }
    }
}
