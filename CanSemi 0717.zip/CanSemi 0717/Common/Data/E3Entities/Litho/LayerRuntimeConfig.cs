﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace R2R.Common.Data.Litho
{
    public class LayerRuntimeConfig
    {
        public string PreOvlLayer { get; set; }
        public string DedicationLayer { get; set; }
        public string Relaxation { get; set; }
        public string FeedbackStageOvl { get; set; }
        public string FeedbackStageCd { get; set; }
        public string AlignLayer { get; set; }
        public Boolean UseMachineStatus { get; set; }
        public Boolean NPWFlag{get;set;}
    }
}
