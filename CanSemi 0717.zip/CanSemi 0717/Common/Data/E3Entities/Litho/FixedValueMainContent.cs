﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.Litho
{
    public class FixedValueMainContent
    {
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string PreTool { get; set; }
        public string PreReticle { get; set; }

        public string ModelName { get; set; }
        public List<ParameterRow> FixedValues { get; set; }

    }
}
