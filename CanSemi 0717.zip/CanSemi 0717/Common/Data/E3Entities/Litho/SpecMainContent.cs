﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace R2R.Common.Data.Litho
{
    public class SpecMainContent
    {
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string Controller { get; set; }
        public string ModelName { get; set; }
        public List<SpecEntity> Specs { get; set; }
    }
}
