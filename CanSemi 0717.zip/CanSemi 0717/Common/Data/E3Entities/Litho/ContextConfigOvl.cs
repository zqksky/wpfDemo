﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.Litho
{
    public class ContextConfigOvl
    {
        public string OVLMode { get; set; }
        public string ControlModel { get; set; }
        public string DedicationType { get; set; }
        public int MaxMetrologyDay { get; set; }
        public Boolean ChuckControl { get; set; }
        public string CtlFlag { get; set; }
    }
}
