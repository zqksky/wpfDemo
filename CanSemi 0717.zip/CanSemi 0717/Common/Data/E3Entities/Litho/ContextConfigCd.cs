﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 

namespace R2R.Common.Data.Litho
{
    public class ContextConfigCd
    {
        public double Dose { get; set; }
        public double Foucs { get; set; }
        public string CDFeature { get; set;}
        public double Sentivity { get; set; }
        public double Target { get; set; }
        public double ReworkBias { get; set; }
        public string CtlFlag { get; set; }
    }
}
