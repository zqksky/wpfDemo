﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ForConvert
    {
        public static double String2Double(string param)
        {
            try
            {
                return System.Convert.ToDouble(param);
            }
            catch (Exception e)
            {
                return double.NaN;
            }
        }


        public static string Double2String(double param)
        {
            if (double.IsNaN(param))
                return "";
            else
                return param.ToString();
        }
    }
    public class SpecEntity
    {
        public string ParameterName { get; set; }
        public double Upperlimit { get; set; }
        public double LowerLimit { get; set; }
        public double Delta { get; set; }
        public double Deadband { get; set; }
        public double FbUpper { get; set; }
        public double FbLower { get; set; }
        public double FbDelta { get; set; }
        public double Lambda { get; set; }
        public double LambdaForPiRun { get; set; }
        public double MinPointsFoeAvg { get; set; }
        public string ControlModelName { get; set; }
        public SpecEntity() { }
        public SpecEntity(SpecEntityString specString)
        {
            this.ParameterName = specString.ParameterName;
            this.ControlModelName = specString.ControlModelName;
            this.Upperlimit = ForConvert.String2Double(specString.Upperlimit);
            this.LowerLimit = ForConvert.String2Double(specString.LowerLimit);
            this.Delta = ForConvert.String2Double(specString.Delta);
            this.Deadband = ForConvert.String2Double(specString.Deadband);
            this.FbUpper = ForConvert.String2Double(specString.FbUpper);
            this.FbLower = ForConvert.String2Double(specString.FbLower);
            this.FbDelta = ForConvert.String2Double(specString.FbDelta);
            this.Lambda = ForConvert.String2Double(specString.Lambda);
            this.LambdaForPiRun = ForConvert.String2Double(specString.LambdaForPiRun);
            this.MinPointsFoeAvg = ForConvert.String2Double(specString.MinPointsFoeAvg);
        }
    }

    public class SpecEntityString
    {
        public string ParameterName { get; set; }
        public string Upperlimit { get; set; }
        public string LowerLimit { get; set; }
        public string Delta { get; set; }
        public string Deadband { get; set; }
        public string FbUpper { get; set; }
        public string FbLower { get; set; }
        public string FbDelta { get; set; }
        public string Lambda { get; set; }
        public string LambdaForPiRun { get; set; }
        public string MinPointsFoeAvg { get; set; }
        public string ControlModelName { get; set; }
        public SpecEntityString() { }
        public SpecEntityString(SpecEntity spec)
        {
            this.ParameterName = spec.ParameterName;
            this.ControlModelName = spec.ControlModelName;
            this.Upperlimit = ForConvert.Double2String(spec.Upperlimit);
            this.MinPointsFoeAvg = ForConvert.Double2String(spec.MinPointsFoeAvg);
            this.LowerLimit = ForConvert.Double2String(spec.LowerLimit);
            this.Delta = ForConvert.Double2String(spec.Delta);
            this.Deadband = ForConvert.Double2String(spec.Deadband);
            this.FbUpper = ForConvert.Double2String(spec.FbUpper);
            this.FbLower = ForConvert.Double2String(spec.FbLower);
            this.FbDelta = ForConvert.Double2String(spec.FbDelta);
            this.Lambda = ForConvert.Double2String(spec.Lambda);
            this.LambdaForPiRun = ForConvert.Double2String(spec.LambdaForPiRun);
        }
    }
}
