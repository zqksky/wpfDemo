﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    /// <summary>
    /// 方法枚举
    /// </summary>
    public enum EMethod
    {
        Login,

        GetContextRowsCD,
        GetContextRowsOVL,
        GetLayerList,
        GetModeColumnList,
        GetProductList,

        GetContextContentCD,
        GetContextContentOVL,

        SaveContextConfigCD,
        SaveContextConfigOVL,

        GetToolList,
        QuerySpecialJobList,
        QuerySpecialJobParameters,

        AddDedicationWafer,
        AddNewCDContext,
        AddNewLayer,
        AddNewOVLContext,
        DeleteDedicationWafer,
        DeleteExistingCDContext,
        DeleteExistingLayer,
        DeleteExistingOVLContext,
        GetRuntimeConfig4Layer,
        QueryCDContextConfig,
        QueryCDContextLimitSettings,
        QueryDedicationWaferList4Layer,
        QueryDedicationWaferListByRoot,
        QueryExistingCDContext,
        QueryExistingOVLContext,
        QueryOVLContextConfig,
        QueryOVLContextFixedValue,
        QueryOVLContextLimitSettings,
        QueryOVLContextOffset,
        SaveCDContextLimitSettings,
        SaveOVLContextFixedValue,
        SaveOVLContextLimitSettings,
        SaveOVLContextOffset,
        SaveRuntimeValue,
        SaveCDContextConfig,
        SaveCDContextFixedValue,
        SaveOVLContextConfig
    }
}