﻿using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace R2R.Common.Data
{
    public class WSClass
    {
        private Type classType;
        public Type ClassType
        {
            get { return this.classType; }
            set { this.classType = value; }
        }

        private Dictionary<string, MethodInfo> methodDic = new Dictionary<string, MethodInfo>();
        public Dictionary<string, MethodInfo> MethodDic
        {
            get { return this.methodDic; }
            set { this.methodDic = value; }
        }

        private Dictionary<string, PropertyInfo> propertyDic = new Dictionary<string, PropertyInfo>();
        public Dictionary<string, PropertyInfo> PropertyDic
        {
            get { return this.propertyDic; }
            set { this.propertyDic = value; }
        }
    }
}
