﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public enum EProperty
    {
        // Login Property
        UserName,
        DomainName,
        Password,
        AppType,
        AutoLogin,

        // Litho Property
        UserID,
        ClientVersion,
        ProductId,
        LayerId,
        ToolId,
        ToolType,
        ReticleId,
        RecipeId,
        Chuck,
        PreTool,
        PreReticle,

        Parameters,
        OriParameters,
        StartTime,
        EndTime,
        LotId,
        UsedFlag,
        JobId,
        OvlConfig,
        OriOvlConfig,
        FixedValue,
        OriFixedValue,
        CdConfig,
        OriCdConfig,
        Layer,
        Product,
        RuntimeConfig,
        OriRuntimeConfig,
        LimitSettings,
        OriLimitSettings,
        Offset,
        OriOffset,
        RootId,
        WaferId,
        DedicationWafer,
        OriDedicationWafer,

        ControlModel,
        FEMFlag,
        C2CFlag,
        SpecialJob,
        OriSpecialJob
    }
}