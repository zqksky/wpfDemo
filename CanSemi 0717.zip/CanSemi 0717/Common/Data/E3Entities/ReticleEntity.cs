﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ReticleEntity
    {
        public int Id { get; set; }
        public string ReticleId { get; set; }
        public string ReticleName { get; set; }
        public string Version { get; set; }
    }
}
