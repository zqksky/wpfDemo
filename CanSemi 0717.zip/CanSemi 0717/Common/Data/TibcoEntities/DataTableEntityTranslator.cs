﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class DataTableEntityTranslator : IEntityTranslator
    {
        public NullableConverter ValueConverter { get; set; }

        public DataTableEntityTranslator()
        {
            ValueConverter = new NullableConverter();
        }

        #region IEntityTranslator Members


        /// <summary>
        /// Do translation from source into tagetType.  This method translate a DataTable or a single DataRow to a list of entity.
        /// </summary>
        /// <typeparam name="TTarget">type of target entity</typeparam>
        /// <param name="source">source object to be translated</param>
        /// <returns>List of translated entity objects.</returns>
        public IList<TTarget> TranslateToList<TTarget>(object source) where TTarget : new()
        {
            Debug.Assert(source != null);

            string unsupportedTypeErrorMessage = string.Format(
                    "'{0}' only support '{1}' and '{2}' to be translated. Current source type is '{3}'.",
                    this.GetType().FullName, typeof(DataRow).FullName, typeof(DataTable).FullName, source.GetType().FullName);
            Debug.Assert(source is DataRow || source is DataTable, unsupportedTypeErrorMessage);

            if (source == null) return null;

            List<TTarget> targetList = new List<TTarget>();

            Type sourceType = source.GetType();
            if (sourceType == typeof(DataTable))
            {
                var table = source as DataTable;

                foreach (DataRow dr in table.Rows)
                {
                    targetList.Add(TranslateFromDataRow<TTarget>(dr));
                }
            }
            else if (sourceType == typeof(DataRow))
            {
                targetList.Add(TranslateFromDataRow<TTarget>((DataRow)source));
            }
            else
            { }
            return targetList;
        }

        #endregion


        /// <summary>
        /// Convert DataRow into Business Entity.
        /// </summary>
        /// <param name="source">Datarow which contains service entity</param>
        /// <returns>Converted Business entity</returns>
        protected virtual TTarget TranslateFromDataRow<TTarget>(DataRow source) where TTarget : new()
        {
            string errorCol;
            // If converting source is null return null object.
            if (source == null)
            {
                return default(TTarget);
            }

            try
            {
                // create return object.
                TTarget targetObjet = new TTarget();

                Type type = targetObjet.GetType();
                PropertyInfo[] properties = type.GetProperties();

                var propertiesWithColumnMapping = from pi in properties
                                                  where Attribute.GetCustomAttribute(pi, typeof(ColumnMappingAttribute)) != null
                                                  select pi;

                // for get column names.
                DataTable dt = source.Table;

                List<DataColumn> mismatchedColumns = new List<DataColumn>();

                // for each columns in datatable, try to find out mapped entity property of TTarget type.
                foreach (DataColumn col in dt.Columns)
                {
                    var foundPropertyByColumnName = from pi in propertiesWithColumnMapping
                                                    where ColumnNameMatchesPropertyName(pi, col.ColumnName)
                                                    select pi;
                    if (foundPropertyByColumnName.Count() > 0)
                    {
                        var pi = foundPropertyByColumnName.FirstOrDefault();

                        string colName = col.ColumnName;
                        var attr = Attribute.GetCustomAttribute(pi, typeof(ColumnMappingAttribute)) as ColumnMappingAttribute;
                        errorCol = colName;
                        if (colName == "CLOSE_DT")
                        {

                        }
                        if(pi.PropertyType == typeof(DateTime) || pi.PropertyType == typeof(DateTime?))
                        {

                        }

                        object targetValue =
                            GetConvertedValue(
                                source,
                                colName,
                                pi.PropertyType,
                                (pi.PropertyType == typeof(DateTime) || pi.PropertyType == typeof(DateTime?) ) ? attr.ColumnFormat : null);

                        pi.SetValue(targetObjet, targetValue, null);
                    }
                    else
                    {
                        mismatchedColumns.Add(col);
                    }
                }

                if(targetObjet == null)
                {

                }

                return targetObjet;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                return default(TTarget);
            }
        }

        private bool ColumnNameMatchesPropertyName(PropertyInfo property,  string columnName)
        {
            bool isMatch = false;
            ColumnMappingAttribute mappingAttribute = Attribute.GetCustomAttribute(property, typeof(ColumnMappingAttribute)) as ColumnMappingAttribute;
            if (mappingAttribute == null || string.IsNullOrEmpty(columnName)) return false;

            if(string.IsNullOrEmpty(mappingAttribute.ColumnName))
            {
                string unifiedColumnName = columnName.Replace("_", "");
                string unifiedPropertyName = property.Name.Replace("_", "");

                isMatch = string.Equals(unifiedColumnName, unifiedPropertyName);
            }
            else
            {
                isMatch = string.Equals(columnName, mappingAttribute.ColumnName);
            }

            return isMatch;
        }


        private object GetConvertedValue(DataRow source, string colName, Type targetType, string format)
        {
            object tempVal = null;
            if (targetType == typeof(string))
            {
                tempVal = source[colName] == null ? string.Empty : source[colName].ToString();
            }
            else if (targetType == typeof(int) || targetType == typeof(int?))
            {
                tempVal = ValueConverter.Convert<int>(source[colName], format);
            }
            else if (targetType == typeof(long) || targetType == typeof(long?))
            {
                tempVal = ValueConverter.Convert<long>(source[colName], format);
            }
            else if (targetType == typeof(double) || targetType == typeof(double?))
            {
                tempVal = ValueConverter.Convert<double>(source[colName], format);
            }
            else if (targetType == typeof(DateTime) || targetType == typeof(DateTime?))
            {
                if(source[colName] is DateTime || source[colName] is DateTime?)
                {
                    tempVal = new DateTime?((DateTime)source[colName]);
                }
                else if(source[colName] is DBNull)
                {
                    tempVal = new DateTime?();
                }
                else
                {
                    tempVal = ValueConverter.Convert<DateTime>(source[colName], format);
                }
            }
            else if(targetType.IsEnum)
            {
                string enumString = string.Empty;
                if(source[colName] == DBNull.Value)
                {
                    enumString = "DBNull";
                }
                else
                {
                    enumString = source[colName] as string;
                }
                if(Enum.IsDefined(targetType, enumString))
                {
                    tempVal = Enum.Parse(targetType, enumString);
                }
                else
                {
                    throw new InvalidCastException(string.Format("Can not convert value to type '{2}'. Column Name: {0} Column Value:{1}", colName, source[colName] as string, targetType.Name));
                }
            }
            else if(targetType == typeof(bool) || targetType == typeof(bool?))
            {
                var strValue = source[colName] as string;
                tempVal = ValueConverter.Convert<bool>(strValue);
            }
            else { }
            return tempVal;
        }
    }
}
