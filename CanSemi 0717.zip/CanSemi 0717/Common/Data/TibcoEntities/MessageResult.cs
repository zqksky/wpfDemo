﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace R2R.Common.Data
{
    public class MessageResult<T> : MessageResult
    {
        public T Content { get; set; }
    }

    public class MessageResult
    {
        public bool HasError { get; set; }
        public string ErrorCode { get; set; }
        //public ServerSideException Exception { get; set; }
    }
}
