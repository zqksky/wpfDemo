﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace R2R.Common.Data
{
    public class QueryParameter
    {
        private string _type;
        private object _value;
        // TODO: add operator, =, > , <, contains, like


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="name">The query parameter name</param>
        /// <param name="value">The query parameter value</param>
        [JsonConstructor]
        public QueryParameter(string name, object value)
        {
            Name = name;
            if(value is string && (string)value == "")
            {
                _value = null;
            }
            else
            {
                _value = value;
            }
        }

        /// <summary>
        /// The parameter name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// The parameter value
        /// </summary>
        public object Value
        {
            get { return _value; }
            set { _value = value; }
        }
    }
}
