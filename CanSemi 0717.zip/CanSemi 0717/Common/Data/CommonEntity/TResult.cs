﻿
namespace R2R.Common.Data
{
    public class TResult
    {
        int _returnCode;
        public int ReturnCode
        {
            get { return _returnCode; }
            set { _returnCode = value; }
        }

        string _returnText;
        public string ReturnText
        {
            get { return _returnText; }
            set { _returnText = value; }
        }

        string _returnMsg;
        public string ReturnMsg
        {
            get { return _returnMsg; }
            set { _returnMsg = value; }
        }

        public TResult()
        {
            _returnCode = 0;
            _returnText = "";
            _returnMsg = "";
        }
    }
}
