﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public interface IEntityTranslator
    {
        /// <summary>
        /// Do translation from source into tagetType. 
        /// </summary>
        /// <typeparam name="TTarget">type of target entity</typeparam>
        /// <param name="source">source object to be translated</param>
        /// <returns>List of translated entity objects.</returns>
        IList<TTarget> TranslateToList<TTarget>(object source) where TTarget : new();
    }
}
