﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class ParameterRow
    {
        public ToolEntity Tool { get; set; }
        public string ParameterName { get; set; }
        public string ParameterVaue { get; set; }
        public string ParameterVaue1 { get; set; }
        public string ParameterVaue2 { get; set; }
        public string Lower { get; set; }
        public string Upper { get; set; }
        public string Deadbound { get; set; }
        public string Delta { get; set; }
        public string Fixed { get; set; }
        public string ReworkBias { get; set; }
        public string uCalc { get; set; }
        public int Precision { get; set; }
    }
}
