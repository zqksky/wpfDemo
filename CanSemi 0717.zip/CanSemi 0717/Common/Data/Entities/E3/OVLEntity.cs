﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class OVLEntity
    {
        public string Chuck { get; set; }
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string PreToolId { get; set; }
        public string PreReticleId { get; set; }
        public string CtlFlag { get; set; }
        public string ExpX { get; set; }
        public string ExpY { get; set; }
        public string NonOrt { get; set; }
        public string WftRot { get; set; }
        public string TransX { get; set; }
        public string TransY { get; set; }
        public string AsymMag { get; set; }
        public string AsymRot { get; set; }
        public string ShtMag { get; set; }
        public string ShtRot { get; set; }
        public string LastEstiTime { get; set; }
    }
}