﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using R2R.Client.Common;
using R2R.Client.Shell.ViewModels;
using R2R.Common.Data;
using MahApps.Metro.Controls;
using Prism.Common;
using Prism.Regions;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using System.Timers;

namespace R2R.Client.Shell.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow
    {
        DispatcherTimer _dateTimeTimer;
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
            Unloaded += MainWindow_Unloaded;
        }

        private void MainWindow_Unloaded(object sender, RoutedEventArgs e)
        {
            StopDateTimeTimer();
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            StartDateTimeTimer();
        }

        private void StartDateTimeTimer()
        {
            if (_dateTimeTimer == null)
            {
                _dateTimeTimer = new DispatcherTimer(DispatcherPriority.ApplicationIdle);
                _dateTimeTimer.Interval = TimeSpan.FromSeconds(1);
                _dateTimeTimer.Tick += _dateTimeTimer_Tick;
                _dateTimeTimer.Start();
            }
        }
        private void StopDateTimeTimer()
        {
            if (_dateTimeTimer == null)
            {
                _dateTimeTimer.Stop();
                _dateTimeTimer.Tick -= _dateTimeTimer_Tick;
                _dateTimeTimer = null;
            }
        }

        private void _dateTimeTimer_Tick(object sender, EventArgs e)
        {
            (this.DataContext as MainWindowViewModel).DateTimeText = DateTime.Now.ToString();
        }


        private void OKClick(object sender, RoutedEventArgs e)
        {
            MainWindowViewModel mainWindowViewModel = this.DataContext as MainWindowViewModel;
            //bool userCheck = true;
            bool userCheck = mainWindowViewModel.CheckUser(this.userPasswordBox.Password);


            if (userCheck)
            {
                mainWindowViewModel.LoginVisiable = Visibility.Collapsed;
                mainWindowViewModel.MenuVisiable = Visibility.Visible;
                this.WindowState = WindowState.Maximized;
                this.userPasswordBox.Password = "";
                this.Width = 1440;
                this.Height = 900;
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                ClientInfo.NoOperationTimer.Tick += new EventHandler((obj, eventArg) => {
                    this.Width = 500;
                    this.Height = 400;
                    this.WindowState = WindowState.Normal;
                    mainWindowViewModel.LoginVisiable = Visibility.Visible;
                    mainWindowViewModel.MenuVisiable = Visibility.Hidden;
                });
            }
            else
            {
                MessageBox.Show("Invalid user or password!", "Error", MessageBoxButton.OK);
                userPasswordBox.Password = "";
            }
        }

        private void CheckUpdatetimer_Elapsed(object sender, EventArgs e)
        {
        }

        private void ActiveViews_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {

        }
    }
}
