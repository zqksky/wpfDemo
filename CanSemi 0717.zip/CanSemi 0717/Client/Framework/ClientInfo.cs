﻿

using System;
using System.Threading;
using System.Windows.Threading;

namespace R2R.Client.Framework
{
    public class ClientInfo
    {
        private static TimeSpan Interval = TimeSpan.FromMilliseconds( 1000 * 60 * 20 );//执行间隔时间为20min  
        public static string CurrentUser { get; set; }
        public static string CurrentVersion { get; set; }
        public static string CurrentServer { get; set; }

        #region field

        private static System.Windows.Threading.DispatcherTimer _noOperationTimer = new System.Windows.Threading.DispatcherTimer();
        public static System.Windows.Threading.DispatcherTimer NoOperationTimer
        {
            get
            {
               return _noOperationTimer;
            }

            set
            {
                if(null != _noOperationTimer)
                { 
                    _noOperationTimer.Stop();
                }
                SetProperty(ref _noOperationTimer, value);
                if (null != _noOperationTimer)
                {
                    _noOperationTimer.Interval = Interval;
                    _noOperationTimer.Start();
                }
            }
        }
        #endregion field

        private static void SetProperty(ref DispatcherTimer noOperationTimer, DispatcherTimer value)
        {
            //throw new NotImplementedException();
        }
    }
}