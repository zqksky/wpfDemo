﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace R2R.Client.Framework
{
    public static class DesignModeHelper
    {
        /// <summary>
        /// Judge whether current thread is in designer or in run-time
        /// </summary>
        public static bool IsInDesignMode
        {
            get
            {
                return (bool)DesignerProperties.IsInDesignModeProperty
                            .GetMetadata(typeof(DependencyObject)).DefaultValue;
            }
        }
    }
}
