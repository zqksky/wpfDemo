﻿using System;

namespace R2R.Client.Framework.Controls
{
    public class DateTimeDependencyPropertyAttribute : Attribute
    {

    }
}