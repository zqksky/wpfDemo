﻿using System.Windows.Controls;

namespace R2R.Client.ProfileManagement.Views
{
    /// <summary>
    /// Interaction logic for FactorySetting
    /// </summary>
    public partial class FactorySetting : UserControl
    {
        public FactorySetting()
        {
            InitializeComponent();
        }
    }
}
