﻿using Prism.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.ProfileManagement.ViewModels
{
    internal class RefreshUserListEvent : PubSubEvent<string>
    {
    }
}
