﻿using Prism.Events;


namespace R2R.Client.ProfileManagement.ViewModels
{
    public class RefreshNotificationGroupListEvent : PubSubEvent<string>
    {
    }
}
