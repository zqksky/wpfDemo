﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Service.ConfigUIService;
using R2R.Client.LithoModeManagement.Views;
using R2R.Service.LithoModeService;
using R2R.Common.Data;
using System.Windows;
using R2R.Common.Library;
using R2R.Common.Data.Litho;
using System.Data;
using System.Windows.Controls;

namespace R2R.Client.LithoModeManagement.ViewModels
{

    public class HistoryViewModel : ViewModelBase
    {
        public ILithoService            LithoService { get; set; }
        public IConfigurationUIService  ConfigUIService { get; set; }
        public HistoryViewModel(ILithoService lithonService, IConfigurationUIService configUIService)
        {
            this.LithoService = lithonService;
            this.ConfigUIService = configUIService;

            this.StartDateTimeText = DateTime.Now.AddSeconds(-60 * 60 * 24 * 7).ToString("yyyy/MM/dd HH:mm:ss");
            this.EndDateTimeText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            this.titleText = null;
        }


        #region Field
        private string titleText;
        public string TitleText
        {
            get { return this.titleText; }
            set
            {
                SetProperty(ref this.titleText, value);
            }
        }
        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set
            {
                SetProperty(ref this.currentWindow, value);
            }
        }

        private CDContextContent cdContextContent;
        public CDContextContent CDContextContent
        {
            get
            {
                return this.cdContextContent;
            }
            set
            {
                SetProperty(ref this.cdContextContent, value);
                if (this.cdContextContent != null)
                {
                    this.cdContextRow = null;
                    //this.cdContextContent = null;
                    this.ovlContextContent = null;
                    this.ovlContextRow = null;
                }
            }
        }
        
        private CDContextRow cdContextRow;
        public CDContextRow CDContextRow
        {
            get
            {
                return this.cdContextRow;
            }
            set
            {
                SetProperty(ref this.cdContextRow, value);
                if (this.cdContextRow != null)
                {
                    //this.cdContextRow = null;
                    this.cdContextContent = null;
                    this.ovlContextContent = null;
                    this.ovlContextRow = null;
                }
            }
        }

        private OVLContextContent ovlContextContent;
        public OVLContextContent OVLContextContent
        {
            get
            {
                return this.ovlContextContent;
            }
            set
            {
                SetProperty(ref this.ovlContextContent, value);
                if (this.ovlContextContent != null)
                {
                    this.cdContextRow = null;
                    this.cdContextContent = null;
                    //this.ovlContextContent = null;
                    this.ovlContextRow = null;
                }
            }
        }

        private OVLContextRow ovlContextRow;
        public OVLContextRow OVLContextRow
        {
            get
            {
                return this.ovlContextRow;
            }
            set
            {
                SetProperty(ref this.ovlContextRow, value);
                if (this.ovlContextRow != null)
                {
                    this.cdContextRow = null;
                    this.cdContextContent = null;
                    this.ovlContextContent = null;
                    //this.ovlContextRow = null;
                }
            }
        }

        private string startDateTimeText;
        public string StartDateTimeText
        {
            get
            {
                return this.startDateTimeText;
            }
            set
            {
                SetProperty(ref this.startDateTimeText, value);
            }
        }

        private string endDateTimeText;
        public string EndDateTimeText
        {
            get
            {
                return this.endDateTimeText;
            }
            set
            {
                SetProperty(ref this.endDateTimeText, value);
            }
        }

    


        private List<HistoryEntity> historyList;
        public List<HistoryEntity> HistoryList
        {
            get
            {
                return this.historyList;
            }
            set
            {
                SetProperty(ref this.historyList, value);
            }
        }

        private List<ContextChangeHistory> contextHistoryList;
        public List<ContextChangeHistory> ContextHistoryList
        {
            get
            {
                return this.contextHistoryList;
            }
            set
            {
                SetProperty(ref this.contextHistoryList, value);
                if (this.contextHistoryList != null)
                {
                    if (null == this.HistoryList)
                        this.HistoryList = new List<HistoryEntity>();
                    foreach (ContextChangeHistory para in  this.contextHistoryList)
                    {
                        HistoryEntity temp = new HistoryEntity();
                        temp.ChangeBy = para.ChangeBy;
                        temp.Comment = para.ChangeComment;
                        temp.Details = para.ChangeDetails;
                        temp.Details = temp.Details.Replace("&amp;gt;", ">");
                        temp.TimeSnap = para.ChangeTime;
                        this.HistoryList.Add(temp);
                    }
                }
            }
        }

        private string returnText;
        public string ReturnText
        {
            get
            {
                return this.returnText;
            }
            set
            {
                SetProperty(ref this.returnText, value);
            }
        }
        #endregion

        #region Event
        private DelegateCommand _queryHistory;
        public DelegateCommand QueryHistory =>
            _queryHistory ?? (_queryHistory = new DelegateCommand(OnQueryHistory));
        #endregion

        #region local Function
        void OnQueryHistory()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            if (this.cdContextContent != null || this.TitleText.Contains("CD History"))
            {
                this.HistoryList = this.LithoService.QueryCDConfigOperationHist(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.CDContextContent.ToolId,
                                                                    this.CDContextContent.ProductId,
                                                                    this.CDContextContent.LayerId,
                                                                    this.CDContextContent.ReticleId,
                                                                    this.CDContextContent.RecipeId,
                                                                    //this.StartDateTimeText,
                                                                    //this.EndDateTimeText,
                                                                    out retMsg);
                this.ReturnText = retMsg;
            }
            else if (this.ovlContextContent!=null || this.TitleText.Contains("OVL History"))
            {
                retMsg = null;
                this.HistoryList = this.LithoService.QueryOVLConfigOperationHist(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.OVLContextContent.ToolId,
                                                                    this.OVLContextContent.ProductId,
                                                                    this.OVLContextContent.LayerId,
                                                                    this.OVLContextContent.ReticleId,
                                                                    this.OVLContextContent.PreTool,
                                                                    this.OVLContextContent.PreReticle,
                                                                    this.OVLContextContent.RecipeId,
                                                                    //this.StartDateTimeText,
                                                                    //this.EndDateTimeText,
                                                                    out retMsg);
                this.ReturnText = retMsg;
            }
            else if (this.cdContextRow != null || this.TitleText.Contains("CD Config History"))
            {
                retMsg = null;
                this.ContextHistoryList = this.ConfigUIService.QueryCDContextHist(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.CDContextRow.ToolId,
                                                                    this.CDContextRow.ProductId,
                                                                    this.CDContextRow.LayerId,
                                                                    this.CDContextRow.ReticleId,
                                                                    this.CDContextRow.RecipeId,
                                                                    this.StartDateTimeText,
                                                                    this.EndDateTimeText,
                                                                    out retMsg);
                this.ReturnText = retMsg;
            }
            else if (this.ovlContextRow!= null || this.TitleText.Contains("OVL Config History"))
            {
                retMsg = null;
                this.ContextHistoryList = this.ConfigUIService.QueryOVLContextHist(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.OVLContextRow.ToolId,
                                                                    this.OVLContextRow.ProductId,
                                                                    this.OVLContextRow.LayerId,
                                                                    this.OVLContextRow.ReticleId,
                                                                    this.OVLContextRow.RecipeId,
                                                                    this.OVLContextRow.PreTool,
                                                                    this.OVLContextRow.PreReticle,
                                                                    this.StartDateTimeText,
                                                                    this.EndDateTimeText,
                                                                    out retMsg);
                this.ReturnText = retMsg;
            }
        }
        #endregion
    }
}