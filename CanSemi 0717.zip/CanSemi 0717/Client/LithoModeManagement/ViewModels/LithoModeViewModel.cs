﻿using Prism.Commands;
using R2R.Client.Framework;
using R2R.Client.LithoModeManagement.Views;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;
using R2R.Service.LithoModeService;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class LithoModeViewModel : ViewModelBase
    {
        public ILithoService LithoService { get; set; }
        public IParameterConfigCDService ParameterConfigCDService { get; set; }
        public IParameterConfigOVLService ParameterConfigOVLService { get; set; }


        #region Field
        private string selectedProductText;
        public string SelectedProductText
        {
            get { return this.selectedProductText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedProductText, value);
            }
        }

        private string selectedLayerText;
        public string SelectedLayerText
        {
            get { return this.selectedLayerText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedLayerText, value);
            }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string cdEditByText;
        public string CDEditByText
        {
            get { return this.cdEditByText; }
            set
            {
                SetProperty(ref this.cdEditByText, value);
            }
        }

        private string ovlEditByText;
        public string OVLEditByText
        {
            get { return this.ovlEditByText; }
            set { SetProperty(ref this.ovlEditByText, value); }
        }

        private string cdEditTimeText;
        public string CDEditTimeText
        {
            get { return this.cdEditTimeText; }
            set { SetProperty(ref this.cdEditTimeText, value); }
        }

        private string ovlEditTimeText;
        public string OVLEditTimeText
        {
            get { return this.ovlEditTimeText; }
            set { SetProperty(ref this.ovlEditTimeText, value); }
        }

        private string cdCommentText;
        public string CDCommentText
        {
            get { return this.cdCommentText; }
            set { SetProperty(ref this.cdCommentText, value); }
        }

        private TabItem selectedTabItem;
        public TabItem SelectedTabItem
        {
            get { return this.selectedTabItem; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedTabItem, value);
            }
        }

        private string ovlCommentText;
        public string OVLCommentText
        {
            get { return this.ovlCommentText; }
            set { SetProperty(ref this.ovlCommentText, value); }
        }

        private bool isShowAll;
        public bool IsShowAll
        {
            get { return this.isShowAll; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                if (this.isShowAll != value)
                {
                    string retMsg = null;
                    List<DataView> dataViews = this.LithoService.GetLithoColumnList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
                    if (dataViews.Count > 0)
                    {
                        this.CDDataTable = dataViews[0];
                        this.OVLDataTable = dataViews[1];
                    }
                    this.SelectedCDValue = null;
                    this.selectedOVLValue = null;
                }
                SetProperty(ref this.isShowAll, value);

            }
        }

        private DataRowView selectedCDValue;
        public DataRowView SelectedCDValue
        {
            get { return this.selectedCDValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedCDValue, value);
                if (this.selectedCDValue != null)
                {
                    DataRow dataRow = this.SelectedCDValue.Row;
                    string retMsg = null;
                    this.CurrentCDContextContent = this.ParameterConfigCDService.GetCDContext(ClientInfo.CurrentUser,
                                                                          ClientInfo.CurrentVersion,
                                                                          (string)dataRow["Product"],
                                                                          (string)dataRow["Layer"],
                                                                          (string)dataRow["Tool"],
                                                                          (string)dataRow["Reticle"],
                                                                          (string)dataRow["Recipe"],
                                                                          "",
                                                                          out retMsg);
                }
            }
        }
        private CDContextContent currentCDContextContent;
        public CDContextContent CurrentCDContextContent
        {
            get
            {
                return this.currentCDContextContent;
            }
            set
            {
                this.currentCDContextContent = value;
                if (this.currentCDContextContent != null)
                {
                    this.CDEditByText = currentCDContextContent.comment.LastEditBy;
                    this.CDEditTimeText = currentCDContextContent.comment.LastEditDate;
                    this.CDCommentText = currentCDContextContent.comment.LastCommnet;
                }
            }
        }

        private DataRowView selectedOVLValue;
        public DataRowView SelectedOVLValue
        {
            get { return this.selectedOVLValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedOVLValue, value);
                if (null != this.selectedOVLValue)
                {
                    DataRow dataRow = this.SelectedOVLValue.Row;
                    string retMsg = null;
                    this.CurrentOVLContextContent = this.ParameterConfigOVLService.GetOVLContext(ClientInfo.CurrentUser,
                                                                          ClientInfo.CurrentVersion,
                                                                          (string)dataRow["Product"],
                                                                          (string)dataRow["Layer"],
                                                                          (string)dataRow["Tool"],
                                                                          (string)dataRow["Reticle"],
                                                                          (string)dataRow["Recipe"],
                                                                          (string)dataRow["PreTool"],
                                                                          (string)dataRow["PreReticle"],
                                                                          (string)dataRow["Chuck"],
                                                                          out retMsg);
                }
            }
        }

        private OVLContextContent currentOVLContextContent;
        public OVLContextContent CurrentOVLContextContent
        {
            get
            {
                return this.currentOVLContextContent;
            }
            set
            {
                this.currentOVLContextContent = value;
                if (this.currentOVLContextContent != null)
                {
                    this.OVLEditByText = currentOVLContextContent.comment.LastEditBy;
                    this.OVLEditTimeText = currentOVLContextContent.comment.LastEditDate;
                    this.OVLCommentText = currentOVLContextContent.comment.LastCommnet;
                }
            }
        }

        private DataView _CDDataTable;
        public DataView CDDataTable
        {
            get { return _CDDataTable; }
            set { SetProperty(ref _CDDataTable, value); }
        }

        private DataView _OVLDataTable;
        public DataView OVLDataTable
        {
            get { return _OVLDataTable; }
            set { SetProperty(ref _OVLDataTable, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _queryListCommand;
        public DelegateCommand QueryListCommand =>
            _queryListCommand ?? (_queryListCommand = new DelegateCommand(OnQueryList));

        private DelegateCommand _cdEditCommand;
        public DelegateCommand CDEditCommand =>
            _cdEditCommand ?? (_cdEditCommand = new DelegateCommand(OnCDEditClick));

        private DelegateCommand _cdRefreshCommand;
        public DelegateCommand CDRefreshCommand =>
            _cdRefreshCommand ?? (_cdRefreshCommand = new DelegateCommand(OnCDRefreshClick));

        private DelegateCommand _ovlEditCommand;
        public DelegateCommand OVLEditCommand =>
            _ovlEditCommand ?? (_ovlEditCommand = new DelegateCommand(OnOVLEditClick));

        private DelegateCommand _ovlRefreshCommand;
        public DelegateCommand OVLRefreshCommand =>
            _ovlRefreshCommand ?? (_ovlRefreshCommand = new DelegateCommand(OnOVLRefreshClick));

        private DelegateCommand _cdHistoryCommand;
        public DelegateCommand CDHistoryCommand =>
            _cdHistoryCommand ?? (_cdHistoryCommand = new DelegateCommand(OnCDHistoryClick));

        private DelegateCommand _cdResetCommand;
        public DelegateCommand CDResetCommand =>
            _cdResetCommand ?? (_cdResetCommand = new DelegateCommand(OnCDResetClick));

        private DelegateCommand _ovlHistoryCommand;
        public DelegateCommand OVLHistoryCommand =>
            _ovlHistoryCommand ?? (_ovlHistoryCommand = new DelegateCommand(OnOVLHistoryClick));

        private DelegateCommand _ovlResetCommand;
        public DelegateCommand OVLResetCommand =>
            _ovlResetCommand ?? (_ovlResetCommand = new DelegateCommand(OnOVLResetClick));

        private DelegateCommand _productSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _productSelectionChangedCommand ?? (_productSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        

        private DelegateCommand _layerSelectionChangedCommand;
        public DelegateCommand LayerSelectionChangedCommand =>
            _layerSelectionChangedCommand ?? (_layerSelectionChangedCommand = new DelegateCommand(OnLayerSelectionChanged));

        #endregion

        #region local Function

        void OnCDResetClick()
        {
            MessageBoxResult selectRst = MessageBox.Show("Are you sure to Reset?", "Reset", System.Windows.MessageBoxButton.YesNo);
            if (selectRst == MessageBoxResult.Yes)
            {
                if (this.SelectedCDValue != null)
                {
                    DataRow dataRow = this.SelectedCDValue.Row;
                    string retMsg = null;
                    if (this.ParameterConfigCDService.ResetHorizonCD(ClientInfo.CurrentUser,
                                                                          ClientInfo.CurrentVersion,
                                                                          (string)dataRow["Product"],
                                                                          (string)dataRow["Layer"],
                                                                          (string)dataRow["Tool"],
                                                                          (string)dataRow["Reticle"],
                                                                          (string)dataRow["Recipe"],
                                                                          out retMsg))
                    {
                        MessageBox.Show("Reset Successful!");
                    }
                    else
                    {
                        MessageBox.Show("Reset failed!");
                    }
                }
            }
        }

        void OnOVLResetClick()
        {
            MessageBoxResult selectRst = MessageBox.Show("Are you sure to Reset?", "Select overwrite", System.Windows.MessageBoxButton.YesNo);
            if (selectRst == MessageBoxResult.Yes)
            {
                if (this.SelectedOVLValue != null)
                {
                    DataRow dataRow = this.SelectedOVLValue.Row;
                    string retMsg = null;
                    if (this.ParameterConfigOVLService.ResetHorizonOVL(ClientInfo.CurrentUser,
                                                                          ClientInfo.CurrentVersion,
                                                                          (string)dataRow["Product"],
                                                                          (string)dataRow["Layer"],
                                                                          (string)dataRow["Tool"],
                                                                          (string)dataRow["Reticle"],
                                                                          (string)dataRow["Recipe"],
                                                                          (string)dataRow["PreTool"],
                                                                          (string)dataRow["PreReticle"],
                                                                          out retMsg))
                    {
                        MessageBox.Show("Reset Successful!");
                    }
                    else
                    {
                        MessageBox.Show("Reset failed!");
                    }
                }
            }
        }

        void OnCDRefreshClick()
        {
            OnQueryList();
        }

        void OnOVLRefreshClick()
        {
            OnQueryList();
        }

        void OnCDHistoryClick()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            History parameter = new History();
            HistoryViewModel v = (HistoryViewModel)parameter.DataContext;
            if (this.SelectedCDValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            v.CDContextContent = this.CurrentCDContextContent;
            v.OVLContextContent = null;
            v.CurrentWindow = window;
            window.Title = "History";
            v.TitleText = "CD History";
            window.Content = parameter;
            window.Height = 600;
            window.Width = 900;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void OnOVLHistoryClick()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();


            var window = new Window();//Windows窗体
            History parameter = new History();
            HistoryViewModel v = (HistoryViewModel)parameter.DataContext;
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            v.OVLContextContent = this.CurrentOVLContextContent;
            v.CDContextContent = null;
            v.CurrentWindow = window;
            window.Title = "History";
            v.TitleText = "OVL History";
            window.Content = parameter;
            window.Height = 600;
            window.Width = 900;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void OnQueryList()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            if (((string)this.SelectedTabItem.Header).Contains("CD"))
            {
                DataView cdDataView = this.LithoService.GetCDDataList(ClientInfo.CurrentUser, 
                                                                    ClientInfo.CurrentVersion,
                                                                    this.SelectedProductText,
                                                                    this.IsShowAll?"*":this.SelectedLayerText,
                                                                    "", 
                                                                    "", 
                                                                    CDDataTable.ToTable(),
                                                                    out retMsg);
                this.CDDataTable = cdDataView;
                return;
            }
            retMsg = null;
            DataView ovlDataView = this.LithoService.GetOVLDataList(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.SelectedProductText,
                                                                    this.IsShowAll?"*":this.SelectedLayerText,
                                                                    "",
                                                                    "",
                                                                    OVLDataTable.ToTable(),
                                                                    out retMsg);
            this.OVLDataTable = ovlDataView;
        }
        void OnLayerSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            string retMsg = null;
            List<DataView> dataViews = this.LithoService.GetLithoColumnList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
            if (dataViews.Count > 0)
            {
                this.CDDataTable = dataViews[0];
                this.OVLDataTable = dataViews[1];
            }
            this.SelectedCDValue = null;
            this.selectedOVLValue = null;
        }
        void OnProductSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            this.LayerList = this.LithoService.GetLayerList(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion, 
                this.SelectedProductText,
                out retMsg);

            List<DataView> dataViews = this.LithoService.GetLithoColumnList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
            if (dataViews.Count > 0)
            {
                this.CDDataTable = dataViews[0];
                this.OVLDataTable = dataViews[1];
            }
            this.SelectedCDValue = null;
            this.selectedOVLValue = null;
        }

        void OnCDEditClick()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            ParameterConfigCD parameter = new ParameterConfigCD();
            ParameterConfigCDViewModel v = (ParameterConfigCDViewModel)parameter.DataContext;
            if (this.SelectedCDValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            v.ContextContent = this.CurrentCDContextContent;
            v.OriContextContent = CommonHelp.DeepCopy<CDContextContent>(v.ContextContent);
            v.CurrentWindow = window;
            window.Content = parameter;
            window.Width = 1350;
            window.Height = 720;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            OnQueryList();
        }

        void OnOVLEditClick()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            ParameterConfigOVL parameter = new ParameterConfigOVL();
            ParameterConfigOVLViewModel view = (ParameterConfigOVLViewModel)parameter.DataContext;
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }

            view.ContextContent = this.CurrentOVLContextContent;
            view.OriContextContent = CommonHelp.DeepCopy<OVLContextContent>(view.ContextContent);
            view.CurrentWindow = window;
            window.Content = parameter;
            window.Width = 1350;
            window.Height = 720;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            OnQueryList();
        }
        #endregion

        public LithoModeViewModel(ILithoService lithoService, IParameterConfigOVLService parameterConfigOVLService, IParameterConfigCDService parameterConfigCDService)
        {
            this.LithoService = lithoService;
            this.ParameterConfigCDService = parameterConfigCDService;
            this.ParameterConfigOVLService = parameterConfigOVLService;

            Title = "LithoModeView";

            string retMsg = null;
            this.ProductList = this.LithoService.GetProductList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);

            List<DataView> dataViews = this.LithoService.GetLithoColumnList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
            if(dataViews.Count > 0)
            { 
                this.CDDataTable = dataViews[0];
                this.OVLDataTable = dataViews[1];
            }
        }
    }
}
