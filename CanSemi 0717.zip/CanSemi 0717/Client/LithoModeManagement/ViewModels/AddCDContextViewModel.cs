﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Service.ConfigUIService;
using R2R.Service.LithoModeService;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class AddCDContextViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;
        public ISpecialJobListViewService SpecialJobListViewService { get; set; }

        public AddCDContextViewModel(IConfigurationUIService configurationUIService, ISpecialJobListViewService specialJobListViewService)
        {
            this.ConfigurationUIService = configurationUIService;
            this.SpecialJobListViewService = specialJobListViewService;

            string retMsg = null;
            this.ToolList = this.SpecialJobListViewService.GetToolList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
        }

        #region Field
        private List<String> toolList;
        public List<String> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }
        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }

        private string productId;
        public string ProductId
        {
            get { return this.productId; }
            set
            {
                SetProperty(ref this.productId, value); }
        }

        private string layerId;
        public string LayerId
        {
            get { return this.layerId; }
            set
            {
                SetProperty(ref this.layerId, value); }
        }

        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.toolText, value); }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.reticleText, value); }
        }

        private string recipeText;
        public string RecipeText
        {
            get { return this.recipeText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.recipeText, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand =>
            _saveCommand ?? (_saveCommand = new DelegateCommand(OnSave));

        private DelegateCommand _closeCommand;
        public DelegateCommand CloseCommand =>
            _closeCommand ?? (_closeCommand = new DelegateCommand(OnClose));
        #endregion

        #region local Function
        void OnSave()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            string retMsg = null;
            bool ret = this.ConfigurationUIService.AddNewCDContext(ClientInfo.CurrentUser, 
                ClientInfo.CurrentVersion, 
                this.ToolText, 
                this.ProductId, 
                this.LayerId, 
                this.ReticleText,
                this.RecipeText,
                out retMsg);
            if (!ret)
            {
                if(!string.IsNullOrEmpty(retMsg))
                    MessageBox.Show(retMsg);
                return;
            }
            MessageBox.Show("sava is success!");
            OnClose();
        }
        void OnClose()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            this.CurrentWindow.Close();
        }
        
        #endregion
    }
}