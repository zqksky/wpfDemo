﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Service.ConfigUIService;
using R2R.Service.LithoModeService;
using System.Windows;
using R2R.Common.Data;
using R2R.Common.Data.Litho;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    class ResetHorizonByToolViewModel: ViewModelBase
    {
        public ILithoService LithoService { get; set; }
        public ISpecialJobListViewService SpecialJobListViewService { get; set; }

        public ResetHorizonByToolViewModel(ILithoService lithoService, ISpecialJobListViewService specialJobListViewService)
        {
            this.LithoService = lithoService;
            this.SpecialJobListViewService = specialJobListViewService;

            string retMsg = null;
            this.ToolList = this.SpecialJobListViewService.GetToolList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
        }


        #region Field

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }

        private List<String> toolList;
        public List<String> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }

        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.toolText, value);
            }
        }

        private string lastResetByText;
        public string LastResetByText
        {
            get { return this.lastResetByText; }
            set
            {
                SetProperty(ref this.lastResetByText, value);
            }
        }

        private string lastResetTime;
        public string LastResetTime
        {
            get { return this.lastResetTime; }
            set
            {
                SetProperty(ref this.lastResetTime, value);
            }
        }

        private string lastResetResult;
        public string LastResetResult
        {
            get { return this.lastResetResult; }
            set
            {
                SetProperty(ref this.lastResetResult, value);
            }
        }

        #endregion

        #region Event
        private DelegateCommand _resetCommand;
        public DelegateCommand ResetCommand =>
            _resetCommand ?? (_resetCommand = new DelegateCommand(OnReset));

        
        private DelegateCommand _toolSelectionChangedCommand;
        public DelegateCommand ToolSelectionChangedCommand =>
            _toolSelectionChangedCommand ?? (_toolSelectionChangedCommand = new DelegateCommand(OnToolSelectionChanged));
        #endregion

        #region local Function
        void OnToolSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            string retMsg = null;
            ToolResetHistory ret = this.LithoService.GetLatestResetHistory4Tool(ClientInfo.CurrentUser,
                 ClientInfo.CurrentVersion,
                 this.ToolText,
                 out retMsg);
            if (null == ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            this.LastResetByText = ret.LastResetBy;
            this.LastResetTime = ret.LastResetTime;
            this.LastResetResult = ret.LastResetResult;
        }

        void OnReset()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            string retMsg = null;
            bool ret = this.LithoService.ResetHorizonByTool(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                this.ToolText,
                out retMsg);
            if (!ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            MessageBox.Show("sava is success!");

            OnToolSelectionChanged();//update history
        }
        #endregion
    }
}

