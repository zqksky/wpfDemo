﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Client.LithoModeManagement.Views;
using R2R.Service.LithoModeService;
using R2R.Common.Data;
using System.Windows;
using R2R.Common.Library;

namespace R2R.Client.LithoModeManagement.ViewModels
{

    public class SpecialJobListViewModel : ViewModelBase
    {
        public ISpecialJobListViewService SpecialJobListViewService { get; set; }

        public SpecialJobListViewModel(ISpecialJobListViewService specialJobListViewService)
        {
            this.SpecialJobListViewService = specialJobListViewService;

            string retMsg = null;
            this.ToolList = this.SpecialJobListViewService.GetToolList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
            this.ProductList = this.SpecialJobListViewService.GetProductList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);

            this.StartDateTimeText = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
            this.EndDateTimeText = DateTime.Now.AddDays(20).ToString("yyyy/MM/dd HH:mm:ss");

            this.IsNew = true;
        }

        #region Field
        private bool isUseTimeIsNull;
        public bool IsUseTimeIsNull
        {
            get { return this.isUseTimeIsNull; }
        }

        private List<string> toolList;
        public List<string> ToolList
        {
            get
            {
                return this.toolList;
            }
            set
            {
                SetProperty(ref this.toolList, value);
            }
        }

        private string selectedToolValue;
        public string SelectedToolValue
        {
            get{ return this.selectedToolValue;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedToolValue, value);
            }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get
            {
                return this.productList;
            }
            set
            {
                SetProperty(ref this.productList, value);
            }
        }

        private string selectedProductValue;
        public string SelectedProductValue
        {
            get
            {
                return this.selectedProductValue;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedProductValue, value);
            }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get
            {
                return this.layerList;
            }
            set
            {
                SetProperty(ref this.layerList, value);
            }
        }

        private string selectedLayerValue;
        public string SelectedLayerValue
        {
            get
            {
                return this.selectedLayerValue;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedLayerValue, value);
            }
        }

        private string startDateTimeText;
        public string StartDateTimeText
        {
            get{ return this.startDateTimeText;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.startDateTimeText, value);}
        }

        private string endDateTimeText;
        public string EndDateTimeText
        {
            get
            {
                return this.endDateTimeText;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.endDateTimeText, value);
            }
        }

        private string lotText;
        public string LotText
        {
            get
            {
                return this.lotText;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.lotText, value);
            }
        }
        private string recipeText;
        public string RecipeText
        {
            get
            {
                return this.recipeText;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.recipeText, value);
            }
        }

        private bool isNew;
        public bool IsNew
        {
            get
            {
                return this.isNew;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isNew, value);
            }
        }

        private bool isUsed;
        public bool IsUsed
        {
            get
            {
                return this.isUsed;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isUsed, value);
            }
        }

        private bool isAll;
        public bool IsAll
        {
            get
            {
                return this.isAll;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isAll, value);
            }
        }

        private ObservableCollection<SpecialJobRow> _DataList;
        public ObservableCollection<SpecialJobRow> DataList
        {
            get { return _DataList; }
            set { SetProperty(ref _DataList, value); }
        }

        private SpecialJobRow selectedValue;
        public SpecialJobRow SelectedValue
        {
            get { return selectedValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref selectedValue, value);
                if(this.selectedValue != null)
                { 
                    if (string.IsNullOrEmpty(this.SelectedValue.UsedTime))
                    {
                        this.isUseTimeIsNull = true;
                    }
                    else
                    {//Insufficient data, waiting for test
                        this.isUseTimeIsNull = false;
                    }
                }
            }
        }

        private ObservableCollection<ParameterRow> _cdDataList;
        public ObservableCollection<ParameterRow> CDDataList
        {
            get { return _cdDataList; }
            set { SetProperty(ref _cdDataList, value); }
        }

        private ObservableCollection<ParameterRow> _ovlDataList;
        public ObservableCollection<ParameterRow> OVLDataList
        {
            get { return _ovlDataList; }
            set { SetProperty(ref _ovlDataList, value); }
        }
        
        #endregion

        #region Event
        private DelegateCommand _queryListCommand;
        public DelegateCommand QueryListCommand => 
            _queryListCommand ?? (_queryListCommand = new DelegateCommand(OnQueryList));

        private DelegateCommand _productSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _productSelectionChangedCommand ?? (_productSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        private DelegateCommand _selectionChangedCommand;
        public DelegateCommand SelectionChangedCommand =>
            _selectionChangedCommand ?? (_selectionChangedCommand = new DelegateCommand(OnSelectionChanged));


        private DelegateCommand _paramEditCommand;
        public DelegateCommand ParamEditCommand =>
            _paramEditCommand ?? (_paramEditCommand = new DelegateCommand(OnParamEdit));

        private DelegateCommand _paramDeleteCommand;
        public DelegateCommand ParamDeleteCommand =>
            _paramDeleteCommand ?? (_paramDeleteCommand = new DelegateCommand(OnParamDelete));

        private DelegateCommand _paramCreateByCommand;
        public DelegateCommand ParamCreateByCommand =>
            _paramCreateByCommand ?? (_paramCreateByCommand = new DelegateCommand(OnParamCreateBy));

        private DelegateCommand _paramCreateNewCommand;
        public DelegateCommand ParamCreateNewCommand =>
            _paramCreateNewCommand ?? (_paramCreateNewCommand = new DelegateCommand(OnParamCreateNew));

        #endregion

        #region local Function
        void OnQueryList()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string userFlag = GetUserFlag();
            string retMsg = null;
            List<SpecialJobRow> specials = this.SpecialJobListViewService.GetDataList(ClientInfo.CurrentUser,
                                                                                      ClientInfo.CurrentVersion,
                                                                                      this.startDateTimeText,
                                                                                      this.EndDateTimeText,
                                                                                      this.SelectedToolValue,
                                                                                      this.SelectedProductValue,
                                                                                      this.SelectedLayerValue,
                                                                                      this.LotText,
                                                                                      "",
                                                                                      this.RecipeText,
                                                                                      userFlag,
                                                                                      out retMsg);
            if(specials != null)
            {
                this.DataList = new ObservableCollection<SpecialJobRow>(specials);
            }
            
        }
        void OnProductSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            this.LayerList = this.SpecialJobListViewService.GetLayerList(ClientInfo.CurrentUser, 
                ClientInfo.CurrentVersion, 
                this.SelectedProductValue,
                out retMsg);
        }

        void OnSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;

            SpecialJobRow specialJobRow = this.selectedValue;
            if (specialJobRow == null) return;

            SpecialJobRow tempParameters = this.SpecialJobListViewService.GetDataParamsList(ClientInfo.CurrentUser,
                                                                                        ClientInfo.CurrentVersion,
                                                                                        specialJobRow.JobId, out retMsg);
            if (tempParameters != null)
            {
                this.SelectedValue = tempParameters;
            }
            if ((!string.IsNullOrEmpty(retMsg)) && (!retMsg.Equals("OK", StringComparison.OrdinalIgnoreCase)))
            {
                MessageBox.Show(retMsg);
            }
            if (this.selectedValue != null && this.selectedValue.cdParameters != null && this.selectedValue.cdParameters.Count > 0)
            {
                this.CDDataList = new ObservableCollection<ParameterRow>(this.selectedValue.cdParameters);
            }
            if (this.selectedValue != null && this.selectedValue.ovlParameters != null && this.selectedValue.ovlParameters.Count > 0)
            {
                this.OVLDataList = new ObservableCollection<ParameterRow>(this.selectedValue.ovlParameters);
            }
        }

        void OnParamEdit()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            if (!this.IsUseTimeIsNull)
            {
                MessageBox.Show("Speical job has been completed!");
                return;
            }
            var window = new Window();//Windows窗体
            CreateSpecialJob view = new CreateSpecialJob();
            CreateSpecialJobViewModel model = (CreateSpecialJobViewModel)view.DataContext;
            if (this.SelectedValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }

            model.SpecialJob = this.SelectedValue;
            model.OriSpecialJob = CommonHelp.DeepCopy<SpecialJobRow>(this.SelectedValue);
            window.Content = view;
            model.TitleText = "Edit SpecialJob";
            //window.WindowStyle = WindowStyle.None;
            window.Title = "Edit SpecialJob";
            window.Height = 800;
            window.Width = 1050;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void OnParamCreateBy()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            CreateSpecialJob view = new CreateSpecialJob();
            CreateSpecialJobViewModel model = (CreateSpecialJobViewModel)view.DataContext;
            if (this.SelectedValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            model.SpecialJob = this.SelectedValue;
            model.OriSpecialJob = CommonHelp.DeepCopy<SpecialJobRow>(this.SelectedValue);
            model.TitleText = "CreateBy SpecialJob";
            window.Title = "CreateBy SpecialJob";
            window.Content = view;
            //window.WindowStyle = WindowStyle.None;
            window.Height = 800;
            window.Width = 1050;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void OnParamCreateNew()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            CreateSpecialJob view = new CreateSpecialJob();
            CreateSpecialJobViewModel model = (CreateSpecialJobViewModel)view.DataContext;
            //if (this.SelectedValue == null)
            //{
            //    MessageBox.Show("Row is not selected!");
            //    return;
            //}
            model.CurrentWindow = window;
            model.SpecialJob = new SpecialJobRow();;
            model.TitleText = "CreateNew SpecialJob";
            window.Title = "CreateNew SpecialJob";
            window.Content = view;
            //window.WindowStyle = WindowStyle.None;
            window.Height = 800;
            window.Width = 1050;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void OnParamDelete()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            bool deleteRst = this.SpecialJobListViewService.DeleteNewSpecialJob(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion, 
                this.SelectedValue.JobId,
                out retMsg);
            if (deleteRst)
            {
                OnQueryList();
            }
            else
            {
                MessageBox.Show(retMsg);
            }
        }

        string GetUserFlag()
        {
            if(this.isAll)
                return "All";
            if (this.isNew)
                return "New";
            if (this.isUsed)
                return "Used";
            return null;
        }
        #endregion
    }
}