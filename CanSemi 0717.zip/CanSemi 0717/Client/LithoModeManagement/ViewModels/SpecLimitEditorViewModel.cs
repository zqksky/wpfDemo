﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Service.ConfigUIService;
using R2R.Common.Data.Litho;
using R2R.Common.Data;
using System.Windows;
using R2R.Common.Library;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class SpecLimitEditorViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;

        public SpecLimitEditorViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
        }


        #region Field
        private string returnText;
        public string ReturnText
        {
            get { return this.returnText; }
            set { SetProperty(ref this.returnText, value); }
        }

        private string limitType;
        public string LimitType
        {
            get { return this.limitType; }
            set { SetProperty(ref this.limitType, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }

        private SpecMainContent oriMainContent;
        public SpecMainContent OriMainContent
        {
            get { return this.oriMainContent; }
            set
            {
                SetProperty(ref this.oriMainContent, value);
            }
        }

        private SpecMainContent mainContent;
        public SpecMainContent MainContent
        {
            get { return this.mainContent; }
            set
            {            
                SetProperty(ref this.mainContent, value);
                if(this.mainContent != null)
                {
                    //this.SpecLimitStringList = this.mainContent.Specs;
                    this.specLimitStringList.Clear();
                    foreach (SpecEntity spec in this.mainContent.Specs)
                    {
                        SpecEntityString temp = new SpecEntityString(spec);
                        this.specLimitStringList.Add(temp);
                    }
                }
            }
        }

        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set
            {
                SetProperty(ref this.toolText, value);
                if(this.MainContent != null)
                {
                    this.mainContent.ToolId = this.ToolText;
                }
            }
        }

        private string recipeText;
        public string RecipeText
        {
            get { return this.recipeText; }
            set
            {
                SetProperty(ref this.recipeText, value);
            }
        }

        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set
            {
                SetProperty(ref this.productText, value);
                if (this.MainContent != null)
                {
                    this.mainContent.ProductId = this.productText;
                }
            }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set
            {
                SetProperty(ref this.layerText, value);
                if (this.MainContent != null)
                {
                    this.mainContent.LayerId = this.layerText;
                }
            }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set
            {
                SetProperty(ref this.reticleText, value);
                if (this.MainContent != null)
                {
                    this.mainContent.ReticleId = this.reticleText;
                }
            }
        }

        private string preTool;
        public string PreTool
        {
            get { return this.preTool; }
            set
            {
                SetProperty(ref this.preTool, value);
            }
        }

        private string preReticle;
        public string PreReticle
        {
            get { return this.preReticle; }
            set
            {
                SetProperty(ref this.preReticle, value);
            }
        }

        private List<SpecEntityString> specLimitStringList = new List<SpecEntityString>();
        public List<SpecEntityString> SpecLimitStringList
        {
            get { return this.specLimitStringList; }
            set
            {
                SetProperty(ref this.specLimitStringList, value);
                if (this.MainContent != null)
                {
                    //this.mainContent.Specs = this.specLimitList;
                    this.mainContent.Specs = new List<SpecEntity>();
                    if (this.specLimitStringList != null)
                    { 
                        foreach (SpecEntityString specStr in this.specLimitStringList)
                        {
                            SpecEntity temp = new SpecEntity(specStr);
                            this.mainContent.Specs.Add(temp);
                        }
                    }
                }
            }
        }

        private SpecEntity selectedSpecLimitValue;
        public SpecEntity SelectedSpecLimitValue
        {
            get { return this.selectedSpecLimitValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedSpecLimitValue, value);
            }
        }
        #endregion

        #region Event
        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand =>
            _saveCommand ?? (_saveCommand = new DelegateCommand(OnSave));
        #endregion

        #region local Function
        void OnSave()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (!CheckFixedValueInRange())
            {
                MessageBox.Show("Pls Check the Values!");
                return;
            }
            string retMsg = null;
            SpecMainContent returnRst = null;
            if (this.LimitType == "CD")
            {
                this.mainContent.Specs = new List<SpecEntity>();
                if (this.specLimitStringList != null)
                {
                    foreach (SpecEntityString specStr in this.specLimitStringList)
                    {
                        SpecEntity temp = new SpecEntity(specStr);
                        this.mainContent.Specs.Add(temp);
                    }
                }
                bool ret = this.ConfigurationUIService.saveCDSpecLimitMainContent(ClientInfo.CurrentUser,
                                                                                ClientInfo.CurrentVersion,
                                                                                this.RecipeText,
                                                                                this.MainContent,
                                                                                this.OriMainContent,
                                                                                out returnRst,
                                                                                out retMsg);
                if(!ret)
                {
                    this.ReturnText = retMsg;
                    return;
                }
                if (null != returnRst)
                {
                    this.OriMainContent = returnRst;
                }
                MessageBox.Show("sava is success!");
                this.currentWindow.Close();
            }
            else
            {
                this.mainContent.Specs = new List<SpecEntity>();
                if (this.specLimitStringList != null)
                {
                    foreach (SpecEntityString specStr in this.specLimitStringList)
                    {
                        SpecEntity temp = new SpecEntity(specStr);
                        this.mainContent.Specs.Add(temp);
                    }
                }
                bool ret = this.ConfigurationUIService.saveOVLSpecLimitMainContent(ClientInfo.CurrentUser,
                                                                                ClientInfo.CurrentVersion,
                                                                                this.RecipeText,
                                                                                this.PreTool,
                                                                                this.preReticle,
                                                                                this.MainContent,
                                                                                this.OriMainContent,
                                                                                out returnRst,
                                                                                out retMsg);
                if (!ret)
                {
                    this.ReturnText = retMsg;
                    return;
                }
                if (null != returnRst)
                {
                    this.OriMainContent = returnRst;
                }
                MessageBox.Show("sava is success!");
                this.currentWindow.Close();
            }
        }

        bool CheckFixedValueInRange()
        {
            bool rst = true;
            double lowerLimit = 0;
            double upperLimit = 0;
            double fblower = 0;
            double fbupper = 0;
            foreach (SpecEntityString para in this.specLimitStringList)
            {
                lowerLimit = 0;
                upperLimit = 0;
                fblower = 0;
                fbupper = 0;
                if (!string.IsNullOrEmpty(para.LowerLimit))
                {
                    try {
                        lowerLimit = System.Convert.ToDouble(para.LowerLimit);
                    }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.Upperlimit))
                {
                    try {
                        upperLimit = System.Convert.ToDouble(para.Upperlimit);
                    }
                    catch { return false; }
                }
                else
                { return false; }

                //check lowerLimit is biger than upperLimit
                if (lowerLimit > upperLimit)
                { return false; }

                if (!string.IsNullOrEmpty(para.Delta))
                {
                    try { System.Convert.ToDouble(para.Delta); }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.Deadband))
                {
                    try { System.Convert.ToDouble(para.Deadband); }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.FbLower))
                {
                    try {
                        fblower = System.Convert.ToDouble(para.FbLower);
                    }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.FbUpper))
                {
                    try {
                        fbupper = System.Convert.ToDouble(para.FbUpper);
                    }
                    catch { return false; }
                }
                else
                { return false; }

                //check fblower is biger than fbupper
                if (fblower > fbupper)
                { return false; }

                if (!string.IsNullOrEmpty(para.FbDelta))
                {
                    try { System.Convert.ToDouble(para.FbDelta); }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.Lambda))
                {
                    try { System.Convert.ToDouble(para.Lambda); }
                    catch { return false; }
                }
                else
                { return false; }

                if (!string.IsNullOrEmpty(para.LambdaForPiRun))
                {
                    try { System.Convert.ToDouble(para.LambdaForPiRun); }
                    catch { return false; }
                }
                else
                { return false; }
            }
            return rst;
        }
        #endregion
    }
}