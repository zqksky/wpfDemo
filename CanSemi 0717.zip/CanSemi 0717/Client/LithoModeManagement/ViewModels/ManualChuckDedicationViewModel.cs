﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using System.Data;
using R2R.Service.ManualService;
using R2R.Common.Data.Litho;
using System.Windows.Forms;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ManualChuckDedicationViewModel : ViewModelBase
    {
        public IQueryManualService QueryManualService;

        public ManualChuckDedicationViewModel(IQueryManualService queryManualService)
        {
            this.QueryManualService = queryManualService;
        }



        #region Field
        private string msgText;
        public string MsgText
        {
            get { return this.msgText; }
            set { SetProperty(ref this.msgText, value); }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set { SetProperty(ref this.layerText, value); }
        }

        private string waferText;
        public string WaferText
        {
            get { return this.waferText; }
            set { SetProperty(ref this.waferText, value); }
        }

        private List<string> chuckList;
        public List<string> ChuckList
        {
            get { return this.chuckList; }
            set { SetProperty(ref this.chuckList, value); }
        }

        private string selectedChuckText;
        public string SelectedChuckText
        {
            get { return this.selectedChuckText;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedChuckText, value);}
        }

        private ObservableCollection<ManualDedicationRow> dataList;
        public ObservableCollection<ManualDedicationRow> DataList
        {
            get
            {
                return this.dataList;
            }
            set
            {
                SetProperty(ref this.dataList, value);
            }
        }

        private ManualDedicationRow selectedValue;
        public ManualDedicationRow SelectedValue
        {
            get { return this.selectedValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedValue, value);
                if ( this.selectedValue != null )
                {
                    LayerText = selectedValue.Layer;
                    WaferText = selectedValue.WaferId;
                    SelectedChuckText = selectedValue.ChuckId;
                }
            }
        }
        #endregion






        #region Event
        private DelegateCommand _queryLayerCommand;
        public DelegateCommand QueryLayerCommand =>
            _queryLayerCommand ?? (_queryLayerCommand = new DelegateCommand(OnQueryLayer));

        private DelegateCommand _queryWaferCommand;
        public DelegateCommand QueryWaferCommand =>
            _queryWaferCommand ?? (_queryWaferCommand = new DelegateCommand(OnQueryWafer));

        private DelegateCommand _deleteCommand;
        public DelegateCommand DeleteCommand =>
            _deleteCommand ?? (_deleteCommand = new DelegateCommand(OnDelete));

        private DelegateCommand _addCommand;
        public DelegateCommand AddCommand =>
            _addCommand ?? (_addCommand = new DelegateCommand(OnAdd));

        #endregion






        #region local Function
        void OnQueryLayer()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            ObservableCollection<ManualDedicationRow> manuals = new ObservableCollection<ManualDedicationRow>(
                this.QueryManualService.QueryDedicationWaferList4Layer(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                this.LayerText,
                out retMsg));

            if (manuals != null)
            {
                this.DataList = new ObservableCollection<ManualDedicationRow>(manuals);
            }
            this.MsgText = retMsg;
        }
        void OnQueryWafer()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            ObservableCollection<ManualDedicationRow> manuals = this.QueryManualService.QueryDedicationWaferListByRoot(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                this.WaferText,
                out retMsg);

            if (manuals != null)
            {
                this.DataList = manuals;
            }
            this.MsgText = retMsg;
        }
        void OnAdd()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            ManualDedicationRow dedicationWafer = new ManualDedicationRow();
            dedicationWafer.Layer = this.LayerText;
            dedicationWafer.WaferId = this.WaferText;
            dedicationWafer.ChuckId = this.SelectedChuckText;
            string retMsg = null;
            bool rstAdd = this.QueryManualService.AddDedicationWafer(ClientInfo.CurrentUser, 
                ClientInfo.CurrentVersion,
                dedicationWafer,
                out retMsg);

            if (rstAdd)
            {
                ManualDedicationRow tempEntity = new ManualDedicationRow();
                tempEntity.WaferId = this.WaferText;
                tempEntity.Layer = this.LayerText;
                tempEntity.ChuckId = this.SelectedChuckText;
                this.dataList.Add(tempEntity);
            }
            this.MsgText = retMsg;
        }
        void OnDelete()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            string retMsg = null;
            bool rstDelete = this.QueryManualService.DeleteDedicationWafer(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                this.SelectedValue,
                out retMsg);

            if (rstDelete)
            {//Delete in the DataGrid
                bool rst = DataList.Remove(selectedValue);
                bool temp = rst;
            }
            this.MsgText = retMsg;
        }
        #endregion

    }
}