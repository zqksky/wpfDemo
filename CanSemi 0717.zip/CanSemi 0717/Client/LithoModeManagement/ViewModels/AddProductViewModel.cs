﻿using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Data;
using R2R.Service.ConfigUIService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class AddProductViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;

        public AddProductViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
        }

        #region Field
        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.productText, value);
                if (this.Product != null)
                {
                    this.Product.ProductId = this.productText;
                }
            }
        }

        private string productTypeText;
        public string ProductTypeText
        {
            get { return this.productTypeText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.productTypeText, value);
                if(this.Product != null)
                {
                    this.Product.ProductType = this.productTypeText;
                }
            }
        }

        private ProductEntity product = new ProductEntity();
        public ProductEntity Product
        {
            get { return this.product; }
            set { SetProperty(ref this.product, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand =>
            _saveCommand ?? (_saveCommand = new DelegateCommand(OnSave));

        private DelegateCommand _closeCommand;
        public DelegateCommand CloseCommand =>
            _closeCommand ?? (_closeCommand = new DelegateCommand(OnClose));
        #endregion

        #region local Function
        void OnSave()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            string retMsg = null;
            bool ret = this.ConfigurationUIService.AddNewProduct(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion, 
                this.Product,
                out retMsg);
            if (!ret)
            {
                if (!string.IsNullOrEmpty(retMsg))
                    MessageBox.Show(retMsg);
                return;
            }
            MessageBox.Show("sava is success!");
            OnClose();
        }
        void OnClose()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            this.CurrentWindow.Close();
        }

        #endregion
    }
}
