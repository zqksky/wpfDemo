﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Common.Data.Litho;
using System.Windows;
using R2R.Client.LithoModeManagement.Views;
using System.Windows.Controls;
using R2R.Service.ConfigUIService;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ProductConfigurationViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;
        public ProductConfigurationViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
            string retMsg = null;
            this.ProductList = this.ConfigurationUIService.GetProductList(ClientInfo.CurrentUser, 
                ClientInfo.CurrentVersion, 
                out retMsg);

            this.rexlaxationList = new List<string>();
            this.rexlaxationList.Add("");
            this.rexlaxationList.Add("1");
            this.rexlaxationList.Add("2");
            this.rexlaxationList.Add("3");
            this.rexlaxationList.Add("4");
            this.rexlaxationList.Add("5");

            this._CDFeatureList = new List<string>();
            this._CDFeatureList.Add("");
            this._CDFeatureList.Add("CDP1");
            this._CDFeatureList.Add("CDP2");
            this._CDFeatureList.Add("CDP3");
            this._CDFeatureList.Add("CDP4");
            this._CDFeatureList.Add("CDP5");
            this._CDFeatureList.Add("CDP6");
            this._CDFeatureList.Add("CDP7");
            this._CDFeatureList.Add("CDP8");
            this._CDFeatureList.Add("CDP9");
            this._CDFeatureList.Add("CDP10");
                      
            this.ovlModelList = new List<string>();
            this.ovlModelList.Add("");
            this.ovlModelList.Add("T1M0R0F1");
            this.ovlModelList.Add("T3M0R0F1");
            this.ovlModelList.Add("T3M0R0F3");
            this.ovlModelList.Add("T3M3R3F3");
            this.ovlModelList.Add("T5M5R5F3");


            this._OVLControlModelList = new List<string>();
            this._OVLControlModelList.Add("");
            this._OVLControlModelList.Add("LINEAR");
            this._OVLControlModelList.Add("HOPC");
            this._OVLControlModelList.Add("iHOPC1");
        }

        #region Field

        private int dedicationIndex;
        public int DedicationIndex
        {
            get {
                return this.dedicationIndex;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.dedicationIndex, value);
                if (this.OVLSpecConfig != null)
                {
                    this.OVLSpecConfig.DedicationType = (dedicationIndex + 1).ToString();
                }
            }
        }


        private TabItem selectedTabItem;
        public TabItem SelectedTabItem
        {
            get { return this.selectedTabItem; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedTabItem, value); }
        }

        private List<ProductEntity> productList;
        public List<ProductEntity> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }
		
		private ProductEntity selectedProductValue;
        public ProductEntity SelectedProductValue
        {
            get { return this.selectedProductValue; }
            set { 
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedProductValue, value); }
        }
		
		private List<LayerEntity> layerList;
        public List<LayerEntity> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }
		
		private LayerEntity selectedLayerValue;
        public LayerEntity SelectedLayerValue
        {
            get { return this.selectedLayerValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedLayerValue, value); }
        }
		
		private string preOVLLayerText;
        public string PreOVLLayerText
        {
            get { return this.preOVLLayerText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.preOVLLayerText, value);
                if (this.runtime != null)
                {
                    this.runtime.PreOvlLayer = this.PreOVLLayerText;
                } 
            }
        }

        //private string _OVLDedicationTypeText;
        //public string OVLDedicationTypeText
        //{
        //    get
        //    {
        //        return _OVLDedicationTypeText;
        //    }
        //    set
        //    {
        //        SetProperty(ref this._OVLDedicationTypeText, value);
        //        if (this.runtime != null)
        //        {
        //            this.runtime.DedicationLayer = _OVLDedicationTypeText;
        //        }
        //    }
        //}

        private string dedicationLayerText;
        public string DedicationLayerText
        {
            get { return this.dedicationLayerText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.dedicationLayerText, value);
                if (this.runtime != null)
                {
                    this.runtime.DedicationLayer = this.dedicationLayerText;
                }
            }
        }
		
		private string rexlaxationText;
        public string RexlaxationText
        {
            get { return this.rexlaxationText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.rexlaxationText, value);
                if (this.runtime != null)
                {
                    this.runtime.Relaxation = this.rexlaxationText;
                }
            }
        }

        private List<string> rexlaxationList;
        public List<string> RexlaxationList
        {
            get { return this.rexlaxationList; }
            set
            {
                SetProperty(ref this.rexlaxationList, value);
            }
        }
        private List<string> _CDFeatureList;
        public List<string> CDFeatureList
        {
            get { return this._CDFeatureList; }
            set
            {
                SetProperty(ref this._CDFeatureList, value);
            }
        }
        

        private string feedbackStageOVLText;
        public string FeedbackStageOVLText
        {
            get { return this.feedbackStageOVLText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.feedbackStageOVLText, value);
                if (this.runtime != null)
                {
                    this.runtime.FeedbackStageOvl = this.feedbackStageOVLText;
                }
            }
        }
		private string feedbackStageCDText;
        public string FeedbackStageCDText
        {
            get { return this.feedbackStageCDText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.feedbackStageCDText, value);
                if (this.runtime != null)
                {
                    this.runtime.FeedbackStageCd = this.feedbackStageCDText;
                }
            }
        }
		
		private string alignLayerText;
        public string AlignLayerText
        {
            get { return this.alignLayerText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.alignLayerText, value);
                if (this.runtime != null)
                {
                    this.runtime.AlignLayer = this.alignLayerText;
                }
            }
        }
		
		private bool isUseMachineStatus;
        public bool IsUseMachineStatus
        {
            get { return this.isUseMachineStatus; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isUseMachineStatus, value);
                if (this.runtime != null)
                {
                    this.runtime.UseMachineStatus = this.isUseMachineStatus;
                }
            }
        }
		
		private bool isNpmFlag;
        public bool IsNpmFlag
        {
            get { return this.isNpmFlag; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isNpmFlag, value);
                if (this.runtime != null)
                {
                    this.runtime.NPWFlag = this.isNpmFlag;
                }
            }
        }
		
		private List<CDContextRow> cdList;
        public List<CDContextRow> CDList
        {
            get { return this.cdList; }
            set { SetProperty(ref this.cdList, value); }
        }
		
		private CDContextRow selectedCDValue;
        public CDContextRow SelectedCDValue
        {
            get { return this.selectedCDValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedCDValue, value); }
        }
		
		private string cdDoseText;
        public string CDDoseText
        {
            get { return this.cdDoseText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdDoseText, value);
               
                if (this.cdSpecConfig != null)
                {
                    if(this.cdDoseText == "")
                    {
                        this.cdSpecConfig.Dose = double.NaN;
                    }
                    else
                    {
                        try
                        {
                            this.cdSpecConfig.Dose = System.Convert.ToDouble(this.cdDoseText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.CDDoseText = "";
                        }
                    }
                }
            }
        }
		
		private string cdFocusText;
        public string CDFocusText
        {
            get { return this.cdFocusText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdFocusText, value);
                if (this.cdSpecConfig != null)
                {
                    if (this.cdFocusText == "")
                    {
                        this.cdSpecConfig.Foucs = double.NaN;
                    }
                    else
                    {
                        try
                        {
                            this.cdSpecConfig.Foucs = System.Convert.ToDouble(this.cdFocusText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.CDFocusText = "";
                        }
                    }
                }
            }
        }
		
		private string selectedCDFeatureText;
        public string SelectedCDFeatureText
        {
            get { return this.selectedCDFeatureText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedCDFeatureText, value);
                if (this.cdSpecConfig != null)
                {
                    this.cdSpecConfig.CDFeature = this.selectedCDFeatureText;
                }
            }
        }
		
		private string cdSentivityText;
        public string CDSentivityText
        {
            get { return this.cdSentivityText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdSentivityText, value);
                if (this.cdSpecConfig != null)
                {
                    if (this.cdSentivityText == "")
                    {
                        this.cdSpecConfig.Sentivity = double.NaN;
                    }
                    else
                    {
                        try
                        {
                            this.cdSpecConfig.Sentivity = System.Convert.ToDouble(this.cdSentivityText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.CDSentivityText = "";
                        }
                    }
                }
            }
        }
		
		private string cdTargetText;
        public string CDTargetText
        {
            get { return this.cdTargetText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdTargetText, value);
                if (this.cdSpecConfig != null)
                {
                    if (this.cdTargetText == "")
                    {
                        this.cdSpecConfig.Target = double.NaN;
                    }
                    else
                    {
                        try
                        { 
                            this.cdSpecConfig.Target = System.Convert.ToDouble(this.cdTargetText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.CDTargetText = "";
                        }
                    }
                }
            }
        }
		
		private string cdReworkBaisText;
        public string CDReworkBaisText
        {
            get { return this.cdReworkBaisText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdReworkBaisText, value);
                if (this.cdSpecConfig != null)
                {
                    if (this.cdReworkBaisText == "")
                    {
                        this.cdSpecConfig.ReworkBias = double.NaN;
                    }
                    else
                    {
                        try
                        {
                            this.cdSpecConfig.ReworkBias = System.Convert.ToDouble(this.cdReworkBaisText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.CDReworkBaisText = "";
                        }
                    }
                }
            }
        } 
		
		private string cdControlFlagText;
        public string CDControlFlagText
        {
            get { return this.cdControlFlagText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdControlFlagText, value);
                if (this.cdSpecConfig != null)
                {
                    this.cdSpecConfig.CtlFlag = this.cdControlFlagText;
                }
            }
        }

		private List<OVLContextRow> ovlList;
        public List<OVLContextRow> OVLList
        {
            get { return this.ovlList; }
            set { SetProperty(ref this.ovlList, value); }
        }
		
		private OVLContextRow selectedOVLValue;
        public OVLContextRow SelectedOVLValue
        {
            get { return this.selectedOVLValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedOVLValue, value); }
        }
		
		private string selectedOVLModelText;
        public string SelectedOVLModelText
        {
            get { return this.selectedOVLModelText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedOVLModelText, value);
                if (this.OVLSpecConfig != null)
                {
                    this.ovlSpecConfig.OVLMode = this.selectedOVLModelText;
                }
            }
        }


        private string selectedOVLControlModelText;
        public string SelectedOVLControlModelText
        {
            get { return this.selectedOVLControlModelText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedOVLControlModelText, value);
                if (this.OVLSpecConfig != null)
                {
                    this.ovlSpecConfig.ControlModel = this.selectedOVLControlModelText;
                }
            }
        }

        private List<string> ovlModelList;
        public List<string> OVLModelList
        {
            get { return this.ovlModelList; }
            set { SetProperty(ref this.ovlModelList, value); }
        }

        private List<string> _OVLControlModelList;
        public List<string> OVLControlModelList
        {
            get { return this._OVLControlModelList; }
            set { SetProperty(ref this._OVLControlModelList, value); }
        }

        private string ovlMaxMetrologyDayText;
        public string OVLMaxMetrologyDayText
        {
            get { return this.ovlMaxMetrologyDayText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.ovlMaxMetrologyDayText, value);
                if (this.OVLSpecConfig != null)
                {
                    if(this.ovlMaxMetrologyDayText == "")
                    {
                        this.ovlSpecConfig.MaxMetrologyDay = -1;
                    }
                    else
                    {
                        try
                        {
                            this.ovlSpecConfig.MaxMetrologyDay = int.Parse(this.ovlMaxMetrologyDayText);
                        }
                        catch
                        {
                            MessageBox.Show("Pls input a number!");
                            this.OVLMaxMetrologyDayText = "";
                        }
                    }
                }
            }
        }	

		private bool isOVLChuckControl;
        public bool IsOVLChuckControl
        {
            get { return this.isOVLChuckControl; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isOVLChuckControl, value);
                if (this.OVLSpecConfig != null)
                {
                    this.ovlSpecConfig.ChuckControl = this.isOVLChuckControl;
                }
            }
        }	

		private string ovlControlFlagText;
        public string OVLControlFlagText
        {
            get { return this.ovlControlFlagText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.ovlControlFlagText, value);
                if (this.OVLSpecConfig != null)
                {
                    this.ovlSpecConfig.CtlFlag = this.ovlControlFlagText;
                }
            }
        }

        private LayerRuntimeConfig oriRuntime = new LayerRuntimeConfig();
        public LayerRuntimeConfig OriRuntime
        {
            get { return this.oriRuntime; }
            set
            {
                SetProperty(ref this.oriRuntime, value);
            }
        }

        private LayerRuntimeConfig runtime;
        public LayerRuntimeConfig Runtime
        {
            get { return this.runtime; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.runtime, value);
                if(this.runtime != null)
                {
                    this.PreOVLLayerText = this.runtime.PreOvlLayer;
                    this.DedicationLayerText = this.runtime.DedicationLayer;
                    this.RexlaxationText = this.runtime.Relaxation;
                    this.FeedbackStageOVLText = this.runtime.FeedbackStageOvl;
                    this.FeedbackStageCDText = this.runtime.FeedbackStageCd;
                    this.AlignLayerText = this.runtime.AlignLayer;
                    this.IsUseMachineStatus = this.runtime.UseMachineStatus;
                    this.IsNpmFlag = this.runtime.NPWFlag;
                }
            }
        }

        private ContextConfigCd oriCdSpecConfig;
        public ContextConfigCd OriCDSpecConfig
        {
            get { return this.oriCdSpecConfig; }
            set
            {
                SetProperty(ref this.oriCdSpecConfig, value);
            }
        }

        private ContextConfigCd cdSpecConfig;
        public ContextConfigCd CDSpecConfig
        {
            get { return this.cdSpecConfig; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.cdSpecConfig, value);
                if (this.cdSpecConfig != null)
                {
                    this.CDDoseText = (double.IsNaN(this.cdSpecConfig.Dose))?(""):(this.cdSpecConfig.Dose.ToString());
                    this.CDFocusText = (double.IsNaN(this.cdSpecConfig.Foucs))?(""):(this.cdSpecConfig.Foucs.ToString());
                    this.SelectedCDFeatureText = this.cdSpecConfig.CDFeature;
                    this.CDSentivityText = (double.IsNaN(this.cdSpecConfig.Sentivity))?(""):(this.cdSpecConfig.Sentivity.ToString());
                    this.CDTargetText = (double.IsNaN(this.cdSpecConfig.Target))?(""):(this.cdSpecConfig.Target.ToString());
                    this.CDReworkBaisText = (double.IsNaN(this.cdSpecConfig.ReworkBias))?(""):(this.cdSpecConfig.ReworkBias.ToString());
                    this.CDControlFlagText = this.cdSpecConfig.CtlFlag;
                }
            }
        }

        private ContextConfigOvl oriOvlSpecConfig;
        public ContextConfigOvl OriOVLSpecConfig
        {
            get { return this.oriOvlSpecConfig; }
            set
            {
                SetProperty(ref this.oriOvlSpecConfig, value);
            }
        }

        private ContextConfigOvl ovlSpecConfig;
        public ContextConfigOvl OVLSpecConfig
        {
            get { return this.ovlSpecConfig; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.ovlSpecConfig, value);
                if (this.ovlSpecConfig != null)
                {
                    this.SelectedOVLModelText = this.ovlSpecConfig.OVLMode;
                    this.SelectedOVLControlModelText = this.ovlSpecConfig.ControlModel;
                    this.DedicationIndex = int.Parse(this.ovlSpecConfig.DedicationType)-1;
                    this.OVLMaxMetrologyDayText = (double.IsNaN(this.ovlSpecConfig.MaxMetrologyDay))?(""):(this.ovlSpecConfig.MaxMetrologyDay.ToString());
                    this.IsOVLChuckControl = this.ovlSpecConfig.ChuckControl;
                    this.OVLControlFlagText = this.ovlSpecConfig.CtlFlag;
                }
            }
        }
        #endregion

        #region Event
        private DelegateCommand _deleteProductCommand;
        public DelegateCommand DeleteProductCommand =>
            _deleteProductCommand ?? (_deleteProductCommand = new DelegateCommand(OnDeleteProduct));

        private DelegateCommand _addProductCommand;
        public DelegateCommand AddProductCommand =>
            _addProductCommand ?? (_addProductCommand = new DelegateCommand(OnAddProduct));      

		private DelegateCommand _addLayerCommand;
        public DelegateCommand AddLayerCommand =>
            _addLayerCommand ?? (_addLayerCommand = new DelegateCommand(OnAddLayer));  
		
		private DelegateCommand _addContextCommand;
        public DelegateCommand AddContextCommand =>
            _addContextCommand ?? (_addContextCommand = new DelegateCommand(AddContext)); 
			
		private DelegateCommand _cdLimitCommand;
        public DelegateCommand CDLimitCommand =>
            _cdLimitCommand ?? (_cdLimitCommand = new DelegateCommand(OnCDLimit)); 
			
		private DelegateCommand _ovlLimitCommand;
        public DelegateCommand OVLLimitCommand =>
            _ovlLimitCommand ?? (_ovlLimitCommand = new DelegateCommand(OnOVLLimit)); 
			
		private DelegateCommand _fixedValueCommand;
        public DelegateCommand FixedValueCommand =>
            _fixedValueCommand ?? (_fixedValueCommand = new DelegateCommand(OnFixedValue));

        private DelegateCommand _offsetCommand;
        public DelegateCommand OffsetCommand =>
            _offsetCommand ?? (_offsetCommand = new DelegateCommand(OnOffset));

        private DelegateCommand _closeCommand;
        public DelegateCommand CloseCommand =>
            _closeCommand ?? (_closeCommand = new DelegateCommand(OnClose));

        private DelegateCommand _productSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _productSelectionChangedCommand ?? (_productSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        private DelegateCommand _layerSelectionChangedCommand;
        public DelegateCommand LayerSelectionChangedCommand =>
            _layerSelectionChangedCommand ?? (_layerSelectionChangedCommand = new DelegateCommand(OnLayerSelectionChanged));

        private DelegateCommand _ovlSelectionChangedCommandd;
        public DelegateCommand OVLSelectionChangedCommand =>
            _ovlSelectionChangedCommandd ?? (_ovlSelectionChangedCommandd = new DelegateCommand(OnOVLSelectionChanged));

        private DelegateCommand _cdSelectionChangedCommand;
        public DelegateCommand CDSelectionChangedCommand =>
            _cdSelectionChangedCommand ?? (_cdSelectionChangedCommand = new DelegateCommand(OnCDSelectionChanged));

        private DelegateCommand _saveCDValueCommand;
        public DelegateCommand SaveCDValueCommand =>
            _saveCDValueCommand ?? (_saveCDValueCommand = new DelegateCommand(OnSaveCDValue));

        private DelegateCommand _saveOVLValueCommand;
        public DelegateCommand SaveOVLValueCommand =>
            _saveOVLValueCommand ?? (_saveOVLValueCommand = new DelegateCommand(OnSaveOVLValue));

        private DelegateCommand _saveOVLConfigCommand;
        public DelegateCommand SaveOVLConfigCommand =>
            _saveOVLConfigCommand ?? (_saveOVLConfigCommand = new DelegateCommand(OnSaveOVLConfig));

        private DelegateCommand _saveCDConfigCommand;
        public DelegateCommand SaveCDConfigCommand =>
            _saveCDConfigCommand ?? (_saveCDConfigCommand = new DelegateCommand(OnSaveCDConfig));

        private DelegateCommand _saveRunTimed;
        public DelegateCommand SaveRunTime =>
            _saveRunTimed ?? (_saveRunTimed = new DelegateCommand(OnSaveRunTime));
        
        private DelegateCommand _deleteLayerCommand;
        public DelegateCommand DeleteLayerCommand =>
            _deleteLayerCommand ?? (_deleteLayerCommand = new DelegateCommand(OnDeleteLayer));

        private DelegateCommand _deleteCDCommand;
        public DelegateCommand DeleteCDCommand =>
            _deleteCDCommand ?? (_deleteCDCommand = new DelegateCommand(OnDeleteCD));

        private DelegateCommand _historyCDCommand;
        public DelegateCommand HistoryCDCommand =>
            _historyCDCommand ?? (_historyCDCommand = new DelegateCommand(OnHistoryCD));

        private DelegateCommand _deleteOVLCommand;
        public DelegateCommand DeleteOVLCommand =>
            _deleteOVLCommand ?? (_deleteOVLCommand = new DelegateCommand(OnDeleteOVL));

        private DelegateCommand _historyOVLCommand;
        public DelegateCommand HistoryOVLCommand =>
            _historyOVLCommand ?? (_historyOVLCommand = new DelegateCommand(OnHistoryOVL));

        #endregion

        #region local Function
        void OnHistoryCD()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            History parameter = new History();
            HistoryViewModel v = (HistoryViewModel)parameter.DataContext;
            if (this.SelectedCDValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            v.OVLContextContent = null;
            v.CDContextRow = this.SelectedCDValue;
            v.CurrentWindow = window;
            window.Title = "History";
            v.TitleText = "CD Config History";
            window.Content = parameter;
            window.Height = 600;
            window.Width = 900;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }
        void OnHistoryOVL()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();//Windows窗体
            History parameter = new History();
            HistoryViewModel v = (HistoryViewModel)parameter.DataContext;
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            v.CDContextContent = null;
            v.OVLContextRow = this.SelectedOVLValue;
            v.CurrentWindow = window;
            window.Title = "History";
            v.TitleText = "OVL Config History";
            window.Content = parameter;
            window.Height = 600;
            window.Width = 900;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }

        void ClearRuntimeContent()
        {
            this.PreOVLLayerText = "";
            this.DedicationLayerText = "";
            this.FeedbackStageOVLText = "";
            this.FeedbackStageCDText = "";
            this.AlignLayerText = "";
            this.IsUseMachineStatus = false;
            this.IsNpmFlag = false;
        }

        void ClearCDContent()
        {
            this.CDDoseText = "";
            this.CDFocusText = "";
            this.CDSentivityText = "";
            this.CDTargetText = "";
            this.CDReworkBaisText = "";

            this.CDControlFlagText = "";
        }

        void ClearOVLContent()
        {
            this.OVLMaxMetrologyDayText = "";
            this.IsOVLChuckControl = false;
            this.OVLControlFlagText = "";
        }

        void OnDeleteProduct()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null)
            {
                string retMsg = null;
                bool ret = this.ConfigurationUIService.DeleteExistingProduct(ClientInfo.CurrentUser, 
                    ClientInfo.CurrentVersion,
                    this.SelectedProductValue,
                    out retMsg);
                if (!ret)
                {
                    MessageBox.Show(retMsg);
                    return;
                }
                MessageBox.Show("Delete Product is Success");
                this.ProductList = this.ConfigurationUIService.GetProductList(ClientInfo.CurrentUser,
                    ClientInfo.CurrentVersion,
                    out retMsg);
                OnProductSelectionChanged();
            }
        }

        void OnLayerSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null)
            {

                string retMsg = null;

                this.Runtime = this.ConfigurationUIService.GetRuntimeConfig(ClientInfo.CurrentUser,
                    ClientInfo.CurrentVersion,
                    this.SelectedProductValue.ProductId,
                    this.SelectedLayerValue.LayerId,
                    out retMsg);
                this.OriRuntime = CommonHelp.DeepCopy<LayerRuntimeConfig>(this.Runtime);

                this.CDList = this.ConfigurationUIService.GetExistingCDContext(ClientInfo.CurrentUser,
                    ClientInfo.CurrentVersion,
                    this.SelectedProductValue.ProductId,
                    this.SelectedLayerValue.LayerId,
                    out retMsg);

                this.OVLList = this.ConfigurationUIService.GetExistingOVLContext(ClientInfo.CurrentUser,
                    ClientInfo.CurrentVersion,
                    this.SelectedProductValue.ProductId,
                    this.SelectedLayerValue.LayerId,
                    out retMsg);

                ClearCDContent();
                ClearOVLContent();
            }
            else
            {
                this.CDList = null;
                this.OVLList = null;
            }
        }
        void OnAddProduct()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            AddProduct view = new AddProduct();
            AddProductViewModel model = (AddProductViewModel)view.DataContext;
            model.CurrentWindow = window;
            window.Content = view;
            window.Title = "AddProduct";
            window.Height = 300;
            window.Width = 400;
            window.ResizeMode = System.Windows.ResizeMode.NoResize;
            window.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            string retMsg = null;
            this.ProductList = this.ConfigurationUIService.GetProductList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
        }
		
		void OnAddLayer()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            MaintainLayer view = new MaintainLayer();
            MaintainLayerViewModel model = (MaintainLayerViewModel)view.DataContext;
            model.CurrentWindow = window;
            model.ProductId = this.SelectedProductValue.ProductId;
            window.Content = view;
            window.Title = "Maintain Layer";
            window.Height = 300;
            window.Width = 400;
            window.ResizeMode = System.Windows.ResizeMode.NoResize;
            window.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            window.ShowDialog();

            OnProductSelectionChanged();
        }
        void OnDeleteLayer()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null)
            {
                string retMsg = null;
                bool ret = this.ConfigurationUIService.DeleteNewLayer(ClientInfo.CurrentUser, 
                    ClientInfo.CurrentVersion,
                    this.SelectedProductValue.ProductId, 
                    this.SelectedLayerValue,
                    out retMsg);
                if(!ret)
                {
                    MessageBox.Show(retMsg);
                    return;
                }
                MessageBox.Show("Delete Layer is Success");
                OnProductSelectionChanged();
            }
        }
        void OnDeleteCD()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null && this.SelectedCDValue != null)
            {
                string retMsg = null;
                bool ret = this.ConfigurationUIService.DeleteCDContext(ClientInfo.CurrentUser,
                                                                        ClientInfo.CurrentVersion,
                                                                        this.SelectedCDValue.ToolId,
                                                                        this.SelectedProductValue.ProductId, 
                                                                        this.SelectedLayerValue.LayerId,
                                                                        this.SelectedCDValue.ReticleId,
                                                                        this.SelectedCDValue.RecipeId,
                                                                        out retMsg);
                if (!ret)
                {
                    MessageBox.Show(retMsg);
                    return;
                }
                MessageBox.Show("Delete is Success");
                OnLayerSelectionChanged();
            }
        }

        void OnDeleteOVL()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null && this.SelectedOVLValue != null)
            {
                string retMsg = null;
                bool ret = this.ConfigurationUIService.DeleteOVLContext(ClientInfo.CurrentUser,
                                                                        ClientInfo.CurrentVersion,
                                                                        this.SelectedOVLValue.ToolId,
                                                                        this.SelectedProductValue.ProductId,
                                                                        this.SelectedLayerValue.LayerId,
                                                                        this.SelectedOVLValue.ReticleId,
                                                                        this.SelectedOVLValue.RecipeId,
                                                                        this.SelectedOVLValue.PreTool,
                                                                        this.SelectedOVLValue.PreReticle,
                                                                        out retMsg);
                if (!ret)
                {
                    MessageBox.Show(retMsg);
                    return;
                }
                MessageBox.Show("Delete is Success");
                OnLayerSelectionChanged();
            }
        }
        void AddContext()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (((string)this.SelectedTabItem.Header).Contains("CD"))
            {
                var cdWindow = new Window();
                AddCDContext cdView = new AddCDContext();
                AddCDContextViewModel cdModel = (AddCDContextViewModel)cdView.DataContext;
                cdModel.CurrentWindow = cdWindow;
                if(this.SelectedProductValue != null)
                    cdModel.ProductId = this.SelectedProductValue.ProductId;
                if (this.SelectedLayerValue != null)
                    cdModel.LayerId = this.SelectedLayerValue.LayerId;
                cdWindow.Content = cdView;
                cdWindow.Title = "AddCDContext";
                cdWindow.Height = 300;
                cdWindow.Width = 400;
                cdWindow.ResizeMode = System.Windows.ResizeMode.NoResize;
                cdWindow.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
                cdWindow.ShowDialog();
                OnLayerSelectionChanged();
                return;
            }
            var window = new Window();
            AddOVLContext view = new AddOVLContext();
            AddOVLContextViewModel model = (AddOVLContextViewModel)view.DataContext;
            model.CurrentWindow = window;
            if (this.SelectedProductValue != null)
                model.ProductId = this.SelectedProductValue.ProductId;
            if (this.SelectedLayerValue != null)
                model.LayerId = this.SelectedLayerValue.LayerId;
            window.Title = "AddOVLContent";
            window.Content = view;
            window.Height = 300;
            window.Width = 400;
            window.ResizeMode = System.Windows.ResizeMode.NoResize;
            window.WindowStartupLocation = System.Windows.WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            OnLayerSelectionChanged();
        }
		
		void OnCDLimit()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            SpecLimitEditor view = new SpecLimitEditor();
            SpecLimitEditorViewModel model = (SpecLimitEditorViewModel)view.DataContext;
            model.LimitType = "CD";
            if(this.SelectedCDValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }

            string retMsg = null;
            model.MainContent = this.ConfigurationUIService.GetCDSpecLimitMainContent(ClientInfo.CurrentUser,
                                                                                        ClientInfo.CurrentVersion,
                                                                                        this.SelectedCDValue.ToolId,
                                                                                        this.SelectedProductValue.ProductId,
                                                                                        this.SelectedLayerValue.LayerId,
                                                                                        this.SelectedCDValue.ReticleId,
                                                                                        this.SelectedCDValue.RecipeId,
                                                                                        out retMsg);
            model.ReturnText = retMsg;
            model.OriMainContent = CommonHelp.DeepCopy<SpecMainContent>(model.MainContent);
            model.RecipeText = this.SelectedCDValue.RecipeId;
            model.CurrentWindow = window;
            model.ToolText = this.SelectedCDValue.ToolId;
            model.ProductText = this.SelectedProductValue.ProductId;
            model.LayerText = this.SelectedLayerValue.LayerId;
            model.RecipeText = this.SelectedCDValue.RecipeId;
            model.ReticleText = this.SelectedCDValue.ReticleId;
            model.RecipeText = this.SelectedCDValue.RecipeId;
            window.Content = view;
            window.Height = 720;
            window.Width = 980;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();

        }
		
		void OnOVLLimit()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            SpecLimitEditor view = new SpecLimitEditor();
            SpecLimitEditorViewModel model = (SpecLimitEditorViewModel)view.DataContext;
            model.LimitType = "OVL";
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            model.ToolText = this.SelectedOVLValue.ToolId;
            model.ProductText = this.SelectedProductValue.ProductId;
            model.LayerText = this.SelectedLayerValue.LayerId;
            model.ReticleText = this.SelectedOVLValue.ReticleId;

            model.RecipeText = this.SelectedOVLValue.RecipeId;
            model.PreTool = this.SelectedOVLValue.PreTool;
            model.PreReticle = this.SelectedOVLValue.PreReticle;
            model.CurrentWindow = window;

            string retMsg = null;
            model.MainContent = this.ConfigurationUIService.GetOVLSpecLimitMainContent(ClientInfo.CurrentUser,
                                                                                        ClientInfo.CurrentVersion,
                                                                                        this.SelectedOVLValue.ToolId,
                                                                                        this.SelectedProductValue.ProductId,
                                                                                        this.SelectedLayerValue.LayerId,
                                                                                        this.SelectedOVLValue.ReticleId,
                                                                                        this.SelectedOVLValue.RecipeId,
                                                                                        this.SelectedOVLValue.PreTool,
                                                                                        this.SelectedOVLValue.PreReticle,
                                                                                        out retMsg);
            model.ReturnText = retMsg;
            model.OriMainContent = CommonHelp.DeepCopy<SpecMainContent>(model.MainContent);
            window.Content = view;
            window.Height = 720;
            window.Width = 980;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();

        }
		void OnFixedValue()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            OVLFixedValueEditor view = new OVLFixedValueEditor();
            OVLFixedValueEditorViewModel model = (OVLFixedValueEditorViewModel)view.DataContext;
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            model.Recipe = this.SelectedOVLValue.RecipeId;
            model.CurrentWindow = window;
            string retMsg = null;
            model.FixedValueMain = this.ConfigurationUIService.GetFixedValueMainContent(ClientInfo.CurrentUser,
                                                                                        ClientInfo.CurrentVersion,
                                                                                        this.SelectedOVLValue.ToolId,
                                                                                        this.SelectedProductValue.ProductId,
                                                                                        this.SelectedLayerValue.LayerId,
                                                                                        this.SelectedOVLValue.ReticleId,
                                                                                        this.SelectedOVLValue.RecipeId,
                                                                                        this.SelectedOVLValue.PreTool,
                                                                                        this.SelectedOVLValue.PreReticle, 
                                                                                        out retMsg);
            model.ReturnText = retMsg;
            model.OriFixedValueMain = CommonHelp.DeepCopy<FixedValueMainContent>(model.FixedValueMain);
            window.Content = view;
            window.Height = 720;
            window.Width = 980;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }
        
        void OnOffset()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            var window = new Window();
            OVLOffsetEditor view = new OVLOffsetEditor();
            OVLOffsetEditorViewModel model = (OVLOffsetEditorViewModel)view.DataContext;
            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }
            model.Recipe = this.SelectedOVLValue.RecipeId;
            model.PreTool = this.SelectedOVLValue.PreTool;
            model.PreReticle = this.SelectedOVLValue.PreReticle;
            model.Recipe = this.SelectedOVLValue.RecipeId;
            model.CurrentWindow = window;

            string retMsg = null;
            model.MainContent = this.ConfigurationUIService.GetOffsetMainContent(ClientInfo.CurrentUser,
                                                                                        ClientInfo.CurrentVersion,
                                                                                        this.SelectedOVLValue.ToolId,
                                                                                        this.SelectedProductValue.ProductId,
                                                                                        this.SelectedLayerValue.LayerId,
                                                                                        this.SelectedOVLValue.ReticleId,
                                                                                        this.SelectedOVLValue.RecipeId,
                                                                                        this.SelectedOVLValue.PreTool,
                                                                                        this.SelectedOVLValue.PreReticle,
                                                                                        out retMsg);
            model.ReturnText = retMsg;
            model.OriMainContent = CommonHelp.DeepCopy<OffsetMainContent>(model.MainContent);
            window.Content = view;
            window.Height = 720;
            window.Width = 980;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
        }
		void OnClose()
        {

            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();


        }

        void OnProductSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null)
            {

                string retMsg = null;
                this.LayerList = this.ConfigurationUIService.GetLayerList(ClientInfo.CurrentUser, 
                    ClientInfo.CurrentVersion, 
                    this.SelectedProductValue.ProductId,
                    out retMsg);
                this.SelectedLayerValue = null;
                this.SelectedCDValue = null;
                this.SelectedOVLValue = null;
                this.CDList = null;
                this.OVLList = null;
                ClearRuntimeContent();
                ClearCDContent();
                ClearOVLContent();
            }
        }


        void OnOVLSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null)
            { 
                if(this.SelectedOVLValue != null)
                {
                    string retMsg = null;
                    this.OVLSpecConfig = this.ConfigurationUIService.GetOVLContextConfig(ClientInfo.CurrentUser,
                                                                                    ClientInfo.CurrentVersion,
                                                                                    this.SelectedOVLValue.ToolId,
                                                                                    this.SelectedProductValue.ProductId,
                                                                                    this.SelectedLayerValue.LayerId,
                                                                                    this.SelectedOVLValue.ReticleId,
                                                                                    this.SelectedOVLValue.RecipeId,
                                                                                    this.SelectedOVLValue.PreTool,
                                                                                    this.SelectedOVLValue.PreReticle,
                                                                                    out retMsg);
                    this.OriOVLSpecConfig = CommonHelp.DeepCopy<ContextConfigOvl>(this.OVLSpecConfig);
                }
            }
        }

        void OnCDSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedProductValue != null && this.SelectedLayerValue != null)
            { 
                if (this.SelectedCDValue != null)
                {
                    string retMsg = null;
                    this.CDSpecConfig = this.ConfigurationUIService.GetCDContextConfig(ClientInfo.CurrentUser,
                                                                                ClientInfo.CurrentVersion,
                                                                                this.SelectedCDValue.ToolId,
                                                                                this.SelectedCDValue.ProductId,
                                                                                this.SelectedCDValue.LayerId,
                                                                                this.SelectedCDValue.ReticleId,
                                                                                this.SelectedCDValue.RecipeId,
                                                                                out retMsg);
                    this.OriCDSpecConfig = CommonHelp.DeepCopy<ContextConfigCd>(this.CDSpecConfig);
                }
            }
        }
        void OnSaveCDValue()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.CDSpecConfig == null)
            {
                MessageBox.Show("Please select a CD data row.");
                return;
            }
            string retMsg = null;
            ContextConfigCd returnRst = null;
            bool ret = this.ConfigurationUIService.saveCDContextValue(ClientInfo.CurrentUser,
                                                                               ClientInfo.CurrentVersion,
                                                                               this.SelectedCDValue.ToolId,
                                                                               this.SelectedProductValue.ProductId,
                                                                               this.SelectedLayerValue.LayerId,
                                                                               this.SelectedCDValue.ReticleId,
                                                                               this.SelectedCDValue.RecipeId,
                                                                               this.CDSpecConfig,
                                                                               this.OriCDSpecConfig,
                                                                               out returnRst,
                                                                               out retMsg);
            if (!ret)
            {
                MessageBox.Show("sava is fail!");
                return;
            }
            if ( null != returnRst)
            {
                this.OriCDSpecConfig = returnRst;
            }
            MessageBox.Show("sava is success!");
        }
        void OnSaveOVLConfig()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.OVLSpecConfig == null)
            {
                MessageBox.Show("Please select a OVL data row.");
                return;
            }
            string retMsg = null;
            ContextConfigOvl returnRst = null;
            bool ret = this.ConfigurationUIService.saveOVLContextConfig(ClientInfo.CurrentUser,
                                                                               ClientInfo.CurrentVersion,
                                                                               this.SelectedOVLValue.ToolId,
                                                                               this.SelectedProductValue.ProductId,
                                                                               this.SelectedLayerValue.LayerId,
                                                                               this.SelectedOVLValue.ReticleId,
                                                                               this.SelectedOVLValue.RecipeId,
                                                                               this.SelectedOVLValue.PreTool,
                                                                               this.SelectedOVLValue.PreReticle,
                                                                               this.OVLSpecConfig,
                                                                               this.OriOVLSpecConfig,
                                                                               out returnRst,
                                                                               out retMsg);
            if (!ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            if (null != returnRst)
                this.OriOVLSpecConfig = returnRst;
            MessageBox.Show("sava is success!");
        }
        void OnSaveCDConfig()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.CDSpecConfig == null)
            {
                MessageBox.Show("Please select a CD data row.");
                return;
            }
            string retMsg = null;
            ContextConfigCd returnRst = null;
            bool ret = this.ConfigurationUIService.saveCDContextConfig(ClientInfo.CurrentUser,
                                                                               ClientInfo.CurrentVersion,
                                                                               this.SelectedCDValue.ToolId,
                                                                               this.SelectedProductValue.ProductId,
                                                                               this.SelectedLayerValue.LayerId,
                                                                               this.SelectedCDValue.ReticleId,
                                                                               this.SelectedCDValue.RecipeId,
                                                                               this.CDSpecConfig,
                                                                               this.OriCDSpecConfig,
                                                                               out returnRst,
                                                                               out retMsg);
            if (!ret)
            {
                MessageBox.Show("sava is fail!");
                return;
            }
            if(null != returnRst)
            { 
                this.OriCDSpecConfig = returnRst;
            }
            MessageBox.Show("sava is success!");
        }
        void OnSaveOVLValue()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.SelectedOVLValue == null)
            {
                MessageBox.Show("Please select a OVL data row.");
                return;
            }
            string retMsg = null;
            ContextConfigOvl returnRst = null;
            bool ret = this.ConfigurationUIService.saveOVLContextValue(ClientInfo.CurrentUser,
                                                                              ClientInfo.CurrentVersion,
                                                                              this.SelectedOVLValue.ToolId,
                                                                              this.SelectedProductValue.ProductId,
                                                                              this.SelectedLayerValue.LayerId,
                                                                              this.SelectedOVLValue.ReticleId,
                                                                              this.SelectedOVLValue.RecipeId,
                                                                              this.SelectedOVLValue.PreTool,
                                                                              this.SelectedOVLValue.PreReticle,
                                                                              this.OVLSpecConfig,
                                                                              this.OriOVLSpecConfig,
                                                                              out returnRst,
                                                                              out retMsg);
            if (!ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            if (null != returnRst)
            {
                this.OriOVLSpecConfig = returnRst;
            }
            MessageBox.Show("sava is success!");
        }
        
        void OnSaveRunTime()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (null == this.SelectedLayerValue)
            {
                MessageBox.Show("Save fail, Selected Layer is null!");
                return;
            }
            string retMsg = null;
            LayerRuntimeConfig returnRst = null;
            bool ret = this.ConfigurationUIService.saveRuntimeConfig(ClientInfo.CurrentUser,
                                                                               ClientInfo.CurrentVersion,
                                                                               this.SelectedProductValue.ProductId,
                                                                               this.SelectedLayerValue.LayerId,
                                                                               this.Runtime,
                                                                               this.OriRuntime,
                                                                               out returnRst,
                                                                               out retMsg);
            if (!ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            if (null != returnRst)
            {
                this.OriRuntime = returnRst;
            }
            MessageBox.Show("sava is success!");
        }

        
        #endregion

    }
}