﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService;
using R2R.Common.Data.Litho;
using R2R.Common.Data;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ParameterConfigOVLViewModel : ViewModelBase
    {

        public IParameterConfigOVLService ParameterConfigOVLService { get; set; }

        public ParameterConfigOVLViewModel(IParameterConfigOVLService parameterConfigOVLService)
        {
            this.ParameterConfigOVLService = parameterConfigOVLService;
        }

        #region Field
        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set
            {
                SetProperty(ref this.toolText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.ToolId = this.toolText;
                }
            }
        }

        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set
            {
                SetProperty(ref this.productText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.ProductId = this.productText;
                }
            }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set
            {
                SetProperty(ref this.layerText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.LayerId = this.layerText;
                }
            }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set
            {
                SetProperty(ref this.reticleText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.ReticleId = this.reticleText;
                }
            }
        }

        private string recipeText;
        public string RecipeText
        {
            get { return this.recipeText; }
            set
            {
                SetProperty(ref this.recipeText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.RecipeId = this.recipeText;
                }
            }
        }

        private string preToolText;
        public string PreToolText
        {
            get { return this.preToolText; }
            set
            {
                SetProperty(ref this.preToolText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.PreTool = this.preToolText;
                }
            }
        }

        private string preReticleText;
        public string PreReticleText
        {
            get { return this.preReticleText; }
            set
            {
                SetProperty(ref this.preReticleText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.PreReticle = this.preReticleText;
                }
            }
        }

        private string pilotText;
        public string PilotText
        {
            get { return this.pilotText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.pilotText, value);
                if (this.contextContent != null)
                {
                    this.contextContent.Pilot = this.pilotText;
                }
            }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set
            {
                SetProperty(ref this.currentWindow, value);
            }
        }

        private string dedicationTypeText;
        public string DedicationTypeText
        {
            get { return this.dedicationTypeText; }
            set
            {
                SetProperty(ref this.dedicationTypeText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.DedicationType = this.dedicationTypeText;
                }
            }
        }

        private string oVLModelText;
        public string OVLModelText
        {
            get { return this.oVLModelText; }
            set
            {
                SetProperty(ref this.oVLModelText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.OVLMode = this.oVLModelText;
                }
            }
        }

        private float lambdaText;
        public float LambdaText
        {
            get { return this.lambdaText; }
            set
            {
                SetProperty(ref this.lambdaText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.Lambda = this.lambdaText;
                }
            }
        }

        private float lambdaPiRunText;
        public float LambdaPiRunText
        {
            get { return this.lambdaPiRunText; }
            set
            {
                SetProperty(ref this.lambdaPiRunText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.LambdaPiRun = this.lambdaPiRunText;
                }
            }
        }

        private int metrologyDaysText;
        public int MetrologyDaysText
        {
            get { return this.metrologyDaysText; }
            set
            {
                SetProperty(ref this.metrologyDaysText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.MetrologyDays = this.metrologyDaysText;
                }
            }
        }

        private string feedbackStageText;
        public string FeedbackStageText
        {
            get { return this.feedbackStageText; }
            set
            {
                SetProperty(ref this.feedbackStageText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.FeedbackStage = this.feedbackStageText;
                }

            }
        }

        private string preLayerText;
        public string PreLayerText
        {
            get { return this.preLayerText; }
            set
            {
                SetProperty(ref this.preLayerText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.PreLayer = this.preLayerText;
                }

            }
        }

        private string preAlignLayerText;
        public string PreAlignLayerText
        {
            get { return this.preAlignLayerText; }
            set
            {
                SetProperty(ref this.preAlignLayerText, value);
                if (this.contextContent != null && this.contextContent.specConfig != null)
                {
                    this.contextContent.specConfig.PreAlignLayer = this.preAlignLayerText;
                }

            }
        }
        private Boolean isPirunOn;
        public Boolean IsPirunOn
        {
            get { return this.isPirunOn; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isPirunOn, value);
                if (this.isPirunOn && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "PIRUNON";
                }
            }
        }

        private Boolean isPirunOff;
        public Boolean IsPirunOff
        {
            get { return this.isPirunOff; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isPirunOff, value);
                if (this.isPirunOff && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "PIRUNOFF";
                }
            }
        }

        private Boolean isOff;
        public Boolean IsOff
        {
            get { return this.isOff; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isOff, value);
                if (this.isOff && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "OFF";
                }
            }
        }

        private Boolean isFixed;
        public Boolean IsFixed
        {
            get { return this.isFixed; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isFixed, value);
                if (this.isFixed && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "FIXED";
                }
            }
        }
        private bool isC2CFlag;
        public bool IsC2CFlag
        {
            get { return this.isC2CFlag; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isC2CFlag, value);
            }
        }
        private Boolean isOn;
        public Boolean IsOn
        {
            get { return this.isOn; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isOn, value);
                if (this.isOn && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "ON";
                }
            }
        }
        private string commentText;
        public string CommentText
        {
            get { return this.commentText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.commentText, value);
                if (this.contextContent != null && this.contextContent.comment != null)
                {
                    this.contextContent.comment.LastCommnet = this.commentText;
                }

            }
        }

        private ParameterRow selectedValue;
        public ParameterRow SelectedValue
        {
            get { return this.selectedValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                this.selectedValue = value; }
        }

        private ObservableCollection<ParameterRow> _DataList;
        public ObservableCollection<ParameterRow> DataList
        {
            get { return _DataList; }
            set
            {
                SetProperty(ref this._DataList, value);
                if (this.contextContent != null)
                {
                    this.contextContent.parametersRows = this._DataList.ToList();
                }

            }
        }

        private OVLContextContent oriContextContent = new OVLContextContent();
        public OVLContextContent OriContextContent
        {
            get
            {
                return this.oriContextContent;
            }
            set
            {
                SetProperty(ref this.oriContextContent, value);
            }
        }
        private OVLContextContent contextContent;
        public OVLContextContent ContextContent
        {
            get
            {
                return this.contextContent;
            }
            set
            {
                this.contextContent = value;
                if (this.contextContent != null)
                {
                    this.ToolText = this.contextContent.ToolId;
                    this.ProductText = this.contextContent.ProductId;
                    this.LayerText = this.contextContent.LayerId;
                    this.ReticleText = this.contextContent.ReticleId;
                    this.RecipeText = this.contextContent.RecipeId;
                    this.PreToolText = this.contextContent.PreTool;
                    this.PreReticleText = this.contextContent.PreReticle;
                    this.PilotText = this.contextContent.Pilot;
                    this.IsC2CFlag = this.contextContent.specConfig.C2C;
                    if (!string.IsNullOrEmpty(this.contextContent.CtlFlag))
                    {
                        if (this.contextContent.CtlFlag.Equals("PIRUNON"))
                        {
                            this.IsOff = false;
                            this.IsOn = false;
                            this.IsPirunOff = false;
                            this.IsFixed = false;
                            this.IsPirunOn = true;
                        }
                        else if (this.contextContent.CtlFlag.Equals("FIXED"))
                        {
                            this.IsOff = false;
                            this.IsOn = false;
                            this.IsPirunOff = false;
                            this.IsPirunOn = false;
                            this.IsFixed = true;
                        }
                        else if (this.contextContent.CtlFlag.Equals("PIRUNOFF"))
                        {
                            this.IsOff = false;
                            this.IsOn = false;
                            this.IsFixed = false;
                            this.IsPirunOn = false;
                            this.IsPirunOff = true;
                        }
                        else if (this.contextContent.CtlFlag.Equals("ON"))
                        {
                            this.IsOff = false;
                            this.IsPirunOff = false;
                            this.IsFixed = false;
                            this.IsPirunOn = false;
                            this.IsOn = true;
                        }
                        else if (this.contextContent.CtlFlag.Equals("OFF"))
                        {
                            this.IsOn = false;
                            this.IsPirunOff = false;
                            this.IsFixed = false;
                            this.IsPirunOn = false;
                            this.IsOff = true;
                        }
                    }

                    this.DedicationTypeText = this.contextContent.specConfig.DedicationType;
                    this.OVLModelText = this.contextContent.specConfig.OVLMode;
                    this.LambdaText = this.contextContent.specConfig.Lambda;
                    this.LambdaPiRunText = this.contextContent.specConfig.LambdaPiRun;
                    this.MetrologyDaysText = this.contextContent.specConfig.MetrologyDays;
                    this.FeedbackStageText = this.contextContent.specConfig.FeedbackStage;
                    this.PreLayerText = this.contextContent.specConfig.PreLayer;
                    this.PreAlignLayerText = this.contextContent.specConfig.PreAlignLayer;

                    this.CommentText = this.contextContent.comment.LastCommnet;
                    this.DataList = new ObservableCollection<ParameterRow>(this.contextContent.parametersRows);
                    
                }
            }
        }
        #endregion

        #region Event
        private DelegateCommand _saveChange;
        public DelegateCommand SaveChange =>
            _saveChange ?? (_saveChange = new DelegateCommand(OnSaveChange));

        private DelegateCommand _cellEditEndingCommand;
        public DelegateCommand CellEditEndingCommand =>
            _cellEditEndingCommand ?? (_cellEditEndingCommand = new DelegateCommand(OnCellEditEnding));

        #endregion

        #region Local Function

        private void OnSaveChange()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (string.IsNullOrEmpty(this.CommentText))
            {
                MessageBox.Show("Pls input Comment!");
                return;
            }
            contextContent.CtlFlag = GetFlag();

            if (CheckValue())
            {
                string retMsg = null;
                OVLContextContent returnRst = null;
                bool ret = this.ParameterConfigOVLService.SaveOVLParameters(ClientInfo.CurrentUser,
                                                                ClientInfo.CurrentVersion,
                                                                "",
                                                                contextContent,
                                                                OriContextContent,
                                                                out returnRst,
                                                                out retMsg);
                if (null != returnRst)
                    this.OriContextContent = returnRst;
                if (ret)
                {
                    this.CurrentWindow.Close();
                }
            }
        }

        private bool CheckValue()
        {
            try
            {
                foreach (ParameterRow para in this.DataList)
                {
                    double uCalc = Convert.ToDouble(para.uCalc);
                    double reworkBias = Convert.ToDouble(para.ReworkBias);
                    double lower = Convert.ToDouble(para.Lower);
                    double upper = Convert.ToDouble(para.Upper);
                    if (uCalc > upper || uCalc < lower)
                    {
                        MessageBox.Show("UCalc must be larger than Lower and be less than Upper!");
                        return false;
                    }
                }
                return true;
            }
            catch (Exception excep)
            {
                MessageBox.Show("Pls input a number!");
                return false;
            }
        }

        private void OnCellEditEnding()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            try
            { 
                double uCalc = Convert.ToDouble(this.SelectedValue.uCalc);
                double lower = Convert.ToDouble(this.SelectedValue.Lower);
                double upper = Convert.ToDouble(this.SelectedValue.Upper);
                if (uCalc > upper || uCalc < lower)
                {
                    MessageBox.Show("UCalc must be larger than Lower and be less than Upper!");
                }
            }
            catch (Exception excep)
            {
                MessageBox.Show("Pls input a number!");
            }
        }

        private void SetFlag(string flag)
        {
            switch (flag)
            {
                case "PIRUNON":
                    this.IsPirunOn = true;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
                case "FIXED":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = true;
                    this.IsOn = false;
                    break;
                case "PIRUNOFF":
                    this.IsPirunOn = false;
                    this.IsPirunOff = true;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
                case "ON":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = true;
                    break;
                case "OFF":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = true;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
            }

        }

        private string GetFlag()
        {
            if (this.IsPirunOn)
                return "PIRUNON";
            if (this.IsFixed)
                return "FIXED";
            if (this.IsPirunOff)
                return "PIRUNOFF";
            if (this.IsOn)
                return "ON";
            if (this.IsOff)
                return "OFF";
            return null;
        }
        #endregion

    }
}
