﻿using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.LithoModeService;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ParameterConfigCDViewModel : ViewModelBase
    {

        public IParameterConfigCDService ParameterConfigCDService { get; set; }

        public ParameterConfigCDViewModel(IParameterConfigCDService parameterConfigCDService)
        {
            this.ParameterConfigCDService = parameterConfigCDService;
        }

        #region Event
        private DelegateCommand _saveChange;
        public DelegateCommand SaveChange =>
            _saveChange ?? (_saveChange = new DelegateCommand(OnSaveChange));
        #endregion

        #region Field
        private string toolText;
        public string ToolText
        {
            get
            {
                return this.toolText;
            }
            set
            {
                SetProperty(ref this.toolText, value);
                if(this.ContextContent != null)
                {
                    this.ContextContent.ToolId = this.toolText;
                }
            }
        }

        private string productText;
        public string ProductText
        {
            get
            {
                return this.productText;
            }
            set
            {
                SetProperty(ref this.productText, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.ProductId = this.productText;
                }
            }
        }

        private string layerText;
        public string LayerText
        {
            get
            {
                return this.layerText;          
            }
            set
            {
                SetProperty(ref this.layerText, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.LayerId = this.layerText;
                }
            }
        }

        private string reticleText;
        public string ReticleText
        {
            get
            {
                return this.reticleText;
            }
            set
            {
                SetProperty(ref this.reticleText, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.ReticleId = this.reticleText;
                }
            }
        }

        

        private string recipeText;
        public string RecipeText
        {
            get
            {
                return this.recipeText;
            }
            set
            {
                SetProperty(ref this.recipeText, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.RecipeId = this.recipeText;
                }
            }
        }

        private string pilotText;
        public string PilotText
        {
            get
            {
                return this.pilotText;
            }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.pilotText, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.Pilot = this.pilotText;
                }
            }
        }

        private float sensitivityText;
        public float SensitivityText
        {
            get
            {
                return this.sensitivityText;
            }
            set
            {
                SetProperty(ref this.sensitivityText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.Sensitivity = this.sensitivityText;
                }
            }
        }

        private string cDTargetText;
        public string CDTargetText
        {
            get
            {
                return this.cDTargetText;
            }
            set
            {
                SetProperty(ref this.cDTargetText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.CDTarget = this.cDTargetText;
                }
            }
        }

        private string feedbackPointText;
        public string FeedbackPointText
        {
            get
            {
                return this.feedbackPointText;
            }
            set
            {
                SetProperty(ref this.feedbackPointText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.FeedbackPoint = this.feedbackPointText;
                }
            }
        }

        private float lambdaText;
        public float LambdaText
        {
            get
            {
                return this.lambdaText;
            }
            set
            {
                SetProperty(ref this.lambdaText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.Lambda = this.lambdaText;
                }
            }
        }

        private float lambdaPiRunText;
        public float LambdaPiRunText
        {
            get
            {
                return this.lambdaPiRunText;
            }
            set
            {
                SetProperty(ref this.lambdaPiRunText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.LambdaPiRun = this.lambdaPiRunText;
                }
            }
        }

        private int minPointsFoeAvText;
        public int MinPointsFoeAvText
        {
            get
            {
                return this.minPointsFoeAvText;
            }
            set
            {
                SetProperty(ref this.minPointsFoeAvText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.MinPointFieAvg = this.minPointsFoeAvText;
                }
            }
        }

        private string feedbackStageText;
        public string FeedbackStageText
        {
            get
            {
                return this.feedbackStageText;
            }
            set
            {
                SetProperty(ref this.feedbackStageText, value);
                if (this.ContextContent != null && this.ContextContent.specConfig != null)
                {
                    this.ContextContent.specConfig.FeebbackStage = this.feedbackStageText;
                }
            }
        }

        private Boolean isPirunOn;
        public Boolean IsPirunOn
        {
            get { return this.isPirunOn; }
            set
            {

                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isPirunOn, value);
                if (this.isPirunOn && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "PIRUNON";
                }
            }
        }

        private Boolean isPirunOff;
        public Boolean IsPirunOff
        {
            get { return this.isPirunOff; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isPirunOff, value);
                if (this.isPirunOff && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "PIRUNOFF";
                }
            }
        }

        private Boolean isOff;
        public Boolean IsOff
        {
            get { return this.isOff; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isOff, value);
                if (this.isOff && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "OFF";
                }
            }
        }

        private Boolean isFixed;
        public Boolean IsFixed
        {
            get { return this.isFixed; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isFixed, value);
                if (this.isFixed && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "FIXED";
                }
            }
        }

        private Boolean isOn;
        public Boolean IsOn
        {
            get { return this.isOn; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.isOn, value);
                if (this.isOn && this.ContextContent != null)
                {
                    this.ContextContent.CtlFlag = "ON";
                }
            }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set
            {
                SetProperty(ref this.currentWindow, value);
            }
        }

        private ObservableCollection<ParameterRow> dataList;
        public ObservableCollection<ParameterRow> DataList
        {
            get
            {
                return this.dataList;
            }
            set
            {
                SetProperty(ref this.dataList, value);
                if (this.ContextContent != null)
                {
                    this.ContextContent.parametersRows = this.dataList.ToList();
                }
            }
        }

        private string commentText;
        public string CommentText
        {
            get { return this.commentText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.commentText, value);
                if (this.ContextContent != null && this.ContextContent.comment != null)
                {
                    this.ContextContent.comment.LastCommnet = this.commentText;
                }
            }
        }

        private ParameterRow selectedValue;
        public ParameterRow SelectedValue
        {
            get { return this.selectedValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedValue, value);
            }
        }
        private CDContextContent oriContextContent;
        public CDContextContent OriContextContent
        {

            get
            {
                return this.oriContextContent;
            }
            set
            {
                SetProperty(ref this.oriContextContent, value);
            }
        }

        private CDContextContent contextContent;
        public CDContextContent ContextContent
        {
            get
            {
                return this.contextContent;
            }
            set
            {
                this.contextContent = value;
                if(this.contextContent != null)
                {
                    this.ToolText = this.contextContent.ToolId;
                    this.ProductText = this.contextContent.ProductId;
                    this.LayerText = this.contextContent.LayerId;
                    this.ReticleText = this.contextContent.ReticleId;
                    this.RecipeText = this.contextContent.RecipeId;
                    this.PilotText = this.contextContent.Pilot;
                    this.SensitivityText = this.contextContent.specConfig.Sensitivity;
                    this.CDTargetText = this.contextContent.specConfig.CDTarget;
                    this.FeedbackPointText = this.contextContent.specConfig.FeedbackPoint;
                    this.LambdaText = this.contextContent.specConfig.Lambda;
                    this.LambdaPiRunText = this.contextContent.specConfig.LambdaPiRun;
                    this.MinPointsFoeAvText = this.contextContent.specConfig.MinPointFieAvg;
                    this.FeedbackStageText = this.contextContent.specConfig.FeebbackStage;
                    this.DataList = new ObservableCollection<ParameterRow>(this.contextContent.parametersRows);
                    if (this.contextContent.comment != null)
                    {
                        this.CommentText = this.contextContent.comment.LastCommnet;
                    }
                    SetFlag(this.contextContent.CtlFlag);
                }
            }
        }
        #endregion

        private void OnSaveChange()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (string.IsNullOrEmpty(this.CommentText))
            {
                MessageBox.Show("Pls input Comment!");
                return;
            }
            contextContent.CtlFlag = GetFlag();
            if(CheckValue())
            { 
                string retMsg = null;
                CDContextContent returnRst = null;
                bool ret = this.ParameterConfigCDService.SaveCDParameters(ClientInfo.CurrentUser,
                                                                ClientInfo.CurrentVersion,
                                                                "",
                                                                contextContent,
                                                                oriContextContent,
                                                                out returnRst,
                                                                out retMsg);
                if(null != this.OriContextContent)
                    this.OriContextContent = returnRst;
                if (ret)
                {
                    this.CurrentWindow.Close();
                }
            }

        }
        private bool CheckValue()
        {
            try
            {
                foreach (ParameterRow para in this.DataList)
                {
                    double uCalc = Convert.ToDouble(para.uCalc);
                    double reworkBias = Convert.ToDouble(para.ReworkBias);
                    double lower = Convert.ToDouble(para.Lower);
                    double upper = Convert.ToDouble(para.Upper);
                    if (uCalc > upper || uCalc < lower)
                    {
                        MessageBox.Show("UCalc must be larger than Lower and be less than Upper!");
                        return false;
                    }
                }
                return true;
            }
            catch (Exception excep)
            {
                MessageBox.Show("Pls input a number!");
                return false;
            }
        }


        private void SetFlag(string flag)
        {
            switch (flag)
            {
                case "PIRUNON":
                    this.IsPirunOn = true;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
                case "FIXED":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = true;
                    this.IsOn = false;
                    break;
                case "PIRUNOFF":
                    this.IsPirunOn = false;
                    this.IsPirunOff = true;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
                case "ON":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = false;
                    this.IsFixed = false;
                    this.IsOn = true;
                    break;
                case "OFF":
                    this.IsPirunOn = false;
                    this.IsPirunOff = false;
                    this.IsOff = true;
                    this.IsFixed = false;
                    this.IsOn = false;
                    break;
            }

        }

        private string GetFlag()
        {
            if (this.IsPirunOn)
                return "PIRUNON";
            if (this.IsFixed)
                return "FIXED";
            if (this.IsPirunOff)
                return "PIRUNOFF";
            if (this.IsOn)
                return "ON";
            if (this.IsOff)
                return "OFF";
            return null;
        }
    }
}
