﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Service.ConfigUIService;
using System.Windows;
using R2R.Common.Data;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class MaintainLayerViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;
        public MaintainLayerViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
            
        }

        #region Field
        private LayerEntity layerEntity = new LayerEntity();
        public LayerEntity LayerEntity
        {
            get { return this.layerEntity; }
            set { SetProperty(ref this.layerEntity, value); }
        }

        private string productId;
        public string ProductId
        {
            get { return this.productId; }
            set { SetProperty(ref this.productId, value); }
        }

        private string layerIDText;
        public string LayerIDText
        {
            get { return this.layerIDText; }
            set
            {
                SetProperty(ref this.layerIDText, value);
                if (this.LayerEntity != null)
                {
                    this.LayerEntity.LayerId = this.layerIDText;
                }
            }
        }

        private string layerNameText;
        public string LayerNameText
        {
            get { return this.layerNameText; }
            set
            {
                SetProperty(ref this.layerNameText, value);
                if (this.LayerEntity != null)
                {
                    this.LayerEntity.LayerName = this.layerNameText;
                }
            }
        }

        private string stepNameText;
        public string StepNameText
        {
            get { return this.stepNameText; }
            set
            {
                SetProperty(ref this.stepNameText, value);
                if (this.LayerEntity != null)
                {
                    this.LayerEntity.StepName = this.stepNameText;
                }
            }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _SaveCommand;
        public DelegateCommand SaveCommand =>
            _SaveCommand ?? (_SaveCommand = new DelegateCommand(OnSave));

        private DelegateCommand _CloseCommand;
        public DelegateCommand CloseCommand =>
            _CloseCommand ?? (_CloseCommand = new DelegateCommand(OnClose));
        #endregion
        #region local Function
        void OnSave()
        {
            string retMsg = null;
            bool ret = this.ConfigurationUIService.AddNewLayer(ClientInfo.CurrentUser, 
                ClientInfo.CurrentVersion, 
                this.ProductId, 
                this.LayerEntity,
                out retMsg);
            if (!ret)
            {
                MessageBox.Show(retMsg);
                return;
            }
            MessageBox.Show("sava is success!");
            OnClose();
        }
        void OnClose()
        {
            this.CurrentWindow.Close();
        }

        #endregion
    }
}