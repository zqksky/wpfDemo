﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Common.Data.Litho;
using R2R.Service.ConfigUIService;
using R2R.Common.Data;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class OVLFixedValueEditorViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;
        public OVLFixedValueEditorViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
        }


        #region Field
        private string returnText;
        public string ReturnText
        {
            get { return this.returnText; }
            set { SetProperty(ref this.returnText, value); }
        }
        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set { SetProperty(ref this.toolText, value); }
        }

        private FixedValueMainContent oriFixedValueMain;
        public FixedValueMainContent OriFixedValueMain
        {
            get { return this.oriFixedValueMain; }
            set
            {
                SetProperty(ref this.oriFixedValueMain, value);
            }
        }

        private FixedValueMainContent fixedValueMain;
        public FixedValueMainContent FixedValueMain
        {
            get { return this.fixedValueMain; }
            set
            {
                SetProperty(ref this.fixedValueMain, value);
                if (this.fixedValueMain != null)
                {
                    this.ToolText = this.fixedValueMain.ToolId;
                    this.ProductText = this.fixedValueMain.ProductId;
                    this.LayerText = this.fixedValueMain.LayerId;
                    this.ReticleText = this.fixedValueMain.ReticleId;
                    this.PreToolText = this.fixedValueMain.PreTool;
                    this.PreReticleText = this.fixedValueMain.PreReticle;
                    this.OVLFixedList = this.fixedValueMain.FixedValues;
                }

            }
        }
        

        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set { SetProperty(ref this.productText, value); }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set { SetProperty(ref this.layerText, value); }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set { SetProperty(ref this.reticleText, value); }
        }

        private string preToolText;
        public string PreToolText
        {
            get { return this.preToolText; }
            set { SetProperty(ref this.preToolText, value); }
        }

        private string preReticleText;
        public string PreReticleText
        {
            get { return this.preReticleText; }
            set { SetProperty(ref this.preReticleText, value); }
        }

        private List<ParameterRow> ovlFixedList;
        public List<ParameterRow> OVLFixedList
        {
            get { return this.ovlFixedList; }
            set
            {
                SetProperty(ref this.ovlFixedList, value);
                if(this.fixedValueMain != null)
                {
                    this.fixedValueMain.FixedValues = this.ovlFixedList;
                }
            }
        }

        private ParameterRow selectedFixedValue;
        public ParameterRow SelectedFixedValue
        {
            get { return this.selectedFixedValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedFixedValue, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }

        private string recipe;
        public string Recipe
        {
            get { return this.recipe; }
            set { SetProperty(ref this.recipe, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand =>
            _saveCommand ?? (_saveCommand = new DelegateCommand(OnSave));
        #endregion

        #region local Function
        void OnSave()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            if (!CheckFixedValueInRange())
            {
                MessageBox.Show("Pls Check the Values!");
                return;
            }
            string retMsg = null;
            FixedValueMainContent returnRst = null;
            bool ret = this.ConfigurationUIService.saveFixedValueMainContent(ClientInfo.CurrentUser,
                                                                         ClientInfo.CurrentVersion,
                                                                         this.Recipe,
                                                                         this.FixedValueMain,
                                                                         this.OriFixedValueMain,
                                                                         out returnRst,
                                                                         out retMsg);
            if (!ret)
            {
                this.ReturnText = retMsg;
                return;
            }
            if (null != returnRst)
            {
                this.OriFixedValueMain = returnRst;
            }
            MessageBox.Show("sava is success!");
            this.currentWindow.Close();
        }

        bool CheckFixedValueInRange()
        {
            bool rst = true;
            foreach (ParameterRow para in this.FixedValueMain.FixedValues)
            {
                if (!string.IsNullOrEmpty(para.ParameterVaue))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.ParameterVaue);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                        bool tempRst = (offset >= lower && offset <= upper);
                        rst = rst && tempRst;
                        if (!rst)
                            return rst;
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                if (!string.IsNullOrEmpty(para.ParameterVaue1))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.ParameterVaue1);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                        bool tempRst = (offset >= lower && offset <= upper);
                        rst = rst && tempRst;
                        if (!rst)
                            return rst;
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                if (!string.IsNullOrEmpty(para.ParameterVaue2))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.ParameterVaue2);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                        bool tempRst = (offset >= lower && offset <= upper);
                        rst = rst && tempRst;
                        if (!rst)
                            return rst;
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            return rst;
        }
        #endregion
    }
}