﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using Prism.Commands;
using R2R.Service.LithoModeService.VO;
using R2R.Common.Data.Litho;
using R2R.Service.ConfigUIService;
using R2R.Common.Data;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class OVLOffsetEditorViewModel : ViewModelBase
    {
        public IConfigurationUIService ConfigurationUIService;

        public OVLOffsetEditorViewModel(IConfigurationUIService configurationUIService)
        {
            this.ConfigurationUIService = configurationUIService;
        }

        #region Field
        private string returnText;
        public string ReturnText
        {
            get { return this.returnText; }
            set { SetProperty(ref this.returnText, value); }
        }
        private OffsetMainContent oriMainContent;
        public OffsetMainContent OriMainContent
        {
            get { return this.oriMainContent; }
            set
            {
                SetProperty(ref this.oriMainContent, value);
            }
        }

        private OffsetMainContent mainContent;
        public OffsetMainContent MainContent
        {
            get { return this.mainContent; }
            set
            {
                SetProperty(ref this.mainContent, value);
                if(this.mainContent != null)
                {
                    this.ToolText = this.mainContent.ToolId;
                    this.ProductText = this.mainContent.ProductId;
                    this.LayerText = this.mainContent.LayerId;
                    this.ReticleText = this.mainContent.ReticleId;
                    this.OVLOffsetList = this.mainContent.OffsetValues;
                }
            }
        }

        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set { SetProperty(ref this.toolText, value); }
        }

        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set { SetProperty(ref this.productText, value); }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set { SetProperty(ref this.layerText, value); }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set { SetProperty(ref this.reticleText, value); }
        }

        private string recipe;
        public string Recipe
        {
            get { return this.recipe; }
            set { SetProperty(ref this.recipe, value); }
        }

        private string preTool;
        public string PreTool
        {
            get { return this.preTool; }
            set { SetProperty(ref this.preTool, value); }
        }

        private string preReticle;
        public string PreReticle
        {
            get { return this.preReticle; }
            set { SetProperty(ref this.preReticle, value); }
        }

        private List<ParameterRow> ovlOffsetList;
        public List<ParameterRow> OVLOffsetList
        {
            get { return this.ovlOffsetList; }
            set
            {
                SetProperty(ref this.ovlOffsetList, value);
                if (this.MainContent != null)
                {
                    this.MainContent.OffsetValues = this.ovlOffsetList;
                }
            }
        }

        private ParameterRow selectedOVLOffsetValue;
        public ParameterRow SelectedOVLOffsetValue
        {
            get { return this.selectedOVLOffsetValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.selectedOVLOffsetValue, value); }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get { return this.currentWindow; }
            set { SetProperty(ref this.currentWindow, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _saveCommand;
        public DelegateCommand SaveCommand =>
            _saveCommand ?? (_saveCommand = new DelegateCommand(OnSave));

        private DelegateCommand _closeCommand;
        public DelegateCommand CloseCommand =>
            _closeCommand ?? (_closeCommand = new DelegateCommand(OnClose));
        #endregion

        #region local Function
        void OnSave()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
            if (!CheckValues())
            {
                MessageBox.Show("Pls Check the Values!");
                return;
            }
            string retMsg = null;
            OffsetMainContent returnRst = null;
            bool ret = this.ConfigurationUIService.saveOffsetMainContent(ClientInfo.CurrentUser,
                                                                         ClientInfo.CurrentVersion,
                                                                         this.Recipe,
                                                                         this.PreTool,
                                                                         this.PreReticle,
                                                                         this.mainContent,
                                                                         this.OriMainContent,
                                                                         out returnRst,
                                                                         out retMsg);
            if (!ret)
            {
                this.ReturnText = retMsg;
                return;
            }
            if (null != returnRst)
            {
                this.OriMainContent = returnRst;
            }
            MessageBox.Show("sava is success!");
            this.currentWindow.Close();
        }
        bool CheckValues()
        {
            bool rst = true;
            foreach (ParameterRow para in this.mainContent.OffsetValues)
            {
                if (!string.IsNullOrEmpty(para.Offset))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.Offset);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                if (!string.IsNullOrEmpty(para.Offset1))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.Offset1);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }

                if (!string.IsNullOrEmpty(para.Offset2))
                {
                    try
                    {
                        double offset = System.Convert.ToDouble(para.Offset2);
                        double lower = System.Convert.ToDouble(para.Lower);
                        double upper = System.Convert.ToDouble(para.Upper);
                    }
                    catch
                    {
                        return false;
                    }
                }
                else
                {
                    return false;
                }
            }
            return rst;
        }

        void OnClose()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

        }

        #endregion

    }
}