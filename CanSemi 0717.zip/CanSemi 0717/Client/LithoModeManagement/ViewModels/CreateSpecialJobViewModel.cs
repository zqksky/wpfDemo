﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;
using R2R.Service.LithoModeService.VO;
using Prism.Commands;
using R2R.Service.LithoModeService;
using R2R.Common.Data;
using System.Windows;

namespace R2R.Client.LithoModeManagement.ViewModels
{

    public class CreateSpecialJobViewModel : ViewModelBase
    {
        public ICreateSpecialJobViewService CreateSpecialJobViewService { get; set; }

        public CreateSpecialJobViewModel(ICreateSpecialJobViewService createSpecialJobViewService)
        {
            this.CreateSpecialJobViewService = createSpecialJobViewService;
            string retMsg = null;
            List<string> tools = this.CreateSpecialJobViewService.GetToolList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, out retMsg);
            if (tools != null)
            {
                this.ToolList = new ObservableCollection<string>(tools);
            }
            else
            {
                MessageBox.Show(retMsg);
            }

            List<string> modes = new List<string>();
            modes.Add("T1M0R0F1");
            modes.Add("T3M0R0F1");
            modes.Add("T3M0R0F3");
            modes.Add("T3M3R3F3");
            modes.Add("T5M5R5F3");
            this.ControlModeList = new ObservableCollection<string>(modes);
            this.SelectedControlModeValue = "T1M0R0F1";

            List<string> products = this.CreateSpecialJobViewService.GetProductList(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                out retMsg);
            this.ProductList = new ObservableCollection<string>(products);
        }

        #region Field

        private bool isFEMFlagChecked;
        public bool IsFEMFlagChecked
        {
            get { return this.isFEMFlagChecked; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.isFEMFlagChecked, value);
                if (this._specialJob != null)
                    this.SpecialJob.FEMFlag = (value)?("Y"):("N");
            }
        }


        private bool isRunCardChecked;
        public bool IsRunCardChecked
        {
            get { return this.isRunCardChecked; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.isRunCardChecked, value);
            }
        }

        private bool isLotChecked;
        public bool IsLotChecked
        {
            get { return this.isLotChecked; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.isLotChecked, value);
            }
        }

        private bool isC2CFlagChecked;
        public bool IsC2CFlagChecked
        {
            get { return this.isC2CFlagChecked; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.isC2CFlagChecked, value);
                if (this._specialJob != null)
                    this.SpecialJob.C2CFlag = (value) ? ("Y") : ("N");
            }
        }

        private string returnText;
        public string ReturnText
        {
            get { return this.returnText; }
            set { SetProperty(ref this.returnText, value); }
        }

        private SpecialJobRow _OriSpecialJob = new SpecialJobRow();
        public SpecialJobRow OriSpecialJob
        {
            get { return this._OriSpecialJob; }
            set
            {
                SetProperty(ref this._OriSpecialJob, value);
            }
        }

        private SpecialJobRow _specialJob = new SpecialJobRow();
        public SpecialJobRow SpecialJob
        {
            get { return this._specialJob; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this._specialJob, value);
                if(this._specialJob != null)
                {
                    if(!string.IsNullOrEmpty(this._specialJob.FEMFlag))
                    { 
                        this.IsFEMFlagChecked = (this._specialJob.FEMFlag.Equals("Y", StringComparison.OrdinalIgnoreCase)) ? (true) : (false);
                    }
                    if (!string.IsNullOrEmpty(this._specialJob.C2CFlag))
                    {
                        this.IsC2CFlagChecked = (this._specialJob.C2CFlag.Equals("Y", StringComparison.OrdinalIgnoreCase)) ? (true) : (false);
                    }
                    this.CurrentRecipeText = (this._specialJob.RecipeId);

                    this.ToolList.Add(this._specialJob.ToolId);
                    this.LayerList.Add(this._specialJob.LayerId);
                    this.ReticleList.Add(this._specialJob.ReticleId);
                    this.SelectedToolValue = this._specialJob.ToolId;
                    this.SelectedProductValue = this._specialJob.ProductId;
                    this.SelectedLayerValue = this._specialJob.LayerId;
                    this.SelectedReticleValue = this._specialJob.ReticleId;
                    this.CurrentRecipeText = this._specialJob.RecipeId;
                    this.SelectedControlModeValue = this.controlModeList[0];
                    this.LotText = this._specialJob.LotId;
                    this.RunCardText = this._specialJob.RunCardId;
                    this.SplitText = this._specialJob.SplitId;

                    if ((string.IsNullOrEmpty(this.LotText))||(this.LotText.Equals("NA", StringComparison.OrdinalIgnoreCase)))
                    {
                        this.IsRunCardChecked = true;
                        this.IsLotChecked = false;
                    }
                    else if ( (string.IsNullOrEmpty(this.RunCardText) || this.RunCardText.Equals("NA", StringComparison.OrdinalIgnoreCase) )
                        && ( string.IsNullOrEmpty(this.SplitText) || this.SplitText.Equals("NA", StringComparison.OrdinalIgnoreCase) ) )
                    {
                        this.IsRunCardChecked = false;
                        this.IsLotChecked = true;
                    }
                    this.CDDataList = new List<ParameterRow>(this._specialJob.cdParameters);
                    this.OVLDataList = new List<ParameterRow>(this._specialJob.ovlParameters);
                }
            }
        }

        private string titleText;
        public string TitleText
        {
            get { return this.titleText; }
            set
            {
                SetProperty(ref this.titleText, value);
                if (this.titleText != null && this.titleText.Contains("Edit"))
                {//Edit
                    IsLine1Enable = false;
                    IsLine2Enable = true;
                    IsLine3Enable = false;
                    IsRefreshEnable = false;
                    ButtonName_CreateUpdate = "Update";
                } else if (this.titleText != null && this.titleText.Contains("CreateBy")) {
                    //CreateBy
                    IsLine1Enable = false;
                    IsLine2Enable = true;
                    IsLine3Enable = true;
                    IsRefreshEnable = false;
                    ButtonName_CreateUpdate = "Create";
                }
                else if (this.titleText != null && this.titleText.Contains("CreateNew")) {
                    //CreateNew
                    IsLine1Enable = true;
                    IsLine2Enable = false;
                    IsLine3Enable = true;
                    IsRefreshEnable = true;
                    ButtonName_CreateUpdate = "Create";
                }
            }
        }

        private bool isLine1Enable;
        public bool IsLine1Enable
        {
            get { return this.isLine1Enable; }
            set { SetProperty(ref this.isLine1Enable, value); }
        }
        private bool isLine2Enable;
        public bool IsLine2Enable
        {
            get { return this.isLine2Enable; }
            set { SetProperty(ref this.isLine2Enable, value); }
        }
        private bool isLine3Enable;
        public bool IsLine3Enable
        {
            get { return this.isLine3Enable; }
            set { SetProperty(ref this.isLine3Enable, value); }
        }
        private string buttonName_CreateUpdate;
        public string ButtonName_CreateUpdate
        {
            get{return this.buttonName_CreateUpdate;}
            set{SetProperty(ref this.buttonName_CreateUpdate, value);}
        }
        private bool isRefreshEnable;
        public bool IsRefreshEnable
        {
            get{return this.isRefreshEnable;}
            set{SetProperty(ref this.isRefreshEnable, value);}
        }



        private ObservableCollection<string> toolList = new ObservableCollection<string>();
        public ObservableCollection<string> ToolList
        {
            get
            {
                return this.toolList;
            }
            set
            {
                SetProperty(ref this.toolList, value);
            }
        }

        private string selectedToolValue;
        public string SelectedToolValue
        {
            get{ return this.selectedToolValue;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedToolValue, value);

                if (!string.IsNullOrEmpty(this.selectedToolValue))
                    this.SpecialJob.ToolId = this.selectedToolValue;

                if ((!string.IsNullOrEmpty(this.selectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.CurrentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
                {
                    IsLine2Enable = true;
                }
                else
                {
                    IsLine2Enable = false;
                }
            }
        }

        private ObservableCollection<string> productList = new ObservableCollection<string>();
        public ObservableCollection<string> ProductList
        {
            get{return this.productList;}
            set{SetProperty(ref this.productList, value);}
        }

        private string selectedProductValue;
        public string SelectedProductValue
        {
            get{return this.selectedProductValue;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedProductValue, value);

                if (!string.IsNullOrEmpty(this.selectedProductValue))
                    this.SpecialJob.ProductId = this.selectedProductValue;

                if ((!string.IsNullOrEmpty(this.selectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.CurrentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
                {
                    IsLine2Enable = true;
                }
                else
                {
                    IsLine2Enable = false;
                }
            }
        }
        
        private ObservableCollection<string> layerList = new ObservableCollection<string>();
        public ObservableCollection<string> LayerList
        {
            get{ return this.layerList;}
            set{ SetProperty(ref this.layerList, value);}
        }

        private string selectedLayerValue;
        public string SelectedLayerValue
        {
            get{return this.selectedLayerValue; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedLayerValue, value);

                if (!string.IsNullOrEmpty(this.selectedLayerValue))
                    this.SpecialJob.LayerId = this.selectedLayerValue;

                if ((!string.IsNullOrEmpty(this.selectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.CurrentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
                {
                    IsLine2Enable = true;
                }
                else
                {
                    IsLine2Enable = false;
                }
            }
        }

        private ObservableCollection<string> reticleList = new ObservableCollection<string>();
        public ObservableCollection<string> ReticleList
        {
            get{return this.reticleList;}
            set{SetProperty(ref this.reticleList, value);}
        }

        private ObservableCollection<string> recipeList = new ObservableCollection<string>();
        public ObservableCollection<string> RecipeList
        {
            get { return this.recipeList; }
            set { SetProperty(ref this.recipeList, value); }
        }

        private string currentRecipeText;
        public string CurrentRecipeText
        {
            get { return this.currentRecipeText; }
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.currentRecipeText, value);

                if (!string.IsNullOrEmpty(this.currentRecipeText))
                    this.SpecialJob.RecipeId = this.currentRecipeText;

                if ((!string.IsNullOrEmpty(this.currentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
                {
                    IsLine2Enable = true;
                }
                else
                {
                    IsLine2Enable = false;
                }
            }
        }

        private string selectedReticleValue;
        public string SelectedReticleValue
        {
            get{return this.selectedReticleValue;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedReticleValue, value);

                if (!string.IsNullOrEmpty(this.selectedReticleValue))
                    this.SpecialJob.ReticleId = this.selectedReticleValue;

                if ((!string.IsNullOrEmpty(this.selectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.CurrentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
                {
                    IsLine2Enable = true;
                }
                else
                {
                    IsLine2Enable = false;
                }
            }
        }

        private ObservableCollection<string> controlModeList = new ObservableCollection<string>();
        public ObservableCollection<string> ControlModeList
        {
            get{return this.controlModeList;}
            set{SetProperty(ref this.controlModeList, value);}
        }

        private string selectedControlModeValue;
        public string SelectedControlModeValue
        {
            get{return this.selectedControlModeValue;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

                SetProperty(ref this.selectedControlModeValue, value);

                if (!string.IsNullOrEmpty(this.selectedControlModeValue))
                    this.SpecialJob.ControlMode = this.SelectedControlModeValue;
            }
        }

        private string lotText;
        public string LotText
        {
            get {return this.lotText;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.lotText, value);

                if (!string.IsNullOrEmpty(this.lotText))
                    this.SpecialJob.LotId = this.lotText;
            }
        }

        private string runCardText;
        public string RunCardText
        {
            get{return this.runCardText;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.runCardText, value);

                if (!string.IsNullOrEmpty(this.runCardText))
                    this.SpecialJob.RunCardId = this.runCardText;
            }
        }

        private Window currentWindow;
        public Window CurrentWindow
        {
            get{return this.currentWindow;}
            set {SetProperty(ref this.currentWindow, value); }
        }

        private string splitText;
        public string SplitText
        {
            get{return this.splitText;}
            set
            {
                ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();
                SetProperty(ref this.splitText, value);

                if (!string.IsNullOrEmpty(this.splitText))
                    this.SpecialJob.SplitId = this.splitText;
            }
        }

        private List<ParameterRow> _cdDataList;
        public List<ParameterRow> CDDataList
        {
            get { return _cdDataList; }
            set { SetProperty(ref _cdDataList, value);

                if ( _cdDataList != null && _cdDataList.Count > 0 )
                    this.SpecialJob.cdParameters = this._cdDataList;
            }
        }

        private List<ParameterRow> _ovlDataList;
        public List<ParameterRow> OVLDataList
        {
            get { return _ovlDataList; }
            set { SetProperty(ref _ovlDataList, value);

                if (_ovlDataList != null && _ovlDataList.Count > 0)
                    this.SpecialJob.ovlParameters = this._ovlDataList;
            }
        }

        #endregion

        #region Event
        private DelegateCommand _createUpdateCommand;
        public DelegateCommand CreateUpdateCommand =>
            _createUpdateCommand ?? (_createUpdateCommand = new DelegateCommand(OnCreateUpdate));

        private DelegateCommand _productSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _productSelectionChangedCommand ?? (_productSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));

        private DelegateCommand _layerSelectionChangedCommand;
        public DelegateCommand LayerSelectionChangedCommand =>
            _layerSelectionChangedCommand ?? (_layerSelectionChangedCommand = new DelegateCommand(OnLayerSelectionChanged));

        private DelegateCommand _reticleSelectionChangedCommand;
        public DelegateCommand ReticleSelectionChangedCommand =>
            _reticleSelectionChangedCommand ?? (_reticleSelectionChangedCommand = new DelegateCommand(OnReticleSelectionChanged));

        private DelegateCommand _closeCommand;
        public DelegateCommand CloseCommand =>
            _closeCommand ?? (_closeCommand = new DelegateCommand(OnClose));

        private DelegateCommand _controlModeSelectionChanged;
        public DelegateCommand ControlModeSelectionChanged =>
            _controlModeSelectionChanged ?? (_controlModeSelectionChanged = new DelegateCommand(Edit4ChangeSpecialJobProperty));

        private DelegateCommand _flagUpdate;
        public DelegateCommand FlagUpdate =>
            _flagUpdate ?? (_flagUpdate = new DelegateCommand(Edit4ChangeSpecialJobProperty));

        private DelegateCommand _refreshCommand;
        public DelegateCommand RefreshCommand =>
            _refreshCommand ?? (_refreshCommand = new DelegateCommand(OnRefresh));


        #endregion



        #region local Function

        void OnRefresh()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (this.selectedToolValue != null 
                && this.selectedProductValue != null 
                && this.selectedLayerValue != null
                && this.selectedReticleValue != null
                && this.CurrentRecipeText != null
                && this.selectedControlModeValue != null)
            {
                string retMsg = null;
                SpecialJobRow specialJob = this.CreateSpecialJobViewService.QeuryReferences4SpecialJob(ClientInfo.CurrentUser,
                    ClientInfo.CurrentVersion, 
                    this.selectedProductValue,
                    this.selectedLayerValue,
                    this.selectedToolValue,
                    this.selectedReticleValue,
                    this.CurrentRecipeText,
                    this.selectedControlModeValue,
                    (this.isFEMFlagChecked),
                    (this.isC2CFlagChecked),
                    out retMsg);
                if(null != specialJob)
                { 
                    if (specialJob.cdParameters != null)
                    {
                        this.CDDataList = specialJob.cdParameters;
                    }
                    if (specialJob.ovlParameters != null)
                    {
                        this.OVLDataList = specialJob.ovlParameters;
                    }
                }
                this.ReturnText = retMsg;
            }
            else
            {
                this.ReturnText = "Pls selecte Tool, Product, Layer, Reticle, Recipe, ControlModel and FEM(C2C)!";
            }
        }

        void Edit4ChangeSpecialJobProperty()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if ((!string.IsNullOrEmpty(this.selectedToolValue))
                    && (!string.IsNullOrEmpty(this.SelectedProductValue))
                    && (!string.IsNullOrEmpty(this.SelectedLayerValue))
                    && (!string.IsNullOrEmpty(this.CurrentRecipeText))
                    && (!string.IsNullOrEmpty(this.SelectedReticleValue)))
            {
                string retMsg = null;
                SpecialJobRow specialJob = null;
                if (this.TitleText.Contains("Create"))
                {
                    specialJob = this.CreateSpecialJobViewService.ChangeSpecialJobProperty(ClientInfo.CurrentUser,
                                        ClientInfo.CurrentVersion,
                                        "NA",
                                        this.SelectedControlModeValue,
                                        (this.IsFEMFlagChecked),
                                        (this.IsC2CFlagChecked),
                                        this.selectedToolValue,
                                        this.SelectedProductValue,
                                        this.SelectedLayerValue,
                                        this.SelectedReticleValue,
                                        this.CurrentRecipeText,
                                        out retMsg);
                }
                else
                {
                    specialJob = this.CreateSpecialJobViewService.ChangeSpecialJobProperty(ClientInfo.CurrentUser,
                                        ClientInfo.CurrentVersion,
                                        this._specialJob.JobId,
                                        this.SelectedControlModeValue,
                                        (this.IsFEMFlagChecked),
                                        (this.IsC2CFlagChecked),
                                        this.selectedToolValue,
                                        this.SelectedProductValue,
                                        this.SelectedLayerValue,
                                        this.SelectedReticleValue,
                                        this.CurrentRecipeText,
                                        out retMsg);
                } 
                this.ReturnText = retMsg;
                if (specialJob != null)
                {
                    MessageBoxResult selectRst = MessageBox.Show("Is overWrite the parameters?", "Select overwrite", System.Windows.MessageBoxButton.YesNo);
                    if (selectRst == MessageBoxResult.Yes)
                    {
                        if (specialJob.cdParameters != null)
                        {
                            this.CDDataList = specialJob.cdParameters;
                        }
                        if (specialJob.ovlParameters != null)
                        {
                            this.OVLDataList = specialJob.ovlParameters;
                        }
                    }
                    else
                    {
                        this.CDDataList = UpdateParamterListOverWrite(this.CDDataList, specialJob.cdParameters);
                        this.OVLDataList = UpdateParamterListOverWrite(this.OVLDataList, specialJob.ovlParameters);
                    }
                }
            }
            else
            {
                this.ReturnText = "Pls selecte Tool, Product, Layer, Reticle, ControlModel and FEM(C2C)!";
            }
        }
        bool OVLParameterInLimit(List<ParameterRow> listParam, bool C2CFlag)
        {//waiting Test
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            bool rst = false;
            if (null == listParam)
            {
                ReturnText = "The OVLParameter list is Null!";
                return rst;
            }
            if (listParam.Count < 1)
            {
                return true;
            }

            double value = 0;
            double value1 = 0;
            double value2 = 0;
            double lower = 0;
            double upper = 0;
            foreach (ParameterRow param in listParam)
            {
                rst = false;
                if (!string.IsNullOrEmpty(param.ParameterVaue))
                {
                    try
                    {
                        if (C2CFlag)
                        {
                            value1 = System.Convert.ToDouble(param.ParameterVaue1);
                            value2 = System.Convert.ToDouble(param.ParameterVaue2);
                        }
                        else
                        {
                            value = System.Convert.ToDouble(param.ParameterVaue);
                        }
                        lower = System.Convert.ToDouble(param.Lower);
                        upper = System.Convert.ToDouble(param.Upper);
                    }
                    catch
                    {
                        ReturnText = string.Format("The OVLParameter named \"{0}\" is not a number!", param.ParameterName);
                        return rst;
                    }
                    if (C2CFlag)
                    {
                        rst = (lower <= value1 && value1 <= upper)
                            && (lower <= value2 && value2 <= upper);
                    }
                    else
                    {
                        rst = (lower <= value && value <= upper);
                    }
                    if (!rst)
                    {
                        ReturnText = string.Format("The OVLParameter named \"{0}\" is not in limit range!", param.ParameterName);
                        return rst;
                    }
                }
                else
                {
                    ReturnText = string.Format("The OVLParameter named \"{0}\" is not entered!", param.ParameterName);
                    return rst;
                }
            }
            return rst;
        }
        bool CDParameterInLimit(List<ParameterRow> listParam)
        {//waiting Test
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            bool rst = false;
            if (null == listParam)
            {
                ReturnText = "The CDParameter list is Null!";
                return rst;
            }
            if (listParam.Count < 1)
            {
                return true;
            }
            double value = 0;
            double lower = 0;
            double upper = 0;
            foreach (ParameterRow param in listParam)
            {
                rst = false;
                if (!string.IsNullOrEmpty(param.ParameterVaue))
                {
                    try
                    {
                        value = System.Convert.ToDouble(param.ParameterVaue);
                        lower = System.Convert.ToDouble(param.Lower);
                        upper = System.Convert.ToDouble(param.Upper);
                    }
                    catch
                    {
                        ReturnText = string.Format("The CDParameter named \"{0}\" is not a number!", param.ParameterName);
                        return rst;
                    }
                    rst = (lower <= value && value <= upper);
                    if ( !rst )
                    {
                        ReturnText = string.Format("The CDParameter named \"{0}\" is not in limit range!", param.ParameterName);
                        return rst;
                    }
                }
                else
                {
                    ReturnText = string.Format("The CDParameter named \"{0}\" is not entered!", param.ParameterName);
                    return rst;
                }
            }
            return rst;
        }
        void OnCreateUpdate()
        {//waiting Test
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            if (null == this.SpecialJob)
            {
                ReturnText = "The speicalJob is NULL";
                return;
            }
            
            if(true)
            {
                string retMsg = null;
                SpecialJobRow returnSeicalJob = null;
                bool rst = false;
                if (this.TitleText.Contains("Create"))
                {
                    SpecialJobRow temp = this.SpecialJob;
                    temp.JobId = "NA";
                    rst = this.CreateSpecialJobViewService.SaveSpecialJob(ClientInfo.CurrentUser,
                        ClientInfo.CurrentVersion,
                        temp,
                        null,//"Createnew" OriParameter use the created
                        out returnSeicalJob,
                        out retMsg);
                }
                else
                {
                    rst = this.CreateSpecialJobViewService.SaveSpecialJob(ClientInfo.CurrentUser,
                        ClientInfo.CurrentVersion,
                        this.SpecialJob,
                        OriSpecialJob,
                        out returnSeicalJob,
                        out retMsg);
                }
                if(null != returnSeicalJob)
                    this.OriSpecialJob = returnSeicalJob;
                this.ReturnText = retMsg;
            }
        }

        void OnClose()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            this.CurrentWindow.Close();
        }

        void OnProductSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            List<string> layers = this.CreateSpecialJobViewService.GetLayerList(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion, 
                this.SelectedProductValue,
                out retMsg);
            this.LayerList = new ObservableCollection<string>(layers);
            this.ReturnText = retMsg;
        }

        void OnLayerSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            List<string> reticles = this.CreateSpecialJobViewService.GetReticleForLayer(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion, 
                this.SelectedProductValue,
                this.SelectedLayerValue,
                out retMsg);
            if (reticles != null)
            {
                this.ReticleList = new ObservableCollection<string>(reticles);
            }
            this.ReturnText = retMsg;
        }

        void OnReticleSelectionChanged()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            string retMsg = null;
            List<string> recipes = this.CreateSpecialJobViewService.GetRecipeForLayer(ClientInfo.CurrentUser,
                ClientInfo.CurrentVersion,
                this.SelectedToolValue,
                this.SelectedProductValue,
                this.SelectedLayerValue,
                this.SelectedReticleValue,
                out retMsg);
            if (recipes != null)
            {
                this.RecipeList = new ObservableCollection<string>(recipes);
            }
            this.ReturnText = retMsg;
        }

        List<ParameterRow> UpdateParamterListOverWrite(List<ParameterRow> oldParaList, List<ParameterRow> newParaList)
        {
            if (newParaList != null && newParaList.Count > 0 && oldParaList != null && oldParaList.Count > 0)
            {
                //step1:Find parameters with the same name in the old list in the new list: update values from the old list to the new list
                //step2:Replace the old list with the new one
                bool foundFlag = false;
                foreach (ParameterRow oldPara in oldParaList)
                {
                    foundFlag = false;
                    for (int i = 0; (false == foundFlag) && i < newParaList.Count; i++)
                    {
                        if ( oldPara.ParameterName == newParaList[i].ParameterName)
                        {
                            foundFlag = true;
                            newParaList[i].ParameterVaue = oldPara.ParameterVaue;
                            newParaList[i].ParameterVaue1 = oldPara.ParameterVaue1;
                            newParaList[i].ParameterVaue2 = oldPara.ParameterVaue2;
                        }
                    }
                }
                return newParaList;
            }
            return oldParaList;
        }

        #endregion
    }
}