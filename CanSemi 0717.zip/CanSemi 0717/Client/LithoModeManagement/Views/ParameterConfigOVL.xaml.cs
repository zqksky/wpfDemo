﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace R2R.Client.LithoModeManagement.Views
{
    /// <summary>
    /// Interaction logic for ParameterConfigOVL.xaml
    /// </summary>
    public partial class ParameterConfigOVL : Page
    {
        public ParameterConfigOVL()
        {
            InitializeComponent();
            syncColumnWidth();
        }
        private void ColumnHeader_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (e.Source == null)
                return;
            syncColumnWidth();
        }
        public void syncColumnWidth()
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            ParameterName_row1.Width = ParameterName_Row2.ActualWidth - 11;
            NA.Width =  NA_FixedValue.ActualWidth + NA_Offset.ActualWidth + NA_uCalc.ActualWidth - 11;
            C1.Width =  C1_FixedValue.ActualWidth + C1_Offset.ActualWidth + C1_uCalc.ActualWidth - 11;
            C2.Width =  C2_FixedValue.ActualWidth + C2_Offset.ActualWidth + C2_uCalc.ActualWidth - 11;
            Spec.Width = Spec_Lower.ActualWidth + Spec_Upper.ActualWidth + Spec_Delta.ActualWidth + Spec_DeadBand.ActualWidth - 11;
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            Window window = (Window)this.Parent;
            window.Close();
        }
    }
}
