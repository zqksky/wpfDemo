﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace R2R.Client.LithoModeManagement.Views
{
    /// <summary>
    /// SpecLimitEditor.xaml 的交互逻辑
    /// </summary>
    public partial class SpecLimitEditor : UserControl
    {
        public SpecLimitEditor()
        {
            InitializeComponent();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            Window window = (Window)this.Parent;
            window.Close();
        }

        private void CheckValue(object sender, DataGridCellEditEndingEventArgs e)
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            try
            {
                System.Convert.ToDouble((e.EditingElement as TextBox).Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Pls input a number!");
            }
        }
    }
}
