﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using R2R.Client.LithoModeManagement.ViewModels;

namespace R2R.Client.LithoModeManagement.Views
{
    /// <summary>
    /// Interaction logic for CreateSpecialJob.xaml
    /// </summary>
    public partial class CreateSpecialJob : Page
    {
        public CreateSpecialJob()
        {
            InitializeComponent();
            this.radionBtn_Lot.IsChecked = true;
        }
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            Window window = (Window)this.Parent;
            window.Close();
        }
        private void OnRadionBtn_Lot_Checked(object sender, RoutedEventArgs e)
        {
            this.textBox_Lot.IsReadOnly = false;
            this.textBox_Lot.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));

            this.textBox_RunCard.IsReadOnly = true;
            this.textBox_RunCard.Background = new SolidColorBrush(Color.FromRgb(0xF8,0xF8,0xF8));
            this.textBox_SplitId.IsReadOnly = true;
            this.textBox_SplitId.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xF8, 0xF8));

            this.textBox_RunCard.Text = "";
            this.textBox_SplitId.Text = "";
        }
        private void OnRadionBtn_Lot_Unchecked(object sender, RoutedEventArgs e)
        {
            this.textBox_Lot.IsReadOnly = true;
            this.textBox_Lot.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xF8, 0xF8));

            this.textBox_RunCard.IsReadOnly = false;
            this.textBox_RunCard.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));
            this.textBox_SplitId.IsReadOnly = false;
            this.textBox_SplitId.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));
        }
        private void OnRadionBtn_RunCard_Checked(object sender, RoutedEventArgs e)
        {
            this.textBox_Lot.IsReadOnly = true;
            this.textBox_Lot.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xF8, 0xF8));

            this.textBox_RunCard.IsReadOnly = false;
            this.textBox_RunCard.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));
            this.textBox_SplitId.IsReadOnly = false;
            this.textBox_SplitId.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));

            this.textBox_Lot.Text = "";

        }
        private void OnRadionBtn_RunCard_Unchecked(object sender, RoutedEventArgs e)
        {
            this.textBox_Lot.IsReadOnly = false;
            this.textBox_Lot.Background = new SolidColorBrush(Color.FromRgb(0xFF, 0xFF, 0xFF));

            this.textBox_RunCard.IsReadOnly = true;
            this.textBox_RunCard.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xF8, 0xF8));
            this.textBox_SplitId.IsReadOnly = true;
            this.textBox_SplitId.Background = new SolidColorBrush(Color.FromRgb(0xF8, 0xF8, 0xF8));
        }


        private System.Windows.Controls.DataGridColumn editingColumn;
        private System.Windows.Controls.DataGridRow editingRow;
        private System.Windows.Controls.DataGrid currentDataGrid;
        private System.Windows.Controls.DataGridCellInfo currentCellInfo;
        private Common.Data.ParameterRow oriParameter;


        private void DataGridBeginningEdit(object sender, DataGridBeginningEditEventArgs e)
        {
            //this.editingColumn = e.Column;
            //this.editingRow = e.Row;
            //TextBlock tboxValue = (TextBlock)e.EditingEventArgs.Source;
            //System.Windows.Controls.DataGrid tempDataGrid = (System.Windows.Controls.DataGrid)sender;
            //CreateSpecialJobViewModel model = this.DataContext as CreateSpecialJobViewModel;
            //if (tempDataGrid.Name == "CDDataGrid")
            //{
            //    this.currentDataGrid = CDDataGrid;
            //    this.currentCellInfo = CDDataGrid.CurrentCell;
            //    int row = GetParameterRowIndexInList((Common.Data.ParameterRow)this.editingRow.Item, model.CDDataList);
            //    if (-1 != row)
            //        this.oriParameter = model.OriSpecialJob.cdParameters[row];
            //}
            //else if(tempDataGrid.Name == "OVLDataGrid")
            //{
            //    this.currentDataGrid = OVLDataGrid;
            //    this.currentCellInfo = OVLDataGrid.CurrentCell;
            //    int row = GetParameterRowIndexInList((Common.Data.ParameterRow)this.editingRow.Item, model.OVLDataList);
            //    if (-1 != row)
            //        this.oriParameter = model.OriSpecialJob.ovlParameters[row];
            //}
        }

        private void DataGridCellEditEnding(object sender, DataGridCellEditEndingEventArgs e)
        {
            //if (this.editingColumn == e.Column && this.editingRow == e.Row)
            //{
            //    System.Windows.Controls.DataGrid Sender = (System.Windows.Controls.DataGrid)sender as System.Windows.Controls.DataGrid;
            //    //this.editingRow.Background = Brushes.Black;
            //    System.Windows.Controls.TextBox tboxValue = (System.Windows.Controls.TextBox)e.EditingElement as System.Windows.Controls.TextBox;
            //    tboxValue.Background = Brushes.Red;
            //    tboxValue.Foreground = Brushes.Yellow;
                
            //    //CreateSpecialJobViewModel model = this.DataContext as CreateSpecialJobViewModel;

            //}
        }

        private int GetParameterRowIndexInList(Common.Data.ParameterRow parameter, List<Common.Data.ParameterRow> dataList)
        {
            int rst = -1;
            Common.Data.ParameterRow para = null;
            for (int i = 0; i < dataList.Count; i++)
            {
                para = dataList[i];
                if ( (!string.IsNullOrEmpty(para.ParameterName)) && (!string.IsNullOrEmpty(parameter.ParameterName)) )
                {
                    if (  para.ParameterVaue == parameter.ParameterVaue )
                    {
                        rst = i;
                        return rst;
                    }
                }
            }
            return rst;
        }
    }
}
