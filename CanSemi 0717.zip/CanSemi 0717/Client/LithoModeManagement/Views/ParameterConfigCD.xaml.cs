﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using R2R.Client.Framework;
using R2R.Common.Data;

namespace R2R.Client.LithoModeManagement.Views
{
    /// <summary>
    /// Interaction logic for ParameterConfigCD.xaml
    /// </summary>
    public partial class ParameterConfigCD : Page
    {
        public ParameterConfigCD()
        {
            InitializeComponent();
        }
        private void dgSourceData_BeginningEdit(object sender, DataGridCellEditEndingEventArgs e)
        {
           
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            ClientInfo.NoOperationTimer = new System.Windows.Threading.DispatcherTimer();

            Window window = (Window)this.Parent;
            window.Close();
        }
        private void CheckValue(object sender, DataGridCellEditEndingEventArgs e)
        {
            if (e.Column.Header.ToString().Equals("uCalc"))
            {
                DataGrid t = (DataGrid)sender;
                ParameterRow row = (ParameterRow)t.CurrentItem;
                if(row != null)
                {
                    try
                    {
                        double upper = System.Convert.ToDouble(row.Upper);
                        double lower = System.Convert.ToDouble(row.Lower);
                        double ucalc = System.Convert.ToDouble((e.EditingElement as TextBox).Text);
                        if (ucalc > upper || ucalc < lower)
                        {
                            MessageBox.Show("UCalc must be larger than Lower and be less than Upper!");
                        }
                    }
                    catch (Exception excep)
                    {
                        MessageBox.Show("Pls input a number!");
                    }
                }
            }
        }
    }
}
