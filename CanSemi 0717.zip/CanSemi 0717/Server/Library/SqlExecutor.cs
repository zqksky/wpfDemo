﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Library;
using R2R.Server.Library.Sqls;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library
{
    /// <summary>
    /// execute multiple sqls in a single transaction.
    /// </summary>
    public class SqlExecutor
    {
        public static void Execute(List<SqlBase> sqlList)
        {
            using (OracleConnection connnection = OracleHelper.NewAmsConnection())
            {
                MyLogger.PerformanceStart();
                OracleTransaction oracleTransaction = null;
                try
                {
                    bool result = true;
                    connnection.Open();
                    oracleTransaction = connnection.BeginTransaction();
                    foreach (var sql in sqlList)
                    {
                        result &= sql.Execute(connnection);
                        if (!result)
                        {
                            throw new InvalidOperationException($"Sql execution failed. {sql}");
                        }
                    }
                    oracleTransaction.Commit();
                }
                catch (Exception)
                {
                    oracleTransaction.Rollback();
                    throw;
                }
                finally
                {
                    MyLogger.PerformanceStop();
                }
            }
        }

        public static void ExecuteOracleTransaction(Func<OracleConnection, bool> callback)
        {
            using (OracleConnection connnection = OracleHelper.NewAmsConnection())
            {
                MyLogger.PerformanceStart();
                OracleTransaction oracleTransaction = null;
                try
                {
                    bool result = true;
                    connnection.Open();
                    oracleTransaction = connnection.BeginTransaction();

                    result = callback(connnection);

                    if (!result)
                    {
                        throw new InvalidOperationException($"Sql execution failed.");
                    }

                    oracleTransaction.Commit();
                }
                catch (Exception)
                {
                    oracleTransaction.Rollback();
                    throw;
                }
                finally
                {
                    MyLogger.PerformanceStop();
                }
            }

        }
    }
}
