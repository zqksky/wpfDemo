﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Queries
{
    public class QuerySubSystem : QueryBase
    {
        protected override string InternalExecute(QueryRequest req)
        {
            if (req == null)
            {
                throw new ArgumentNullException(nameof(req));
            }

            string baseSql = "select NAME, OWNER_SYSTEM from sub_system ";

            string whereClause = " where owner_system=:system ";

            string orderByClause = "";

            if (req.Ordering != null)
            {
                orderByClause = $" ORDER BY {req.Ordering.OrderBy} {req.Ordering.Order} , name ASC ";
            }
            else
            {
                orderByClause = $" ORDER BY name ASC ";
            }

            string finalSql;

            if(req.Parameters.Count > 0)
            {
                finalSql = baseSql + whereClause + orderByClause;
            }
            else
            {
                finalSql = baseSql + orderByClause;
            }

            if (req.Paging != null)
            {
                finalSql = string.Format(PagedSqlFormat, finalSql);
            }

            DataSet ds = new DataSet();
            using (OracleConnection oracleConnection = new OracleConnection(Connection))
            {
                OracleCommand cmd = new OracleCommand();
                cmd.Connection = oracleConnection;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = finalSql;
                cmd.BindByName = true;
                foreach (var p in req.Parameters)
                {
                    cmd.Parameters.Add(p.Name.ToLower(), p.Value);
                }
                //if (req.Paging != null)
                //{
                //    cmd.Parameters.Add(StartRow, req.Paging.StartRowNo);
                //    cmd.Parameters.Add(EndRow, req.Paging.StartRowNo + req.Paging.PageSize);
                //}
                oracleConnection.Open();

                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    da.Fill(ds);
                    cmd.Parameters.Clear();
                }
            }
            //return ds;
            return string.Empty;
        }
    }
}
