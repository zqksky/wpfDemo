﻿using System;
using System.Collections.Generic;
using System.Reflection;
using R2R.Common.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace R2R.Server.Library
{
    public static class TxnExecutor
    {
        public static string ExecuteQuery(string reqJson)
        {
            try
            {
                string replyJson;
                QueryRequest queryRequest = JsonConvert.DeserializeObject<QueryRequest>(reqJson);
                if (queryRequest == null)
                {
                    throw new ArgumentNullException($"QueryRequest message is invalid. message = {reqJson}");
                }
                TxnContext.CreateContext(queryRequest);
                var resultJson = QueryAgent.Instance.ExecuteQuery(queryRequest);

                MessageResult<string> result = new MessageResult<string>
                {
                    HasError = false,
                    ErrorCode = null,
                    Content = resultJson
                };
                replyJson = JsonConvert.SerializeObject(result);
                return replyJson;
            }
            finally
            {
                TxnContext.ClearContext();
            }
        }

        public static string ExecuteCommand(string reqJson)
        {
            try
            {
                string replyJson;
                CommandRequest commandRequest = JsonConvert.DeserializeObject<CommandRequest>(reqJson);
                if (commandRequest == null)
                {
                    throw new ArgumentNullException($"CommandRequest message is invalid. message = {reqJson}");
                }
                TxnContext.CreateContext(commandRequest);
                object invokeResult = null;
                if (commandRequest != null)
                {
                    object implementInstance = ServiceDirector.Instance.GetServiceInstance(commandRequest.Interface);

                    Type implementType = implementInstance.GetType();
                    MethodInfo method = implementType.GetMethod(commandRequest.MethodName);
                    if (method == null)
                    {
                        throw new ArgumentException($"Method {commandRequest.MethodName} does not exist in class {implementType.FullName}");
                    }
                    invokeResult = method.Invoke(implementInstance, RebuildTypeValues(commandRequest, method.GetParameters()));
                }

                MessageResult<dynamic> result = new MessageResult<dynamic>
                {
                    HasError = false,
                    ErrorCode = null,
                    Content = invokeResult
                };
                replyJson = JsonConvert.SerializeObject(result);
                return replyJson;
            }
            finally
            {
                TxnContext.ClearContext();
            }
        }

        private static object[] RebuildTypeValues(CommandRequest commandRequest, ParameterInfo[] parameters)
        {
            int i = 0;
            List<object> paraValues = new List<object>();
            foreach (object dynamicObject in commandRequest.InputParams)
            {
                if (dynamicObject != null)
                {
                    object paramValue = null;
                    var t = dynamicObject.GetType();
                    if (dynamicObject is JObject jObject)
                    {
                        paramValue = jObject.ToObject(parameters[i].ParameterType);
                    }
                    else if(dynamicObject is string)
                    {
                        paramValue = dynamicObject as string;
                    }
                    else
                    {
                        var dyString = dynamicObject.ToString();
                        paramValue = JsonConvert.DeserializeObject(dyString, parameters[i].ParameterType);
                    }
                    paraValues.Add(paramValue);
                }
                else
                {
                    paraValues.Add(null);
                }
                i++;
            }

            return paraValues.ToArray();
        }
    }
}
