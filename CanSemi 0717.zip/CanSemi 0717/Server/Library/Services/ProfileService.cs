﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Client.Framework;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Server.Library.Sqls;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Services
{
    public class ProfileService : IProfileService
    {
        public void AddFactory(List<Factory> factoryList)
        {
            try
            {
                MyLogger.PerformanceStart();

                InsertSql insertSql = new InsertSql(Factory.TableName);
                insertSql.AddColumValueFromListObject(factoryList.ToArray());
                insertSql.Execute();

                if (true)
                {

                }
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
        }

        /*
        public void AddFactory(Factory factory)
        {
            //bool isInsertSucceed = false;
            try
            {
                MyLogger.PerformanceStart();
                InsertSql insertSql = new InsertSql(Factory.TableName);
                insertSql.AddColumValueFromObject(factory);
                var alarm_ID_String = insertSql.Execute();
                bool tryParse = long.TryParse(alarm_ID_String, out long alarm_ID);
                //alarm = QueryAlarm(alarm_ID);
                //AlarmStatusChanged?.Invoke(this, new AlarmStatusChangedEventArgs(alarm, AlarmStatus.New, alarm.Status));
                //isInsertSucceed = true;
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
            //return isInsertSucceed;
        }
        */

        public void DeleteFactory(string factoryName)
        {
            // TxnContext.Current.UserID
            string sqlString = $"DELETE FROM {Factory.TableName}  WHERE {Factory.COL_FACTORY_NAME} = :{Factory.COL_FACTORY_NAME}";

            using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    CommandText = sqlString
                };

                cmd.Parameters.Add(Factory.COL_FACTORY_NAME, factoryName);

                oracleConnection.Open();
                var succeeded = cmd.ExecuteNonQuery() == 1;

                if(!succeeded)
                {
                    throw new Exception("Delete failed.");
                }
            }
        }

        public void ModifyFactory(Factory factory)
        {
            
            // TxnContext.Current.UserID
            string sqlString = $"UPDATE {Factory.TableName} SET {Factory.COL_FACTORY_DESC} = :{Factory.COL_FACTORY_DESC}" +
                $", {Factory.COL_MODIFIED_DT} = :{Factory.COL_MODIFIED_DT}, {Factory.COL_MODIFIED_BY} = :{Factory.COL_MODIFIED_BY}" +
                $", {Factory.COL_IS_ENABLED} = :{Factory.COL_IS_ENABLED} " +
                $" WHERE {Factory.COL_FACTORY_NAME} = :{Factory.COL_FACTORY_NAME}";

            using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    CommandText = sqlString
                };

                cmd.Parameters.Add(Factory.COL_FACTORY_DESC, factory.Description);
                cmd.Parameters.Add(Factory.COL_MODIFIED_DT, factory.ModifiedDate);
                cmd.Parameters.Add(Factory.COL_MODIFIED_BY, factory.ModifiedBy);
                cmd.Parameters.Add(Factory.COL_IS_ENABLED, factory.IsEnabled ? "Y" : "N" );
                cmd.Parameters.Add(Factory.COL_FACTORY_NAME, factory.Name);

                oracleConnection.Open();
                var succeeded = cmd.ExecuteNonQuery() == 1;

                if (!succeeded)
                {
                    throw new Exception("Modify failed.");
                }
            }
        }

        public List<Factory> GetFactories(List<QueryParameter> parameters, OrderSettings orderSettings)
        {
            throw new NotImplementedException();
        }

        public void EnableFactory(string factoryName)
        {
            // TxnContext.Current.UserID
            string sqlString = $"UPDATE {Factory.TableName} SET {Factory.COL_IS_ENABLED} = :{Factory.COL_IS_ENABLED} WHERE {Factory.COL_FACTORY_NAME} = :{Factory.COL_FACTORY_NAME}";
            using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    CommandText = sqlString
                };

                cmd.Parameters.Add(Factory.COL_IS_ENABLED, "Y");
                cmd.Parameters.Add(Factory.COL_FACTORY_NAME, factoryName);

                if (oracleConnection.State != ConnectionState.Open)
                    oracleConnection.Open();

                var succeeded = cmd.ExecuteNonQuery() == 1;

                if (!succeeded)
                {
                    throw new Exception("Enable failed.");
                }
            }
        }

        public void DisableFactory(string factoryName)
        {
            // TxnContext.Current.UserID
            string sqlString = $"UPDATE {Factory.TableName} SET {Factory.COL_IS_ENABLED} = :{Factory.COL_IS_ENABLED} WHERE {Factory.COL_FACTORY_NAME} = :{Factory.COL_FACTORY_NAME}";
            using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    CommandText = sqlString
                };

                cmd.Parameters.Add(Factory.COL_IS_ENABLED, "N");
                cmd.Parameters.Add(Factory.COL_FACTORY_NAME, factoryName);

                if (oracleConnection.State != ConnectionState.Open)
                    oracleConnection.Open();

                var succeeded = cmd.ExecuteNonQuery() == 1;

                if (!succeeded)
                {
                    throw new Exception("Disabled failed.");
                }
            }
        }
    }
}
