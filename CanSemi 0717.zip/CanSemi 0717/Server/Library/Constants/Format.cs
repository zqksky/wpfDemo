﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Server.Library.Constants
{
    public class Format
    {
        public const string OracleDateTimeFormat = "yyyy/mm/dd hh24:mi:ss";
        public const string ClrDateTimeFormat = "yyyy/MM/dd HH:mm:ss";
        public const string OracleTimeStampFormat = "yyyy/mm/dd hh24:mi:ss.ff3";
        public const string ClrTimeStampFormat = "yyyy/MM/dd HH:mm:ss.fff";
        public const string XmlDateTimeStampFormat = "yyyyMMdd HHmmssfff";
        public const string XmlDateTimeFormat = "yyyyMMdd HHmmss";
    }
}
