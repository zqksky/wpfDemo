﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Server.Library.Constants;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Sqls
{
    public class UpdateSql : ConditionalSql
    {
        private string _sqlStart;
        private string _wherePrimary;
        private string _primaryKeyName;

        public override string ToString()
        {
            string columnNames = string.Empty;
            foreach (var kvp in _columnValueList)
            {
                if (_primaryKeyName == kvp.Key)
                {
                    continue;
                }
                columnNames += $"{kvp.Key} =" + $":{kvp.Key}" + ",";
            }

            if (columnNames.Length > 0)
            {
                columnNames = columnNames.Substring(0, columnNames.Length - 1);
            }

            return $"{_sqlStart} {columnNames} {_wherePrimary}";
        }

        public UpdateSql(string tableName, string primaryKeyName, object primaryKeyValue)
        {
            TableName = tableName;
            _sqlStart = $"UPDATE {tableName} SET ";

            _wherePrimary = $" WHERE {primaryKeyName} = :{primaryKeyName}";

            //
            _primaryKeyName = primaryKeyName;

            // AddParameter(primaryKeyName, primaryKeyValue, primaryKeyValue.GetType());
        }

        
        public virtual bool Execute()
        {
            bool result = false;
            try
            {
                Console.Write(ToString());
                using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
                {
                    OracleCommand cmd = new OracleCommand
                    {
                        Connection = oracleConnection,
                        CommandType = CommandType.Text,
                        BindByName = true,
                        CommandText = this.ToString()
                    };

                    // add input params
                    foreach (var kvp in _columnValueList)
                    {
                        cmd.Parameters.Add(kvp.Key, _columnDbTypes[kvp.Key]).Value = kvp.Value;
                    }

                    oracleConnection.Open();
                    result = cmd.ExecuteNonQuery() == 1;
                }
                Console.WriteLine(result ? "OK." : "Failed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(result ? "OK." : "Failed.");
                Console.WriteLine(ex.ToString());
                MyLogger.Error(ex);
            }
            return result;
        }
    }
}
