﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity
{
    public class ColumnEntity
    {
        public string FieldName { get; set; }
        public string ColumnName { get; set; }
        public Boolean Hidden { get; set; }
        public string FiledType { get; set; }
        public string Width { get; set; }
    }
}
