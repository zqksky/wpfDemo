﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity
{
    public class ParameterRow
    {
        public ToolEntity Tool { get; set; }
        public ChamberEntity Chamber { get; set; }
        public string RecipeName { get; set; }
        public string ParameterName { get; set; }
        public string ParameterVaue { get; set; }
        public string uCalc { get; set; }
        public string Offset { get; set; }
        public string FFOffset { get; set; }
        public string ParameterVaue1 { get; set; }
        public string uCalc1 { get; set; }
        public string Offset1 { get; set; }
        public string FFOffset1 { get; set; }
        public string ParameterVaue2 { get; set; }
        public string uCalc2 { get; set; }
        public string Offset2 { get; set; }
        public string FFOffset2 { get; set; }
        public string Lower { get; set; }
        public string Upper { get; set; }
        public string Deadbound { get; set; }
        public string Delta { get; set; }
        public string Fixed { get; set; }
        public string ReworkBias { get; set; }
        public int Precision { get; set; }
        public string ControlModelName { get; set; }
    }
}
