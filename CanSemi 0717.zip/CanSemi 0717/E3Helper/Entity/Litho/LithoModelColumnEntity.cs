﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using E3Helper.Message.Entity;

namespace E3Helper.Message.Entity.Litho
{
    public class LithoModelColumnEntity
    {
        public List<ColumnEntity> CDCols { get; set; } 
        public List<ColumnEntity> OVLCols { get; set; }
    }
}
