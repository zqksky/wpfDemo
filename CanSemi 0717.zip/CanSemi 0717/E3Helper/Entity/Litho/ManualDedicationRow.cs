﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity.Litho
{
    public class ManualDedicationRow
    {
        public string Layer { get; set; }
        public string WaferId { get; set; }
        public string ChuckId { get; set; }
    }
}
