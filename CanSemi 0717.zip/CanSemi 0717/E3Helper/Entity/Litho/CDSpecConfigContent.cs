﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using E3Helper.Message.Entity;

namespace E3Helper.Message.Entity.Litho
{
    public class CDSpecConfigContent
    {
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }

        public double Sensitivity { get; set; }
        public double CDTarget { get; set; }
        public string FeedbackPoint { get; set; }
        public double Lambda { get; set; }
        public double LambdaPiRun { get; set; }
        public int MetrologyDays { get; set; }
        public int MinPointFieAvg { get; set; }
        public string FeedbackStage { get; set; }
    }
}
