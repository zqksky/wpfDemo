﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using E3Helper.Message.Entity;

namespace E3Helper.Message.Entity.Litho
{
    public class SpecialJobRow
    {
        public string JobId { get; set; }
        public string UsedTime { get; set; }
        public string LotId { get; set; }
        public string RunCardId { get; set; }
        public string SplitId { get; set; }
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        public string RecipeId { get; set; }
        public string CreateBy { get; set; }
        public string CreateTime { get; set; }
        public string ControlMode { get; set; }
        public string OVLMode { get; set; }
        public string WaferCnt { get; set; }
        public string FEMFlag { get; set; }
        public string C2CFlag { get; set; }

        public List<ParameterRow> cdParameters = new List<ParameterRow>();
        public List<ParameterRow> ovlParameters = new List<ParameterRow>();

    }

}
