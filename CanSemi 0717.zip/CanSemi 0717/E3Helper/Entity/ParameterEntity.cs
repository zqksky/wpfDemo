﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity
{
    public class ParameterEntity
    {
        public string ParameterName { get; set; }
        public string ParameterVaue { get; set; }
        public string ParameterBiasName { get; set; }
        public string ParameterValueType { get; set; }
        public string ParameterProcessType { get; set; }
        public int Precision { get; set; }

        public string Name
        {
            get { return this.ParameterName; }
            set { this.ParameterName = value; }
        }
        public string Value
        {
            get { return this.ParameterVaue; }
            set { this.ParameterVaue = value; }
        }
    }
}
