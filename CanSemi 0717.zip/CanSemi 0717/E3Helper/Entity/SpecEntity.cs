﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity
{
    public class SpecEntity
    {
        public string ParameterName { get; set; }
        public double Upperlimit { get; set; }
        public double LowerLimit { get; set; }
        public double Delta { get; set; }
        public double Deadband { get; set; }
        public double FbUpper { get; set; }
        public double FbLower { get; set; }
        public double FbDelta { get; set; }
        public double Lambda { get; set; }
        public double LambdaForPiRun { get; set; }
        public double MinPointsFoeAvg { get; set; }
        public string ControlModelName { get; set; }
    }
}
