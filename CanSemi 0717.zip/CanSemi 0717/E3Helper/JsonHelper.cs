﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using E3Helper.Message.Entity;
using E3Helper.Message.Struct;

namespace E3Helper.Message
{
    public class JsonHelper
    {
        /// <summary>
        /// to get the products class list when open Litho Model View
        /// </summary>
        /// <param name="productIds"></param>
        /// <returns></returns>
        public static string ConvertToProducts(string[] productIds)
        {
            List<ProductEntity> products = new List<ProductEntity>();
            foreach (string productId in productIds)
            {
                products.Add(new ProductEntity { ProductId = productId });
            }

             
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(products.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, products);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }
             
            return jsonText;
        }

        public static string ConvertToProducts(string[] productIds,string[] productTypes)
        {
            List<ProductEntity> products = new List<ProductEntity>();
            for(int i = 0; i < productIds.Length; i++)
            {
                products.Add(new ProductEntity { ProductId = productIds[i] ,ProductType = productTypes[i] });
            }
             

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(products.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, products);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToReticles(string[] reticleIds)
        {
            List<ReticleEntity> retices = new List<ReticleEntity>();
            foreach (string reticleId in reticleIds)
            {
                retices.Add(new ReticleEntity { ReticleId= reticleId, ReticleName= reticleId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(retices.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, retices);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToRecipes(string[] recipeIds)
        {
            List<RecipeEntity> recipes = new List<RecipeEntity>();
            foreach (string recipeId in recipeIds)
            {
                recipes.Add(new RecipeEntity { RecipeId = recipeId, RecipeName = recipeId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(recipes.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, recipes);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="layerIds"></param>
        /// <returns></returns>
        public static string ConvertToLayers(string[] layerIds)
        {
            List<LayerEntity> layers = new List<LayerEntity>();
            foreach (string layerId in layerIds)
            {
                layers.Add(new LayerEntity { LayerId = layerId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(layers.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, layers);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToLayers(string[] layerIds,string[] layerNames)
        {
            List<LayerEntity> layers = new List<LayerEntity>();
            for (int i = 0; i < layerIds.Length; i++)
            {
                layers.Add(new LayerEntity { LayerId = layerIds[i],  LayerName= layerNames[i] });
            }
             


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(layers.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, layers);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToTools(string[] toolIds)
        {
            List<ToolEntity> tools = new List<ToolEntity>();
            foreach (string toolId in toolIds)
            {
                tools.Add(new ToolEntity { ToolId = toolId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(tools.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, tools);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToChambers(string[] chNames)
        {
            List<ChamberEntity> chs = new List<ChamberEntity>();
            foreach (string chName in chNames)
            {
                chs.Add(new ChamberEntity { ChName = chName });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(chs.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, chs);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToParameters(string[] parameterNames, string[] parameterVaue, string[] parameterBiasName, string[] parameterValueType, string[] parameterProcessType, int[] precision)
        {
            List<ParameterEntity> paras = new List<ParameterEntity>();
            for(int i = 0; i < parameterNames.Length; i++)
            {
                paras.Add(new ParameterEntity { ParameterName=parameterNames[i],ParameterBiasName=parameterBiasName[i],ParameterProcessType=parameterProcessType[i],ParameterValueType=parameterProcessType[i],ParameterVaue=parameterVaue[i],Precision=precision[i]});
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(paras.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, paras);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static ProductEntityS GetProductEntity(string jsonProduct)
        {
            ProductEntityS product2 = new ProductEntityS();
            try
            {
                ProductEntity product = new ProductEntity();
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(product.GetType());
                System.IO.MemoryStream stream = new System.IO.MemoryStream(Encoding.Default.GetBytes(jsonProduct));
                product = (ProductEntity)serializer.ReadObject(stream);

                product2.Err = "OK";
                product2.Category = product.Category;
                product2.ProductId = product.ProductId;
                product2.ProductType = product.ProductType;
                product2.Technology = product.Technology;
            }
            catch (Exception ex)
            {
                //roduct2.Err = "Error to read product";
                //throw new Exception("Error to read product");
                product2.Err = "Error to read product";
            }

            return product2;
        }

        public static LayerEntityS GetLayerEntitys(string jsonLayer)
        {
            LayerEntityS layer2 = new LayerEntityS();
            try
            {
                LayerEntity layer = new LayerEntity();
                DataContractJsonSerializer serializer = new DataContractJsonSerializer(layer.GetType());
                System.IO.MemoryStream stream = new System.IO.MemoryStream(Encoding.Default.GetBytes(jsonLayer));
                layer = (LayerEntity)serializer.ReadObject(stream);

                layer2.Err = "OK";
                layer2.LayerId = layer.LayerId;
                layer2.Id = layer.Id;
                layer2.LayerName = string.IsNullOrEmpty(layer.LayerName)?"":layer.LayerName;
                layer2.PreLayer = string.IsNullOrEmpty(layer.PreLayer)?"":layer.PreLayer;
                layer2.StepName = string.IsNullOrEmpty(layer.StepName)?"":layer.StepName;
            }
            catch (Exception ex)
            {
                //roduct2.Err = "Error to read product";
                //throw new Exception("Error to read product");
                layer2.Err = "Error to read Layer";
            }

            return layer2;
        }

      
    }
}
