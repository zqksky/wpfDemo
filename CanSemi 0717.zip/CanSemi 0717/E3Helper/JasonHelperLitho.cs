﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using E3Helper.Message.Entity;
using E3Helper.Message.Entity.Litho;
namespace E3Helper.Message
{
    public class JasonHelperLitho
    {
        /// <summary>
        /// 
        /// </summary>
        public static string ConvertToColumns4LithoModel(string[] cdHeaders, string[] cdFields, string[] ovlHeaders, string[] ovlFields)
        {
            LithoModelColumnEntity col = new LithoModelColumnEntity();
            col.CDCols = new List<ColumnEntity>();
            col.OVLCols = new List<ColumnEntity>();

            for (int i = 0; i < cdHeaders.Length; i++)
            {
                col.CDCols.Add(new ColumnEntity { ColumnName = cdHeaders[i], FieldName = cdFields[i] });
            }

            for (int i = 0; i < ovlHeaders.Length; i++)
            {
                col.OVLCols.Add(new ColumnEntity { ColumnName = ovlHeaders[i], FieldName = ovlFields[i] });
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(col.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, col);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="layerIds"></param>
        /// <returns></returns>
        public static string ConvertCDRows4LithoModel(string[] toolId, string[] productId, string[] layerId, string[] reticleId, string[] recipeId, string[] mode, string[] ctlFlag, string[] lastEstiTime, string cdName, string focusName, string[] cd, string[] focus)
        {
            List<CDContextRow> rows = new List<CDContextRow>();
            for (int i = 0; i < toolId.Length; i++)
            {
                CDContextRow row = new CDContextRow();
                row.ToolId = toolId[i];
                row.ProductId = productId[i];
                row.LayerId = layerId[i];
                row.ReticleId = reticleId[i];
                row.RecipeId = recipeId[i];
                row.Chuck = "NA";
                row.CtlFlag = ctlFlag[i];
                row.Mode = mode[i];
                row.LastEstiTime = lastEstiTime[i];
                row.Parameters = new List<ParameterEntity>();
                row.Parameters.Add(new ParameterEntity { ParameterName = cdName, ParameterVaue = cd[i] });
                row.Parameters.Add(new ParameterEntity { ParameterName = focusName, ParameterVaue = focus[i] });
                rows.Add(row);
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(rows.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, rows);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertOVLRows4LithoModel(string[] toolId, string[] productId, string[] layerId, string[] reticleId, string[] recipeId, string[] preTool,string[] preReticle,string[] chuckId,string[] mode, string[] ctlFlag, string[] lastEstiTime, string ovlNames,  string[] ovlValues)
        {
            List<OVLContextRow> rows = new List<OVLContextRow>();
            string[] ovls = ovlNames.Split(',');
            for (int i = 0; i < toolId.Length; i++)
            {
                OVLContextRow row = new OVLContextRow();
                row.ToolId = toolId[i];
                row.ProductId = productId[i];
                row.LayerId = layerId[i];
                row.ReticleId = reticleId[i];
                row.RecipeId = recipeId[i];
                row.PreTool = preTool[i];
                row.PreReticle = preReticle[i];
                row.Chuck = chuckId[i];
                row.CtlFlag = ctlFlag[i];
                row.Mode = mode[i];
                row.LastEstiTime = lastEstiTime[i];
                row.Parameters = new List<ParameterEntity>();
                string[] vals = ovlValues[i].Split(',');
                for(int j = 0 ;j < ovls.Length; j++)
                {
                    row.Parameters.Add(new ParameterEntity { ParameterName = ovls[j], ParameterVaue = vals[j] });
                }

                rows.Add(row);
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(rows.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, rows);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string GetContextContentOVL()
        {
            OVLContextContent ovl = new OVLContextContent();
            ovl.ProductId = "Prod1";
            ovl.ToolId = "tool";
            ovl.LayerId = "laer";
            ovl.ReticleId = "gg";
            ovl.PreTool = "pretol";
            ovl.PreReticle = "prereticle";
            ovl.parametersRows = new List<ParameterRow>();
            ovl.specConfig = new OVLSpecConfigContent();
            ovl.specConfig.LayerId = "100";
            ovl.specConfig.Lambda = 1;
            ovl.ToolId = "tol";
            ParameterRow row = new ParameterRow();
            row.Chamber = new ChamberEntity { ToolId = "too", ChName = "A", ChBias = "CHA" };
            row.Tool = new ToolEntity { ToolId = "too" };
            row.ParameterName = "EXP_X";
            row.ParameterVaue = "0.00268";
            row.ParameterVaue1 = "0.000278";
            row.ParameterVaue2 = "0.0035";
            ovl.parametersRows.Add(row);

            ParameterRow row1 = new ParameterRow();
            row1.Chamber = new ChamberEntity { ToolId = "too", ChName = "A", ChBias = "CHA" };
            row1.Tool = new ToolEntity { ToolId = "too" };
            row1.ParameterName = "EXP_X";
            row1.ParameterVaue = "0.00268";
            row1.ParameterVaue1 = "0.000278";
            row1.ParameterVaue2 = "0.0035";
            row1.uCalc = "0.001001";
            row1.uCalc1 = "0.002001";
            row1.uCalc2 = "0.00020002";
            row1.ReworkBias = "0.0001";
            row1.RecipeName = "abcrecipe";
            ovl.parametersRows.Add(row1);

            row1 = new ParameterRow();
            row1.Chamber = new ChamberEntity { ToolId = "too", ChName = "A", ChBias = "CHA" };
            row1.Tool = new ToolEntity { ToolId = "too" };
            row1.ParameterName = "EXP_Y";
            row1.ParameterVaue = "0.002682";
            row1.ParameterVaue1 = "0.0002782";
            row1.ParameterVaue2 = "0.00352";
            row1.uCalc = "0.0010012";
            row1.uCalc1 = "0.0020012";
            row1.uCalc2 = "0.000200022";
            row1.ReworkBias = "0.0001";
            row1.RecipeName = "abcrecipe";
            ovl.parametersRows.Add(row1);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(ovl.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, ovl);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string GetContextContentCD()
        {
            CDContextContent cd = new CDContextContent();
            cd.ProductId = "Prod1";
            cd.ToolId = "tool";
            cd.LayerId = "laer";
            cd.ReticleId = "gg";
            cd.RecipeId = "rec";
            cd.parametersRows = new List<ParameterRow>();
            cd.specConfig = new CDSpecConfigContent();
            cd.specConfig.LayerId = "100";
            cd.specConfig.Lambda = 1;
            cd.ToolId = "tol";
            ParameterRow row = new ParameterRow();
            row.Chamber = new ChamberEntity { ToolId = "too", ChName = "A",ChBias="CHA" };
            row.Tool = new ToolEntity { ToolId = "too" };
            row.ParameterName = "EXP_X";
            row.ParameterVaue = "0.00268";
            row.ParameterVaue1 = "0.000278";
            row.ParameterVaue2 = "0.0035";
            cd.parametersRows.Add(row);

            ParameterRow row1 = new ParameterRow();
            row1.Chamber = new ChamberEntity { ToolId = "too", ChName = "A", ChBias = "CHA" };
            row1.Tool = new ToolEntity { ToolId = "too" };
            row1.ParameterName = "EXP_X";
            row1.ParameterVaue = "0.00268";
            row1.ParameterVaue1 = "0.000278";
            row1.ParameterVaue2 = "0.0035";
            row1.uCalc = "0.001001";
            row1.uCalc1 = "0.002001";
            row1.uCalc2 = "0.00020002";
            row1.ReworkBias = "0.0001";
            row1.RecipeName = "abcrecipe";
            cd.parametersRows.Add(row1);

            row1 = new ParameterRow();
            row1.Chamber = new ChamberEntity { ToolId = "too", ChName = "A", ChBias = "CHA" };
            row1.Tool = new ToolEntity { ToolId = "too" };
            row1.ParameterName = "EXP_Y";
            row1.ParameterVaue = "0.002682";
            row1.ParameterVaue1 = "0.0002782";
            row1.ParameterVaue2 = "0.00352";
            row1.uCalc = "0.0010012";
            row1.uCalc1 = "0.0020012";
            row1.uCalc2 = "0.000200022";
            row1.ReworkBias = "0.0001";
            row1.RecipeName = "abcrecipe";
            cd.parametersRows.Add(row1);

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(cd.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, cd);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertSpecialJobRow()
        {
            List<SpecialJobRow> rows = new List<SpecialJobRow>();

            SpecialJobRow sjr = new SpecialJobRow();
            sjr.JobId = "2019094001";
            sjr.C2CFlag = "Y";
            sjr.ControlMode = "T1M0R0F1";
            sjr.CreateBy = "Roy";
            sjr.CreateTime="20190223 15:09:10";
            sjr.FEMFlag = "N";
            sjr.LayerId = "CT";
            sjr.OVLMode = "LINEAR";
            sjr.ProductId = "0025D01-000-A";
            sjr.RecipeId = "9iuwwew@983434";
            sjr.ReticleId = "0025-00-000010";
            sjr.RunCardId = "NA";
            sjr.SplitId = "NA";
            sjr.ToolId = "ALIMIA01";
            sjr.UsedTime = "";
            sjr.WaferCnt = "2";
            rows.Add(sjr);

            SpecialJobRow sjr1 = new SpecialJobRow();
            sjr1.JobId = "2019094001";
            sjr1.C2CFlag = "Y";
            sjr1.ControlMode = "T1M0R0F1";
            sjr1.CreateBy = "Roy";
            sjr1.CreateTime = "20190223 15:09:10";
            sjr1.FEMFlag = "N";
            sjr1.LayerId = "CT";
            sjr1.OVLMode = "LINEAR";
            sjr1.ProductId = "0025D01-000-A";
            sjr1.RecipeId = "9iuwwew@983434";
            sjr1.ReticleId = "0025-00-000010";
            sjr1.RunCardId = "RunCardId-0001";
            sjr1.SplitId = "SplitId-0001";
            sjr1.ToolId = "ALIMIA01";
            sjr1.UsedTime = "";
            sjr1.WaferCnt = "2";
            rows.Add(sjr1);
            ///
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(rows.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, rows);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertSpecialJobParameters()
        {
            SpecialJobRow sjr = new SpecialJobRow();
            sjr.JobId = "2019094001";
            sjr.C2CFlag = "Y";
            sjr.ControlMode = "T1M0R0F1";
            sjr.CreateBy = "Roy";
            sjr.CreateTime = "20190223 15:09:10";
            sjr.FEMFlag = "N";
            sjr.LayerId = "CT";
            sjr.OVLMode = "LINEAR";
            sjr.ProductId = "0025D01-000-A";
            sjr.RecipeId = "9iuwwew@983434";
            sjr.ReticleId = "0025-00-000010";
            sjr.RunCardId = "NA";
            sjr.SplitId = "NA";
            sjr.ToolId = "ALIMIA01";
            sjr.UsedTime = "";
            sjr.WaferCnt = "2";

            sjr.cdParameters = new List<ParameterRow>();
            ParameterRow p1 = new ParameterRow { ParameterName = "DSOE", ParameterVaue = "28.03" };
            ParameterRow p2 = new ParameterRow { ParameterName = "FOUCS", ParameterVaue = "0.58" };
            sjr.cdParameters.Add(p1);
            sjr.cdParameters.Add(p2);

            sjr.ovlParameters = new List<ParameterRow>();
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "EXP_X", ParameterVaue = "0.001" ,  ParameterVaue1="0.0011" , ParameterVaue2="0.0021" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "EXP_Y", ParameterVaue = "0.002",   ParameterVaue1 = "0.0012", ParameterVaue2 = "0.0022" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "NON_ORT", ParameterVaue = "0.003", ParameterVaue1 = "0.0013", ParameterVaue2 = "0.0023" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "WFR_ROT", ParameterVaue = "0.004", ParameterVaue1 = "0.0014", ParameterVaue2 = "0.0024" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "TRANS_X", ParameterVaue = "0.005", ParameterVaue1 = "0.0015", ParameterVaue2 = "0.0025" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "TRANS_Y", ParameterVaue = "0.006", ParameterVaue1 = "0.0016", ParameterVaue2 = "0.0026" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "ASYM_MAG", ParameterVaue = "0.007", ParameterVaue1 = "0.0017", ParameterVaue2 = "0.0027" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "ASYM_ROT", ParameterVaue = "0.008", ParameterVaue1 = "0.0018", ParameterVaue2 = "0.0028" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "SHT_MAG", ParameterVaue = "0.009", ParameterVaue1 = "0.0019", ParameterVaue2 = "0.0029" });
            sjr.ovlParameters.Add(new ParameterRow { ParameterName = "SHT_ROT", ParameterVaue = "0.010", ParameterVaue1 = "0.0020", ParameterVaue2 = "0.0030" });
            ///
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(sjr.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, sjr);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }
            return jsonText;

        }
    }
}
