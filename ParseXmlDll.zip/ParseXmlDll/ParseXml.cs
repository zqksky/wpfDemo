﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using System.Threading;

namespace ParseXmlDll
{
    public class ParseXml
    {
        #region InitMap
        private System.Collections.Hashtable InitMap()
        {
            System.Collections.Hashtable htMap = new System.Collections.Hashtable();

            htMap.Add("Start", "eventInfo");
            htMap.Add("StartSub", "InputData");
            htMap.Add("DataArray", "");
            htMap.Add("And", "MergedPathCount");
            htMap.Add("AppCmd", "");
            htMap.Add("CallSub", "OutputData");
            htMap.Add("Case", "");
            htMap.Add("DataCache", "");
            htMap.Add("DataFilter", "DataFilter");
            htMap.Add("DataSet", "DataSet");
            htMap.Add("StringOps", "Output");
            htMap.Add("Math", "MathResult");
            htMap.Add("DBRead", "Read_Output");
            htMap.Add("DBWrite", "");
            htMap.Add("DTConvert", "DTCovertOutput");
            htMap.Add("ArrayOps", "Operation_Output");
            htMap.Add("End", "");
            htMap.Add("EndSub", "OutputData");
            htMap.Add("FaultSub", "FaultInfo");
            htMap.Add("Invoke", "");
            htMap.Add("Loop", "LoopInfo");
            htMap.Add("Catch", "StrategyException");
            htMap.Add("OR", "DataSet");
            htMap.Add("Param", "Context");
            //htMap.Add("Param", "ParametersOutput");
            htMap.Add("Timer", "TimerBlock");
            htMap.Add("Stats", "StatsResults");
            htMap.Add("Controller", "uReccommended");
            //htMap.Add("Controller", "Optimization");
            htMap.Add("MatrixMath", "MatrixMathResult");
            htMap.Add("Model", "LinearSSModel");
            htMap.Add("R2R_Read", "Result");
            htMap.Add("R2R_Write", "Result");
            htMap.Add("ReadHzn", "HorizonData");
            htMap.Add("ResetHorizon", "ResetHorizon");
            htMap.Add("StateEst", "xEstimate");

            return htMap;
        }

        private string GetOutputType(string strInputKey, ref string strOuputKey)
        {
            System.Collections.Hashtable htMap = new System.Collections.Hashtable();
            htMap = InitMap();

            string strOutputType = strInputKey;
            if (strInputKey.Equals("Param"))
            {
                strOuputKey = "//Context";
            }
            else if (strInputKey.Equals("Controller"))
            {
                strOuputKey = "//uReccommended";
            }
            else if (strInputKey.Equals("Model"))
            {
                strOuputKey = "//LinearSSModel";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("R2R_Read"))
            {
                strOuputKey = "//Result";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("StateEst"))
            {
                strOuputKey = "//xEstimate";
                strOutputType = "Special";
            }
            else if (strInputKey.Equals("Invoke"))
            {
                strOutputType = "Invoke";
            }
            else if (htMap.Contains(strInputKey))
            {
                strOuputKey = htMap[strInputKey].ToString();
                if (strOuputKey.Equals(""))
                {
                    strOutputType = "Unspecified";
                }
                else
                {
                    strOuputKey = "//" + strOuputKey;
                    strOutputType = "Specified";
                }
            }
            else
            {
                strOutputType = "Other";
            }
            return strOutputType;
        }
        #endregion

        #region DebugToXml
        private bool IsXml(string strXml)
        {
            try
            {
                XmlDocument xml = new XmlDocument();
                xml.LoadXml(strXml);//判断是否加载成功
                return true;//是xml文件，返回
            }
            catch
            {
                return false;//不是xml文件，返回
            }
        }

        private byte[] Decompress(string strGzipPath)
        {
            byte[] bytes = GetFileData(strGzipPath);
            using (var compressStream = new MemoryStream(bytes))
            {
                using (var zipStream = new GZipStream(compressStream, CompressionMode.Decompress))
                {
                    using (var resultStream = new MemoryStream())
                    {
                        zipStream.CopyTo(resultStream);
                        return resultStream.ToArray();
                    }
                }
            }
        }

        private byte[] GetFileData(string fileUrl)
        {
            FileStream fs = new FileStream(fileUrl, FileMode.Open, FileAccess.Read);
            try
            {
                byte[] buffur = new byte[fs.Length];
                fs.Read(buffur, 0, (int)fs.Length);

                return buffur;
            }
            catch (Exception ex)
            {
                //MessageBoxHelper.ShowPrompt(ex.Message);
                return null;
            }
            finally
            {
                if (fs != null)
                {

                    //关闭资源
                    fs.Close();
                }
            }
        }

        private string DebugToXml(string strDebugFilePath)
        {
            string strXml = "";
            if (File.Exists(strDebugFilePath))
            {
                byte[] bytes;
                bytes = Decompress(strDebugFilePath);

                strXml = Encoding.UTF8.GetString(bytes);
            }
            return strXml;
        }
        #endregion

        #region Define param
        private string processLogXml;
        //public string ProcessLogXml
        //{
        //    get
        //    {
        //        return processLogXml;
        //    }

        //    //set
        //    //{
        //    //    processLogXml = value;
        //    //}
        //}
        #endregion

        #region
        #region 反序列化
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="xml">XML字符串</param>
        /// <returns></returns>
        private object Deserialize(Type type, string xml)
        {
            using (StringReader sr = new StringReader(xml))
            {
                XmlSerializer xmldes = new XmlSerializer(type);
                return xmldes.Deserialize(sr);
            }
        }
        /// <summary>
        /// 反序列化
        /// </summary>
        /// <param name="type"></param>
        /// <param name="xml"></param>
        /// <returns></returns>
        private object Deserialize(Type type, Stream stream)
        {
            XmlSerializer xmldes = new XmlSerializer(type);
            return xmldes.Deserialize(stream);
        }
        #endregion

        #region 序列化
        /// <summary>
        /// 序列化
        /// </summary>
        /// <param name="type">类型</param>
        /// <param name="obj">对象</param>
        /// <returns></returns>
        private string Serializer(Type type, object obj)
        {
            MemoryStream Stream = new MemoryStream();
            XmlSerializer xml = new XmlSerializer(type);
            //序列化对象
            xml.Serialize(Stream, obj);
            Stream.Position = 0;
            StreamReader sr = new StreamReader(Stream);
            string str = sr.ReadToEnd();

            sr.Dispose();
            Stream.Dispose();

            return str;
        }

        #endregion
        #endregion

        #region GetPath

        //test use, marked by yang 2019/3/29
        public string GetDebugFilePath(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag)
        {
            string strDebugPath = GetDebugPath(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag);

            return string.IsNullOrEmpty(strDebugPath)?"na":strDebugPath;
        }
        private string GetDebugPath(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag)
        {
            string strDebugPath = string.Empty;
            string strTransactionTagTmp = strTransactionTag;
            string searchlike = "*" + strEngineName + ".Debugger." + strMachineName + ".*";
            int retrycnt = 0;

            try
            {
                if (Directory.Exists(strRootPath))
                {
                    if (strTransactionTagTmp.Contains("@"))
                    {
                        strTransactionTagTmp = strTransactionTagTmp.Substring(0, strTransactionTagTmp.IndexOf("@"));
                    }
                    else
                    {
                        strTransactionTagTmp = strTransactionTag;
                    }
                    DirectoryInfo directoryInfo = new DirectoryInfo(strRootPath);
                    Label:
                    foreach (FileSystemInfo folder in directoryInfo.GetFileSystemInfos(searchlike).OrderByDescending(s => s.LastWriteTime))
                    {  
                        //modified by yang 2019/3/29
                        if (folder is DirectoryInfo)
                        {
                            DirectoryInfo logfolder = new DirectoryInfo(folder.FullName);
                            try
                            {
                                strDebugPath = logfolder.GetFileSystemInfos("*.strategyDbg").
                                    Where(s => s.FullName.Contains(strStrategyName) && s.FullName.Contains(strTransactionTagTmp)).FirstOrDefault().FullName;
                                break;
                            }
                            catch { }
                        }
                    }
                    if (string.IsNullOrEmpty(strDebugPath))
                    {
                        retrycnt += 1;  //retry 3 times  by yang 2019/3/29
                        if (retrycnt <= 3)
                        {
                            Thread.Sleep(5000);
                            goto Label;
                        }
                    }
                }
                else
                {
                    strDebugPath = "DirectoryNotExist";
                }
            }
            catch (Exception ee)
            {
                strDebugPath = ee.ToString();
                //MessageBox.Show(ee.ToString());
            }
            return strDebugPath;
        }
        #endregion

        #region GetStructKeyBlockData
        private List<structKeyBlockData> GetStructKeyBlockDataSingle(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.BIsNull = true;
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(@"C:\YMTC\TestProcessLog TestDll\TestProcessLog\bin\x86\Debug\R2R_PH_MAIN_PostMetrologyOVL.xml");

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                        if (nodeStrategyExeInfo != null)
                        {
                            nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                        else
                        {
                            nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                    }
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        //by zqk 20190128 modify
                        List<string> strListInputName = new List<string>();
                        List<string> strListInputData = new List<string>();
                        List<string> strListOutputName = new List<string>();
                        List<string> strListOutputData = new List<string>();

                        string strSubStrategyName = nodeExeInfo.ParentNode.ParentNode.SelectSingleNode("child::StrategyName").InnerText;

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.BIsNull = false;
                        structData.SubStrategyName = strSubStrategyName;
                        structData.KeyBlockInstanceId = strInstanceId;
                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        public structKeyBlockData[] GetStructKeyBlockData(string strRootPath, string strEngineName, string strMachineName,string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;

            //add strMachineName for retriving debugger log from right server, by yang 2019/3/28

            // (string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag)
            strDebugPath = GetDebugPath(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag);

            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {

                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                            structListKeyBlockData = GetStructKeyBlockDataSingle(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (structListKeyBlockData.Count > 1)
                            {
                                int n = 0;
                                foreach (var structKeyBlockData in structListKeyBlockData)
                                {
                                    structListKeyBlockDataAll.Add(structKeyBlockData);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                        }
                    }
                }
                catch (Exception err)
                {
                }
            }
            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }

        public int GetStructKeyBlockDataNumber(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            int n = 0;

            n = GetStructKeyBlockData(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).Length;

            return n;
        }

        private structAllData GetStructAllDataTest(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            structAllData myStruct = new structAllData();

            myStruct.strXml = GetProcessLogXmlSerialize(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId, iArrayPriority);
            myStruct.arrayStructKeyBlockData = GetStructKeyBlockData(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId, iArrayPriority);
            myStruct.numer = myStruct.arrayStructKeyBlockData.Length;

            return myStruct;
        }

        public structAllData GetStructAllData(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;

            strDebugPath = GetDebugPath(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag);

            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            structAllData myStruct = new structAllData();
            myStruct.numer = 0;
            myStruct.strXml = string.Empty;
            myStruct.arrayStructKeyBlockData = structListKeyBlockDataAll.ToArray();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {

                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                            structListKeyBlockData = GetStructKeyBlockDataSingle(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (structListKeyBlockData.Count > 1)
                            {
                                int n = 0;
                                foreach (var structKeyBlockData in structListKeyBlockData)
                                {
                                    structListKeyBlockDataAll.Add(structKeyBlockData);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                        }
                    }
                }
                catch (Exception err)
                {
                }
            }
            //return structListKeyBlockDataAll.ToArray();
            myStruct.numer = structListKeyBlockDataAllSort.Count;
            myStruct.strXml = GetProcessLogXmlSerialize(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId,iArrayPriority);
            myStruct.arrayStructKeyBlockData = structListKeyBlockDataAllSort.ToArray();
            return myStruct;
        }
        #endregion

        #region GetXml
        private string GetProcessLogXmlSingleSerialize(structKeyBlockDataSerialize structData)
        {
            //string xml = XmlSerializeHelp.Serializer(typeof(structKeyBlockDataSerialize), structData);
            string xml = Serializer(typeof(structKeyBlockDataSerialize), structData);
            return xml;
        }

        private List<structKeyBlockDataSerialize> GetStructKeyBlockDataSingleSerialize(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
            structKeyBlockDataSerialize structData = new structKeyBlockDataSerialize();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
                //doc.Load(strXmlPath);

                XmlNode nodeStrategyExeInfo = null;
                XmlNodeList nodeExeInfoList = null;

                //nodeStrategyExeInfo = doc.SelectSingleNode("//ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                //if (nodeStrategyExeInfo != null)
                //{
                //    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                //}
                //else
                //{
                //    nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                //    if (nodeStrategyExeInfo != null)
                //    {
                //        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                //    }
                //    else
                //    {
                //        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                //    }
                //}

                nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                if (nodeStrategyExeInfo != null)
                {
                    nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                }
                else
                {
                    nodeStrategyExeInfo = doc.SelectSingleNode("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                    if (nodeStrategyExeInfo != null)
                    {
                        nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                    else
                    {
                        nodeStrategyExeInfo = doc.SelectSingleNode("//StrategyExeInfo" + "[StrategyName='" + strStrategyName + "']");
                        if (nodeStrategyExeInfo != null)
                        {
                            nodeExeInfoList = nodeStrategyExeInfo.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                        else
                        {
                            nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo" + "[StrategyName = '" + strStrategyName + "']" + "/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                        }
                    }
                }
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        List<string> strListInputName = new List<string>();
                        List<string> strListInputData = new List<string>();
                        List<string> strListOutputName = new List<string>();
                        List<string> strListOutputData = new List<string>();

                        string strSubStrategyName = nodeExeInfo.ParentNode.ParentNode.SelectSingleNode("child::StrategyName").InnerText;

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.SubStrategyName = strSubStrategyName;
                        structData.KeyBlockInstanceId = strInstanceId;
                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        private structKeyBlockDataSerialize[] GetStructKeyBlockDataSerialize(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strDebugPath = string.Empty;

            strDebugPath = GetDebugPath(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag);

            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            List<structKeyBlockDataSerialize> structListKeyBlockDataAllSort = new List<structKeyBlockDataSerialize>();

            if (strDebugPath.Equals(""))
            {
            }
            else
            {
                List<int> iListPriority = new List<int>(iArrayPriority.ToList());
                List<int> iListSortIndex = new List<int>();

                try
                {
                    if (strArraySubStrategyName.Length == strArrayInstanceId.Length)
                    {

                        for (int i = 0; i < strArrayInstanceId.Length; i++)
                        {
                            List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
                            structListKeyBlockData = GetStructKeyBlockDataSingleSerialize(strDebugPath, strArraySubStrategyName[i], strArrayInstanceId[i]);
                            if (structListKeyBlockData.Count > 1)
                            {
                                int n = 0;
                                foreach (var structKeyBlockData in structListKeyBlockData)
                                {
                                    structListKeyBlockDataAll.Add(structKeyBlockData);
                                    if (n > 0)
                                    {
                                        iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                    }
                                    n++;
                                }
                            }
                            else
                            {
                                structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                            }
                        }
                        iListSortIndex = GetSortIndex(iListPriority);
                    }

                    if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                    {
                        for (int i = 0; i < iListSortIndex.Count; i++)
                        {
                            structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                        }
                    }
                }
                catch (Exception err)
                {
                }
            }
            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }

        public string GetProcessLogXmlSerialize(string strRootPath, string strEngineName, string strMachineName, string strStrategyName, string strTransactionTag, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strXmlResult = "";
            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            try
            {
                structListKeyBlockDataAll = GetStructKeyBlockDataSerialize(strRootPath, strEngineName, strMachineName, strStrategyName, strTransactionTag, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).ToList();

                //strXmlResult = XmlSerializeHelp.Serializer(typeof(List<structKeyBlockData>), structListKeyBlockDataAll);
                strXmlResult = Serializer(typeof(List<structKeyBlockDataSerialize>), structListKeyBlockDataAll);           
            }
            catch (Exception err)
            {
            }
            //strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";
            return strXmlResult;
        }
        #endregion

        #region GetStructKeyBlockData Test
        private List<structKeyBlockData> GetStructKeyBlockDataSingleTest(string strDebugPath, string strStrategyName, string strInstanceId)
        {
            List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
            structKeyBlockData structData = new structKeyBlockData();
            structData.OutputId = "";
            structData.SubStrategyName = strStrategyName;
            structData.KeyBlockInstanceId = strInstanceId;
            structData.InputName = new List<string>();
            structData.InputValue = new List<string>();
            structData.OutputName = new List<string>();
            structData.OutputValue = new List<string>();

            XmlDocument doc = new XmlDocument();
            try
            {
                string strXml = DebugToXml(strDebugPath);
                doc.LoadXml(strXml);
   
                XmlNodeList nodeExeInfoList = null;
                XmlNodeList nodeStrategyExeInfoList = null;
                nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName");
                if (nodeStrategyExeInfoList == null)
                {
                    nodeStrategyExeInfoList = doc.SelectNodes("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/StrategyName");
                }
                bool bIsSubStrategyName = false;
                if (nodeStrategyExeInfoList.Count > 0)
                {
                    foreach (XmlNode node in nodeStrategyExeInfoList)
                    {
                        if (node.InnerText.Contains(strStrategyName))
                        {
                            bIsSubStrategyName = true;
                            nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                            if (nodeExeInfoList == null)
                            {
                                nodeExeInfoList = doc.SelectNodes("//SubStrategyExeInfo/ExecutionSeq/ExeInfo/SubStrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                            }
                            break;
                        }
                    }
                }
                if (!bIsSubStrategyName)
                {
                    bool bStrategyName = false;
                    nodeStrategyExeInfoList = doc.SelectNodes("//StrategyExeInfo/StrategyName");
                    if (nodeStrategyExeInfoList.Count > 0)
                    {
                        foreach (XmlNode node in nodeStrategyExeInfoList)
                        {
                            if (node.InnerText.Contains(strStrategyName))
                            {
                                bStrategyName = true;
                                nodeExeInfoList = node.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                                break;
                            }
                        }
                    }
                    if (!bStrategyName)
                    {
                        nodeExeInfoList = doc.SelectNodes("//StrategyExeInfo/ExecutionSeq/ExeInfo" + "[InstanceId='" + strInstanceId + "']");
                    }
                }
 
                if (nodeExeInfoList.Count > 0)
                {
                    foreach (XmlNode nodeExeInfo in nodeExeInfoList)
                    {
                        string strId = "";
                        string strOutputId = "";
                        string strOutputKey = "";
                        string strOutputType = "";

                        List<string> strListInputName = new List<string>();
                        List<string> strListInputData = new List<string>();
                        List<string> strListOutputName = new List<string>();
                        List<string> strListOutputData = new List<string>();

                        string strSubStrategyName = nodeExeInfo.ParentNode.ParentNode.SelectSingleNode("child::StrategyName").InnerText;

                        strId = nodeExeInfo.SelectSingleNode("child::Id").InnerText;
                        strOutputType = GetOutputType(strId, ref strOutputKey);

                        XmlNodeList nodesInput = nodeExeInfo.SelectNodes("child::Inputs/InputParameter");
                        foreach (XmlNode itemInput in nodesInput)
                        {
                            string strInputXml = itemInput.InnerXml;
                            string strInputName = itemInput.SelectSingleNode("child::Name").InnerText;
                            string strInputData = itemInput.SelectSingleNode("child::Data").InnerText;

                            GetInputValue(strInputData, strInputName, ref strListInputName, ref strListInputData);
                        }

                        XmlNodeList nodesOutput = nodeExeInfo.SelectNodes("child::Output");
                        foreach (XmlNode itemOutput in nodesOutput)
                        {
                            string strOutputData = string.Empty;
                            string strOutputXml = itemOutput.InnerXml;
                            strOutputId = itemOutput.SelectSingleNode("child::Id").InnerText;
                            strOutputData = itemOutput.SelectSingleNode("child::Data").InnerText;

                            bool bIsXml = IsXml(strOutputData);
                            if (bIsXml)
                            {
                                List<string> strListName = new List<string>();
                                List<string> strListData = new List<string>();

                                GetOutputValue(strOutputData, strOutputKey, strOutputType, ref strListName, ref strListData);

                                strListOutputName = new List<string>(strListName);
                                strListOutputData = new List<string>(strListData);
                            }
                        }

                        structData.SubStrategyName = strSubStrategyName;
                        structData.KeyBlockInstanceId = strInstanceId;
                        structData.OutputId = strOutputId;
                        structData.InputName = new List<string>(strListInputName);
                        structData.InputValue = new List<string>(strListInputData);
                        structData.OutputName = new List<string>(strListOutputName);
                        structData.OutputValue = new List<string>(strListOutputData);

                        structListKeyBlockData.Add(structData);
                    }
                }
                else
                {
                    structListKeyBlockData.Add(structData);
                }
            }
            catch (Exception err)
            {
            }
            finally
            {
                doc.RemoveAll();
                doc = null;
            }


            return structListKeyBlockData;
        }

        public structKeyBlockData[] GetStructKeyBlockData(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            //structKeyBlockData[] strArrayStructSort = new structKeyBlockData[strArrayInstanceId.Length];
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {
                    
                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                        structListKeyBlockData = GetStructKeyBlockDataSingle(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (structListKeyBlockData.Count > 1)
                        {
                            int n = 0;
                            foreach (var structKeyBlockData in structListKeyBlockData)
                            {
                                structListKeyBlockDataAll.Add(structKeyBlockData);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n-1 + i, iArrayPriority[i]);                                    
                                }
                                n++;
                            }
                        }
                        else
                        {
                            structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                    }
                }
            }
            catch (Exception err)
            {
            }

            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataAllSort.ToArray();
        }

        public structAllData GetStructAllData(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            List<structKeyBlockData> structListKeyBlockDataAll = new List<structKeyBlockData>();
            List<structKeyBlockData> structListKeyBlockDataAllSort = new List<structKeyBlockData>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            structAllData myStruct = new structAllData();
            myStruct.numer = 0;
            myStruct.strXml = string.Empty;
            myStruct.arrayStructKeyBlockData = structListKeyBlockDataAll.ToArray();

            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {

                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<structKeyBlockData> structListKeyBlockData = new List<structKeyBlockData>();
                        structListKeyBlockData = GetStructKeyBlockDataSingle(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (structListKeyBlockData.Count > 1)
                        {
                            int n = 0;
                            foreach (var structKeyBlockData in structListKeyBlockData)
                            {
                                structListKeyBlockDataAll.Add(structKeyBlockData);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                }
                                n++;
                            }
                        }
                        else
                        {
                            structListKeyBlockDataAll.Add(structListKeyBlockData[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (structListKeyBlockDataAll.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        structListKeyBlockDataAllSort.Add(structListKeyBlockDataAll[iListSortIndex[i]]);
                    }
                }
            }
            catch (Exception err)
            {
            }

            //return structListKeyBlockDataAll.ToArray();
            myStruct.numer = structListKeyBlockDataAllSort.Count;
            myStruct.strXml = GetProcessLogXmlSerialize(strDebugPath, strArrayStrategyName, strArrayInstanceId,iArrayPriority);
            myStruct.arrayStructKeyBlockData = structListKeyBlockDataAllSort.ToArray();
            return myStruct;
        }

        public int GetStructKeyBlockDataNumber(string strDebugPath, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            int n = 0;

            n = GetStructKeyBlockData(strDebugPath, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).Length;

            return n;
        }
        #endregion

        #region GetXml Test
        private structKeyBlockDataSerialize[] GetStructKeyBlockDataSerialize(string strDebugPath, string[] strArrayStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerialize = new List<structKeyBlockDataSerialize>();
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerializeSort = new List<structKeyBlockDataSerialize>();

            List<int> iListPriority = new List<int>(iArrayPriority.ToList());
            List<int> iListSortIndex = new List<int>();

            //structKeyBlockData[] strArrayStructSort = new structKeyBlockData[strArrayInstanceId.Length];
            try
            {
                if (strArrayStrategyName.Length == strArrayInstanceId.Length)
                {

                    for (int i = 0; i < strArrayInstanceId.Length; i++)
                    {
                        List<structKeyBlockDataSerialize> structListKeyBlockData = new List<structKeyBlockDataSerialize>();
                        structListKeyBlockData = GetStructKeyBlockDataSingleSerialize(strDebugPath, strArrayStrategyName[i], strArrayInstanceId[i]);
                        if (structListKeyBlockData.Count > 1)
                        {
                            int n = 0;
                            foreach (var structKeyBlockData in structListKeyBlockData)
                            {
                                structListKeyBlockDataSerialize.Add(structKeyBlockData);
                                if (n > 0)
                                {
                                    iListPriority.Insert(n - 1 + i, iArrayPriority[i]);
                                }
                                n++;
                            }
                        }
                        else
                        {
                            structListKeyBlockDataSerialize.Add(structListKeyBlockData[0]);
                        }
                    }
                    iListSortIndex = GetSortIndex(iListPriority);
                }

                if (structListKeyBlockDataSerialize.Count == iListSortIndex.Count)
                {
                    for (int i = 0; i < iListSortIndex.Count; i++)
                    {
                        structListKeyBlockDataSerializeSort.Add(structListKeyBlockDataSerialize[iListSortIndex[i]]);
                    }
                }
            }
            catch (Exception err)
            {
            }

            //return structListKeyBlockDataAll.ToArray();
            return structListKeyBlockDataSerializeSort.ToArray();
        }

        public string GetProcessLogXmlSerialize(string strDebugPath, string[] strArraySubStrategyName, string[] strArrayInstanceId, int[] iArrayPriority)
        {
            string strXmlResult = "";
            List<structKeyBlockDataSerialize> structListKeyBlockDataSerialize = new List<structKeyBlockDataSerialize>();
            try
            {
                structListKeyBlockDataSerialize = GetStructKeyBlockDataSerialize(strDebugPath, strArraySubStrategyName, strArrayInstanceId, iArrayPriority).ToList();

                //strXmlResult = XmlSerializeHelp.Serializer(typeof(List<structKeyBlockData>), structListKeyBlockDataAll);

                strXmlResult = Serializer(typeof(List<structKeyBlockDataSerialize>), structListKeyBlockDataSerialize);
            }
            catch (Exception err)
            {
            }
            //strXmlResult = "<ArrayOfStrategyExeInfo>" + strXmlResult + "</ArrayOfStrategyExeInfo>";

            return strXmlResult;
        }

        public List<structKeyBlockDataSerialize> GetStructKeyBlockDataSerialize(string strXml)
        {
            List<structKeyBlockDataSerialize> structListKeyBlockDataAll = new List<structKeyBlockDataSerialize>();
            //structListKeyBlockDataAll = XmlSerializeHelp.Deserialize(typeof(List<structKeyBlockData>), strXml) as List<structKeyBlockData>;
            structListKeyBlockDataAll = Deserialize(typeof(List<structKeyBlockDataSerialize>), strXml) as List<structKeyBlockDataSerialize>;

            return structListKeyBlockDataAll;
        }
        #endregion

        #region StructKeyBlockDataArray Sort
        private List<int> GetSortIndex(List<int> iList)
        {
            List<int> iListResult = new List<int>();

            iListResult = iList.Select((item, index) => new { item, index }).OrderBy(a => a.item).Select(a => a.index).ToList();

            //var vList = iList.Select((m, index) => new { index, m }).OrderBy(n => n.m).Take(iList.Count).ToList();
            //foreach (var v in vList)
            //{
            //    iListResult.Add(v.index);
            //}

            return iListResult;
        }
        #endregion

        #region Get InputValue
        private void GetInputValue(string strXml, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                string strValue = string.Empty;
                bool bIsXml = IsXml(strXml);
                if (bIsXml)
                {
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(strXml);

                    //使用xPath选择需要的节点
                    XmlNodeList subNodes = doc.SelectNodes("child::*");//ParametersOutput;
                    foreach (XmlNode item in subNodes)
                    {
                        GetInputSubNodeValue(item, strNodeName, ref strListName, ref strListData);
                    }
                }
                else
                {
                    strListName.Add(strNodeName);
                    strListData.Add(strXml);
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetInputSubNodeValue(XmlNode subNode, string strInputName, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                string strValue = string.Empty;
                string strName = subNode.Name;

                XmlNodeList nodes = subNode.SelectNodes("child::*");
                if (nodes.Count > 0)
                {
                    int i = 0;
                    foreach (XmlNode item in nodes)
                    {
                        i++;
                        strListName.Add(strInputName + "." + i);
                        //strListName.Add(strInputName + "-" + strName + "." + i);
                        strListData.Add(item.InnerText);
                    }
                }
                else
                {
                    strListName.Add(strInputName + "-" + strName);
                    strListData.Add(subNode.InnerText);
                }
            }
            catch (Exception err)
            {

            }
        }
        #endregion

        #region Get OutputValue
        private void GetOutputValue(string strXml, string strOutputNode, string strOutputType, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                strListName.Clear();
                strListData.Clear();

                List<string> strListNameTmp = new List<string>();
                List<string> strListDataTmp = new List<string>();

                XmlDocument doc = new XmlDocument();
                doc.LoadXml(strXml);

                //使用xPath选择需要的节点
                XmlNodeList nodes = null;
                if (strOutputType.Equals("Unspecified"))
                {
                    nodes = doc.SelectNodes("child::*");
                    if (nodes.Count > 0)
                    {
                        GetOutputDataUnspecified(nodes, ref strListName, ref strListData);
                    }
                }
                else if (strOutputType.Equals("Param"))
                {
                    int type = 0;
                    nodes = doc.SelectNodes(strOutputNode); //strOutputNode = "//Context"
                    if (nodes.Count > 0)
                    {
                        type = 1;
                        //GetOutputDataParam(nodes, ref strListName, ref strListData);
                        GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                    }

                    nodes = doc.SelectNodes("//ParametersOutput");
                    if (nodes.Count > 0)
                    {
                        type = 2;
                        //GetOutputDataParam(nodes, ref strListNameTmp, ref strListDataTmp);
                        GetOutputData(nodes, strOutputType, ref strListNameTmp, ref strListDataTmp);//by zqk modify 20181226
                    }
                    if (type == 2)
                    {
                        for (int i = 0; i < strListNameTmp.Count; i++)
                        {
                            strListName.Add(strListNameTmp[i]);
                            strListData.Add(strListDataTmp[i]);
                        }
                    }
                    else if (type == 0)//ParameterBlockResult
                    {
                        nodes = doc.SelectNodes("//ParameterBlockResult");

                        if (nodes.Count > 0)
                        {
                            GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                        }
                    }
                }
                else if (strOutputType.Equals("Invoke"))
                {
                    nodes = doc.SelectNodes("child::*");
                    if (nodes.Count > 0)
                    {
                        GetOutputDataInvoke(nodes, ref strListName, ref strListData);
                    }
                }
                else //Controller   Special Specified
                {
                    nodes = doc.SelectNodes(strOutputNode);

                    if (nodes.Count > 0)
                    {
                        GetOutputData(nodes, strOutputType, ref strListName, ref strListData);
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        #region GetOutputData
        private void GetOutputData(XmlNodeList nodes, string strSpecial, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                switch (strSpecial)
                                {
                                    case "Specified":
                                        GetSubNodeDataSpecified(item2, ref strListName, ref strListData);
                                        break;
                                    case "Param":
                                        GetSubNodeDataParam(item2, ref strListName, ref strListData);
                                        break;
                                    case "Controller":
                                        GetSubNodeDataController(item2, ref strListName, ref strListData);
                                        break;
                                    case "Special":
                                        //GetSubNodeDataSpecial(item2, ref strListName, ref strListData);
                                        GetSubNodeDataSpecial(item2, item2.Name, ref strListName, ref strListData);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }
        #endregion

        #region Unspecified
        private void GetOutputDataUnspecified(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            int i = 0;
                            foreach (XmlNode item2 in nodes2)
                            {
                                i++;
                                GetSubNodeDataUnspecified(item2, item.Name + "." + i, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private void GetSubNodeDataUnspecified(XmlNode subNode, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strNodeName + "." + i);
                    //strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strNodeName);
                //strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Specified
        private void GetOutputDataSpecified(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataSpecified(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataSpecified(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Param
        private void GetOutputDataParam(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataParam(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataParam(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    strListName.Add(strName + "." + i);
                    strListData.Add(item.InnerText);
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Controller
        private void GetOutputDataController(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                GetSubNodeDataController(item2, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            string strName = item.Name;
                            strListName.Add(strName);

                            string strValue = item.InnerText;
                            strListData.Add(strValue);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataController(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            bool flag = false;
            string strValue = string.Empty;
            string strName = subNode.Name;

            if (strName.Equals("Value"))
            {
                flag = false;
                strName = "uReccommended";
            }
            else if (strName.Equals("Optimization"))
            {
                flag = true;
            }

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    if (flag)
                    {
                        strName = item.Name;
                        strListName.Add(strName);
                        strListData.Add(item.InnerText);
                    }
                    else
                    {
                        strListName.Add(strName + "." + i);
                        strListData.Add(item.InnerText);
                    }
                }
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Invoke
        private void GetOutputDataInvoke(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            int i = 0;
                            foreach (XmlNode item2 in nodes2)
                            {
                                i++;
                                GetSubNodeDataInvoke(item2, item.Name + "." + i, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            strListName.Add(item.Name);
                            strListData.Add(item.InnerText);
                        }
                    }
                }
            }
            catch (Exception ee)
            {

            }
        }

        private void GetSubNodeDataInvoke(XmlNode subNode, string strNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                    {
                        strListName.Add(strName + "." + i);
                    }
                    else
                    {
                        string strOutXml = GetOutputNameSpecial(item.OuterXml);
                        strListName.Add("<" + strName + ">" + "." + strOutXml);
                    }
                    strListData.Add(item.InnerText);
                }

                return;
            }
            else if (strName.Equals("string") || strName.Equals("double") || strName.Equals("int"))
            {
                strListName.Add(strNodeName);
                strListData.Add(subNode.InnerText);
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }
        #endregion

        #region Special (Model/R2R_Read/StateEst)
        private void GetOutputDataSpecial(XmlNodeList nodes, ref List<string> strListName, ref List<string> strListData)
        {
            try
            {
                if (nodes.Count > 0)
                {
                    strListName.Clear();
                    strListData.Clear();
                    foreach (XmlNode item in nodes)
                    {
                        XmlNodeList nodes2 = item.SelectNodes("child::*");
                        if (nodes2.Count > 0)
                        {
                            foreach (XmlNode item2 in nodes2)
                            {
                                //GetSubNodeDataSpecial(item2, ref strListName, ref strListData);
                                GetSubNodeDataSpecial(item2, item2.Name, ref strListName, ref strListData);
                            }
                        }
                        else
                        {
                            strListName.Add(item.Name);
                            strListData.Add(item.InnerText);
                        }
                    }
                }
            }
            catch (Exception err)
            {

            }
        }

        private void GetSubNodeDataSpecial(XmlNode subNode, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;
            string strName = subNode.Name;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    XmlNodeList subItems = item.SelectNodes("child::*");
                    if (subItems.Count > 0)
                    {
                        int n = 0;
                        string strSubName = item.Name;
                        foreach (XmlNode subItem in subItems)
                        {
                            n++;
                            if (subItem.Name.Equals("string") || subItem.Name.Equals("double") || subItem.Name.Equals("int"))
                            {
                                strListName.Add("<" + strName + ">" + "." + "<" + strSubName + ">" + "." + n);
                            }
                            else
                            {
                                string strOutXml = GetOutputNameSpecial(item.OuterXml);
                                strListName.Add("<" + strName + ">" + "." + strOutXml);
                            }
                            strListData.Add(subItem.InnerText);
                        }
                    }
                    else
                    {
                        if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                        {
                            strListName.Add(strName + "." + i);
                        }
                        else
                        {
                            string strOutXml = GetOutputNameSpecial(item.OuterXml);
                            strListName.Add("<" + strName + ">" + "." + strOutXml);
                        }
                        strListData.Add(item.InnerText);
                    }
                }

                return;
            }
            else
            {
                strListName.Add(strName);
                strListData.Add(subNode.InnerText);
            }
        }

        private void GetSubNodeDataSpecial(XmlNode subNode, string strSubNodeName, ref List<string> strListName, ref List<string> strListData)
        {
            string strValue = string.Empty;

            XmlNodeList nodes = subNode.SelectNodes("child::*");
            if (nodes.Count > 0)
            {
                int i = 0;
                foreach (XmlNode item in nodes)
                {
                    i++;
                    XmlNodeList subItems = item.SelectNodes("child::*");
                    if (subItems.Count > 0)
                    {
                        string strSubName = "<" + strSubNodeName + ">" + "." + "<" + item.Name + ">";
                        GetSubNodeDataSpecial(item, strSubName, ref strListName, ref strListData);
                    }
                    else
                    {
                        if (item.Name.Equals("string") || item.Name.Equals("double") || item.Name.Equals("int"))
                        {
                            strListName.Add(strSubNodeName + "." + i);
                        }
                        else
                        {
                            string strOutXml = GetOutputNameSpecial(item.OuterXml);
                            strListName.Add("<" + strSubNodeName + ">" + "." + strOutXml);
                        }
                        strListData.Add(item.InnerText);
                    }
                }

                return;
            }
            else
            {
                strListName.Add(strSubNodeName);
                strListData.Add(subNode.InnerText);
            }
        }

        private string GetOutputNameSpecial(string strOutXml)
        {
            string strName = "";
            if (strOutXml.Contains("</"))
            {
                strOutXml = strOutXml.Substring(0, strOutXml.IndexOf("</") - 1);
                strOutXml = strOutXml.Substring(0, strOutXml.LastIndexOf(">") + 1);

                strName = strOutXml.Replace(">", ">.");
                strName = strName.TrimEnd('.');
            }
            if (strName.Contains(".<string>"))
            {
                strName = strName.Replace(".<string>", "");
            }
            if (strName.Contains(".<double>"))
            {
                strName = strName.Replace(".<double>", "");
            }
            if (strName.Contains(".<int>"))
            {
                strName = strName.Replace(".<int>", "");
            }
            return strName;
        }

        private List<string> GetOutputDataSpecial(string strOutXml)
        {
            string str = string.Empty;
            List<string> strList = new List<string>();
            if (strOutXml.Contains("</string>"))
            {
                str = strOutXml.Replace("", "<string>");
                str = strOutXml.Replace(";", "</string>");
            }
            if (strOutXml.Contains("</doule>"))
            {
                str = strOutXml.Replace("", "<double>");
                str = strOutXml.Replace(";", "</double>");
            }
            if (strOutXml.Contains("</int>"))
            {
                str = strOutXml.Replace("", "<int>");
                str = strOutXml.Replace(";", "</int>");
            }
            string[] strSplit = str.Split(';');
            strList = strSplit.ToList();
            return strList;
        }

        #endregion

        #endregion

    }
}
