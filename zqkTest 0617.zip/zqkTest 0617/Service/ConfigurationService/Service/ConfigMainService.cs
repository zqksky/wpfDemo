﻿using ConfigurationService.IService;
using ConfigurationService.Models;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.CommonEntity;
using R2R.Common.Data.E3Entities.ConfigUI;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ConfigurationService.Service
{
    public class ConfigMainService: IConfigMainService
    {
        #region Webservice Fun
        public List<string> GetModuleList(string userId, string clientVersion)
        {
            MyLogger.Trace("ConfigMainService.GetModuleList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigMainService.GetModuleList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    if (result.ReturnCode == 0)
                    {
                        //List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        //foreach (ProductEntity product in productList)
                        //{
                        //    strList.Add(product.ProductId);
                        //}
                        //return strList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetModuleList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return null;
        }
        public List<string> GetProductList(string userId, string clientVersion, string moduleId)
        {
            MyLogger.Trace("ConfigMainService.GetProductList :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("moduleId<{0}>", moduleId));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ModuleId", moduleId);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.GetProductList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("ConfigMainService.GetProductList :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    if (result.ReturnCode == 0)
                    {
                        //List<ProductEntity> productList = JsonHelp.DeserializeJsonToList<ProductEntity>(result.ReturnMsg);
                        //foreach (ProductEntity product in productList)
                        //{
                        //    strList.Add(product.ProductId);
                        //}
                        //return strList;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetProductList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
        public List<string> GetLayerList(string userId, string clientVersion, string moduleId, string productId)
        {
            MyLogger.Trace("ConfigMainService.GetLayerList :: " +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ModuleId", moduleId);
            arguDic.Add("ProductId", productId);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                //    string strResult = WSHelper.GetResponseString(EMethod.GetLayerList, arguDic);
                //    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                //    MyLogger.Trace("ConfigMainService.GetLayerList :: " +
                //                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                //                    string.Format("ReturnText<{0}>", result.ReturnText) +
                //                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                //    if (result.ReturnCode == 0)
                //    {
                //        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                //        foreach (LayerEntity layer in layerList)
                //        {
                //            layers.Add(layer.LayerId);
                //        }
                //        return layers;
                //    }
                //}

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetLayerList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
        public List<string> GetToolList(string userId, string clientVersion, string moduleId, string productId, string layerId)
        {
            MyLogger.Trace("ConfigMainService.GetLayerList :: " +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId)+
                           string.Format("LayerId<{0}>", layerId));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ModuleId", moduleId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                //    string strResult = WSHelper.GetResponseString(EMethod.GetLayerList, arguDic);
                //    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                //    MyLogger.Trace("ConfigMainService.GetToolList :: " +
                //                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                //                    string.Format("ReturnText<{0}>", result.ReturnText) +
                //                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                //    if (result.ReturnCode == 0)
                //    {
                //        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                //        foreach (LayerEntity layer in layerList)
                //        {
                //            layers.Add(layer.LayerId);
                //        }
                //        return layers;
                //    }
                //}

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetToolList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
        public List<string> GetRecipeList(string userId, string clientVersion, string moduleId, string productId, string layerId, string toolId)
        {
            MyLogger.Trace("ConfigMainService.GetLayerList :: " +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClientVersion<{0}>", clientVersion) +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId)+
                           string.Format("ToolId<{0}>", toolId));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ModuleId", moduleId);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", layerId);
            try
            {
                //if (!CommonHelp.ArgumentIsNull(arguDic))
                //{
                //    string strResult = WSHelper.GetResponseString(EMethod.GetLayerList, arguDic);
                //    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                //    MyLogger.Trace("ConfigMainService.GetRecipeList :: " +
                //                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                //                    string.Format("ReturnText<{0}>", result.ReturnText) +
                //                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                //    if (result.ReturnCode == 0)
                //    {
                //        List<LayerEntity> layerList = JsonHelp.DeserializeJsonToList<LayerEntity>(result.ReturnMsg);
                //        foreach (LayerEntity layer in layerList)
                //        {
                //            layers.Add(layer.LayerId);
                //        }
                //        return layers;
                //    }
                //}

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetRecipeList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }

            return null;
        }
        #endregion

        #region
        public ConfigCommonEntity R2R_UI_Config_Get(string requestId, string userId, string clienetVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName)
        {
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.R2R_UI_Config_Get:: " +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clienetVersion) +
                           string.Format("MoudleId<{0}>", moudleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId) +
                           string.Format("TableName<{0}>", tableName));
            ConfigCommonEntity Obj = new ConfigCommonEntity();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clienetVersion);
            arguDic.Add("Module", moudleId);
            arguDic.Add("Product", productId);
            arguDic.Add("Layer", layerId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("Recipe", recipeId);
            arguDic.Add("TableName", tableName);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Get, arguDic);
                    CfgResult result = JsonHelp.DeserializeJsonToObject<CfgResult>(strResult);
                    MyLogger.Trace("ConfigMainService.R2R_UI_Config_Get Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("Content<{0}>", result.Content));
                    if (result.ReturnCode.Equals("0"))
                    {
                        Obj = JsonHelp.DeserializeJsonToObject<ConfigCommonEntity>(result.Content);
                        return Obj;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.R2R_UI_Config_Get Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return Obj;
        }

        public bool R2R_UI_Config_Update(string requestId, string userId, string clienetVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName, string content)
        {
            bool flag = false;
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.R2R_UI_Config_Update :: " +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clienetVersion) +
                           string.Format("MoudleId<{0}>", moudleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId) +
                           string.Format("TableName<{0}>", tableName) +
                           string.Format("Content<{0}>", content));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clienetVersion);
            arguDic.Add("Module", moudleId);
            arguDic.Add("Product", productId);
            arguDic.Add("Layer", layerId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("Recipe", recipeId);
            arguDic.Add("TableName", tableName);
            arguDic.Add("Content", content);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Update, arguDic);
                    CfgResult result = JsonHelp.DeserializeJsonToObject<CfgResult>(strResult);
                    MyLogger.Trace("ConfigMainService.R2R_UI_Config_Update Reply :: " +
                                    string.Format("RequestId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.R2R_UI_Config_Update Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return flag;
        }

        public bool R2R_UI_Config_Delete(string requestId, string userId, string clienetVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName, string content)
        {
            bool flag = false;
            string strJson = string.Empty;
            MyLogger.Trace("R2R_UI_Config_Delete :: " +
                           string.Format("RequestId<{0}>", requestId) +
                           string.Format("UserId<{0}>", userId) +
                           string.Format("ClienetVersion<{0}>", clienetVersion) +
                           string.Format("MoudleId<{0}>", moudleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId) +
                           string.Format("TableName<{0}>", tableName) +
                           string.Format("Content<{0}>", content));
            List<string> strList = new List<string>();
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("RequestId", requestId);
            arguDic.Add("UserID", userId);
            arguDic.Add("ClienetVersion", clienetVersion);
            arguDic.Add("Module", moudleId);
            arguDic.Add("Product", productId);
            arguDic.Add("Layer", layerId);
            arguDic.Add("ToolId", toolId);
            arguDic.Add("Recipe", recipeId);
            arguDic.Add("TableName", tableName);
            arguDic.Add("Content", content);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.R2R_UI_Config_Delete, arguDic);
                    CfgResult result = JsonHelp.DeserializeJsonToObject<CfgResult>(strResult);
                    MyLogger.Trace("ConfigMainService.Config_R2R_PH_CONTROL_SPECS_CONFIG_Delete Reply :: " +
                                    string.Format("RequesteId<{0}>", result.RequestId) +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText));
                    if (result.ReturnCode.Equals("0"))
                    {
                        flag = true;
                    }
                }
            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.R2R_UI_Config_Delete Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return flag;
        }

        public string GetCRListFun(string moduleId, string productId, string layerId, string toolId, string recipeId)
        {
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.GetCRListFun :: " +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId));
            try
            {

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetContextList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return strJson;
        }

        public string GetCRDetailFun(string moduleId, string productId, string layerId, string toolId, string recipeId)
        {
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.GetCRDetailFun :: " +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId));
            try
            {

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetCRDetailFun Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return strJson;
        }

        public string GetVersionLogListFun(string moduleId, string productId, string layerId, string toolId, string recipeId)
        {
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.GetVersionLogListFun :: " +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId));
            try
            {

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetVersionLogListFun Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return strJson;
        }

        public string GetVersionLogDetailFun(string moduleId, string productId, string layerId, string toolId, string recipeId)
        {
            string strJson = string.Empty;
            MyLogger.Trace("ConfigMainService.GetVersionLogDetailFun :: " +
                           string.Format("ModuleId<{0}>", moduleId) +
                           string.Format("ProductId<{0}>", productId) +
                           string.Format("LayerId<{0}>", layerId) +
                           string.Format("ToolId<{0}>", toolId) +
                           string.Format("RecipeId<{0}>", recipeId));
            try
            {

            }
            catch (Exception ex)
            {
                MyLogger.Error("ConfigMainService.GetVersionLogDetailFun Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return strJson;
        }
        #endregion

        #region
        List<StructColumn> GetColumnFormat(string[] arry)
        {
            List<StructColumn> structData = new List<StructColumn>();
            foreach (var str in arry)
            {
                string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                StructColumn column = new StructColumn();
                column.columnName = sArray[0];
                column.columnType = sArray[1];
                column.columnAttribute = sArray[2];
                structData.Add(column);
            }
            return structData;
        }

        List<List<string>> GetColumnData(string[] arry)
        {
            List<List<string>> columnData = new List<List<string>>();
            foreach (var str in arry)
            {
                string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                columnData.Add(sArray.ToList());
            }

            return columnData;
        }

        List<List<string>> GetRowData(List<List<string>> columnData)
        {
            List<List<string>> rowData = new List<List<string>>();

            for (int n = 0; n < columnData[0].Count; n++)
            {
                List<string> strList = new List<string>();
                for (int i = 0; i < columnData.Count; i++)
                {
                    strList.Add(columnData[i][n]);
                }
                rowData.Add(strList);
            }


            return rowData;
        }

        public List<string> GetColumnKeyName(string[] arry)
        {
            List<StructColumn> structColumn = new List<StructColumn>();
            structColumn = GetColumnFormat(arry);

            List<string> strList = new List<string>();

            foreach (var st in structColumn)
            {
                if (st.columnAttribute.ToUpper().Equals("KEY"))
                {
                    strList.Add(st.columnName);
                }
            }
            return strList;
        }

        public List<string> GetColumnName(string[] arry)
        {
            List<StructColumn> structColumn = new List<StructColumn>();
            structColumn = GetColumnFormat(arry);

            List<string> strList = new List<string>();

            foreach (var st in structColumn)
            {
                strList.Add(st.columnName);
            }
            return strList;
        }

        public DataView CreateDataTable(ConfigCommonEntity entity, List<List<string>> rowData)
        {
            DataTable db = new DataTable(entity.TableName);

            List<StructColumn> structData = new List<StructColumn>();
            structData = GetColumnFormat(entity.ColumnFormat);
            foreach (var st in structData)
            {
                string sType = st.columnType.Substring(0, 1).ToUpper() + st.columnType.Substring(1);
                string strType = "System.String";
                db.Columns.Add(st.columnName, Type.GetType(strType));
            }

            for (int i = 0; i < rowData.Count; i++)
            {
                db.Rows.Add();
                for (int n = 0; n < rowData[0].Count; n++)
                {
                    db.Rows[i][n] = rowData[i][n];
                }
            }

            return new DataView(db);
        }

        public DataView CreateDataTable(ConfigCommonEntity entity)
        {
            DataTable db = new DataTable(entity.TableName);

            List<StructColumn> structData = new List<StructColumn>();
            structData = GetColumnFormat(entity.ColumnFormat);
            foreach (var st in structData)
            {
                string sType= st.columnType.Substring(0, 1).ToUpper() + st.columnType.Substring(1);
                string strType = "System.String";
                db.Columns.Add(st.columnName, Type.GetType(strType));
            }

            List<List<string>> columnData = new List<List<string>>();
            columnData = GetColumnData(entity.ColumnData);

            List<List<string>> rowData = new List<List<string>>();
            rowData = GetRowData(columnData);

            for (int i = 0; i < rowData.Count; i++)
            {
                db.Rows.Add();
                for (int n = 0; n < rowData[0].Count; n++)
                {
                    db.Rows[i][n] = rowData[i][n];
                }
            }

            return new DataView(db);
        }

        public ControlConfig GetControlCfg(ConfigCommonEntity eneity)
        {
            ControlConfig controlCfg = new ControlConfig();
            controlCfg.ColumnFormat = eneity.ColumnFormat;
            controlCfg.TableName = eneity.TableName;
            controlCfg.AllowWriteColumn_CSV = eneity.AllowWriteColumn_CSV;
            controlCfg.bAllowView = eneity.bAllowView;
            controlCfg.bAllowWrite = eneity.bAllowWrite;
            controlCfg.bApprover = eneity.bApprover;
            controlCfg.bRequester = eneity.bRequester;
            controlCfg.bRollbacker = eneity.bRollbacker;

            return controlCfg;
        }

        public string[] DataviewConvert(DataView dv,List<string> strColumnName)
        {
            List<string> strList = new List<string>();
            DataTable dt = dv.ToTable();

            foreach (var str in strColumnName)
            {
                string strTmp = string.Empty;
               
                foreach (DataRow dr in dt.Rows)
                {
                    strTmp += dr[str].ToString() + ":";
                }

                //List<string> strListColumn = new List<string>();
                //strListColumn = (from d in dv.ToTable().AsEnumerable() select d.Field<string>(str)).ToList();

                strList.Add(strTmp.TrimEnd(':'));
            }

            return strList.ToArray();
        }
        #endregion
    }
}
