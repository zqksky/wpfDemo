﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class ConfigMainInfoModel
    {
        public string Controller { get; set; }
        public string ModelName { get; set; }
        public string VarName { get; set; }
        public string ToolId { get; set; }
        public string Product { get; set; }
        public string Layer { get; set; }
        public string Reticle { get; set; }
        public double Deadband { get; set; }
        public double EwmaFactor { get; set; }
        public double Max { get; set; }
        public double MaxDelta { get; set; }
        public double MaxOfOutput { get; set; }
        public double Min { get; set; }
        public double MinOutput { get; set; }
        public int MinPointsForAvg { get; set; }
    }
}
