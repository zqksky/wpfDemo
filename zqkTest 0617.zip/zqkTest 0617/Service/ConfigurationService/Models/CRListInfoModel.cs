﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class CRListInfoModel
    {
        public string FromVersion { get; set; }
        public string Requester { get; set; }
        public string Action { get; set; }
    }
}
