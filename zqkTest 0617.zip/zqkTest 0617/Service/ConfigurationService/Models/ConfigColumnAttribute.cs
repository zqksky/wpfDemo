﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public struct StructColumn
    {
        public string columnType;
        public string columnName;
        public string columnAttribute;
    }
}
