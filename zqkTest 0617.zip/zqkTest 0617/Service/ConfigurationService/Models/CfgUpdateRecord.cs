﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class CfgUpdateRecord
    {
        public string Operation;
        public string OldData;
        public string NewData;
    }
}
