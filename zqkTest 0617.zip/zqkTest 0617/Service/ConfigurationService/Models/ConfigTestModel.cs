﻿using Newtonsoft.Json;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class ConfigTestModel : ViewModelBase
    {
        //public bool IsSelected { get; set; }
        //public ConfigMainInfoModel ConfigInfoValue { get; set; }

        private bool _IsSelected = false;
        public bool IsSelected
        {
            get { return this._IsSelected; }
            set
            {
                SetProperty(ref this._IsSelected, value);
            }
        }

        private ConfigMainInfoModel _ConfigInfoValue;
        public ConfigMainInfoModel ConfigInfoValue
        {
            get { return this._ConfigInfoValue; }
            set { SetProperty(ref this._ConfigInfoValue, value); }
        }
    }
}
