﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class ControlConfig
    {
        public string[] ColumnFormat { get; set; }
        public string TableName { get; set; }
        public bool bRequester { get; set; }
        public bool bApprover { get; set; }
        public bool bRollbacker { get; set; }
        public bool bAllowView { get; set; }
        public bool bAllowWrite { get; set; }
        public string AllowWriteColumn_CSV { get; set; }
    }
}
