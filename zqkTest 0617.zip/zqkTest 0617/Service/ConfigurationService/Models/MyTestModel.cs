﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.Models
{
    public class MyTestModel : ViewModelBase
    {
        private bool _IsSelected = false;
        public bool IsSelected
        {
            get { return this._IsSelected; }
            set
            {
                SetProperty(ref this._IsSelected, value);
            }
        }

        private Dictionary<String, String> _ConfigInfoValue;
        public Dictionary<String, String>  ConfigInfoValue
        {
            get { return this._ConfigInfoValue; }
            set { SetProperty(ref this._ConfigInfoValue, value); }
        }

        //private List<string> _ConfigInfoValue;
        //public List<string> ConfigInfoValue
        //{
        //    get { return this._ConfigInfoValue; }
        //    set { SetProperty(ref this._ConfigInfoValue, value); }
        //}
    }
}
