﻿using ConfigurationService.Models;
using R2R.Common.Data.E3Entities.ConfigUI;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationService.IService
{
    public interface IConfigMainService
    {
        List<string> GetModuleList(string userId, string clientVersion);
        List<string> GetProductList(string userId, string clientVersion, string moduleId);
        List<string> GetLayerList(string userId, string clientVersion, string moduleId, string productId);
        List<string> GetToolList(string userId, string clientVersion, string moduleId, string productId,string layerId);
        List<string> GetRecipeList(string userId, string clientVersion, string moduleId, string productId, string layerId,string toolId);

        ConfigCommonEntity R2R_UI_Config_Get(string requestId, string userId, string clientVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName);
        bool R2R_UI_Config_Update(string requestId, string userId, string clientVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName, string content);
        bool R2R_UI_Config_Delete(string requestId, string userId, string clientVersion, string moudleId, string productId, string layerId, string toolId, string recipeId, string tableName, string content);

        DataView CreateDataTable(ConfigCommonEntity entity);
        DataView CreateDataTable(ConfigCommonEntity entity, List<List<string>> rowData);
        ControlConfig GetControlCfg(ConfigCommonEntity eneity);
        string[] DataviewConvert(DataView dv, List<string> strColumnName);
        List<string> GetColumnName(string[] arry);
        List<string> GetColumnKeyName(string[] arry);

        string GetCRListFun(string moduleId, string productId, string layerId, string toolId, string recipeId);
    }
}
