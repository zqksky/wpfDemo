﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.VO
{
    public class CDParameterModel
    {
        public string ParameterName { get; set; }
        public string FixedValue { get; set; }
        public string UCalc { get; set; }
        public string ReworkBias { get; set; }
        public string Upper { get; set; }
        public string Low { get; set; }
        public string Delta { get; set; }
        public string DeadBand { get; set; }
    }
}