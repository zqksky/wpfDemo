﻿using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.VO
{
    public class ColumnList
    {
        public List<ColumnEntity> CDColumns { get; set; }
        public List<ColumnEntity> OVLColumns { get; set; }
    }
}
