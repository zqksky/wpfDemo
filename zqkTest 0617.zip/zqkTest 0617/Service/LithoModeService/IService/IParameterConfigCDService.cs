﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface IParameterConfigCDService
    {
        CDContextContent GetCDContext(string userId, 
                             string clientVersion, 
                             string productId, 
                             string layerId,
                             string tool,
                             string reticleId,
                             string recipeId,
                             string chuck);
        Boolean SaveCDParameters(string userId,
                                 string clientVersion,
                                 string productId,
                                 string layerId,
                                 string tool,
                                 string reticleId,
                                 string recipeId,
                                 string chuck,
                                 string jsonParameters);
    }
}
