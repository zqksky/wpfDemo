﻿using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.LithoModeService
{
    public interface ILithoService
    {
        List<DataView> GetLithoColumnList(string userId, string clientVersion);
        List<string> GetProductList(string userId, string clientVersion);
        List<string> GetLayerList(string userId, string clientVersion, string productId);
        DataView GetCDDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt);
        DataView GetOVLDataList(string userId, string clientVersion, string productId, string layerId, string tool, string toolType, DataTable dt);
    }
}
