﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using R2R.Common.DAL;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Common.Library;

namespace R2R.Service.LithoModeService
{
    public class ParameterConfigCDService : IParameterConfigCDService
    {
        public CDContextContent GetCDContext(string userId, string clientVersion, string productId, string layerId, string tool, string reticleId, string recipeId, string chuck)
        {
            //MyLogger.Trace("ParameterConfigCDService.GetCDContext :: " +
            //                string.Format("UserId<{0}>", userId) +
            //                string.Format("ClientVersion<{0}>", clientVersion) +
            //                string.Format("ProductId<{0}>", productId) +
            //                string.Format("LayerId<{0}>", layerId) +
            //                string.Format("ToolId<{0}>", tool) +
            //                string.Format("ReticleId<{0}>", reticleId) +
            //                string.Format("RecipeId<{0}>", recipeId) +
            //                string.Format("Chuck<{0}>", chuck));
            //Dictionary<string, object> arguDic = new Dictionary<string, object>();
            //arguDic.Add("UserID", userId);
            //arguDic.Add("ClientVersion", clientVersion);
            //arguDic.Add("ProductId", productId);
            //arguDic.Add("LayerId", layerId);
            //arguDic.Add("ToolId", tool);
            //try
            //{
            //    if (!CommonHelp.ArgumentIsNull(arguDic))
            //    {
            //        arguDic.Add("ReticleId", reticleId);
            //        arguDic.Add("RecipeId", recipeId);
            //        arguDic.Add("Chuck", chuck);
            //        string strResult = WSHelper.GetResponseString(EMethod.GetContextContentCD, arguDic);
            //        TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
            //        MyLogger.Trace("LithoService.GetLithoColumnList Reply :: " +
            //                        string.Format("ReturnCode<{0}>", result.ReturnCode) +
            //                        string.Format("ReturnText<{0}>", result.ReturnText) +
            //                        string.Format("ReturnMsg<{0}>", result.ReturnMsg));
            //        if (result.ReturnCode == 0)
            //        {
            //            CDContextContent cDContextContent = JsonHelp.DeserializeJsonToObject<CDContextContent>(result.ReturnMsg);
            //            return cDContextContent;
            //        }
            //    }

            //}
            //catch (Exception ex)
            //{
            //    MyLogger.Error("LithoService.GetLithoColumnList Error :: " + ex.Message);
            //    MessageBox.Show(ex.Message);
            //}
            //return null;
            CDContextContent cDContextContent = new CDContextContent();
            cDContextContent.ToolId = "ToolId1";
            cDContextContent.ProductId = "ProductId1";
            cDContextContent.LayerId = "LayerId1";
            cDContextContent.ReticleId = "ReticleId1";
            cDContextContent.CtlFlag = "CtlFlag1";
            cDContextContent.Pilot = "Pilot1";
            ParameterRow row = new ParameterRow();
            row.ParameterName = "NAME";
            row.ParameterVaue = "VALUE";
            List<ParameterRow> rows = new List<ParameterRow>();
            rows.Add(row);
            cDContextContent.parametersRows = rows;
            CDSpecConfigContent cD = new CDSpecConfigContent();
            cD.ToolId = "ToolId";
            cD.ProductId = "ProductId";
            cD.LayerId = "LayerId";
            cD.ReticleId = "ReticleId";
            cD.Sensitivity = 12;
            cD.CDTarget = "CDTarget";
            cD.FeedbackPoint = "FeedbackPoint";
            cD.Lambda = 12;
            cD.LambdaPiRun = 13;
            cD.MetrologyDays = 14;
            cD.MinPointFieAvg = 15;
            cD.FeebbackStage = "FeebbackStage";
            cDContextContent.specConfig = cD;
            return cDContextContent;
        }
        public Boolean SaveCDParameters(string userId, string clientVersion, string productId, string layerId, string tool, string reticleId, string recipeId, string chuck, string jsonParameters)
        {
            MyLogger.Trace("ParameterConfigCDService.SaveCDParameters :: " +
                            string.Format("UserId<{0}>", userId) +
                            string.Format("ClientVersion<{0}>", clientVersion) +
                            string.Format("ProductId<{0}>", productId) +
                            string.Format("LayerId<{0}>", layerId) +
                            string.Format("ToolId<{0}>", tool) +
                            string.Format("ReticleId<{0}>", reticleId) +
                            string.Format("RecipeId<{0}>", recipeId) +
                            string.Format("Chuck<{0}>", chuck) +
                            string.Format("Parameters<{0}>", jsonParameters));
            Dictionary<string, object> arguDic = new Dictionary<string, object>();
            arguDic.Add("UserID", userId);
            arguDic.Add("ClientVersion", clientVersion);
            arguDic.Add("ProductId", productId);
            arguDic.Add("LayerId", layerId);
            arguDic.Add("ToolId", tool);
            arguDic.Add("ReticleId", reticleId);
            arguDic.Add("RecipeId", recipeId);
            arguDic.Add("Chuck", chuck);
            arguDic.Add("Parameters", jsonParameters);
            try
            {
                if (!CommonHelp.ArgumentIsNull(arguDic))
                {
                    string strResult = WSHelper.GetResponseString(EMethod.GetModeColumnList, arguDic);
                    TResult result = JsonHelp.DeserializeJsonToObject<TResult>(strResult);
                    MyLogger.Trace("LithoService.GetLithoColumnList Reply :: " +
                                    string.Format("ReturnCode<{0}>", result.ReturnCode) +
                                    string.Format("ReturnText<{0}>", result.ReturnText) +
                                    string.Format("ReturnMsg<{0}>", result.ReturnMsg));
                    if (result.ReturnCode == 0)
                    {
                        return true;
                    }
                }

            }
            catch (Exception ex)
            {
                MyLogger.Error("LithoService.GetLithoColumnList Error :: " + ex.Message);
                MessageBox.Show(ex.Message);
            }
            return false;
        }
    }
}
