﻿using R2R.Service.VO;
using System;

namespace R2R.Service.MainService
{
    public interface ILoginService
    {
        int Login(string username, string password, string domain);
    }
}
