﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.DAL;
using R2R.Common.Data;

namespace R2R.Service.ProfileService
{
    public class FactoryService : IFactoryService
    {
        public IMessageManager MessageManager { get; set; }

        public FactoryService(IMessageManager messageManager)
        {
            MessageManager = messageManager;
        }

        public void AddFactory(List<Factory> factoryLst)
        {
            CommandRequest commandRequest = new CommandRequest
            {
                Interface = typeof(IProfileService),
                MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name
            };
            commandRequest.InputParams.Add(factoryLst);
            MessageManager.SendCommand(commandRequest);
        }


        public void DeleteFactory(string factoryName)
        {
            CommandRequest commandRequest = new CommandRequest
            {
                Interface = typeof(IProfileService),
                MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name
            };

            commandRequest.InputParams.Add(factoryName);
            MessageManager.SendCommand(commandRequest);
        }

        public void DisableFactory(string factoryName)
        {
            CommandRequest commandRequest = new CommandRequest
            {
                Interface = typeof(IProfileService),
                MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name
            };

            commandRequest.InputParams.Add(factoryName);
            MessageManager.SendCommand(commandRequest);
        }

        public void EnableFactory(string factoryName)
        {
            CommandRequest commandRequest = new CommandRequest
            {
                Interface = typeof(IProfileService),
                MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name
            };

            commandRequest.InputParams.Add(factoryName);
            MessageManager.SendCommand(commandRequest);
        }

        public List<Factory> GetFactories(List<QueryParameter> parameters, OrderSettings orderSettings)
        {
            QueryRequest queryRequest = new QueryRequest
            {
                QueryName = "ListFactories",
                Parameters = parameters,
                Ordering = orderSettings
            };
            return MessageManager.QueryList<Factory>(queryRequest);
        }

        public void ModifyFactory(Factory factory)
        {
            CommandRequest commandRequest = new CommandRequest
            {
                Interface = typeof(IProfileService),
                MethodName = System.Reflection.MethodBase.GetCurrentMethod().Name
            };

            commandRequest.InputParams.Add(factory);
            MessageManager.SendCommand(commandRequest);
        }
    }
}