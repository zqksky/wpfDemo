﻿using R2R.Common.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Service.ProfileService
{
    public interface IFactoryService
    {
        List<Factory> GetFactories(List<QueryParameter> parameters, OrderSettings orderSettings);
        void AddFactory(List<Factory> factoryLst);
        void ModifyFactory(Factory factory);
        void DeleteFactory(string factoryName);
        void EnableFactory(string factoryName);
        void DisableFactory(string factoryName);
    }
}