﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Server.Library.Constants;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;

namespace R2R.Server.Library.Sqls
{
    public class InsertSql : SqlBase
    {
        private const string ReturnValueParaName = "retCol";
        protected OracleDbType _returnColumnType;
        private string _sqlStart;

        public string ReturnColumnName { get; private set; }

        public string SqlText { get; set; }

        /// <summary>
        /// Create a simple insert into sql statement.
        /// </summary>
        /// <param name="tableName">the table name</param>
        /// <param name="primaryKey">the primary key if the key is auto-genarated by insert trigger. The primary key will be returned by the Execute method.</param>
        public InsertSql(string tableName)
        {
            TableName = tableName;
            _sqlStart = "Insert into ";
        }

        protected override void AddParameter(string columnName, object propertyValue, Type type, bool isKeyColumn)
        {
            base.AddParameter(columnName, propertyValue, type, isKeyColumn);

            if(isKeyColumn && string.IsNullOrEmpty(ReturnColumnName))
            {
                // only use first add out para.
                ReturnColumnName = columnName;
                _returnColumnType = DataTypeHelper.GetOracleDbType(type);
            }
        }

        public override string ToString()
        {
            string columnNames = string.Empty;
            string columnValues = string.Empty;
            foreach (var name in _columnValueList.Keys)
            {
                columnNames += name + ",";
                columnValues += $":{name}" + ",";
            }

            if (columnNames.Length > 0)
            {
                columnNames = columnNames.Substring(0, columnNames.Length - 1);
            }
            if (columnValues.Length > 0)
            {
                columnValues = columnValues.Substring(0, columnValues.Length - 1);
            }

            string sqlCommand = _sqlStart + TableName + "(" + columnNames + ") values (" + columnValues + ")";

            if (!string.IsNullOrEmpty(ReturnColumnName))
            {
                sqlCommand = sqlCommand + $" RETURNING {ReturnColumnName} INTO :{ReturnValueParaName}";
            }

            return sqlCommand;
        }
        
        public bool IsBulk
        {
            get
            {
                return _columnValueList != null && _columnValueList.Count > 0 && _columnValueList.First().Value.Count > 1;
            }
        }

        private void GuardValues()
        {
            if (_columnValueList.Count == 0)
            {
                throw new InvalidOperationException("No data specified for this insert Sql. " + this.ToString());
            }
        }

        public bool Execute()
        {
            GuardValues();
            bool executeResult;
            try
            {
                MyLogger.PerformanceStart();
                using (OracleConnection oracleConnection = OracleHelper.NewAmsConnection())
                {
                    using (OracleCommand cmd = GetOracleCommand(oracleConnection))
                    {
                        oracleConnection.Open();

                        executeResult = cmd.ExecuteNonQuery() == cmd.ArrayBindCount;

                        if (!string.IsNullOrEmpty(ReturnColumnName))
                        {
                            _returnValue = cmd.Parameters[ReturnColumnName].Value;
                        }
                        else
                        {
                            _returnValue = null;
                        }
                    }
                }
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
            return executeResult;
        }

        public override bool Execute(OracleConnection connection)
        {
            GuardValues();
            bool executeResult;
            using (OracleCommand cmd = GetOracleCommand(connection))
            { 
                executeResult = cmd.ExecuteNonQuery() == 1;

                if (!string.IsNullOrEmpty(ReturnColumnName))
                {
                    //_returnValue = cmd.Parameters[ReturnColumnName].Value;
                    _returnValue = cmd.Parameters["retCol"].Value;
                }
                else
                {
                    _returnValue = null;
                }
            }
            return executeResult;
        }

        public override OracleCommand GetOracleCommand(OracleConnection oracleConnection)
        {
            var cmd = oracleConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ToString();
            cmd.BindByName = true;

            if (IsBulk)
            {
                //add bulk input params
                cmd.ArrayBindCount = _columnValueList.First().Value.Count;
                foreach (var kvp in _columnValueList)
                {
                    if (kvp.Value == null || kvp.Value.Count == 0)
                    {
                        throw new InvalidOperationException($"No value provided for key {kvp.Key}.");
                    }
                    cmd.Parameters.Add(kvp.Key, _columnDbTypes[kvp.Key], kvp.Value.ToArray(), ParameterDirection.Input);
                }

                if (!string.IsNullOrEmpty(ReturnColumnName))
                {
                    // add output param for primary key.
                    OracleParameter retParam = cmd.Parameters.Add(ReturnValueParaName, _returnColumnType, ParameterDirection.Output);
                    retParam.ArrayBindSize = Enumerable.Repeat<int>(40, _columnValueList.First().Value.Count).ToArray<int>();
                }
            }
            else
            {
                // add input params
                foreach (var kvp in _columnValueList)
                {
                    if (kvp.Value == null || kvp.Value.Count == 0)
                    {
                        throw new InvalidOperationException($"No value provided for key {kvp.Key}.");
                    }
                    cmd.Parameters.Add(kvp.Key, _columnDbTypes[kvp.Key]).Value = kvp.Value[0];
                }

                if (!string.IsNullOrEmpty(ReturnColumnName))
                {
                    // add output param for primary key.
                    cmd.Parameters.Add(ReturnValueParaName, _returnColumnType, ParameterDirection.Output);
                }
            }

            return cmd;
        }

        private object _returnValue;

        public List<string> GetReturnAsStringList()
        {
            List<string> returnStringList = null;
            if (_returnValue is OracleString[] oracleStringArray)
            {
                returnStringList = oracleStringArray.Select(pk => pk.Value).ToList();
            }
            return returnStringList;
        }

        public List<long> GetReturnAsLongList()
        {
            List<long> returnLongList = null;
            if (_returnValue is OracleDecimal[] oracleDecimalArray)
            {
                returnLongList = oracleDecimalArray.Select(pk => pk.ToInt64()).ToList();
            }
            return returnLongList;
        }


        public long GetReturnAsLong()
        {
            if (_returnValue is OracleDecimal oracleDecimal)
            {
                return oracleDecimal.ToInt64();
            }
            else
            {
                throw new InvalidOperationException("return is not long.");
            }
        }


        public int GetReturnAsInt()
        {
            if (_returnValue is OracleDecimal oracleDecimal)
            {
                return oracleDecimal.ToInt32();
            }
            else
            {
                throw new InvalidOperationException("return is not int.");
            }
        }


        public string GetReturnAsString()
        {
            if (_returnValue is OracleString oracleString)
            {
                return oracleString.Value;
            }
            else
            {
                throw new InvalidOperationException("return is not string.");
            }
        }
    }
}
