﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Sqls
{
    public abstract class SqlBase
    {
        private string _tableName;
        protected Dictionary<string, List<object>> _columnValueList;
        protected Dictionary<string, OracleDbType> _columnDbTypes;
        
        public string TableName { get => _tableName; set => _tableName = value; }

        public SqlBase()
        {
            _columnValueList = new Dictionary<string, List<object>>();
            _columnDbTypes = new Dictionary<string, OracleDbType>();
        }

        public virtual void Clear()
        {
            _columnValueList.Clear();
            _columnDbTypes.Clear();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="columnName">db column name</param>
        /// <param name="propertyValue"> .net type value</param>
        /// <param name="type"> .net type </param>
        /// <param name="isKeyColumn">is output param</param>
        protected virtual void AddParameter(string columnName, object propertyValue, Type type, bool isKeyColumn)
        {
            if (isKeyColumn) return;


            _columnDbTypes[columnName] = DataTypeHelper.GetOracleDbType(type);

            if (!_columnValueList.ContainsKey(columnName) || _columnValueList[columnName] == null)
            {
                _columnValueList[columnName] = new List<object>();
            }

            if (type == typeof(int) || type == typeof(int?))
            {
                var nullableForm = (int?)propertyValue;
                _columnValueList[columnName].Add(nullableForm.Value);
            }
            else if (type == typeof(long) || type == typeof(long?))
            {
                var nullableForm = (long?)propertyValue;
                _columnValueList[columnName].Add(nullableForm.Value);
            }
            else if (type == typeof(double) || type == typeof(double?))
            {
                var nullableForm = (double?)propertyValue;
                _columnValueList[columnName].Add(nullableForm.Value);
            }
            else if (type == typeof(DateTime) || type == typeof(DateTime?))
            {
                var nullableForm = (DateTime?)propertyValue;
                _columnValueList[columnName].Add(nullableForm.Value);
            }
            else if (type == typeof(bool) || type == typeof(bool?))
            {
                // convert bool and bool?.Value to Char Y or N
                bool? nullableForm = (bool?)propertyValue;
                _columnValueList[columnName].Add(nullableForm.HasValue ? (nullableForm.Value ? "Y" : "N") : null);

            }
            else if (type.IsEnum)
            {
                // convert Enum to string.
                string value = Enum.GetName(type, propertyValue);
                if (!string.IsNullOrEmpty(value))
                {
                    _columnValueList[columnName].Add(value);
                }
                else
                {
                    _columnValueList[columnName] = null;
                }
            }
            else if(type == typeof(string))
            {
                _columnValueList[columnName].Add(propertyValue);
            }
            else
            {
                throw new InvalidOperationException("Not supported type!");
            }
            //_columnValueList[columnName].Add(propertyValue);
        }

        public void AddParametersForRow(string[] columnNames, object[] values)
        {

            // TODO: judge length match.
            // TODO: use AddParameter
        }

        public void AddColumnNames(params string[] columnNames)
        {

        }

        public void AddColumnValues(params object[] values)
        {

        }

        public void AddColumnNameValue(string columnName, object value)
        {

        }

        public virtual void AddColumValueFromListObject(Object[] objs)
        {
            if (objs == null) throw new ArgumentNullException();

            foreach (var obj in objs)
            {
                AddColumValueFromObject(obj);
            }
        }

        /// <summary>
        /// add an object's public properties to the parameters.
        /// </summary>
        /// <param name="obj">an object</param>
        public virtual void AddColumValueFromObject(Object obj)
        {
            if (obj == null) throw new ArgumentNullException();

            Type type = obj.GetType();
            PropertyInfo[] properties = type.GetProperties();

            var propertiesWithColumnMapping = from pi in properties
                                              where Attribute.IsDefined(pi, typeof(ColumnMappingAttribute))
                                              select pi;
            foreach (var pi in propertiesWithColumnMapping)
            {
                object propertyValue = pi.GetValue(obj);

                var attr = Attribute.GetCustomAttribute(pi, typeof(ColumnMappingAttribute)) as ColumnMappingAttribute;

                string columnName = string.Empty;

                if (string.IsNullOrEmpty(attr.ColumnName))
                {
                    columnName = pi.Name.ToUpper();
                }
                else
                {
                    columnName = attr.ColumnName;
                }
                AddParameter(attr.ColumnName, propertyValue, pi.PropertyType, attr.IsKeyColumn);
            }
        }


        public virtual OracleCommand GetOracleCommand(OracleConnection oracleConnection)
        {
            var cmd = oracleConnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = ToString();
            cmd.BindByName = true;

            // add input params
            foreach (var kvp in _columnValueList)
            {
                if (kvp.Value == null || kvp.Value.Count == 0)
                {
                    throw new InvalidOperationException($"No value provided for key {kvp.Key}.");
                }
                cmd.Parameters.Add(kvp.Key, _columnDbTypes[kvp.Key]).Value = kvp.Value[0];
            }

            return cmd;
        }

        public virtual bool Execute(OracleConnection connection)
        {
            return false;
        }
    }

    public class ColumnTypeValues
    {
        public string ColumnName { get; set; }
        public OracleDbType DbType { get; set; }
        public List<object> ColumnValues { get; set; }
        public bool IsOutParameter { get; set; }
        
    }
}
