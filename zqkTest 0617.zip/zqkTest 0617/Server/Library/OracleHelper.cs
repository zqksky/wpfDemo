﻿using System.Configuration;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library
{
    public static class OracleHelper
    {
        public static OracleConnection NewAmsConnection()
        {
            return new OracleConnection(ConfigurationManager.ConnectionStrings["AMS"].ConnectionString);
        }
    }
}