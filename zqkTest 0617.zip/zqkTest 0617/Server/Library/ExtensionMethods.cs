﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using R2R.Common.Library;
using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library
{
    public static class ExtensionMethods
    {
        public static string ToJson(this OracleDataReader reader)
        {
            JObject jObject = new JObject();
            for (int i = 0; i < reader.FieldCount; i++)
            {
                object readFieldValue = reader[i];
                string fieldName = reader.GetName(i);
                jObject.Add(fieldName, JToken.FromObject(readFieldValue));
            }
            return jObject.ToString(Newtonsoft.Json.Formatting.None);
        }

        public static TTarget ToObject<TTarget>(this OracleDataReader reader) where TTarget : new()
        {
            if (reader == null) return default(TTarget);

            try
            {
                // create return object.
                TTarget targetObjet = new TTarget();

                Type type = targetObjet.GetType();
                PropertyInfo[] properties = type.GetProperties();

                var propertiesWithColumnMapping = from pi in properties
                                                  where Attribute.GetCustomAttribute(pi, typeof(ColumnMappingAttribute)) != null
                                                  select pi;
                for (int i = 0; i < reader.FieldCount; i++)
                {
                    object readFieldValue = reader[i];
                    string fieldName = reader.GetName(i);

                    var foundPropertyByColumnName = from pi in properties
                                                    where FieldNameMatchesPropertyName(pi, fieldName)
                                                    select pi;
                    if (foundPropertyByColumnName.Count() == 0) continue;
                    PropertyInfo targetProperty = foundPropertyByColumnName.First();
                    SetTargetValue(targetObjet, targetProperty, readFieldValue);
                }
                return targetObjet;
            }
            catch (Exception ex)
            {
                MyLogger.Error(ex);
                return default(TTarget);
            }
        }

        private static void SetTargetValue<TTarget>(TTarget targetObjet, PropertyInfo targetProperty, object readFieldValue) where TTarget : new()
        {
            if (readFieldValue == null || readFieldValue is DBNull)
            {
                if(targetProperty.PropertyType == typeof(string))
                {
                    targetProperty.SetValue(targetObjet, string.Empty);
                }
                else
                {
                    targetProperty.SetValue(targetObjet, null);
                }
            }
            else
            {
                Type readFieldType = readFieldValue.GetType();
                if(targetProperty.PropertyType.IsEnum)
                {
                    targetProperty.SetValue(targetObjet, Enum.Parse(targetProperty.PropertyType, readFieldValue.ToString()));
                }
                else
                {
                    try
                    {
                        targetProperty.SetValue(targetObjet, readFieldValue);
                    }
                    catch (Exception ex)
                    {
                        MyLogger.Error(ex);
                    }
                }
            }
        }

        private static bool FieldNameMatchesPropertyName(PropertyInfo property, string fieldName)
        {
            bool isMatch = false;
            ColumnMappingAttribute columnMappingAttribute = Attribute.GetCustomAttribute(property, typeof(ColumnMappingAttribute)) as ColumnMappingAttribute;
            if (columnMappingAttribute == null || string.IsNullOrEmpty(fieldName)) return false;

            if (string.IsNullOrEmpty(columnMappingAttribute.ColumnName))
            {
                string unifiedColumnName = fieldName.Replace("_", "").ToUpper();
                string unifiedPropertyName = property.Name.Replace("_", "").ToUpper();

                isMatch = string.Equals(unifiedColumnName, unifiedPropertyName);
            }
            else
            {
                isMatch = string.Equals(fieldName, columnMappingAttribute.ColumnName);
            }

            return isMatch;
        }

    }
}
