﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using TIBCO.Rendezvous;

namespace R2R.Server.Library
{
    class Program
    {
        static void Main(string[] args)
        {
            AMSServer amsServer = new AMSServer();
            try
            {
                Console.WriteLine("Starting AMS Server...");
                amsServer.Start();
                Console.WriteLine("====================  AMS Server Started!  ====================");
                Console.ReadLine();
            }
            finally
            {
                amsServer.Stop();
                Console.WriteLine("====================  AMS Server Stopped!  ====================");
                Console.ReadLine();
            }
        }
    }
}
