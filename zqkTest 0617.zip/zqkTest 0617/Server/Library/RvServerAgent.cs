﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TIBCO.Rendezvous;

namespace R2R.Server.Library
{
    public class RvServerAgent
    {
        // TODO: use DQ for loading balance.
        CMTransport _cmTransport;
        Dispatcher _dispatcher = null;
        Queue _queue = null;
        CMListener _listener = null;

        string _agentName;
        string _listenSubject;

        public event EventHandler<MessageReceivedEventArgs> MessageReceived;

        public RvServerAgent(string agentName, string listenSubject)
        {
            _agentName = agentName;
            _listenSubject = listenSubject;
        }

        private void _listener_MessageReceived(object listener, MessageReceivedEventArgs messageReceivedEventArgs)
        {
            MessageReceived?.Invoke(listener, messageReceivedEventArgs);
        }

        public void Start(string service, string network, string daemon)
        {
            var netTransport = new NetTransport(service, network, daemon);
            _cmTransport = new CMTransport(netTransport);

            Console.WriteLine($"Created. - {_agentName} CMTransport. service = {service}, network = {network}, daemon = {daemon}");

            _queue = new Queue();
            Console.WriteLine($"Created. - {_agentName} Queue.");

            _listener = new CMListener(_queue, _cmTransport, _listenSubject, null);
            _listener.MessageReceived += _listener_MessageReceived; ;
            Console.WriteLine($"Created. - {_agentName} Listener. Listen Subject = {_listenSubject}");

            _dispatcher = new Dispatcher(_queue);
            Console.WriteLine($"Created. - {_agentName} Dispatcher.");
        }

        public void Stop()
        {
            if (_dispatcher != null)
            {
                _dispatcher.Destroy();
                _dispatcher = null;
                Console.WriteLine($"Destroyed. - {_agentName} Dispatcher destroyed.");
            }
            if (_listener != null)
            {
                _listener.MessageReceived -= _listener_MessageReceived;
                _listener.Destroy();
                _listener = null;
                Console.WriteLine($"Destroyed. - {_agentName} Listener.");
            }
            if (_queue != null)
            {
                _queue.Destroy();
                _queue = null;
                Console.WriteLine($"Destroyed. - {_agentName} Queue.");
            }

            if (_cmTransport != null)
            {
                _cmTransport.Destroy();
                _cmTransport = null;
                Console.WriteLine($"Destroyed. - {_agentName} CMTransport.");
            }
        }
    }
}
