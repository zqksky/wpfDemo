﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using R2R.Common.Data;
using R2R.Server.Library.Queries;
using Newtonsoft.Json;

namespace R2R.Server.Library
{
    public class QueryAgent
    {
        private static QueryAgent _queryAgent;
        private BooleanJsonConverter _booleanJsonConverter;

        private List<QueryBase> _queries = new List<QueryBase>();

        private QueryAgent()
        {
            RegisterQuery<QuerySystem>();
            RegisterQuery<QuerySubSystem>();
            RegisterQuery<QueryEvent>();
            RegisterQuery<QuerySystemTree>();
            RegisterQuery<ListFactories>();
        }

        public static QueryAgent Instance
        {
            get
            {
                if (_queryAgent == null)
                {
                    _queryAgent = new QueryAgent();
                }
                return _queryAgent;
            }
        }

        public string ExecuteQuery(QueryRequest req)
        {
            QueryBase query = _queries.First((q) => q.QueryName == req.QueryName);
            if (query != null)
            {
                return query.Execute(req);
            }
            else
            {
                throw new ArgumentException($"Query '{req.QueryName}' does not exist!", nameof(req));
            }
        }

        public T ExecuteQuerySingle<T>(QueryRequest req) where T : new()
        {
            string jsonString = ExecuteQuery(req);
            return JsonConvert.DeserializeObject<T>(jsonString, _booleanJsonConverter);
        }

        public List<T> ExecuteQueryList<T>(QueryRequest req) where T : new()
        {
            string jsonString = ExecuteQuery(req);
            return JsonConvert.DeserializeObject<List<T>>(jsonString, _booleanJsonConverter);
        }

        public void RegisterQuery<T>(string connectionStringName = "AMS") where T : QueryBase
        {
            T query = Activator.CreateInstance<T>();
            query.QueryName = typeof(T).Name;
            query.Connection = ConfigurationManager.ConnectionStrings[connectionStringName].ConnectionString;
            _queries.Add(query);
        }
    }
}
