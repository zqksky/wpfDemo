﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using R2R.Common.Data;

namespace R2R.Server.Library
{
    public class TxnContext
    {
        static Dictionary<int, TxnContext> _contextDic = new Dictionary<int, TxnContext>();
        public static TxnContext Current
        {
            get
            {
                if (_contextDic.ContainsKey(Thread.CurrentThread.ManagedThreadId))
                {
                    return _contextDic[Thread.CurrentThread.ManagedThreadId];
                }
                else
                {
                    return null;
                }
            }
        }

        public static void CreateContext(MessageRequest messageRequest)
        {
            lock (_contextDic)
            {
                if (messageRequest != null)
                {
                    _contextDic[Thread.CurrentThread.ManagedThreadId] = new TxnContext()
                    {
                        ClientID = messageRequest.ClientID,
                        UserID = messageRequest.UserID,
                        ClientProcessID = messageRequest.ClientProcessID,
                        ClientThreadID = messageRequest.ClientThreadID,
                        TxnID = messageRequest.TxnID,
                        TxnStartTime = messageRequest.TxnTime
                    };
                }
                else
                {
                    _contextDic[Thread.CurrentThread.ManagedThreadId] = new TxnContext();
                }
            }
        }

        public static void ClearContext()
        {
            lock (_contextDic)
            {
                if (_contextDic.ContainsKey(Thread.CurrentThread.ManagedThreadId))
                {
                    _contextDic.Remove(Thread.CurrentThread.ManagedThreadId);
                }
            }
        }

        private TxnContext()
        {
            ServerID = Environment.MachineName;
            ServerProcessID = Process.GetCurrentProcess().Id;
            ServerThreadID = Thread.CurrentThread.ManagedThreadId;
            TxnStartTime = DateTime.Now;
        }


        public string UserID { get; private set; }
        public string ClientID { get; private set; }
        public int ClientProcessID { get; private set; }
        public int ClientThreadID { get; private set; }

        public DateTime TxnStartTime { get; private set; }
        public string TxnID { get; private set; }

        public string ServerID { get; private set; }
        public int ServerProcessID { get; private set; }
        public int ServerThreadID { get; private set; }
    }
}
