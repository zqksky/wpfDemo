﻿using System;
using System.Collections.Generic;
using R2R.Common.Library;

namespace R2R.Server.Library
{
    public class ServiceDirector
    {
        private static ServiceDirector _instance;
        private Dictionary<Type, Type> _implementationDic;
        private Dictionary<Type, object> _instanceDic;

        private ServiceDirector()
        {
            _implementationDic = new Dictionary<Type, Type>();
            _instanceDic = new Dictionary<Type, object>();
        }


        public static ServiceDirector Instance
        {
            get
            {
                if(_instance == null)
                {
                    _instance = new ServiceDirector();
                }
                return _instance;
            }
        }

        public void RegisterServiceImplement<TInterface, TImplement>() where TImplement : TInterface, new ()
        {
            _implementationDic[typeof(TInterface)] = typeof(TImplement);
        }

        public object GetServiceInstance(Type interfaceType)
        {
            if(!_implementationDic.ContainsKey(interfaceType))
            {
                throw new InvalidOperationException($"Service implementation for interface {interfaceType.FullName} not registered!");
            }

            if(!_instanceDic.ContainsKey(interfaceType))
            {
                _instanceDic.Add(interfaceType, Activator.CreateInstance(_implementationDic[interfaceType]));
            }
            return _instanceDic[interfaceType];
        }

        public void ClearInstanceCache()
        {
            _instanceDic.Clear();
        }
    }
}