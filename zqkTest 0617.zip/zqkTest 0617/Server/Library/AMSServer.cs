﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Diagnostics;
using System.Reflection;
using System.Xml;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Server.Library.Services;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Oracle.ManagedDataAccess.Client;
using TIBCO.Rendezvous;

namespace R2R.Server.Library
{
    public class AMSServer
    {



        RvServerAgent reportAgent;
        RvServerAgent messageAgent;

        public AMSServer()
        {
            ServiceDirector.Instance.RegisterServiceImplement<IProfileService, ProfileService>();
        }


        private void MessageAgent_MessageReceived(object listener, MessageReceivedEventArgs e)
        {
            CMMessage message = e.Message as CMMessage;
            if (message == null) return;

            string replyJson = "";
            try
            {
                MessageField messageField = message.GetFieldByIndex(0);
                string reqJson = message.GetFieldByIndex(0);
                Console.WriteLine($"Received Message: {messageField.Name} = {reqJson} ");

                if (messageField == null)
                {
                    throw new ArgumentNullException($"messageField is null.");
                }

                if (messageField.Name == nameof(CommandRequest))
                {
                    replyJson = TxnExecutor.ExecuteCommand(reqJson);
                }
                else if (messageField.Name == nameof(QueryRequest))
                {
                    replyJson = TxnExecutor.ExecuteQuery(reqJson);
                }
                else
                {
                    throw new ArgumentNullException($"unrecognized messagefield. {messageField.Name}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                MyLogger.Error(ex);

                MessageResult<dynamic> result = new MessageResult<dynamic>
                {
                    HasError = true,
                    ErrorCode = "S001",
                    Exception = new ServerSideException(ex.GetRootException())
                    {
                        ServerProcessId = Process.GetCurrentProcess().Id,
                        ServerName = System.Environment.MachineName
                    }
                };
                replyJson = JsonConvert.SerializeObject(result);
            }

            var cMListener = listener as CMListener;
            var cmTransport = cMListener.Transport as CMTransport;
            ReplyMessage(message, replyJson, cmTransport);
        }

        private static void ReplyMessage(CMMessage message, string replyJson, CMTransport cmTransport)
        {
            try
            {
                // if message had the reply subject, send the reply
                if (message.ReplySubject != null)
                {
                    Message reply = new Message
                    {
                        SendSubject = message.ReplySubject
                    };
                    reply.AddField("REPLY", replyJson);
                    cmTransport.SendReply(reply, message);
                    Console.WriteLine("Replied to {0} with message:\n {1}", message.ReplySubject, replyJson);
                }
            }
            catch (Exception ex)
            {
                // log error for exception of reply.
                Console.WriteLine(ex.ToString());
                MyLogger.Error(ex);
            }
        }

        private void ReportAgent_MessageReceived(object listener, MessageReceivedEventArgs e)
        {
            try
            {
                TxnContext.CreateContext(null);
                // data is xml.
                string xmlString = e.Message.GetFieldByIndex(0);
                XmlDocument doc = new XmlDocument();
                doc.LoadXml(xmlString);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                MyLogger.Error(ex);
            }
            finally
            {
                TxnContext.ClearContext();
            }
        }

        public void Start()
        {
            //TIBCO.Rendezvous.Environment.Open();

            //reportAgent = new RvServerAgent("Alarm Report", ConfigurationManager.AppSettings["ReportSubject"]);
            //reportAgent.MessageReceived += ReportAgent_MessageReceived;
            //reportAgent.Start(
            //    ConfigurationManager.AppSettings["ReportService"],
            //    ConfigurationManager.AppSettings["ReportNetwork"],
            //    ConfigurationManager.AppSettings["ReportDaemon"]);

            //messageAgent = new RvServerAgent("Command Message", ConfigurationManager.AppSettings["MessageSubject"]);
            //messageAgent.MessageReceived += MessageAgent_MessageReceived;
            //messageAgent.Start(
            //    ConfigurationManager.AppSettings["MessageService"],
            //    ConfigurationManager.AppSettings["MessageNetwork"],
            //    ConfigurationManager.AppSettings["MessageDaemon"]);
        }

        public void Stop()
        {
            if(reportAgent!= null)
            {
                reportAgent.Stop();
            }

            if (messageAgent != null)
            {
                messageAgent.Stop();
            }

            TIBCO.Rendezvous.Environment.Close();
        }
    }
}
