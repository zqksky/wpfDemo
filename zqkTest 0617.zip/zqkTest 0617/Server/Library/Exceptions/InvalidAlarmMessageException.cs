﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Server.Library.Exceptions
{
    public class InvalidAlarmMessageException : Exception
    {
        public InvalidAlarmMessageException(string message) : base(message)
        {

        }

        public InvalidAlarmMessageException(string message, Exception inner) : base(message, inner)
        {

        }
    }
}
