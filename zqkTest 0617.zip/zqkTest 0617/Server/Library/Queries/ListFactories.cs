﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Queries
{
    public class ListFactories : QueryBase
    {
        protected override string InternalExecute(QueryRequest req)
        {
            if (req == null)
            {
                throw new ArgumentNullException(nameof(req));
            }

            string baseSql = $"select {Factory.COL_FACTORY_NAME},{Factory.COL_FACTORY_DESC},{Factory.COL_IS_ENABLED},{Factory.COL_MODIFIED_DT},{Factory.COL_MODIFIED_BY} from {Factory.TableName} ";

            string whereClause = "where 1 = 1";

            if (req.Parameters.Count > 0)
            {
                foreach (var p in req.Parameters)
                {
                    whereClause += $" AND {p.Name}=:{p.Name} ";
                }
            }

            if (whereClause.EndsWith(" AND "))
            {
                whereClause = whereClause.Substring(0, whereClause.Length - 4);
            }

            string orderByClause = "";

            if (req.Ordering != null && !string.IsNullOrEmpty(req.Ordering.OrderBy))
            {
                orderByClause = $" ORDER BY {req.Ordering.OrderBy} {req.Ordering.Order}";
            }

            string finalSql = baseSql + whereClause + orderByClause;


            string resultJson = string.Empty;
            using (OracleConnection oracleConnection = new OracleConnection(Connection))
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    BindByName = true,
                    CommandText = finalSql
                };

                foreach (var p in req.Parameters)
                {
                    object value = p.Value;
                    if(p.Value is bool)
                    {
                        value = (bool)p.Value ? "Y" : "N";
                    }
                    cmd.Parameters.Add(p.Name, value);
                }

                resultJson = ExecuteListCommand(oracleConnection, cmd);
            }
            return resultJson;
        }
    }
}
