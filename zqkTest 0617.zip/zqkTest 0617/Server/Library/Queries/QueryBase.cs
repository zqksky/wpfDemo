﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using R2R.Common.Library;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Queries
{

    public abstract class QueryBase
    {
        protected const string StartRow = "STARTROW";

        protected const string EndRow = "ENDROW";
        
        protected const string PagedSqlFormat =
    @"SELECT * FROM
                ( SELECT t.*, rownum r FROM ( {0} ) t
                    WHERE rownum < :ENDROW )
                    WHERE r >= :STARTROW";


        #region Private fields
        private string _queryName;

        private readonly EventHandlerList _events = new EventHandlerList();
        #endregion

        private static readonly object EventQueryRunning = new object();
        private static readonly object EventQueryRun = new object();

        #region Public Events
        /// <summary>
        /// Event fired when query is running
        /// </summary>
        public event EventHandler QueryRunning
        {
            add { _events.AddHandler(EventQueryRunning, value); }
            remove { _events.RemoveHandler(EventQueryRunning, value); }
        }

        /// <summary>
        /// Event fired when query has been run
        /// </summary>
        public event EventHandler QueryRun
        {
            add { _events.AddHandler(EventQueryRun, value); }
            remove { _events.RemoveHandler(EventQueryRun, value); }
        }

        #endregion

        #region Contructors

        /// <summary>
        /// Default constructor
        /// </summary>
        protected QueryBase()
        {

        }


        /// <summary>
        /// Protected constructor
        /// </summary>
        /// <param name="name"></param>
        protected QueryBase(string name)
            : this()
        {
            QueryName = name;
        }
        #endregion

        #region IQuery Members

        /// <summary>
        /// Gets and sets query name
        /// </summary>
        public string QueryName
        {
            get { return _queryName; }
            set
            {
                if (_queryName != value)
                {
                    _queryName = value;
                }
            }
        }

        /// <summary>
        /// Gets and sets connection string
        /// </summary>
        public string Connection { get; set; }


        /// <summary>
        /// Executes the query and returns the query results in a DataSet
        /// </summary>
        /// <returns>DataSet containing the results of the query</returns>
        public virtual string Execute(QueryRequest req)
        {
            string resultJson = null;
            try
            {
                //bool ValidateParameters(parameters);
                OnQueryRunning(EventArgs.Empty);
                resultJson = InternalExecute(req);
            }
            finally
            {
                OnQueryRun(EventArgs.Empty);
            }
            return resultJson;
        }

        #endregion

        #region Protected Methods

        /// <summary>
        /// Internal Execute method (implemented by derived classes)
        /// </summary>
        /// <returns></returns>
        protected abstract string InternalExecute(QueryRequest req);
        

        /// <summary>
        /// Method to invoke QueryRunning event handler delegate
        /// </summary>
        /// <param name="e"></param>
        protected void OnQueryRunning(EventArgs e)
        {
            if (_events[EventQueryRunning] is EventHandler handler)
            {
                handler(this, e);
            }
        }

        /// <summary>
        /// Method to invoke QueryRun event handler delegate
        /// </summary>
        /// <param name="e"></param>
        protected void OnQueryRun(EventArgs e)
        {
            if (_events[EventQueryRun] is EventHandler handler)
            {
                handler(this, e);
            }
        }
        #endregion


        protected static string ExecuteListCommand(OracleConnection connection, OracleCommand cmd)
        {
            connection.Open();
            string resultJson;
            StringBuilder sbJson = new StringBuilder();
            sbJson.Append("[");
            using (OracleDataReader dr = cmd.ExecuteReader())
            {
                while (dr.Read())
                {
                    sbJson.Append(dr.ToJson() + ",");
                }
            }
            if(sbJson.ToString() != "[")
            {
                sbJson.Remove(sbJson.Length - 1, 1);
            }
            sbJson.Append("]");
            resultJson = sbJson.ToString();
            return resultJson;
        }
    }
}
