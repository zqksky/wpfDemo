﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library.Queries
{
    public class QuerySystemTree : QueryBase
    {
        // TODO: add batch sql support
        protected override string InternalExecute(QueryRequest req)
        {
            if (req == null)
            {
                throw new ArgumentNullException(nameof(req));
            }

            string finalSql = "select owner_system as SYSTEM, name as SUB_SYSTEM from sub_system order by SYSTEM, SUB_SYSTEM";
                        
            DataSet ds = new DataSet();
            using (OracleConnection oracleConnection = new OracleConnection(Connection))
            {
                OracleCommand cmd = new OracleCommand
                {
                    Connection = oracleConnection,
                    CommandType = CommandType.Text,
                    CommandText = finalSql,
                    BindByName = true
                };

                oracleConnection.Open();

                using (OracleDataAdapter da = new OracleDataAdapter(cmd))
                {
                    da.Fill(ds);
                    cmd.Parameters.Clear();
                }
            }
            //return ds;
            return string.Empty;
        }
    }
}
