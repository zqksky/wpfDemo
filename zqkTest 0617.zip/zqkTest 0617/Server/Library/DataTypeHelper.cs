﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Oracle.ManagedDataAccess.Client;

namespace R2R.Server.Library
{
    public class DataTypeHelper
    {
        public static OracleDbType GetOracleDbType(object o)
        {
            if (o is string) return OracleDbType.Varchar2;
            if (o is DateTime) return OracleDbType.Date;
            if (o is Int64) return OracleDbType.Int64;
            if (o is Int32) return OracleDbType.Int32;
            if (o is Int16) return OracleDbType.Int16;
            if (o is sbyte) return OracleDbType.Byte;
            if (o is byte) return OracleDbType.Int16;
            if (o is decimal) return OracleDbType.Decimal;
            if (o is float) return OracleDbType.Single;
            if (o is double) return OracleDbType.Double;
            if (o is byte[]) return OracleDbType.Blob;
            if (o is bool) return OracleDbType.Char;

            return OracleDbType.Varchar2;
        }

        public static OracleDbType GetOracleDbType(Type netType)
        {
            if (netType == typeof(string)) return OracleDbType.Varchar2;
            if (netType == typeof(DateTime)) return OracleDbType.Date;
            if (netType == typeof(Int64)) return OracleDbType.Int64;
            if (netType == typeof(Int32)) return OracleDbType.Int32;
            if (netType == typeof(Int16)) return OracleDbType.Int16;
            if (netType == typeof(sbyte)) return OracleDbType.Byte;
            if (netType == typeof(byte)) return OracleDbType.Int16;
            if (netType == typeof(decimal)) return OracleDbType.Decimal;
            if (netType == typeof(float)) return OracleDbType.Single;
            if (netType == typeof(double)) return OracleDbType.Double;
            if (netType == typeof(byte[])) return OracleDbType.Blob;
            if (netType == typeof(bool)) return OracleDbType.Char;

            return OracleDbType.Varchar2;
        }
    }
}
