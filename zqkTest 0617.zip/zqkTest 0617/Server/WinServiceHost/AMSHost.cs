﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using R2R.Server.Library;

namespace R2R.Server.WinServiceHost
{
    public partial class AMSHost : ServiceBase
    {
        public AMSHost()
        {
            InitializeComponent();
        }

        AMSServer amsServer;
        protected override void OnStart(string[] args)
        {
            amsServer = new AMSServer();
            try
            {
                amsServer.Start();
            }
            finally
            {
            }
        }
        protected override void OnStop()
        {
            amsServer.Stop();
        }
    }
}
