﻿using System;
using R2R.Common.Library;
using R2R.Server.Library;

namespace R2R.Server.ConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {
            AMSServer amsServer = new AMSServer();
            try
            {
                MyLogger.Info("Starting AMS Server...");
                Console.WriteLine("Starting AMS Server...");
                amsServer.Start();
                Console.WriteLine("====================  AMS Server Started!  ====================");
                MyLogger.Info("====================  AMS Server Started!  ====================");
                Console.ReadLine();
            }
            finally
            {
                amsServer.Stop();
                MyLogger.Info("====================  AMS Server Stopped!  ====================");
                Console.WriteLine("====================  AMS Server Stopped!  ====================");
                Console.ReadLine();
            }
        }
    }
}
