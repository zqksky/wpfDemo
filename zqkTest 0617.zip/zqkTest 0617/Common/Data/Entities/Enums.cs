﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public enum AlarmStatus
    {
        New,
        Open,
        Acknowledged,
        Closed,
        Invalid
    }

    public enum AlarmSeverity
    {
        DBNull,
        Information,
        Warning,
        Error,
        Disaster
    }

    public enum AlarmRuleStatus
    {
        Enabled,
        Disabled
    }

    public enum TimeKind
    {
        WorkingTime,
        NonworkingTime
    }

    public enum NotifyDelay : int
    {
        Now = 0,
        OneMinuteDelay = 60,
        FiveMinuteDelay = 300,
        FifteenMinuteDelay = 900
    }
    public enum NotificationChannel
    {
        Email,
        Sms,
        Phone,
        Wechat
    }

}
