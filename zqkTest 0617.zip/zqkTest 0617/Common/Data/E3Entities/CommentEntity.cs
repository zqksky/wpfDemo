﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class CommentEntity
    {
        public string LastEditBy { get; set; }
        public string LastCommnet { get; set; }
        public string LastEditDate { get; set; }
    }
}
