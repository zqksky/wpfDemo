﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data
{
    public class Component
    {
        private string outputName;
        public string OutputName
        {
            get { return this.outputName; }
            set { this.outputName = value; }
        }

        private string url;
        public string Url
        {
            get { return this.url; }
            set { this.url = value; }
        }

        private Dictionary<string, WSClass> classDic = new Dictionary<string, WSClass>();
        public Dictionary<string, WSClass> ClassDic
        {
            get { return this.classDic; }
            set { this.classDic = value; }
        }

        private Dictionary<string, ActionInfo> actionDic = new Dictionary<string, ActionInfo>();
        public Dictionary<string, ActionInfo> ActionDic
        {
            get { return this.actionDic; }
            set { this.actionDic = value; }
        }

    }
}
