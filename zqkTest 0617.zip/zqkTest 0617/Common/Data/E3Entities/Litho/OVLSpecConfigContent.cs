﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.Litho
{
    public class OVLSpecConfigContent
    {
        public string ToolId { get; set; }
        public string ProductId { get; set; }
        public string LayerId { get; set; }
        public string ReticleId { get; set; }
        //reserved
        public string PreTool { get; set; }
        //reserved
        public string PreReticle { get; set; }

        public Boolean C2C { get; set; }
        public string DedicationType { get; set; }
        public string OVLMode { get; set; }
        public string ControlMode { get; set; }
        public float Lambda { get; set; }
        public float LambdaPiRun { get; set; }
        public int MinPointFieAvg { get; set; }
        public string FeebbackStage { get; set; }
        public int MetrologyDays { get; set; }
        public string PreLayer{ get; set; }
        public string PreAlignLayer { get; set; }
        public Boolean ChuckControl { get; set; }
    }
}
