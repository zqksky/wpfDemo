﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Data.E3Entities.ConfigUI
{
    public class ConfigCommonEntity
    {
        public string[] ColumnData;
        public string[] ColumnFormat;
        public string TableName;
        public bool bRequester;
        public bool bApprover;
        public bool bRollbacker;
        public bool bAllowView;
        public bool bAllowWrite;
        public string AllowWriteColumn_CSV;

        #region
        //public string[] Controller { get; set; }
        //public string[] ModelName { get; set; }
        //public string[] VarName { get; set; }
        //public string[] ToolId { get; set; }
        //public string[] Product { get; set; }
        //public string[] Layer { get; set; }
        //public string[] Reticle { get; set; }
        //public double[] Deadband { get; set; }
        //public double[] EwmaFactor { get; set; }
        //public double[] Max { get; set; }
        //public double[] MaxDelta { get; set; }
        //public double[] MaxOfOutput { get; set; }
        //public double[] Min { get; set; }
        //public double[] MinOutput { get; set; }
        //public int[] MinPointsForAvg { get; set; }
        //public bool bRequester { get; set; }
        //public bool bApprover { get; set; }
        //public bool bRollbacker { get; set; }
        //public bool bAllowView { get; set; }
        //public bool bAllowWrite { get; set; }
        //public string AllowWriteColumn_CSV { get; set; }
        #endregion
    }
}
