﻿
//===============================================================================
// R2R LIS Lithography UI for HLMC Project
// 
// TTable.cs
//
// Created By XiaoP(WITS) 2018-11-19
//===============================================================================
#region History
// No.          Date            Modifier        Description
// -------------------------------------------------------------------------------
// #000         2018.11.27      XiaoP          Initial Reelase
//===============================================================================
#endregion

using System.Data;

namespace R2R.Common.Data
{
    public static class TTable
    {
        #region CDTable
        public static DataTable CDTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Tool", System.Type.GetType("System.String"));
            dt.Columns.Add("Product", System.Type.GetType("System.String"));
            dt.Columns.Add("Layer", System.Type.GetType("System.String"));
            dt.Columns.Add("Reticle", System.Type.GetType("System.String"));
            dt.Columns.Add("Energy", System.Type.GetType("System.String"));
            dt.Columns.Add("Focus", System.Type.GetType("System.String"));
            dt.Columns.Add("CtlFlag", System.Type.GetType("System.String"));
            dt.Columns.Add("LastEstiTime", System.Type.GetType("System.String"));
            return dt;
        }
        #endregion

        #region OVLTable
        public static DataTable OVLTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Chuck", System.Type.GetType("System.String"));
            dt.Columns.Add("Tool", System.Type.GetType("System.String"));
            dt.Columns.Add("Product", System.Type.GetType("System.String"));
            dt.Columns.Add("Layer", System.Type.GetType("System.String"));
            dt.Columns.Add("Reticle", System.Type.GetType("System.String"));
            dt.Columns.Add("PreTool", System.Type.GetType("System.String"));
            dt.Columns.Add("PreReticle", System.Type.GetType("System.String"));
            dt.Columns.Add("CtlFlag", System.Type.GetType("System.String"));
            dt.Columns.Add("EXP_X", System.Type.GetType("System.String"));
            dt.Columns.Add("EXP_Y", System.Type.GetType("System.String"));
            dt.Columns.Add("NON_ORT", System.Type.GetType("System.String"));
            dt.Columns.Add("WFT_ROT", System.Type.GetType("System.String"));
            dt.Columns.Add("TRANS_X", System.Type.GetType("System.String"));
            dt.Columns.Add("TRANS_Y", System.Type.GetType("System.String"));
            dt.Columns.Add("ASYM_MAG", System.Type.GetType("System.String"));
            dt.Columns.Add("ASYM_ROT", System.Type.GetType("System.String"));
            dt.Columns.Add("SHT_MAG", System.Type.GetType("System.String"));
            dt.Columns.Add("SHT_ROT", System.Type.GetType("System.String"));
            dt.Columns.Add("LastEstiTime", System.Type.GetType("System.String"));
            return dt;
        }
        #endregion

    }
}
