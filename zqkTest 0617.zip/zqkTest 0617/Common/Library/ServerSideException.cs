﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace R2R.Common.Library
{
    public class ServerSideException : Exception
    {
        public int ServerProcessId { get; set; }
        public string ServerName { get; set; }
        public string ServerExceptionType { get; set; }
        public string ServerExceptionMessage { get; set; }
        public string ServerExceptionStackTrace { get; set; }

        public ServerSideException()
        {
        }

        public ServerSideException(Exception serverException)
        {
            ServerExceptionMessage = serverException.Message;
            ServerExceptionType = serverException.GetType().Name;
            ServerExceptionStackTrace = serverException.StackTrace;
        }

        public override string Message
        {
            get
            {
                return ServerExceptionMessage;
            }
        }

        public override string ToString()
        {
            return $"{nameof(ServerExceptionMessage)} : {ServerExceptionMessage}\n{nameof(ServerExceptionType)} = {ServerExceptionType}\n{nameof(ServerExceptionStackTrace)}:{ServerExceptionStackTrace}\n{nameof(ServerName)} = {ServerName}\n{nameof(ServerProcessId)} = {ServerProcessId}";
        }
    }
}
