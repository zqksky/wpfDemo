﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Library
{
    public class DataTableHelp
    {
        void test(DataTable dt1, DataTable dt2)
        {
            //比较两个数据源的交集
            IEnumerable<DataRow> query1 = dt1.AsEnumerable().Intersect(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt3 = query1.CopyToDataTable();

            //获取两个数据源的并集
            IEnumerable<DataRow> query2 = dt1.AsEnumerable().Union(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt4 = query2.CopyToDataTable();

            //获取两个数据源的差集
            IEnumerable<DataRow> query3 = dt1.AsEnumerable().Except(dt2.AsEnumerable(), DataRowComparer.Default);
            DataTable dt5 = query2.CopyToDataTable();
        }

        static string GetSelectKey(DataRow row, List<string> strListColumnKey)
        {
            string str = string.Empty;
            foreach (var s in strListColumnKey)
            {
                str += s + "= '" + row[s] + "' " + "and ";
            }
            str = str.Trim();
            str = str.TrimEnd(new char[] { 'a', 'n', 'd' });
            return str;
        }

        static string GetRowValue(DataRow row)
        {
            string strValue = string.Empty;
            Array temp = row.ItemArray;
            foreach (var str in temp)
            {
                strValue += str.ToString() + ";";
            }
            strValue = strValue.TrimEnd(';');
            return strValue;
        }

        static bool CompareRowValue(DataRow row1, DataRow row2)
        {
            bool flag = false;
            string str1 = string.Empty;
            string str2 = string.Empty;

            //str1=GetRowValue(row1);
            //str2=GetRowValue(row2);

            str1 = JsonHelp.SerializeObject(row1.ItemArray);
            str2 = JsonHelp.SerializeObject(row2.ItemArray);

            if (str1.Equals(str2))
            {
                flag = true;
            }

            //flag = CompareObject(row1.ItemArray, row2.ItemArray);
            return flag;
        }
        public static DataTable GetMerge(DataTable db1, DataTable db2, List<string> strListColumnKey, ref List<DataRow> strListRowEdit, ref List<DataRow> strListRowChanged, ref List<DataRow> strListRowAdded)
        {
            DataTable dbResult = db1.Copy();
            strListRowEdit = new List<DataRow>();
            strListRowChanged = new List<DataRow>();
            strListRowAdded = new List<DataRow>();
            foreach (DataRow row in db2.Rows)
            {
                string str = GetSelectKey(row, strListColumnKey);
                DataRow[] rows = dbResult.Select(str);
                if (rows.Length > 0)
                {
                    bool flag = CompareRowValue(row, rows[0]);
                    if (flag)
                    {

                    }
                    else
                    {
                        DataTable dbTmp = db1.Clone();
                        DataRow rowEdit = dbTmp.NewRow();
                        rowEdit.ItemArray = rows[0].ItemArray;

                        strListRowEdit.Add(rowEdit);
                        strListRowChanged.Add(row);
                        dbResult.Rows.Remove(rows[0]);
                        dbResult.ImportRow(row);
                    }
                }
                else
                {
                    strListRowAdded.Add(row);
                    dbResult.ImportRow(row);
                }
            }

            return dbResult;
        }

        /// <summary>
        /// dataRow比较
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="drB"></param>
        /// <param name="columnNames">需要比较的列名称</param>
        /// <returns></returns>
        public static bool DataRowCompare(DataRow drA, DataRow drB, string[] columnNames)
        {
            bool flag = false;
            //DataRow 中需要比较的列排序
            ColumnSort(drA, columnNames);
            ColumnSort(drB, columnNames);
            foreach (DataColumn dcA in drA.Table.Columns)
            {
                if (columnNames.Contains(dcA.ColumnName))
                {
                    foreach (DataColumn dcB in drB.Table.Columns)
                    {
                        if (columnNames.Contains(dcB.ColumnName))
                        {
                            if (dcB.ColumnName == dcA.ColumnName)//列名比较
                            {
                                //类型比较
                                if (dcB.DataType != dcA.DataType)
                                {
                                    flag = false;
                                    break;
                                }
                                //值比较
                                else if (CompareObject(drA[dcB.ColumnName], drB[dcB.ColumnName]))
                                {
                                    flag = true;
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            return flag;
        }
        /// <summary>
        /// 按照数组中列名顺序排序
        /// </summary>
        /// <param name="drA"></param>
        /// <param name="columnNames">按照数组中列名顺序排序</param>
        private static void ColumnSort(DataRow drA, string[] columnNames)
        {
            //drA 排序
            int i = 0;
            foreach (string columnName in columnNames)
            {
                if (drA.Table.Columns.Contains(columnName))
                {
                    drA.Table.Columns[columnName].SetOrdinal(i);
                    i++;
                }
            }
        }

        /// <summary>
        /// 引用对象比较
        /// </summary>
        /// <param name="objA"></param>
        /// <param name="objB"></param>
        /// <returns></returns>
        public static bool CompareObject(object objA, object objB)
        {
            bool flag = false;
            if (objA == null || objB == null)
            {
                flag = false;
            }
            else if (objA == DBNull.Value && objB != DBNull.Value)
            {
                flag = false;
            }
            else if (objA != DBNull.Value && objB == DBNull.Value)
            {
                flag = false;
            }
            else if (objA == DBNull.Value && objB == DBNull.Value)
            {
                //objA objB 对应的列类型已经比较过 类型已判断 值一致
                flag = true;
            }
            else if (objA.GetType() != objB.GetType())
            {
                flag = false;
            }
            else if (objA is int || objA is short || objA is long || objA is float || objA is double || objA is decimal)
            {
                //int 01与1      
                if (objA is int)
                {
                    if ((int)objA == (int)objB)
                    {
                        flag = true;
                    }
                }
                else if (objA is short)
                {
                    if ((short)objA == (short)objB)
                    {
                        flag = true;
                    }
                }
                else if (objA is long)
                {
                    if ((long)objA == (long)objB)
                    {
                        flag = true;
                    }
                }
                else if (objA is float)
                {
                    if ((float)objA == (float)objB)
                    {
                        flag = true;
                    }
                }
                else if (objA is double)
                {
                    if ((double)objA == (double)objB)
                    {
                        flag = true;
                    }
                }
                else if (objA is decimal)
                {
                    if ((decimal)objA == (decimal)objB)
                    {
                        flag = true;
                    }
                }
            }
            else
            {
                string strA = JsonHelp.SerializeObject(objA);
                string strB = JsonHelp.SerializeObject(objB); 

                if (strA.Equals(strB))
                {
                    flag = true;
                }
            }
            return flag;
        }
    }
}
