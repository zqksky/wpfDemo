﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Common.Library
{
    public class CommonHelp
    {
        public static Boolean ArgumentIsNull(Dictionary<string, object> dic)
        {
            foreach (string key in dic.Keys)
            {
                if ((string)dic[key] == "" || dic[key] == null)
                {
                    MyLogger.Error(string.Format("Argument <{0}> Is Null", key));
                    throw new ArgumentNullException(key);
                }
            }
            return false;
        }
        public static string GetModelValue(string FieldName, object obj)
        {
            try
            {
                Type Ts = obj.GetType();
                object o = Ts.GetProperty(FieldName).GetValue(obj, null);
                string Value = Convert.ToString(o);
                if (string.IsNullOrEmpty(Value)) return null;
                return Value;
            }
            catch
            {
                return null;
            }
        }
    }
}
