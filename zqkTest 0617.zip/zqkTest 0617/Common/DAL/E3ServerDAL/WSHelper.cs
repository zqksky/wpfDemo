﻿using Newtonsoft.Json;
using R2R.Common.Data;
using System;
using System.CodeDom;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services.Description;
using System.Xml;
using System.Xml.Serialization;

namespace R2R.Common.DAL
{
    public class WSHelper
    {
        private static List<Component> componentList = new List<Component>();

        private static bool InitWebService(out string error)
        {
            try
            {
                error = string.Empty;

                string configPath = Path.Combine(Environment.CurrentDirectory, "WebService.xml");
                componentList = GetComponents(configPath);
                foreach(Component component in componentList)
                {
                    string outputPath = Path.Combine(Environment.CurrentDirectory, component.OutputName);

                    WebClient web = new WebClient();
                    Stream stream = web.OpenRead(component.Url);

                    //创建和格式化 WSDL 文档
                    if (stream != null)
                    {
                        // 格式化WSDL
                        ServiceDescription description = ServiceDescription.Read(stream);

                        // 创建客户端代理类。
                        ServiceDescriptionImporter importer = new ServiceDescriptionImporter
                        {
                            ProtocolName = "Soap",
                            Style = ServiceDescriptionImportStyle.Client,
                            CodeGenerationOptions =
                                CodeGenerationOptions.GenerateProperties | CodeGenerationOptions.GenerateNewAsync
                        };

                        // 添加 WSDL 文档。
                        importer.AddServiceDescription(description, null, null);

                        //使用 CodeDom 编译客户端代理类。
                        CodeNamespace nmspace = new CodeNamespace();
                        CodeCompileUnit unit = new CodeCompileUnit();
                        unit.Namespaces.Add(nmspace);

                        ServiceDescriptionImportWarnings warning = importer.Import(nmspace, unit);
                        CodeDomProvider provider = CodeDomProvider.CreateProvider("CSharp");

                        CompilerParameters parameter = new CompilerParameters
                        {
                            GenerateExecutable = false,
                            // 指定输出dll文件名。
                            OutputAssembly = component.OutputName
                        };

                        parameter.ReferencedAssemblies.Add("System.dll");
                        parameter.ReferencedAssemblies.Add("System.XML.dll");
                        parameter.ReferencedAssemblies.Add("System.Web.Services.dll");
                        parameter.ReferencedAssemblies.Add("System.Data.dll");

                        // 编译输出程序集
                        CompilerResults result = provider.CompileAssemblyFromDom(parameter, unit);

                        // 使用 Reflection 调用 WebService。
                        if (!result.Errors.HasErrors)
                        {
                            BuildClasses(component);
                        }
                        else
                        {
                            error = "反射生成dll文件时异常";
                        }
                    }
                    else
                    {
                        error = "打开WebServiceUrl失败";
                    }
                    stream.Close();
                    stream.Dispose();
                }
                
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return false;
        }

        ///// <summary>
        ///// 反射构建class
        ///// </summary>
        private static void BuildClasses(Component component)
        {
            Assembly asm = Assembly.LoadFrom(component.OutputName);
            foreach (string className in component.ClassDic.Keys)
            {
                Type asmType = asm.GetType(className);
                component.ClassDic[className].ClassType = asmType;

                var methods = Enum.GetNames(typeof(EMethod)).ToList();
                foreach (var item in methods)
                {
                    var methodInfo = asmType.GetMethod(item);
                    if (methodInfo != null)
                    {
                        component.ClassDic[className].MethodDic.Add(item, methodInfo);
                    }
                }

                var properties = Enum.GetNames(typeof(EProperty)).ToList();
                foreach (var item in properties)
                {
                    PropertyInfo fieldInfo = asmType.GetProperty(item);
                    if (fieldInfo != null)
                    {
                        component.ClassDic[className].PropertyDic.Add(item, fieldInfo);
                    }
                }
            }
        }


        //}

        /// <summary>
        /// 获取请求响应
        /// </summary>
        /// <param name="method">方法</param>
        /// <param name="para">参数</param>
        /// <returns>返回：Json串</returns>
        public static string GetResponseString(EMethod method, Dictionary<string, object> dic)
        {
            string result = "error";
            if(componentList.Count == 0)
            {
                InitWebService(out result);
            }
            string methodname = Enum.GetName(typeof(EMethod), method);
            foreach (Component component in componentList)
            {
                foreach(string actionName in component.ActionDic.Keys)
                {
                    if(methodname == actionName)
                    {
                        Type className = component.ClassDic[component.ActionDic[actionName].ClassName].ClassType;
                        Type PareName = component.ClassDic[component.ActionDic[actionName].Parameter].ClassType;

                        object requestObject = Activator.CreateInstance(className);
                        object requestPare = Activator.CreateInstance(PareName);

                        Dictionary<string, PropertyInfo> dicProperty = component.ClassDic[component.ActionDic[actionName].Parameter].PropertyDic;
                        foreach (string key in dic.Keys)
                        {                          
                            dicProperty[key].SetValue(requestPare, dic[key]);
                        }

                        object[] para = { requestPare };
                        Dictionary<string, MethodInfo> dicMethod = component.ClassDic[component.ActionDic[actionName].ClassName].MethodDic;
                        var temp = dicMethod[methodname].Invoke(requestObject, para);
                        return JsonConvert.SerializeObject(temp); 
                    }
                }
            }
            return result;
        }

        private static List<Component> GetComponents(string xmlPath)
        {
            List<Component> componentList = new List<Component>();
            try
            {
                XmlDocument m_XMLDoc = new XmlDocument();
                m_XMLDoc.Load(xmlPath.Trim());

                XmlNodeList nodeList = m_XMLDoc.SelectNodes("/WebService/Component");
                foreach (XmlElement element in nodeList)
                {
                    Component component = new Component();
                    component.OutputName = element.Attributes["OutputDllName"].Value;

                    XmlNode urlNode = element.SelectSingleNode("Url");
                    component.Url = urlNode.Attributes["src"].Value + "?WSDL";

                    XmlNodeList classList = element.SelectNodes("ClassTypes/ClassType");
                    foreach (XmlNode classNode in classList)
                    {
                        WSClass wsClass = new WSClass();
                        component.ClassDic.Add(classNode.Attributes["name"].Value, wsClass);
                    }

                    XmlNodeList actionList = element.SelectNodes("Actions/Action");
                    foreach (XmlNode actionNode in actionList)
                    {
                        ActionInfo actionInfo = new ActionInfo();
                        actionInfo.ClassName = actionNode.Attributes["classname"].Value;
                        actionInfo.Parameter = actionNode.Attributes["parameter"].Value;
                        component.ActionDic.Add(actionNode.Attributes["name"].Value, actionInfo);
                    }
                    componentList.Add(component);
                }
            }
            catch (Exception ex)
            {
            }
            return componentList;
        }

    }
}


