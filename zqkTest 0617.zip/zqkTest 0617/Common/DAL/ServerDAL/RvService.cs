﻿using System;
using System.Configuration;
using System.Diagnostics;
using TIBCO.Rendezvous;

namespace R2R.Common.DAL
{
    public class RvClientAgent
    {
        NetTransport _netTransport = null;
        CMTransport _cmTransport = null;
        Queue _queue = null;
        Listener _inboxListener = null;
        Dispatcher _dispatcher = null;

        string _inbox;
        string _clientId;

        private RvClientAgent()
        {
            // TODO: put this to a new class ClientInformation.
            _clientId = "R2R.Client." + System.Environment.MachineName + "." + Process.GetCurrentProcess().Id;

            TIBCO.Rendezvous.Environment.Open();
            // TODO: read from parameters instead of configuration.
            var service = ConfigurationManager.AppSettings["Service"];
            var network = ConfigurationManager.AppSettings["Network"];
            var daemon = ConfigurationManager.AppSettings["Daemon"];

            _netTransport = new NetTransport(service, network, daemon);
            _cmTransport = new CMTransport(_netTransport);
        }

        private void _inboxListener_MessageReceived(object listener, MessageReceivedEventArgs e)
        {
            // TODO: handle inbox message, raise message received events.
            try
            {
                if (e.Message != null && e.Message.FieldCount > 0)
                {
                    string inboxMessage = e.Message.GetFieldByIndex(0);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        // TODO: change singleton to non-singleton and add interface for extension and supporting unit tests.
        private static RvClientAgent _instance;

        public static RvClientAgent Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new RvClientAgent();
                }
                return _instance;
            }
        }

        public string Send(string request, string fieldName)
        {
            if (_cmTransport != null)
            {
                string replyString = "";
                CMMessage requestMessage = new CMMessage
                {
                    // TODO: use parameter instead of reading config.
                    SendSubject = ConfigurationManager.AppSettings["MessageSubject"]
                };

                requestMessage.AddField(fieldName, request);

                string timeOutConfig = ConfigurationManager.AppSettings["TimeOut"];
                bool parseResult = double.TryParse(timeOutConfig, out double timeOut);
                if (!parseResult)
                {
                    // default
                    timeOut = 30.0;
                }

#if DEBUG
                timeOut = TimeoutValue.WaitForever; // set it long time for debugging.
#endif

                var reply = _cmTransport.SendRequest(requestMessage, timeOut);

                if (reply != null && reply.FieldCount > 0)
                {
                    replyString = reply.GetFieldByIndex(0).Value as string;
                }
                else
                {
                    throw new TimeoutException($"Timed out. Message body: {request}");
                }
                return replyString;
            }
            else
            {
                return null;
            }
        }
    }
}
