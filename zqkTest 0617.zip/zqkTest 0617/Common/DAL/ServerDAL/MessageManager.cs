﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;
using R2R.Common.Data;
using R2R.Common.Library;

namespace R2R.Common.DAL
{
    public class MessageManager : IMessageManager
    {
        public void SendCommand(CommandRequest request)
        {
            Send<CommandRequest, string>(request);
        }
        public Tout SendCommand<Tout>(CommandRequest request) where Tout : new()
        {
            return Send<CommandRequest, Tout>(request);
        }

        public T QuerySingle<T>(QueryRequest request) where T : new()
        {
            if (typeof(T).IsValueType)
            {
                request.ReturnSingleValue = true;
            }
            return Send<QueryRequest, T>(request);
        }


        public List<T> QueryList<T>(QueryRequest request) where T : new()
        {
            return Send<QueryRequest, List<T>>(request);
        }


        private Tout Send<Tin, Tout>(Tin request) where Tin : MessageRequest
        {
            MyLogger.PerformanceStart(request.ToString());
            try
            {
                if (request == null)
                {
                    throw new ArgumentNullException("message request is null.");
                }
                SetTxnContext(request);

                var replyString = RvClientAgent.Instance.Send(JsonConvert.SerializeObject(request), request.GetType().Name);
                var result = JsonConvert.DeserializeObject<MessageResult<Tout>>(replyString);
                if (result.HasError && result.Exception != null)
                {
                    throw result.Exception;
                }
                return result.Content;
            }
            finally
            {
                MyLogger.PerformanceStop(request.ToString());
            }
        }

        private static void SetTxnContext<Tin>(Tin request) where Tin : MessageRequest
        {
            //request.ClientID = Environment.MachineName;
            //request.UserID = ClientInfo.CurrentUser;
            //request.ClientProcessID = Process.GetCurrentProcess().Id;
            //request.ClientThreadID = Thread.CurrentThread.ManagedThreadId;
            //request.TxnTime = DateTime.Now;
            //Random random = new Random();
            //request.TxnID = $"{request.ClientID}_{request.ClientProcessID}_{request.TxnTime.ToString(Formats.FACTORYworksDateFormat)}_{random.Next(999).ToString("D3")}";
        }
    }
}
