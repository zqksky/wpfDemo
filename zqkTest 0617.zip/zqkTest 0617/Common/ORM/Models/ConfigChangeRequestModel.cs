﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Models
{
    [SugarTable("R2R_UI_CONFIG_CHANGE_REQUEST")]
    public class ConfigChangeRequestModel
    {
        //指定主键和自增列，当然数据库中也要设置主键和自增列才会有效
        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "CR_ID")]
        public string CrId { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "MODULE")]
        public string Module { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "TABLE_NAME")]
        public string TbName { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "USER_ID")]
        public string UserId { get; set; }

        [SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "TIMESTAMP")]
        public string TimeStamp { get; set; }

        [SugarColumn(ColumnName = "SUBTABLE_01")]
        public string SubTb1 { get; set; }

        [SugarColumn(ColumnName = "SUBTABLE_02")]
        public string SubTb2 { get; set; }

        [SugarColumn(ColumnName = "JSON_01")]
        public string Json1 { get; set; }

        [SugarColumn(ColumnName = "JSON_02")]
        public string Json2 { get; set; }

        [SugarColumn(ColumnName = "CR_CATEGORY")]
        public string Category { get; set; }

        [SugarColumn(ColumnName = "CR_COMMENT")]
        public string Comment { get; set; }

        [SugarColumn(ColumnName = "CR_STATUS")]
        public string Status { get; set; }

        [SugarColumn(ColumnName = "TRACKTIME")]
        public string TrackTime { get; set; }

        [SugarColumn(ColumnName = "USER_MODIFY")]
        public string UserModify { get; set; }

        [SugarColumn(ColumnName = "REASON")]
        public string Reason { get; set; }
    }
}
