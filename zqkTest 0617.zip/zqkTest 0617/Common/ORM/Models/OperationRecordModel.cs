﻿using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Models
{
    [SugarTable("OperationRecord")]
    public class OperationRecordModel
    {
        //指定主键和自增列，当然数据库中也要设置主键和自增列才会有效
        //[SugarColumn(IsPrimaryKey = true, IsIdentity = true, ColumnName = "PRODUCT")]
        [SugarColumn(ColumnName = "PRODUCT")]
        public string Product { get; set; }

        [SugarColumn(ColumnName = "LAYER")]
        public string Layer { get; set; }

        [SugarColumn(ColumnName = "TOOL")]
        public string Tool { get; set; }

        [SugarColumn(ColumnName = "RECIPE")]
        public string Recipe { get; set; }

        [SugarColumn(ColumnName = "CHAMBER")]
        public string Chamber { get; set; }

        [SugarColumn(ColumnName = "Modify_By_User")]
        public string ModifyUser { get; set; }

        [SugarColumn(ColumnName = "Modify_Time")]
        public string ModifyTime { get; set; }

        [SugarColumn(ColumnName = "Operation")]
        public string Operation { get; set; }

        [SugarColumn(ColumnName = "Status")]
        public string Status { get; set; }

        [SugarColumn(ColumnName = "StrXml")]
        public string StrXml { get; set; }
    }
}
