﻿/*================================================================================================
Sunkaixuan/SqlSugar is licensed under the Apache License 2.0
A permissive license whose main conditions require preservation of copyright and license notices. 
Contributors provide an express grant of patent rights. Licensed works, modifications, 
and larger works may be distributed under different terms and without source code.

Copyright[SqlSugar 4.9.9.10][sunkaixuan]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
=====================================================================================================*/

using SqlSugar;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ORM.Dao
{
    /// <summary>
    /// SqlSugar
    /// </summary>
    public class SugarDao
    {
        //禁止实例化
        private SugarDao()
        {

        }
        public static ConnectionConfig Connection()
        {
            ConnectionConfig conn = new ConnectionConfig();
            conn.ConnectionString= ConnectionString;
            conn.DbType = DbType.Oracle;
            return conn;
        }

        public static string ConnectionString
        {
            get
            {
                //string reval = "Data Source=localhost/orcl;User ID=system;Password=JHL52771jhl;"; //这里可以动态根据cookies或session实现多库切换
                //string reval = "Data Source=192.168.150.135/e3suite;User ID=e3suite;Password=e3suite;"; //这里可以动态根据cookies或session实现多库切换

                //connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=152.135.85.246)(PORT=1521))(CONNECT_DATA=(SID=ora11g)));User Id=amsadmin;Password=amsadmin;Pooling=true;Min Pool Size=2;Max Pool Size=5"
                //string reval = "Data Source=152.135.85.246/ora11g;User ID=amsadmin;Password=amsadmin;"; //这里可以动态根据cookies或session实现多库切换
				
				string reval = ConfigurationManager.ConnectionStrings["AMS"].ConnectionString.ToString(); //这里可以动态根据cookies或session实现多库切换

                return reval;
            }
        }
        public static SqlSugarClient GetInstance()
        {	
            var db = new SqlSugarClient(Connection());
            //var db = new SqlSugarClient(ConnectionString);
            //db.IsEnableLogEvent = true;//启用日志事件
            //db.LogEventStarting = (sql, par) => { Console.WriteLine(sql + " " + par + "\r\n"); };
            return db;
        }
    }
}
