﻿/*================================================================================================
Sunkaixuan/SqlSugar is licensed under the Apache License 2.0
A permissive license whose main conditions require preservation of copyright and license notices. 
Contributors provide an express grant of patent rights. Licensed works, modifications, 
and larger works may be distributed under different terms and without source code.

Copyright[SqlSugar 4.9.9.10][sunkaixuan]

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
=====================================================================================================*/

using SqlSugar;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ORM.Models;
using System.Windows.Forms;

namespace ORM.Dao
{
    public class DbContext<T> where T : class, new()
    {
        public DbContext()
        {
            Db = new SqlSugarClient(new ConnectionConfig()
            {
                //"User Id=e3suite;Password=e3suite;Data Source=(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=192.168.150.135)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=e3suite)))";
                ConnectionString = "Data Source=192.168.150.135/e3suite;User ID=e3suite;Password=e3suite",

                //connectionString = "Data Source=(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=152.135.85.246)(PORT=1521))(CONNECT_DATA=(SID=ora11g)));User Id=amsadmin;Password=amsadmin;Pooling=true;Min Pool Size=2;Max Pool Size=5"
                //ConnectionString = "Data Source=152.135.85.246/ora11g;User ID=amsadmin;Password=amsadmin",

                //ConnectionString = ConfigurationManager.ConnectionStrings["AMS"].ConnectionString.ToString(),
                DbType = DbType.Oracle,

                //ConnectionString = @"Data Source=C:\zqk\WPF\TestSqlSugar\TestSqlSugar\bin\Debug\TemporyRecord.db",
                //DbType = DbType.Sqlite,

                InitKeyType = InitKeyType.Attribute,//从特性读取主键和自增列信息
                IsAutoCloseConnection = true,//开启自动释放模式和EF原理一样我就不多解释了

            });

            //调式代码 用来打印SQL 
            Db.Aop.OnLogExecuting = (sql, pars) =>
            {
                sql = sql + "\r\n" + Db.Utilities.SerializeObject(pars.ToDictionary(it => it.ParameterName, it => it.Value));
                //Console.WriteLine(sql + "\r\n" +
                //    Db.Utilities.SerializeObject(pars.ToDictionary(it => it.ParameterName, it => it.Value)));
                //Console.WriteLine();

                MessageBox.Show(sql);
            };

            //Db.CodeFirst.SetStringDefaultLength(200/*设置varchar默认长度为200*/).InitTables(typeof(TestTableModel));//执行完数据库就有这个表了 
            //Db.CodeFirst.SetStringDefaultLength(200/*设置varchar默认长度为200*/).InitTables(typeof(TestTableModel2));//执行完数据库就有这个表了 
            //Db.CodeFirst.SetStringDefaultLength(200/*设置varchar默认长度为200*/).InitTables(typeof(OperationRecordModel));//执行完数据库就有这个表了 
            //Db.CodeFirst.SetStringDefaultLength(200/*设置varchar默认长度为200*/).InitTables(typeof(PreActionRecordModel));//执行完数据库就有这个表了
            //Db.CodeFirst.SetStringDefaultLength(200/*设置varchar默认长度为200*/).InitTables(typeof(ActionRecordModel));//执行完数据库就有这个表了 
        }

        //注意：不能写成静态的，不能写成静态的
        public SqlSugarClient Db;//用来处理事务多表查询和复杂的操作
        public SimpleClient<FactoryModel> FactoryDb { get { return new SimpleClient<FactoryModel>(Db); } }//用来处理表的常用操作

        //public SimpleClient<TestTableModel> TestTableDb { get { return new SimpleClient<TestTableModel>(Db); } }//用来处理表的常用操作
        //public SimpleClient<TestTableModel2> TestTable2Db { get { return new SimpleClient<TestTableModel2>(Db); } }//用来处理表的常用操作

        //public SimpleClient<OperationRecordModel> OperationRecordDb { get { return new SimpleClient<OperationRecordModel>(Db); } }//用来处理表的常用操作
        //public SimpleClient<PreActionRecordModel> PreActionRecordDb { get { return new SimpleClient<PreActionRecordModel>(Db); } }//用来处理表的常用操作
        //public SimpleClient<ActionRecordModel> ActionRecordDb { get { return new SimpleClient<ActionRecordModel>(Db); } }//用来处理表的常用操作

        public SimpleClient<ConfigHistoryModel> CfgHistoryDb { get { return new SimpleClient<ConfigHistoryModel>(Db); } }//用来处理表的常用操作
        public SimpleClient<ConfigChangeRequestModel> CfgChangeRequestDb { get { return new SimpleClient<ConfigChangeRequestModel>(Db); } }//用来处理表的常用操作

        public SimpleClient<T> CurrentDb { get { return new SimpleClient<T>(Db); } }//用来处理T表的常用操作

        /// <summary>
        /// 获取所有
        /// </summary>
        /// <returns></returns>
        public virtual List<T> GetList()
        {
            CurrentDb.AsQueryable().ToJson();
            return CurrentDb.GetList();
        }

        /// <summary>
        /// 获取所有
        /// </summary>
        /// <returns></returns>
        public virtual string GetListToJson()
        {
            return CurrentDb.AsQueryable().ToJson();
        }

        /// <summary>
        /// 根据主键插入
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool Insert(T obj)
        {
            return CurrentDb.Insert(obj);
        }

        /// <summary>
        /// 根据主键批量插入
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool InsertRange(T[] objs)
        {
            return CurrentDb.InsertRange(objs);
        }

        /// <summary>
        /// 根据主键删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool Delete(dynamic id)
        {
            return CurrentDb.Delete(id);
        }

        /// <summary>
        /// 根据主键批量删除
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool DeleteRange(dynamic[] ids)
        {
            return CurrentDb.DeleteByIds(ids);
        }

        /// <summary>
        /// 根据主键更新
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool Update(T obj)
        {
            return CurrentDb.Update(obj);
        }

        /// <summary>
        /// 根据主键批量更新
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public virtual bool UpdateRange(T[] objs)
        {
            return CurrentDb.UpdateRange(objs);
        }
    }
}
