﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.Common
{
    public static class RegionNames
    {
        public const string MainRegion = "MainRegion";
        public const string FactorySettingsRegion = "FactorySettingsRegion";
        public const string SystemSettingsRegion = "SystemSettingsRegion";
        public const string UserSettingsRegion = "UserSettingsRegion";
        public const string AlarmRegion = "AlarmRegion";
        public const string AlarmRuleSettingsRegion = "AlarmRuleSettingsRegion";
        public const string AlarmRuleRegion = "AlarmRuleRegion";
        public const string AlarmRuleLevelRegion = "AlarmRuleLevelRegion";
        public const string NotifiedGroupInLevel = "NotifiedGroupInLevelRegion";
        public const string QuickWatchRegion = "QuickWatchRegion";
        public const string NotificationGroupSettingsRegion = "NotificationGroupSettingsRegion";
        public const string NotificationGroupUserMapping = "NotificationGroupUserMapping";
    }
}
