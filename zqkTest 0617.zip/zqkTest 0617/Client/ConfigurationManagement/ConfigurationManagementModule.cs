﻿using ConfigurationManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Service;
using Prism.Ioc;
using Prism.Modularity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManagement
{
    public class ConfigurationManagementModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }


        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<ConfigMain>();
            containerRegistry.RegisterForNavigation<ConfigTest>();
            containerRegistry.RegisterForNavigation<MyTest>();
            containerRegistry.RegisterForNavigation<ConfigLitho>();
            //containerRegistry.RegisterForNavigation<SpecialJobList>();
            //containerRegistry.RegisterForNavigation<CreateSpecialJob>();

            containerRegistry.RegisterSingleton<IConfigMainService, ConfigMainService>();
            //containerRegistry.RegisterSingleton<ICRListService, CRListService>();
            //containerRegistry.RegisterSingleton<ICRDetailService, CRDetailService>();
            //containerRegistry.RegisterSingleton<IVersionLogListService, VersionLogListService>();
            //containerRegistry.RegisterSingleton<IVersionLogDetailService, VersionLogDetailService>();
        }
    }
}
