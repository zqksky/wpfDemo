﻿using ConfigurationService.Service;
using System.Collections.Generic;
using System.Windows.Controls;
using System.Windows.Data;

namespace ConfigurationManagement.Views
{
    /// <summary>
    /// Interaction logic for MyTest.xaml
    /// </summary>
    public partial class MyTest : UserControl
    {
        public MyTest()
        {
            InitializeComponent();

            AddColumn(strColumnName);
        }

        //public MyTest(List<string> strListColumn)
        //{
        //    InitializeComponent();

        //    AddColumn(strListColumn);
        //}

        List<string> strColumnName = new List<string>() { "可用资金", "可取资金", "手续费", "手续费2" };
        public  void AddColumn(List<string> strListColumn)
        {
            #region
            //List<MyTestModel> list = new List<MyTestModel>();
            //list.Add(new MyTestModel() { IsSelected = false, ConfigInfoValue = new Dictionary<string, string>() { { "可用资金", "1000.0" }, { "可取资金", "958.0" }, { "手续费", "1.68" }, { "手续费2", "1.68" } } });

            foreach (var str in strListColumn)
            {
                grdConfig.Columns.Add(new DataGridTextColumn { Header = str, Binding = new Binding("ConfigInfoValue." + string.Format("[{0}]", str)) });
            }
            //foreach (var node in list.First().ConfigInfoValue)
            //{
            //    grdConfig.Columns.Add(new DataGridTextColumn { Header = node.Key, Binding = new Binding("ConfigInfoValue."+string.Format("[{0}]", node.Key))});
            //}
            grdConfig.AutoGenerateColumns = false;  //去掉多余列
            grdConfig.CanUserAddRows = false; //去掉多余行
            //grdConfig.ItemsSource = list;
            #endregion

            #region
            //List<Dictionary<String, String>> list_dic = new List<Dictionary<String, String>>
            //      {
            //         new Dictionary<String,String>()
            //         {
            //             {   "可用资金","1000.0"},
            //             {   "可取资金", "958.0" },
            //             {   "手续费", "1.68"},
            //             {   "手续费2", "1.68"},
            //         },
            //          new Dictionary<String,String>()
            //         {
            //             {   "可用资金","1100.0"},
            //             {   "可取资金", "1958.0" },
            //             {   "手续费", "31.68"},
            //             {   "手续费2", "1.68"},
            //         },
            //      };
            ////foreach (var node in list_dic.First())
            ////{
            ////    grdConfig.Columns.Add(new DataGridTextColumn { Header = node.Key, Binding = new Binding(string.Format("[{0}]", node.Key)) });
            ////}

            //foreach (var str in strList)
            //{
            //    grdConfig.Columns.Add(new DataGridTextColumn { Header = str, Binding = new Binding(string.Format("[{0}]",str)) });
            //}

            //grdConfig.AutoGenerateColumns = false;  //去掉多余列
            //grdConfig.CanUserAddRows = false; //去掉多余行
            //grdConfig.ItemsSource = list_dic;
            #endregion
        }
    }
}
