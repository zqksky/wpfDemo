﻿using Prism.Ioc;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConfigurationManagement.Views
{
    /// <summary>
    /// Interaction logic for ConfigLitho.xaml
    /// </summary>
    public partial class ConfigLitho : UserControl
    {
        public ConfigLitho()
        {
            InitializeComponent();
        }

        IContainerExtension _container;
        IRegionManager _regionManager;

        public ConfigLitho(IContainerExtension container, IRegionManager regionManager)
        {
            InitializeComponent();
            _container = container;
            _regionManager = regionManager;
        }

        private void btnLithoMain_Click(object sender, RoutedEventArgs e)
        {
            var view = _container.Resolve<CfgLitho>();
            IRegion region = _regionManager.Regions["ContentRegion"];
            region.RemoveAll();
            region.Add(view);
        }

        private void btnSingleLot_Click(object sender, RoutedEventArgs e)
        {
            var view = _container.Resolve<SingleLot>();
            IRegion region = _regionManager.Regions["ContentRegion"];
            region.RemoveAll();
            region.Add(view);
        }
        
    }
}
