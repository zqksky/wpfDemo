﻿using ConfigurationManagement.ViewModels;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConfigurationManagement.Views
{
    /// <summary>
    /// Interaction logic for ConfigMain.xaml
    /// </summary>
    public partial class ConfigMain : UserControl
    {
        public ConfigMain()
        {
            InitializeComponent();

            #region by zqk add
            //cmbModule.SelectedIndex = -1;
            //if (cmbModule.Items.Count > 0)
            //{
            //    cmbModule.SelectedIndex = 0;
            //}
            #endregion
        }
    }
}
