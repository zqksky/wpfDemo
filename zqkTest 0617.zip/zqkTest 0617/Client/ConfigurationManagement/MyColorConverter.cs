﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;

namespace ConfigurationManagement
{
    [ValueConversion(typeof(string), typeof(string))]
    public class ColorConverter : IValueConverter
    {
        public object Convert(object value, Type typeTarget, object param, CultureInfo culture)
        {

            string strValue = value.ToString();
            if (strValue.IndexOf('/') > 0)
            {
                String[] ss = strValue.Split('/');
                if (ss[1] == "安全")
                    return "Green";
                if (ss[1] == "低偏压" || ss[1] == "高偏压")
                    return "Orange";
                return "Red";
            }
            return "Black";


        }
        public object ConvertBack(object value, Type typeTarget, object param, CultureInfo culture)
        {
            return "";
        }
    }

    [ValueConversion(typeof(string), typeof(string))]
    public class MyColorConverter : IMultiValueConverter
    {
        #region Implementation of IMultiValueConverter

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            if (values[1] is DataRow)
            {
                //Change the background of any cell with 1.0 to light red.
                var cell = (DataGridCell)values[0];
                var row = (DataRow)values[1];
                var columnName = cell.Column.SortMemberPath;

                if (row[columnName].IsNumeric() && row[columnName].ToDouble() == 1.0)
                    return new SolidColorBrush(Colors.LightSalmon);

            }
            return SystemColors.ControlLight;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            throw new System.NotImplementedException();
        }

        #endregion
    }

    public static class Extensions
    {
        public static bool IsNumeric(this object val)
        {
            double test;
            return double.TryParse(val.ToString(), out test);
        }

        public static double ToDouble(this object val)
        {
            return Convert.ToDouble(val);
        }
    }
}


