﻿using ConfigurationManagement.Views;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ConfigurationManagement.ViewModels
{
    public class CRListViewModel : ViewModelBase
    {
        public CRListViewModel()
        {
            Title = "CR Detail";
        }

        #region
        private ObservableCollection<CRListInfoModel> _CRInfoList;
        public ObservableCollection<CRListInfoModel> CRInfoList
        {
            get { return _CRInfoList; }
            set { SetProperty(ref _CRInfoList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _CRViewCommand;
        public DelegateCommand CRListCommand =>
            _CRViewCommand ?? (_CRViewCommand = new DelegateCommand(OnCRView));
        #endregion

        #region Event Fun
        void OnCRView()
        {
            var window = new Window();//Windows窗体      
            CRDetail parameter = new CRDetail();
            CRDetailViewModel view = (CRDetailViewModel)parameter.DataContext;
            //view.setViewModel(this.SelectedCDValue);
            window.Content = parameter;
            window.Title = Title;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            //window.Show();
        }
        #endregion
    }
}
