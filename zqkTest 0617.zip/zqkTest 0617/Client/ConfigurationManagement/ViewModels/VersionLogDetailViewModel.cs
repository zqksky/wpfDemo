﻿using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManagement.ViewModels
{
    public class VersionLogDetailViewModel : ViewModelBase
    {
        public VersionLogDetailViewModel()
        {
            Title = "VersionLog Detail";
        }

        #region
        private ObservableCollection<ConfigMainInfoModel> _VersionLogDetailInfoList;
        public ObservableCollection<ConfigMainInfoModel> VersionLogDetailInfoList
        {
            get { return _VersionLogDetailInfoList; }
            set { SetProperty(ref _VersionLogDetailInfoList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _RollbackCommand;
        public DelegateCommand CRDetailCommand =>
            _RollbackCommand ?? (_RollbackCommand = new DelegateCommand(OnRollback));
        #endregion

        #region Event Fun
        void OnRollback()
        {

        }
        #endregion
    }
}
