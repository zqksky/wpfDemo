﻿using ConfigurationManagement.Views;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ConfigurationManagement.ViewModels
{
    public class VersionLogListViewModel : ViewModelBase
    {
        public VersionLogListViewModel()
        {
            Title = "VersionLog Detail";
        }

        #region Filed
        private ObservableCollection<VersionLogListInfoModel> _VersionLogInfoList;
        public ObservableCollection<VersionLogListInfoModel> VersionLogInfoList
        {
            get { return _VersionLogInfoList; }
            set { SetProperty(ref _VersionLogInfoList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _viewLogCommand;
        public DelegateCommand ViewLogCommand =>
            _viewLogCommand ?? (_viewLogCommand = new DelegateCommand(OnViewLog));
        #endregion

        #region Event Fun
        void OnViewLog()
        {
            var window = new Window();//Windows窗体      
            VersionLogDetail parameter = new VersionLogDetail();
            VersionLogDetailViewModel view = (VersionLogDetailViewModel)parameter.DataContext;
            //view.setViewModel(this.SelectedCDValue);
            window.Content = parameter;
            window.Title = Title;
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            //window.Show();
        }
        #endregion
    }
}
