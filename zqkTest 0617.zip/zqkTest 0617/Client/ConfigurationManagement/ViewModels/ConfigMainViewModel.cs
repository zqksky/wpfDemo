﻿using ConfigurationManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Models;
using Microsoft.Win32;
using ORM.Dao;
using ORM.Models;
using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Data.E3Entities.ConfigUI;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;

namespace ConfigurationManagement.ViewModels
{
    public class ConfigMainViewModel : ViewModelBase
    {
        public ConfigMainViewModel()
        {

        }

        public IConfigMainService ConfigMainService { get; set; }
        public ConfigMainViewModel(IConfigMainService configMainService)
        {
            this.ConfigMainService = configMainService;
            Title = "ConfigMain";

            this.moduleList = configMainService.GetModuleList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
            this.moduleList = new List<string>() {"Module1", "Module2", "Module3" };
        }

        #region Variable
        string strRequestId;
        string strUserId;
        string strClientVersion;
        string strTableName;
        string strSelectedModel;
        string strSelectedProduct;
        string strSelectedLayer;
        string strSelectedTool;
        string strSelectedRecipe;

        bool bIsAdd = false;
        bool bIsRowEndEdit = false;

        ControlConfig controlCfg = new ControlConfig();
        List<string> strListColumnName = new List<string>();

        int selectRowIndex = -1;
        string strOperation = string.Empty;
        string strPreEditRow = string.Empty;
        string strEndEditRow = string.Empty;

        CfgOperationRecord OpertionRecord = new CfgOperationRecord();

        DataTable dbAdd = new DataTable();
        DataTable dbEdit = new DataTable();
        DataTable dbDelete = new DataTable();
        DataTable dbUpdate = new DataTable();
        List<CfgUpdateRecord> UpdateRecord = new List<CfgUpdateRecord>();
        List<CfgUpdateRecord> DeleteRecord = new List<CfgUpdateRecord>();
        #endregion

        #region Init
        void InitDefineParameter()
        {
            bIsAdd = false;
            bIsRowEndEdit = false;

            UpdateRecord.Clear();
            DeleteRecord.Clear();
            strListColumnName.Clear();

            strOperation = string.Empty;
            strPreEditRow = string.Empty;
            strEndEditRow = string.Empty;
        }
        void InitChangeDataTable()
        {
            DataTable db = ConfigDataTable.ToTable();
            dbAdd = db.Clone();
            dbEdit = db.Clone();
            dbDelete = db.Clone();
            dbUpdate = db.Clone();
            dbDelete.Rows.Clear();
            dbUpdate.Rows.Clear();

            OpertionRecord.dbSource = db.Copy();
            OpertionRecord.dbAdd = db.Clone();
            OpertionRecord.dbDelete = db.Clone();
            OpertionRecord.dbEdit = db.Clone();
        }

        string GetChangeData()
        {
            string strJson = string.Empty;
            //DataTable db = ConfigDataTable.ToTable();
            //OpertionRecord.dbSource = db.Copy();
            OpertionRecord.dbAdd = dbAdd.Copy();
            OpertionRecord.dbDelete = dbDelete.Copy();
            OpertionRecord.dbEdit = dbEdit.Copy();

            strJson = JsonHelp.SerializeObject(OpertionRecord);
            return strJson;
        }
        #endregion

        #region Field
        private string module;
        public string Module
        {
            get { return this.module; }
            set { SetProperty(ref this.module, value); }
        }

        private List<string> moduleList;
        public List<string> ModuleList
        {
            get { return this.moduleList; }
            set { SetProperty(ref this.moduleList, value); }
        }

        private string product;
        public string Product
        {
            get { return this.product; }
            set { SetProperty(ref this.product, value); }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private string layer;
        public string Layer
        {
            get { return this.layer; }
            set { SetProperty(ref this.layer, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string tool;
        public string Tool
        {
            get { return this.tool; }
            set { SetProperty(ref this.tool, value); }
        }

        private List<string> toolList;
        public List<string> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }

        private string recipe;
        public string Recipe
        {
            get { return this.recipe; }
            set { SetProperty(ref this.recipe, value); }
        }

        private List<string> recipeList;
        public List<string> RecipeList
        {
            get { return this.recipeList; }
            set { SetProperty(ref this.recipeList, value); }
        }

        private int selectedRowIndex;
        public int SelectedRowIndex
        {
            get { return this.selectedRowIndex; }
            set { SetProperty(ref this.selectedRowIndex, value); }
        }

        private DataRowView selectedRowValue;
        public DataRowView SelectedRowValue
        {
            get { return this.selectedRowValue; }
            set { SetProperty(ref this.selectedRowValue, value); }
        }

        private DataView _ConfigDataTable;
        public DataView ConfigDataTable
        {
            get { return _ConfigDataTable; }
            set { SetProperty(ref _ConfigDataTable, value); }
        }

        private DataViewManager _ConfigDataTableManager;
        public DataViewManager ConfigDataTableManager
        {
            get { return _ConfigDataTableManager; }
            set { SetProperty(ref _ConfigDataTableManager, value); }
        }

        private ConfigMainInfoModel selectedConfigValue;
        public ConfigMainInfoModel SelectedConfigValue
        {
            get { return this.selectedConfigValue; }
            set { SetProperty(ref this.selectedConfigValue, value); }
        }

        private ObservableCollection<ConfigMainInfoModel> _configMainInfoList;
        public ObservableCollection<ConfigMainInfoModel> ConfigMainInfoList
        {
            get { return _configMainInfoList; }
            set { SetProperty(ref _configMainInfoList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _cmbSelectionChangedCommand;
        public DelegateCommand<object> CmbSelectionChangedCommand =>
            _cmbSelectionChangedCommand ?? (_cmbSelectionChangedCommand = new DelegateCommand<object>(OnCmbSelectionChanged));

        private DelegateCommand _configListCommand;
        public DelegateCommand ConfigListCommand =>
            _configListCommand ?? (_configListCommand = new DelegateCommand(OnConfigList));

        private DelegateCommand _cRListCommand;
        public DelegateCommand CRListCommand =>
            _cRListCommand ?? (_cRListCommand = new DelegateCommand(OnCRList));

        private DelegateCommand _versionLogCommand;
        public DelegateCommand VersionLogCommand =>
            _versionLogCommand ?? (_versionLogCommand = new DelegateCommand(OnVersionLog));

        private DelegateCommand _addListCommand;
        public DelegateCommand AddListCommand =>
            _addListCommand ?? (_addListCommand = new DelegateCommand(OnAddListClick));

        private DelegateCommand<object> _BeginningEditCommand;
        public DelegateCommand<object> BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand<object>(OnBeginningEdit));

        private DelegateCommand<object> _CellEditingCommand;
        public DelegateCommand<object> CellEditingCommand =>
            _CellEditingCommand ?? (_CellEditingCommand = new DelegateCommand<object>(OnCellEditing));

        private DelegateCommand<object> _RowEditEndingCommand;
        public DelegateCommand<object> RowEditEndingCommand =>
            _RowEditEndingCommand ?? (_RowEditEndingCommand = new DelegateCommand<object>(OnRowEditEnding));

        private DelegateCommand<object> _SelectionChangedCommand;
        public DelegateCommand<object> SelectionChangedCommand =>
            _SelectionChangedCommand ?? (_SelectionChangedCommand = new DelegateCommand<object>(OnSelectionChanged));

        private DelegateCommand _saveListCommand;
        public DelegateCommand SaveListCommand =>
            _saveListCommand ?? (_saveListCommand = new DelegateCommand(OnSaveListClick));

        private DelegateCommand _deleteListCommand;
        public DelegateCommand DeleteListCommand =>
            _deleteListCommand ?? (_deleteListCommand = new DelegateCommand(OnDeleteListClick));

        private DelegateCommand _ImportExcelCommand;
        public DelegateCommand ImportExcelCommand =>
            _ImportExcelCommand ?? (_ImportExcelCommand = new DelegateCommand(OnImportExcel));

        private DelegateCommand _ExportExcelCommand;
        public DelegateCommand ExportExcelCommand =>
            _ExportExcelCommand ?? (_ExportExcelCommand = new DelegateCommand(OnExportExcel));
        #endregion

        #region Event Fun
        void OnImportExcel()
        {
            //string strExcelFile = @"C:\zqk\test.xlsx";
            string strExcelFile = string.Empty;
            OpenFileDialog open = new OpenFileDialog();//定义打开文本框实体
            open.Title = "打开文件";//对话框标题
            open.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
            if ((bool)open.ShowDialog().GetValueOrDefault())
            {
                strExcelFile = System.IO.Path.GetFullPath(open.FileName);
                ConfigCommonEntity eneity = new ConfigCommonEntity();
                eneity = this.ConfigMainService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName);

                List<string> strListColumnKey = this.ConfigMainService.GetColumnKeyName(eneity.ColumnFormat);

                DataTable db = ConfigDataTable.ToTable();
                DataTable dbImport = this.ConfigMainService.CreateDataTable(eneity, ExcelHelp.Inport(strExcelFile)).ToTable();

                List<DataRow> drAddRow = new List<DataRow>();
                List<DataRow> drEndEditRow = new List<DataRow>();
                List<DataRow> drListPreEditRow = new List<DataRow>();
                DataTable dataTableDistinct = DataTableHelp.GetMerge(db, dbImport, strListColumnKey,ref drListPreEditRow, ref drEndEditRow,ref drAddRow);

                AddImportExcelUpdate(drListPreEditRow, drEndEditRow, drAddRow);

                ConfigDataTable = new DataView(dataTableDistinct);

                //ConfigDataTable = this.ConfigMainService.CreateDataTable(eneity, ExcelHelp.Inport(strExcelFile));
            }
        }

        void OnExportExcel()
        {
            //string strExcelFile = @"C:\zqk\test.xlsx";
            string strExcelFile = string.Empty;
            SaveFileDialog save = new SaveFileDialog();//定义打开文本框实体
            save.Title = "打开文件";//对话框标题
            save.Filter = "文件（.xlsx）|*.xlsx|所有文件|*.*";//文件扩展名
            if ((bool)save.ShowDialog().GetValueOrDefault())
            {
                strExcelFile = System.IO.Path.GetFullPath(save.FileName);
                ExcelHelp.Export(ConfigDataTable.ToTable(), strExcelFile);
            }
        }

        void OnCmbSelectionChanged(object obj)
        {
            var cmb = obj as ComboBox;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbModule":
                    strSelectedModel=cmb.SelectedValue.ToString();
                    this.ProductList = new List<string>() { "Product1", "Product2", "Product3" };
                    break;
                case "cmbProduct":
                    strSelectedProduct = cmb.SelectedValue.ToString();
                    this.LayerList = new List<string>() { "Layer1", "Layer2", "Layer3" };
                    break;
                case "cmbLayer":
                    strSelectedLayer = cmb.SelectedValue.ToString();
                    this.ToolList = new List<string>() { "Tool1", "Tool2", "Tool3" };
                    break;
                case "cmbTool":
                    strSelectedTool = cmb.SelectedValue.ToString();
                    this.RecipeList = new List<string>() { "Recipe1", "Recipe2", "Recipe3" };
                    break;
                case "cmbRecipe":
                    strSelectedRecipe = cmb.SelectedValue.ToString();
                    break;
                default:
                    break;
            }            
        }

        void OnConfigList()
        {
            strRequestId = "REQ_002";
            strUserId = "AMAT";
            strClientVersion = "7.8.0.43";
            strSelectedModel = "LITHO";
            strSelectedProduct = "PROD_LITHO_T001";
            strSelectedLayer = "FIRSTLAYER_LITHO_T001";
            strSelectedTool = "EQP_LITHO_T001";
            strSelectedRecipe = "PH-RCP";
            strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

            InitDefineParameter();

            //string strJson = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
            //ControlSpecConfigEntity eneity = JsonHelp.DeserializeJsonToObject<ControlSpecConfigEntity>(strJson);

            ConfigCommonEntity eneity = new ConfigCommonEntity();
            eneity = this.ConfigMainService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName);

            strListColumnName = this.ConfigMainService.GetColumnName(eneity.ColumnFormat);
            ConfigDataTable = this.ConfigMainService.CreateDataTable(eneity);
            controlCfg = this.ConfigMainService.GetControlCfg(eneity);

            //ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;
            InitChangeDataTable();

            if (ConfigDataTable.Count > 0)
            {
                //取得DataTable的第一行  
                //selectedRowValue = ConfigDataTable.ToTable().AsEnumerable().First<DataRow>();

                //取得DataTable的最后一行  
                //selectedRowValue = ConfigDataTable.ToTable().AsEnumerable().Last<DataRow>();

                //foreach (DataRowView drv in ConfigDataTable)
                //{
                //    selectedRowValue = drv;
                //    selectedRowValue.EndEdit();
                //    break;
                //}
                SelectedRowIndex = 0;
            }
        }

        void OnCRList()
        {
            var window = new Window();//Windows窗体      
            CRList parameter = new CRList();
            CRListViewModel view = (CRListViewModel)parameter.DataContext;
            //view.setViewModel(this.SelectedCDValue);
            window.Content = parameter;
            window.Title = "CR List";
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            //window.Show();
        }

        void OnVersionLog()
        {
            var window = new Window();//Windows窗体      
            VersionLogList parameter = new VersionLogList();
            VersionLogListViewModel view = (VersionLogListViewModel)parameter.DataContext;
            //view.setViewModel(this.SelectedCDValue);
            window.Content = parameter;
            window.Title = "VersionLog List";
            window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            window.ShowDialog();
            //window.Show();
        }

        void OnAddListClick()
        {
            bIsAdd = true;
            DataRowView dvRow = ConfigDataTable.AddNew();
            selectedRowValue = dvRow;
            DataRow row = this.selectedRowValue.Row;

            //SelectedRowIndex = ConfigDataTable.Count;
        }

        void OnBeginningEdit(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("BeginningEdit");

            selectedRowValue.BeginEdit();
            DataRow dataRow = selectedRowValue.Row;

            //selectRowIndex = ConfigDataTable.Table.Rows.IndexOf(selectedRowValue.Row);
            //DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(selectRowIndex);//获取选中单元格所在行

            //CellEditChangColor(dgv);
        }

        #region 选中单元格变色或编辑单元格后变色
        void CellEditChangColor(DataGrid dgv)
        {
            int colindex = -1;
            int rowindex = -1;

            colindex = dgv.CurrentCell.Column.DisplayIndex;//获取选中单元格列号
            rowindex = dgv.SelectedIndex;//获取选中单元格行号
            DataGridRow row = (DataGridRow)dgv.ItemContainerGenerator.ContainerFromIndex(rowindex);//获取选中单元格所在行
            DataGridCellsPresenter presenter = GetVisualChild<DataGridCellsPresenter>(row);//函数调用，获取行中所有单元格的集合
            DataGridCell cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);//锁定选中单元格（重点）
            if (cell != null)
            {
                dgv.ScrollIntoView(row, dgv.Columns[colindex]);
                cell = (DataGridCell)presenter.ItemContainerGenerator.ContainerFromIndex(colindex);
                cell.Focus();
                cell.Background = new SolidColorBrush(Colors.DarkOrange);//OK!问题解决，选中单元格变色
                cell.Focusable = false;
            }
        }
        //获取行中所有单元格集合的函数
        public static T GetVisualChild<T>(Visual parent) where T : Visual
        {
            T childContent = default(T);
            int numVisuals = VisualTreeHelper.GetChildrenCount(parent);
            for (int i = 0; i < numVisuals; i++)
            {
                Visual v = (Visual)VisualTreeHelper.GetChild(parent, i);
                childContent = v as T;
                if (childContent == null)
                {
                    childContent = GetVisualChild<T>(v);
                }
                if (childContent != null)
                { break; }
            }
            return childContent;
        }
        #endregion

        void OnCellEditing(object obj)
        {
            var dgv = obj as DataGrid;

            #region Test
            ////var str = dgv.SelectedValue;
            ////var str2 = dgv.SelectedItem;

            ////DataRow dataRow = selectedRowValue.Row;
            ////if (dataRow.HasVersion(DataRowVersion.Proposed))
            ////{
            ////    if (object.ReferenceEquals(dataRow[0, DataRowVersion.Current], dataRow[0, DataRowVersion.Proposed]))
            ////    {
            ////        MessageBox.Show("The original and the proposed are the same.");
            ////        dataRow.CancelEdit();
            ////    }
            ////    else
            ////    {
            ////        dataRow.AcceptChanges();
            ////        MessageBox.Show("The original and the proposed are different.");
            ////    }
            ////}

            //int editIndex = dgv.SelectedIndex;
            //if (iListChangeIndex.Contains(editIndex))
            //{
            //    //string strValue = string.Empty;
            //    //Array temp = ConfigDataTable.Table.Rows[editIndex].ItemArray;
            //    //foreach (var str in temp)
            //    //{
            //    //    strValue += str.ToString() + ";";
            //    //}
            //    //if (strListEditValue.Contains(strValue))
            //    //{
            //    //    iListChangeIndex.Remove(editIndex);
            //    //}
            //}
            //else
            //{
            //    string strValue = string.Empty;
            //    Array temp = ConfigDataTable.Table.Rows[editIndex].ItemArray;
            //    foreach (var str in temp)
            //    {
            //        strValue += str.ToString() + ";";
            //    }
            //    strListEditValue.Add(strValue);
            //    iListChangeIndex.Add(editIndex);
            //}

            ////MessageBox.Show("CellEditing");
            #endregion
        }


        void OnRowEditEnding(object obj)
        {
            var dgv = obj as DataGrid;
            DataRow dataRow = selectedRowValue.Row;

            selectRowIndex = ConfigDataTable.Table.Rows.IndexOf(selectedRowValue.Row);

            if (bIsAdd)
            {
                selectRowIndex = ConfigDataTable.Count-1;
                strPreEditRow = string.Empty;
            }
            else
            {
                strPreEditRow = JsonHelp.SerializeObject(dataRow.ItemArray);
            }

            #region
            //var str = dgv.SelectedItem;
            //int editIndex = dgv.SelectedIndex;

            //ConfigDataTable.RowStateFilter = DataViewRowState.CurrentRows;

            //设置dataview显示的过滤条件，下面的条件是只显示添加或者修改的内容
            //ConfigDataTable.RowStateFilter = DataViewRowState.Added | DataViewRowState.ModifiedCurrent;

            //设置dataview显示的过滤条件，下面的条件是只显示添加或者修改的内容
            //ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedOriginal;

            //设置dataview显示的过滤条件，未更改的行
            //ConfigDataTable.RowStateFilter = DataViewRowState.Unchanged;

            //设置dataview显示的过滤条件，未更改行，已删除行
            //ConfigDataTable.RowStateFilter = DataViewRowState.OriginalRows;

            //ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;
            #endregion

            selectedRowValue.EndEdit();
            selectedRowValue.Row.AcceptChanges();

            //test
            //strEndEditRow = JsonHelp.SerializeObject(ConfigDataTable.Table.Rows[selectRowIndex].ItemArray);
            //ConfigDataTable.ToTable().AcceptChanges();
            //strEndEditRow = JsonHelp.SerializeObject(ConfigDataTable.Table.Rows[selectRowIndex].ItemArray);

            bIsRowEndEdit = true;

            //CellEditChangColor(dgv);
        }

        void OnSelectionChanged(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("SelectionChanged");
            if (bIsRowEndEdit)
            {
                CfgUpdateRecord update = new CfgUpdateRecord();

                strOperation = bIsAdd ? "Add" : "Edit";

                bIsAdd = false;
                bIsRowEndEdit = false;

                //ConfigDataTable.ToTable().AcceptChanges();
                DataRow rowSelect = ConfigDataTable.ToTable().Rows[selectRowIndex];
                strEndEditRow = JsonHelp.SerializeObject(ConfigDataTable.Table.Rows[selectRowIndex].ItemArray);

                DataRow r = SelectedRowValue.Row;
                //ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;

                if (strOperation.ToUpper().Equals("ADD"))
                {
                    dbAdd.ImportRow(rowSelect);
                }
                else
                {
                    dbEdit.ImportRow(rowSelect);
                }

                update.Operation = strOperation;
                update.OldData = strPreEditRow;
                update.NewData = strEndEditRow;
                UpdateRecord.Add(update);

                ConfigDataTable.RowStateFilter = DataViewRowState.CurrentRows;

                //Test
                //GetApprovedUpdate(UpdateRecord);
            }

        }

        void OnSaveListClick()
        {
            foreach (var obj in UpdateRecord)
            {
                //return;
            }

            if (UpdateRecord.Count > 0)
            {
                DataView dvUpdate = GetApprovedUpdate(UpdateRecord);

                //DataView dvUpdate = GetAllUpdate();

                if (dvUpdate.Count > 0)
                {
                    //string strContent = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
                    strRequestId = "REQ_002";
                    strUserId = "AMAT";
                    strClientVersion = "7.8.0.43";
                    strSelectedModel = "LITHO";
                    strSelectedProduct = "PROD_LITHO_T001";
                    strSelectedLayer = "FIRSTLAYER_LITHO_T001";
                    strSelectedTool = "EQP_LITHO_T001";
                    strSelectedRecipe = "PH-RCP";
                    strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

                    string strContent = JsonHelp.SerializeObject(GetCurrentEntity(dvUpdate));
                    bool flag = this.ConfigMainService.R2R_UI_Config_Update(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName, strContent);
                    if (flag)
                    {
                        dbAdd.Rows.Clear();
                        dbEdit.Rows.Clear();
                        dbUpdate.Rows.Clear();
                    }
                    else
                    {
                    }
                }
            }              
        }

        void OnDeleteListClick()
        {
            SaveDataToHistoryDb();
            SaveDataToChangeRequestDb();

            if (this.selectedRowValue == null)
            {
                MessageBox.Show("Row is not selected!");
                return;
            }

            CfgUpdateRecord delete = new CfgUpdateRecord();
            delete.Operation = "delete";
            delete.OldData= JsonHelp.SerializeObject(selectedRowValue.Row.ItemArray);
            delete.NewData = string.Empty;
            DeleteRecord.Add(delete);

            //int i = ConfigDataTable.ToTable().Rows.IndexOf(selectedRowValue.Row);
            //ConfigDataTable.Delete(i);
            //ConfigDataTable.RowStateFilter = DataViewRowState.Deleted;

            dbDelete.ImportRow(selectedRowValue.Row);
            selectedRowValue.Row.Delete();

            DataView dvDelete = new DataView(dbDelete);
            if (dvDelete.Count > 0)
            {
                string strContent = JsonHelp.SerializeObject(GetCurrentEntity(dvDelete));
                //bool flag = this.ConfigMainService.Config_R2R_PH_CONTROL_SPECS_CONFIG_Delete(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedReticle, strTableName, strContent);
                //if (flag)
                //{
                //}
                //else
                //{
                //}
                dbDelete.Clear();
            }

        }
        #endregion

        #region
        void SaveDataToHistoryDb()
        {
            var cm = new CfgHistoryManager();//不能把Manager变成静对象保证每次都NEW出来

            string strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
            string strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

            var cfgChange = new ConfigHistoryModel() { CrId = strCrId, Module = "add", TbName = "tb1", UserId = "test", TimeStamp = strTimeStamp, Action = "" };
            cm.Insert(cfgChange);//插入
            
            var list2 = cm.GetList();
        }

        void SaveDataToChangeRequestDb()
        {
            var cm = new CfgChangeRequestManager();//不能把Manager变成静对象保证每次都NEW出来

            string strJson = GetChangeData();

            string strCrId = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss-") + DateTime.Now.Millisecond + "_User";
            string strTimeStamp = DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");
            string strTrackTime= DateTime.Now.ToString("yyyy-MM-dd-HH-mm-ss");

            var cfgChange = new ConfigChangeRequestModel() { CrId = strCrId, Module = "Litho", TbName = "tb1", UserId = "test", TimeStamp = strTimeStamp, SubTb1 = "" ,Json1= strJson,
                                                             SubTb2 = "", Json2 = "", Category ="",Comment="",Status="Draft",TrackTime="",UserModify=""};
            cm.Insert(cfgChange);//插入

            var list2 = cm.GetList();
        }

        void AddImportExcelUpdate(List<DataRow> oldEditRows, List<DataRow> newEditRows, List<DataRow> addRows)
        {
            for (int i = 0; i < newEditRows.Count; i++)
            {
                CfgUpdateRecord edit = new CfgUpdateRecord();
                edit.Operation = "Edit";
                edit.OldData = JsonHelp.SerializeObject(oldEditRows[i].ItemArray);
                edit.NewData= JsonHelp.SerializeObject(newEditRows[i].ItemArray);
                UpdateRecord.Add(edit);
            }

            foreach (DataRow row in addRows)
            {
                CfgUpdateRecord add = new CfgUpdateRecord();
                add.Operation = "Add";
                add.OldData = string.Empty;
                add.NewData = JsonHelp.SerializeObject(row.ItemArray);
                UpdateRecord.Add(add);
            }
        }

        DataView GetApprovedUpdate(List<CfgUpdateRecord> cfgRecord)
        {
            DataTable db = ConfigDataTable.Table.Clone();
            foreach (var obj in cfgRecord)
            {
                DataRow row = db.NewRow();
                if (obj.NewData.Equals(""))
                {
                    continue;
                }
                else
                {
                    row.ItemArray = JsonHelp.DeserializeJsonToObject<object[]>(obj.NewData);
                    db.Rows.Add(row);
                }

            }

            return db.DefaultView;
        }

        DataView GetAllUpdate()
        {
            DataView dvUpdate = new DataView();

            ConfigDataTable.RowStateFilter = DataViewRowState.ModifiedCurrent;

            dvUpdate = new DataView(ConfigDataTable.ToTable());

            ConfigDataTable.RowStateFilter = DataViewRowState.CurrentRows;

            return dvUpdate;
        }

        ConfigCommonEntity GetCurrentEntity(DataView dv)
        {
            ConfigCommonEntity eneity = new ConfigCommonEntity();

            eneity.ColumnData = this.ConfigMainService.DataviewConvert(dv, strListColumnName);
            eneity.ColumnFormat = controlCfg.ColumnFormat;
            eneity.TableName = controlCfg.TableName;
            eneity.AllowWriteColumn_CSV = controlCfg.AllowWriteColumn_CSV;
            eneity.bAllowView = controlCfg.bAllowView;
            eneity.bAllowWrite = controlCfg.bAllowWrite;
            eneity.bApprover = controlCfg.bApprover;
            eneity.bRequester = controlCfg.bRequester;
            eneity.bRollbacker = controlCfg.bRollbacker;

            return eneity;
        }
        #endregion
    }
}
