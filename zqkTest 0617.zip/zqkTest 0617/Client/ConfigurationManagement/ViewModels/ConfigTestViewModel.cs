﻿using ConfigurationManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Data.E3Entities.ConfigUI;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ConfigurationManagement.ViewModels
{
    public class ConfigTestViewModel : ViewModelBase
    {
        public ConfigTestViewModel()
        {

        }

        public IConfigMainService ConfigMainService { get; set; }
        public ConfigTestViewModel(IConfigMainService configMainService)
        {
            this.ConfigMainService = configMainService;
            Title = "ConfigTest";

            this.ModuleList = new List<string>() { "Module1", "Module2", "Module3" };
        }

        #region Variable
        string strRequestId;
        string strUserId;
        string strClientVersion;
        string strTableName;
        string strSelectedModel;
        string strSelectedProduct;
        string strSelectedLayer;
        string strSelectedTool;
        string strSelectedRecipe;
        ControlConfig controlCfg = new ControlConfig();
        #endregion

        #region Field
        private bool _IsSelectAll;
        public bool IsSelectAll
        {
            get { return this._IsSelectAll; }
            set { SetProperty(ref this._IsSelectAll, value); }
        }

        private string module;
        public string Module
        {
            get { return this.module; }
            set { SetProperty(ref this.module, value); }
        }

        private List<string> moduleList;
        public List<string> ModuleList
        {
            get { return this.moduleList; }
            set { SetProperty(ref this.moduleList, value); }
        }

        private string product;
        public string Product
        {
            get { return this.product; }
            set { SetProperty(ref this.product, value); }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private string layer;
        public string Layer
        {
            get { return this.layer; }
            set { SetProperty(ref this.layer, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string tool;
        public string Tool
        {
            get { return this.tool; }
            set { SetProperty(ref this.tool, value); }
        }

        private List<string> toolList;
        public List<string> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }

        private string recipe;
        public string Recipe
        {
            get { return this.recipe; }
            set { SetProperty(ref this.recipe, value); }
        }

        private List<string> recipeList;
        public List<string> RecipeList
        {
            get { return this.recipeList; }
            set { SetProperty(ref this.recipeList, value); }
        }

        private ConfigTestModel selectedConfigValue;
        public ConfigTestModel SelectedConfigValue
        {
            get { return this.selectedConfigValue; }
            set { SetProperty(ref this.selectedConfigValue, value); }
        }

        private ObservableCollection<ConfigTestModel> configTestList;
        public ObservableCollection<ConfigTestModel> ConfigTestList
        {
            get { return configTestList; }
            set { SetProperty(ref configTestList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _cmbSelectionChangedCommand;
        public DelegateCommand<object> CmbSelectionChangedCommand =>
            _cmbSelectionChangedCommand ?? (_cmbSelectionChangedCommand = new DelegateCommand<object>(OnCmbSelectionChanged));

        private DelegateCommand _configListCommand;
        public DelegateCommand ConfigListCommand =>
            _configListCommand ?? (_configListCommand = new DelegateCommand(OnConfigList));

        private DelegateCommand<object> _SelectAllCommand;
        public DelegateCommand<object> SelectAllCommand =>
            _SelectAllCommand ?? (_SelectAllCommand = new DelegateCommand<object>(OnSelectAll));

        private DelegateCommand<object> _SelectCommand;
        public DelegateCommand<object> SelectCommand =>
            _SelectCommand ?? (_SelectCommand = new DelegateCommand<object>(OnSelect));

        private DelegateCommand _AddCommand;
        public DelegateCommand AddCommand =>
            _AddCommand ?? (_AddCommand = new DelegateCommand(OnAdd));

        private DelegateCommand<object> _DeleteCommand;
        public DelegateCommand<object> DeleteCommand =>
            _DeleteCommand ?? (_DeleteCommand = new DelegateCommand<object>(OnDelete));

        private DelegateCommand<object> _EditCommand;
        public DelegateCommand<object> EditCommand =>
            _EditCommand ?? (_EditCommand = new DelegateCommand<object>(OnEdit));

        private DelegateCommand<object> _SaveCommand;
        public DelegateCommand<object> SaveCommand =>
            _SaveCommand ?? (_SaveCommand = new DelegateCommand<object>(OnSave));

        private DelegateCommand<object> _BeginningEditCommand;
        public DelegateCommand<object> BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand<object>(OnBeginningEdit));

        private DelegateCommand<object> _CellEditingCommand;
        public DelegateCommand<object> CellEditingCommand =>
            _CellEditingCommand ?? (_CellEditingCommand = new DelegateCommand<object>(OnCellEditing));

        private DelegateCommand<object> _RowEditEndingCommand;
        public DelegateCommand<object> RowEditEndingCommand =>
            _RowEditEndingCommand ?? (_RowEditEndingCommand = new DelegateCommand<object>(OnRowEditEnding));

        //private DelegateCommand _cRListCommand;
        //public DelegateCommand CRListCommand =>
        //    _cRListCommand ?? (_cRListCommand = new DelegateCommand(OnCRList));

        //private DelegateCommand _versionLogCommand;
        //public DelegateCommand VersionLogCommand =>
        //    _versionLogCommand ?? (_versionLogCommand = new DelegateCommand(OnVersionLog));

        #endregion

        #region Event Fun
        void OnCmbSelectionChanged(object obj)
        {
            var cmb = obj as ComboBox;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbModule":
                    strSelectedModel = cmb.SelectedValue.ToString();
                    this.ProductList = new List<string>() { "Product1", "Product2", "Product3" };
                    break;
                case "cmbProduct":
                    strSelectedProduct = cmb.SelectedValue.ToString();
                    this.LayerList = new List<string>() { "Layer1", "Layer2", "Layer3" };
                    break;
                case "cmbLayer":
                    strSelectedLayer = cmb.SelectedValue.ToString();
                    this.ToolList = new List<string>() { "Tool1", "Tool2", "Tool3" };
                    break;
                case "cmbTool":
                    strSelectedTool = cmb.SelectedValue.ToString();
                    this.RecipeList = new List<string>() { "Recipe1", "Recipe2", "Recipe3" };
                    break;
                case "cmbRecipe":
                    strSelectedRecipe = cmb.SelectedValue.ToString();
                    break;
                default:
                    break;
            }
        }

        void OnConfigList()
        {
            strRequestId = "REQ_001";
            strUserId = "AMAT";
            strClientVersion = "7.8.0.43";
            strSelectedModel = "LITHO";
            strSelectedProduct = "PROD_LITHO_T001";
            strSelectedLayer = "FIRSTLAYER_LITHO_T001";
            strSelectedTool = "EQP_LITHO_T001";
            strSelectedRecipe = "PH-RCP";
            strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

            //string strJson = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
            //ControlSpecConfigEntity eneity = JsonHelp.DeserializeJsonToObject<ControlSpecConfigEntity>(strJson);

            ConfigCommonEntity eneity = new ConfigCommonEntity();
            eneity = this.ConfigMainService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName);

            controlCfg.AllowWriteColumn_CSV = eneity.AllowWriteColumn_CSV;
            controlCfg.bAllowView = eneity.bAllowView;
            controlCfg.bAllowWrite = eneity.bAllowWrite;
            controlCfg.bApprover = eneity.bApprover;
            controlCfg.bRequester = eneity.bRequester;
            controlCfg.bRollbacker = eneity.bRollbacker;

            test(GetRowData(GetColumnData(eneity.ColumnData)));
        }

        struct StructColumn
        {
            public string columnType;
            public string columnName;
            public string columnAttribute;
        }

        void GetColumnFormat(string[] arry)
        {
            List<StructColumn> structData = new List<StructColumn>();
            foreach (var str in arry)
            {
                string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                StructColumn column = new StructColumn();
                column.columnName = sArray[0];
                column.columnType = sArray[1];
                column.columnAttribute = sArray[2];
                structData.Add(column);
            }
        }

        List<List<string>> GetColumnData(string[] arry)
        {
            List<List<string>> columnData = new List<List<string>>();
            foreach (var str in arry)
            {
                string[] sArray = System.Text.RegularExpressions.Regex.Split(str, ":", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                columnData.Add(sArray.ToList());
            }

            return columnData;
        }

        void test(List<List<string>> rowData)
        {
            ObservableCollection<ConfigTestModel> configList = new ObservableCollection<ConfigTestModel>();
            for (int i = 0; i < rowData.Count; i++)
            {
                ConfigMainInfoModel cfgModel = new ConfigMainInfoModel();
                cfgModel.Controller = rowData[i][0];
                cfgModel.ModelName = rowData[i][1];
                cfgModel.VarName = rowData[i][2];
                cfgModel.ToolId = rowData[i][3];
                cfgModel.Product = rowData[i][4];
                cfgModel.Layer = rowData[i][5];
                cfgModel.Reticle = rowData[i][6];
                cfgModel.Deadband = double.Parse(rowData[i][7]);
                cfgModel.EwmaFactor = double.Parse(rowData[i][8]);
                cfgModel.Max = double.Parse(rowData[i][9]);
                cfgModel.MaxDelta = double.Parse(rowData[i][10]);
                cfgModel.MaxOfOutput = double.Parse(rowData[i][11]);
                cfgModel.Min = double.Parse(rowData[i][12]);
                cfgModel.MinOutput = double.Parse(rowData[i][13]);
                cfgModel.MinPointsForAvg = int.Parse(rowData[i][14]);
                ConfigTestModel model = new ConfigTestModel();
                model.IsSelected = false;
                model.ConfigInfoValue = cfgModel;
                configList.Add(model);
            }
            ConfigTestList = new ObservableCollection<ConfigTestModel>(configList);
        }

        List<List<string>> GetRowData(List<List<string>> columnData)
        {
            List<List<string>> rowData = new List<List<string>>();

            for (int n = 0; n < columnData[0].Count; n++)
            {
                List<string> strList = new List<string>();
                for (int i = 0; i < columnData.Count; i++)
                {
                    strList.Add(columnData[i][n]);
                }
                rowData.Add(strList);
            }


            return rowData;
        }
        #endregion

        #region
        //void GetControlCfg(ConfigCommonEntity eneity)
        //{
        //    controlCfg.AllowWriteColumn_CSV = eneity.AllowWriteColumn_CSV;
        //    controlCfg.bAllowView = eneity.bAllowView;
        //    controlCfg.bAllowWrite = eneity.bAllowWrite;
        //    controlCfg.bApprover = eneity.bApprover;
        //    controlCfg.bRequester = eneity.bRequester;
        //    controlCfg.bRollbacker = eneity.bRollbacker;
        //}

        //void setControlCfg(ConfigCommonEntity eneity)
        //{
        //    eneity.AllowWriteColumn_CSV = controlCfg.AllowWriteColumn_CSV;
        //    eneity.bAllowView = controlCfg.bAllowView;
        //    eneity.bAllowWrite = controlCfg.bAllowWrite;
        //    eneity.bApprover = controlCfg.bApprover;
        //    eneity.bRequester = controlCfg.bRequester;
        //    eneity.bRollbacker = controlCfg.bRollbacker;
        //}

        //void OnCRList()
        //{
        //    var window = new Window();//Windows窗体      
        //    CRList parameter = new CRList();
        //    CRListViewModel view = (CRListViewModel)parameter.DataContext;
        //    //view.setViewModel(this.SelectedCDValue);
        //    window.Content = parameter;
        //    window.Title = "CR List";
        //    window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        //    window.ShowDialog();
        //    //window.Show();
        //}

        //void OnVersionLog()
        //{
        //    var window = new Window();//Windows窗体      
        //    VersionLogList parameter = new VersionLogList();
        //    VersionLogListViewModel view = (VersionLogListViewModel)parameter.DataContext;
        //    //view.setViewModel(this.SelectedCDValue);
        //    window.Content = parameter;
        //    window.Title = "VersionLog List";
        //    window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        //    window.ShowDialog();
        //    //window.Show();
        //}

        //void OnCurrentCellChanged(object obj)
        //{
        //    var dgv = obj as DataGrid;
        //    MessageBox.Show("CurrentCellChanged" );
        //}

        //void OnSaveListClick()
        //{
        //    string strContent = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
        //    strRequestId = "REQ_002";
        //    strUserId = "AMAT";
        //    strClientVersion = "7.8.0.43";
        //    strSelectedModel = "LITHO";
        //    strSelectedProduct = "PROD_LITHO_T001";
        //    strSelectedLayer = "FIRSTLAYER_LITHO_T001";
        //    strSelectedTool = "EQP_LITHO_T001";
        //    strSelectedRecipe = "PH-RCP";
        //    strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

        //    //string strContent = JsonHelp.SerializeObject(GetCurrentEntity());
        //    bool flag = this.ConfigMainService.R2R_UI_Config_Update(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName, strContent);
        //    if (flag)
        //    {
        //    }
        //    else
        //    {
        //    }
        //}

        //void OnDeleteListClick()
        //{
        //    ConfigMainInfoList.Remove(SelectedConfigValue);
        //    SelectedConfigValue = ConfigMainInfoList.Last();

        //    //string strContent = JsonHelp.SerializeObject(GetCurrentEntity());
        //    //bool flag = this.ConfigMainService.Config_R2R_PH_CONTROL_SPECS_CONFIG_Delete(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedReticle, strTableName, strContent);
        //    //if (flag)
        //    //{
        //    //}
        //    //else
        //    //{
        //    //}
        //}

        //ConfigCommonEntity GetCurrentEntity()
        //{
        //    ConfigCommonEntity eneity = new ConfigCommonEntity();

        //    return eneity;
        //}
        #endregion

        #region Test
        /// <summary>
        /// 全选
        /// </summary>
        /// <param name="id"></param>
        public void OnSelectAll(object id)
        {
            foreach (var item in configTestList)
            {
                item.IsSelected = IsSelectAll;
            }
        }

        /// <summary>
        /// 单选
        /// </summary>
        /// <param name="id"></param>
        public void OnSelect(object id)
        {
            ConfigTestModel cm = ConfigTestList.Where(p => p.IsSelected).FirstOrDefault();
            if (cm != null)
            {
                if (!cm.IsSelected && IsSelectAll)
                {
                    IsSelectAll = false;
                }
                else if (cm.IsSelected && !IsSelectAll)
                {
                    foreach (var item in ConfigTestList)
                    {
                        if (!item.IsSelected) return;
                    }
                    IsSelectAll = true;
                }
            }
        }

        /// <summary>
        /// 判断是否选中
        /// </summary>
        /// <param name="onlyOne">是否单选</param>
        /// <returns></returns>
        public bool SelectValidate(bool onlyOne = false)
        {
            if (this.ConfigTestList.Count(p => p.IsSelected) < 1)
            {
                MessageBox.Show("未勾选数据！");
                return false;
            }

            if (onlyOne)
            {
                if (this.ConfigTestList.Count(p => p.IsSelected) > 1)
                {
                    MessageBox.Show("只能勾选一条数据！");
                    return false;
                }
            }

            return true;
        }

        string strBeginEdit = string.Empty;
        string strEndEdit = string.Empty;
        void OnBeginningEdit(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("CellEditing");

            SelectedConfigValue.IsSelected = true;

            //strBeginEdit = JsonHelp.SerializeObject(SelectedConfigValue);
            strBeginEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (!SelectValidate(true))
            {
                return;
            }

            ConfigTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("BeginningEdit " + model.ConfigInfoValue.Product);
        }

        void OnCellEditing(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("CellEditing");

            SelectedConfigValue.IsSelected = true;
            strEndEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (strBeginEdit.Equals(strEndEdit))
            {
                MessageBox.Show("Not Value Change");
                return;
            }
            if (!SelectValidate(true))
            {
                return;
            }

            ConfigTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("CellEditing " + model.ConfigInfoValue.Product);
        }

        void OnRowEditEnding(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("RowEditing");

            SelectedConfigValue.IsSelected = true;

            strEndEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (strBeginEdit.Equals(strEndEdit))
            {
                MessageBox.Show("Not Value Change");
                return;
            }

            if (!SelectValidate(true))
            {
                return;
            }

            ConfigTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("RowEditing " + model.ConfigInfoValue.Product);
        }

        void OnAdd()
        {
            ConfigMainInfoModel cfgModel = new ConfigMainInfoModel();
            cfgModel.Controller = "ControllerNew";
            cfgModel.ModelName = "ModelNameNew";
            cfgModel.VarName = "ReticleNew";
            cfgModel.ToolId = "ToolNew";
            cfgModel.Product = "ProductNew";
            cfgModel.Layer = "LayerNew";
            cfgModel.Reticle = "ReticleNew";
            cfgModel.Deadband = 2;
            cfgModel.EwmaFactor = 3;
            cfgModel.Max = 15;
            cfgModel.MaxDelta = 14;
            cfgModel.MaxOfOutput = 12;
            cfgModel.Min = 10;
            cfgModel.MinOutput = 8;
            cfgModel.MinPointsForAvg = 5;

            ConfigTestModel cfg = new ConfigTestModel();
            cfg.IsSelected = true;
            cfg.ConfigInfoValue = cfgModel;
            
            ConfigTestList.Add(cfg);
            SelectedConfigValue = cfg;
        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="obj"></param>
        public void OnDelete(object obj = null)
        {
            if (!SelectValidate())
            {
                return;
            }

            MessageBoxResult result = MessageBox.Show("是否删除选中项?", "提示", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            StringBuilder sb = new StringBuilder();

            bool hasSelect = false;

            ////获取选中的数据
            //foreach (var v in ConfigTestList)
            //{
            //    if (v.IsSelected)
            //    {
            //        sb.Append(v.ConfigInfoValue.Product + ";");
            //        hasSelect = true;
            //    }
            //}
            for (int i = ConfigTestList.Count - 1; i >= 0; --i)
            {
                if (ConfigTestList[i].IsSelected)
                {
                    hasSelect = true;
                    ConfigTestList.Remove(ConfigTestList[i]);
                }
            }

            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            //MessageBox.Show("选中 " + sb.ToString());
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="obj"></param>
        public void OnEdit(object obj = null)
        {
            if (!SelectValidate(true))
            {
                return;
            }

            ConfigTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("选中 " + model.ConfigInfoValue.Product);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        public void OnSave(object obj = null)
        {
            if (!SelectValidate(true))
            {
                return;
            }

            ConfigTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("Save " + model.ConfigInfoValue.Product);
        }
        #endregion
    }
}
