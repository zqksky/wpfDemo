﻿using ConfigurationManagement.Views;
using ConfigurationService.IService;
using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using R2R.Common.Data.E3Entities.ConfigUI;
using R2R.Common.Library;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ConfigurationManagement.ViewModels
{
    public class MyTestViewModel : ViewModelBase
    {
        public MyTestViewModel()
        {

        }

        public IConfigMainService ConfigMainService { get; set; }
        public MyTestViewModel(IConfigMainService configMainService)
        {
            this.ConfigMainService = configMainService;
            Title = "MyTest";

            this.ModuleList = new List<string>() { "Module1", "Module2", "Module3" };
        }

        #region Variable
        string strRequestId;
        string strUserId;
        string strClientVersion;
        string strTableName;
        string strSelectedModel;
        string strSelectedProduct;
        string strSelectedLayer;
        string strSelectedTool;
        string strSelectedRecipe;
        List<string> strListColumnName = new List<string>();
        ControlConfig controlCfg = new ControlConfig();
        #endregion

        #region Field
        private bool _IsSelectAll;
        public bool IsSelectAll
        {
            get { return this._IsSelectAll; }
            set { SetProperty(ref this._IsSelectAll, value); }
        }

        private string module;
        public string Module
        {
            get { return this.module; }
            set { SetProperty(ref this.module, value); }
        }

        private List<string> moduleList;
        public List<string> ModuleList
        {
            get { return this.moduleList; }
            set { SetProperty(ref this.moduleList, value); }
        }

        private string product;
        public string Product
        {
            get { return this.product; }
            set { SetProperty(ref this.product, value); }
        }

        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private string layer;
        public string Layer
        {
            get { return this.layer; }
            set { SetProperty(ref this.layer, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string tool;
        public string Tool
        {
            get { return this.tool; }
            set { SetProperty(ref this.tool, value); }
        }

        private List<string> toolList;
        public List<string> ToolList
        {
            get { return this.toolList; }
            set { SetProperty(ref this.toolList, value); }
        }

        private string recipe;
        public string Recipe
        {
            get { return this.recipe; }
            set { SetProperty(ref this.recipe, value); }
        }

        private List<string> recipeList;
        public List<string> RecipeList
        {
            get { return this.recipeList; }
            set { SetProperty(ref this.recipeList, value); }
        }

        private MyTestModel selectedConfigValue;
        public MyTestModel SelectedConfigValue
        {
            get { return this.selectedConfigValue; }
            set { SetProperty(ref this.selectedConfigValue, value); }
        }

        private ObservableCollection<MyTestModel> configTestList;
        public ObservableCollection<MyTestModel> ConfigTestList
        {
            get { return configTestList; }
            set { SetProperty(ref configTestList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand<object> _cmbSelectionChangedCommand;
        public DelegateCommand<object> CmbSelectionChangedCommand =>
            _cmbSelectionChangedCommand ?? (_cmbSelectionChangedCommand = new DelegateCommand<object>(OnCmbSelectionChanged));

        private DelegateCommand _configListCommand;
        public DelegateCommand ConfigListCommand =>
            _configListCommand ?? (_configListCommand = new DelegateCommand(OnConfigList));

        private DelegateCommand<object> _SelectAllCommand;
        public DelegateCommand<object> SelectAllCommand =>
            _SelectAllCommand ?? (_SelectAllCommand = new DelegateCommand<object>(OnSelectAll));

        private DelegateCommand<object> _SelectCommand;
        public DelegateCommand<object> SelectCommand =>
            _SelectCommand ?? (_SelectCommand = new DelegateCommand<object>(OnSelect));

        private DelegateCommand _AddCommand;
        public DelegateCommand AddCommand =>
            _AddCommand ?? (_AddCommand = new DelegateCommand(OnAdd));

        private DelegateCommand<object> _DeleteCommand;
        public DelegateCommand<object> DeleteCommand =>
            _DeleteCommand ?? (_DeleteCommand = new DelegateCommand<object>(OnDelete));

        private DelegateCommand<object> _EditCommand;
        public DelegateCommand<object> EditCommand =>
            _EditCommand ?? (_EditCommand = new DelegateCommand<object>(OnEdit));

        private DelegateCommand<object> _SaveCommand;
        public DelegateCommand<object> SaveCommand =>
            _SaveCommand ?? (_SaveCommand = new DelegateCommand<object>(OnSave));

        private DelegateCommand<object> _BeginningEditCommand;
        public DelegateCommand<object> BeginningEditCommand =>
            _BeginningEditCommand ?? (_BeginningEditCommand = new DelegateCommand<object>(OnBeginningEdit));

        private DelegateCommand<object> _CellEditingCommand;
        public DelegateCommand<object> CellEditingCommand =>
            _CellEditingCommand ?? (_CellEditingCommand = new DelegateCommand<object>(OnCellEditing));

        private DelegateCommand<object> _RowEditEndingCommand;
        public DelegateCommand<object> RowEditEndingCommand =>
            _RowEditEndingCommand ?? (_RowEditEndingCommand = new DelegateCommand<object>(OnRowEditEnding));

        //private DelegateCommand _cRListCommand;
        //public DelegateCommand CRListCommand =>
        //    _cRListCommand ?? (_cRListCommand = new DelegateCommand(OnCRList));

        //private DelegateCommand _versionLogCommand;
        //public DelegateCommand VersionLogCommand =>
        //    _versionLogCommand ?? (_versionLogCommand = new DelegateCommand(OnVersionLog));

        #endregion

        #region Event Fun
        void OnCmbSelectionChanged(object obj)
        {
            var cmb = obj as ComboBox;
            string strCmbName = cmb.Name;
            switch (strCmbName)
            {
                case "cmbModule":
                    strSelectedModel = cmb.SelectedValue.ToString();
                    this.ProductList = new List<string>() { "Product1", "Product2", "Product3" };
                    break;
                case "cmbProduct":
                    strSelectedProduct = cmb.SelectedValue.ToString();
                    this.LayerList = new List<string>() { "Layer1", "Layer2", "Layer3" };
                    break;
                case "cmbLayer":
                    strSelectedLayer = cmb.SelectedValue.ToString();
                    this.ToolList = new List<string>() { "Tool1", "Tool2", "Tool3" };
                    break;
                case "cmbTool":
                    strSelectedTool = cmb.SelectedValue.ToString();
                    this.RecipeList = new List<string>() { "Recipe1", "Recipe2", "Recipe3" };
                    break;
                case "cmbRecipe":
                    strSelectedRecipe = cmb.SelectedValue.ToString();
                    break;
                default:
                    break;
            }
        }

        void OnConfigList()
        {
            strRequestId = "REQ_001";
            strUserId = "AMAT";
            strClientVersion = "7.8.0.43";
            strSelectedModel = "LITHO";
            strSelectedProduct = "PROD_LITHO_T001";
            strSelectedLayer = "FIRSTLAYER_LITHO_T001";
            strSelectedTool = "EQP_LITHO_T001";
            strSelectedRecipe = "PH-RCP";
            strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

            //string strJson = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
            //ControlSpecConfigEntity eneity = JsonHelp.DeserializeJsonToObject<ControlSpecConfigEntity>(strJson);

            ConfigCommonEntity eneity = new ConfigCommonEntity();
            eneity = this.ConfigMainService.R2R_UI_Config_Get(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName);

            controlCfg.AllowWriteColumn_CSV = eneity.AllowWriteColumn_CSV;
            controlCfg.bAllowView = eneity.bAllowView;
            controlCfg.bAllowWrite = eneity.bAllowWrite;
            controlCfg.bApprover = eneity.bApprover;
            controlCfg.bRequester = eneity.bRequester;
            controlCfg.bRollbacker = eneity.bRollbacker;

            strListColumnName = this.ConfigMainService.GetColumnName(eneity.ColumnFormat);

            InitValue();
        }

        public void InitValue()
        {
            ConfigTestList = new ObservableCollection<MyTestModel>();
            ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new Dictionary<string, string>() { { "可用资金", "1000.0" }, { "可取资金", "900.0" }, { "手续费", "1.68" }, { "手续费2", "1.68" } } });
            ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new Dictionary<string, string>() { { "可用资金", "1100.0" }, { "可取资金", "910.0" }, { "手续费", "1.68" }, { "手续费2", "1.68" } } });
            ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new Dictionary<string, string>() { { "可用资金", "1200.0" }, { "可取资金", "920.0" }, { "手续费", "1.68" }, { "手续费2", "1.68" } } });
            ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new Dictionary<string, string>() { { "可用资金", "1300.0" }, { "可取资金", "930.0" }, { "手续费", "1.68" }, { "手续费2", "1.68" } } });

            //ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new List<string>() { "1", "2", "3", "4" } });
            //ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new List<string>() { "1", "2", "3", "4" } });
            //ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new List<string>() { "1", "2", "3", "4" } });
            //ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new List<string>() { "1", "2", "3", "4" } });
            //ConfigTestList.Add(new MyTestModel() { ConfigInfoValue = new List<string>() { "1", "2", "3", "4" } });
        }
        #endregion

        #region
        //void GetControlCfg(ConfigCommonEntity eneity)
        //{
        //    controlCfg.AllowWriteColumn_CSV = eneity.AllowWriteColumn_CSV;
        //    controlCfg.bAllowView = eneity.bAllowView;
        //    controlCfg.bAllowWrite = eneity.bAllowWrite;
        //    controlCfg.bApprover = eneity.bApprover;
        //    controlCfg.bRequester = eneity.bRequester;
        //    controlCfg.bRollbacker = eneity.bRollbacker;
        //}

        //void setControlCfg(ConfigCommonEntity eneity)
        //{
        //    eneity.AllowWriteColumn_CSV = controlCfg.AllowWriteColumn_CSV;
        //    eneity.bAllowView = controlCfg.bAllowView;
        //    eneity.bAllowWrite = controlCfg.bAllowWrite;
        //    eneity.bApprover = controlCfg.bApprover;
        //    eneity.bRequester = controlCfg.bRequester;
        //    eneity.bRollbacker = controlCfg.bRollbacker;
        //}

        //void OnCRList()
        //{
        //    var window = new Window();//Windows窗体      
        //    CRList parameter = new CRList();
        //    CRListViewModel view = (CRListViewModel)parameter.DataContext;
        //    //view.setViewModel(this.SelectedCDValue);
        //    window.Content = parameter;
        //    window.Title = "CR List";
        //    window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        //    window.ShowDialog();
        //    //window.Show();
        //}

        //void OnVersionLog()
        //{
        //    var window = new Window();//Windows窗体      
        //    VersionLogList parameter = new VersionLogList();
        //    VersionLogListViewModel view = (VersionLogListViewModel)parameter.DataContext;
        //    //view.setViewModel(this.SelectedCDValue);
        //    window.Content = parameter;
        //    window.Title = "VersionLog List";
        //    window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        //    window.ShowDialog();
        //    //window.Show();
        //}

        //void OnCurrentCellChanged(object obj)
        //{
        //    var dgv = obj as DataGrid;
        //    MessageBox.Show("CurrentCellChanged" );
        //}

        //void OnSaveListClick()
        //{
        //    string strContent = System.IO.File.ReadAllText(@"C:\zqk\json.txt");
        //    strRequestId = "REQ_002";
        //    strUserId = "AMAT";
        //    strClientVersion = "7.8.0.43";
        //    strSelectedModel = "LITHO";
        //    strSelectedProduct = "PROD_LITHO_T001";
        //    strSelectedLayer = "FIRSTLAYER_LITHO_T001";
        //    strSelectedTool = "EQP_LITHO_T001";
        //    strSelectedRecipe = "PH-RCP";
        //    strTableName = "R2R_PH_CONTROL_SPECS_CONFIG";

        //    //string strContent = JsonHelp.SerializeObject(GetCurrentEntity());
        //    bool flag = this.ConfigMainService.R2R_UI_Config_Update(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedRecipe, strTableName, strContent);
        //    if (flag)
        //    {
        //    }
        //    else
        //    {
        //    }
        //}

        //void OnDeleteListClick()
        //{
        //    ConfigMainInfoList.Remove(SelectedConfigValue);
        //    SelectedConfigValue = ConfigMainInfoList.Last();

        //    //string strContent = JsonHelp.SerializeObject(GetCurrentEntity());
        //    //bool flag = this.ConfigMainService.Config_R2R_PH_CONTROL_SPECS_CONFIG_Delete(strRequestId, strUserId, strClientVersion, strSelectedModel, strSelectedProduct, strSelectedLayer, strSelectedTool, strSelectedReticle, strTableName, strContent);
        //    //if (flag)
        //    //{
        //    //}
        //    //else
        //    //{
        //    //}
        //}

        //ConfigCommonEntity GetCurrentEntity()
        //{
        //    ConfigCommonEntity eneity = new ConfigCommonEntity();

        //    return eneity;
        //}
        #endregion

        #region Test
        /// <summary>
        /// 全选
        /// </summary>
        /// <param name="id"></param>
        public void OnSelectAll(object id)
        {
            foreach (var item in configTestList)
            {
                item.IsSelected = IsSelectAll;
            }
        }

        /// <summary>
        /// 单选
        /// </summary>
        /// <param name="id"></param>
        public void OnSelect(object id)
        {
            MyTestModel cm = ConfigTestList.Where(p => p.IsSelected).FirstOrDefault();
            if (cm != null)
            {
                if (!cm.IsSelected && IsSelectAll)
                {
                    IsSelectAll = false;
                }
                else if (cm.IsSelected && !IsSelectAll)
                {
                    foreach (var item in ConfigTestList)
                    {
                        if (!item.IsSelected) return;
                    }
                    IsSelectAll = true;
                }
            }
        }

        /// <summary>
        /// 判断是否选中
        /// </summary>
        /// <param name="onlyOne">是否单选</param>
        /// <returns></returns>
        public bool SelectValidate(bool onlyOne = false)
        {
            if (this.ConfigTestList.Count(p => p.IsSelected) < 1)
            {
                MessageBox.Show("未勾选数据！");
                return false;
            }

            if (onlyOne)
            {
                if (this.ConfigTestList.Count(p => p.IsSelected) > 1)
                {
                    MessageBox.Show("只能勾选一条数据！");
                    return false;
                }
            }

            return true;
        }

        string strBeginEdit = string.Empty;
        string strEndEdit = string.Empty;
        void OnBeginningEdit(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("CellEditing");

            SelectedConfigValue.IsSelected = true;

            //strBeginEdit = JsonHelp.SerializeObject(SelectedConfigValue);
            strBeginEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (!SelectValidate(true))
            {
                return;
            }

            MyTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("BeginningEdit " + model.ConfigInfoValue);
        }

        void OnCellEditing(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("CellEditing");

            SelectedConfigValue.IsSelected = true;
            strEndEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (strBeginEdit.Equals(strEndEdit))
            {
                MessageBox.Show("Not Value Change");
                return;
            }
            if (!SelectValidate(true))
            {
                return;
            }

            MyTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("CellEditing " + model.ConfigInfoValue);
        }

        void OnRowEditEnding(object obj)
        {
            var dgv = obj as DataGrid;
            //MessageBox.Show("RowEditing");

            SelectedConfigValue.IsSelected = true;

            strEndEdit = JsonHelp.SerializeObject(SelectedConfigValue.ConfigInfoValue);
            if (strBeginEdit.Equals(strEndEdit))
            {
                MessageBox.Show("Not Value Change");
                return;
            }

            if (!SelectValidate(true))
            {
                return;
            }

            MyTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("RowEditing " + model.ConfigInfoValue);
        }

        void OnAdd()
        {

        }

        /// <summary>
        /// 删除
        /// </summary>
        /// <param name="obj"></param>
        public void OnDelete(object obj = null)
        {
            if (!SelectValidate())
            {
                return;
            }

            MessageBoxResult result = MessageBox.Show("是否删除选中项?", "提示", MessageBoxButton.YesNo);
            if (result != MessageBoxResult.Yes)
            {
                return;
            }

            StringBuilder sb = new StringBuilder();

            bool hasSelect = false;

            ////获取选中的数据
            //foreach (var v in ConfigTestList)
            //{
            //    if (v.IsSelected)
            //    {
            //        sb.Append(v.ConfigInfoValue.Product + ";");
            //        hasSelect = true;
            //    }
            //}
            for (int i = ConfigTestList.Count - 1; i >= 0; --i)
            {
                if (ConfigTestList[i].IsSelected)
                {
                    hasSelect = true;
                    ConfigTestList.Remove(ConfigTestList[i]);
                }
            }

            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            //MessageBox.Show("选中 " + sb.ToString());
        }

        /// <summary>
        /// 修改
        /// </summary>
        /// <param name="obj"></param>
        public void OnEdit(object obj = null)
        {
            if (!SelectValidate(true))
            {
                return;
            }

            MyTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("选中 " + model.ConfigInfoValue);

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="obj"></param>
        public void OnSave(object obj = null)
        {
            if (!SelectValidate(true))
            {
                return;
            }

            MyTestModel model = null;

            bool hasSelect = false;

            //获取选中的数据
            foreach (var v in ConfigTestList)
            {
                if (v.IsSelected)
                {
                    model = v;
                    hasSelect = true;
                    break;
                }
            }
            if (!hasSelect)
            {
                MessageBox.Show("请选择修改项", "警告");
                return;
            }

            MessageBox.Show("Save " + model.ConfigInfoValue);
        }
        #endregion
    }
}
