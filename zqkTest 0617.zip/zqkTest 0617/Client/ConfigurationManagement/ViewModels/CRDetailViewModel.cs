﻿using ConfigurationService.Models;
using Prism.Commands;
using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConfigurationManagement.ViewModels
{
    public class CRDetailViewModel : ViewModelBase
    {
        public CRDetailViewModel()
        {
            Title = "CRDetail";
        }

        #region
        private ObservableCollection<ConfigMainInfoModel> _CRDetailInfoList;
        public ObservableCollection<ConfigMainInfoModel> CRDetailInfoList
        {
            get { return _CRDetailInfoList; }
            set { SetProperty(ref _CRDetailInfoList, value); }
        }
        #endregion

        #region Event Define
        private DelegateCommand _ApproveCommand;
        public DelegateCommand CRDetailCommand =>
            _ApproveCommand ?? (_ApproveCommand = new DelegateCommand(OnApprove));
        #endregion

        #region Event Fun
        void OnApprove()
        {  
 
        }
        #endregion
    }
}
