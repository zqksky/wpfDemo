﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.Framework.Interfaces
{
    public interface IPageController
    {
        uint GetTotalCount(object FilterTag);
        ICollection<object> GetRecordsBy(uint startRowNumber, uint pageSize, object FilterTag);
    }
}
