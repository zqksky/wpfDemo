﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Common.Data;
using Prism.Commands;

namespace R2R.Client.Framework
{
    public class ListViewModelBase : ViewModelBase
    {
        private DelegateCommand _addCommand;
        public DelegateCommand AddCommand =>
            _addCommand ?? (_addCommand = new DelegateCommand(OnAdd, CanAdd));

        protected virtual bool CanAdd()
        {
            return true;
        }

        protected virtual void OnAdd()
        {
            // Empty. implemented by sub-class
        }

        private DelegateCommand _deleteCommand;
        public DelegateCommand DeleteCommand =>
            _deleteCommand ?? (_deleteCommand = new DelegateCommand(OnDelete, CanDelete));

        protected virtual bool CanDelete()
        {
            return SelectedEntity != null;
        }

        protected virtual void OnDelete()
        {
            // Empty. implemented by sub-class
        }

        private DelegateCommand _ModifyCommand;
        public DelegateCommand ModifyCommand =>
            _ModifyCommand ?? (_ModifyCommand = new DelegateCommand(OnModify, CanModify));

        protected virtual bool CanModify()
        {
            return SelectedEntity != null;
        }

        protected virtual void OnModify()
        {
            // Empty. implemented by sub-class
        }

        private DelegateCommand _disableCommand;
        public DelegateCommand DisableCommand =>
            _disableCommand ?? (_disableCommand = new DelegateCommand(OnDisable, CanDisable));

        protected virtual bool CanDisable()
        {
            return SelectedEntity != null && SelectedEntity.IsEnabled;
        }

        protected virtual void OnDisable()
        {
            // Empty. implemented by sub-class
        }

        private DelegateCommand _enableCommand;
        public DelegateCommand EnableCommand =>
            _enableCommand ?? (_enableCommand = new DelegateCommand(OnEnable, CanEnable));

        protected virtual bool CanEnable()
        {
            return SelectedEntity != null && !SelectedEntity.IsEnabled;
        }

        protected virtual void OnEnable()
        {
            
        }

        private DelegateCommand _RefreshCommand;
        public DelegateCommand RefreshCommand =>
            _RefreshCommand ?? (_RefreshCommand = new DelegateCommand(OnRefresh));

        protected virtual void OnRefresh()
        {
            // Empty. implemented by sub-class
        }

        private bool _isShowAll = false;
        public bool IsShowAll
        {
            get { return _isShowAll; }
            set { SetProperty(ref _isShowAll, value); }
        }

        private EntityBase _SelectedEntity;
        public EntityBase SelectedEntity
        {
            get { return _SelectedEntity; }
            set { SetProperty(ref _SelectedEntity, value); }
        }
    }
}
