﻿using System.Windows;
using R2R.Client.Common;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Common.Library;
using Prism.Commands;
using Prism.Events;
using Prism.Regions;
using R2R.Client.Shell.Views;
using R2R.Service.MainService;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using R2R.Common.Data;

namespace R2R.Client.Shell.ViewModels
{
    public class MainWindowViewModel : ViewModelBase
    {
        #region field
        private string dateTimeText;
        public string DateTimeText
        {
            get { return dateTimeText; }
            set { SetProperty(ref dateTimeText, value); }
        }

        private string _versionText;
        public string VersionText
        {
            get { return _versionText; }
            set { SetProperty(ref _versionText, value); }
        }

        private string _statusText;
        public string StatusText
        {
            get { return _statusText; }
            set { SetProperty(ref _statusText, value); }
        }

        private string currentUser;
        public string CurrentUser
        {
            get { return currentUser; }
            set { SetProperty(ref currentUser, value); }
        }

        private string currentServer;
        public string CurrentServer
        {
            get { return currentServer; }
            set { SetProperty(ref currentServer, value); }
        }

        private string username;
        public string UserName
        {
            get { return username; }
            set { SetProperty(ref username, value); }
        }

        private string domain;
        public string Domain
        {
            get { return domain; }
            set { SetProperty(ref domain, value); }
        }
        private List<string> _domainList = new List<string>();
        public List<string> DomainList
        {
            get { return _domainList; }
            set { _domainList = value; }
        }

        private Visibility _loginVisiable = Visibility.Visible;
        public Visibility LoginVisiable
        {
            get
            {
                return _loginVisiable;
            }
            set
            {
                SetProperty(ref _loginVisiable, value);
            }
        }

        private Visibility _menuVisiable = Visibility.Collapsed;
        public Visibility MenuVisiable
        {
            get
            {
                return _menuVisiable;
            }
            set
            {
                SetProperty(ref _menuVisiable, value);
            }
        }

        private ILoginService _loginService;
        public ILoginService LoginService
        {
            get { return _loginService; }
            set { _loginService = value; }
        }
        #endregion field

        #region command
        private DelegateCommand _exitCommand;
        public DelegateCommand ExitCommand =>
            _exitCommand ?? (_exitCommand = new DelegateCommand(ExecuteExitCommand));

        private DelegateCommand<string> _navigateToCommand;
        public DelegateCommand<string> NavigateToCommand =>
            _navigateToCommand ?? (_navigateToCommand = new DelegateCommand<string>(OnNavigateTo));
        #endregion command

        #region class function
        public MainWindowViewModel(IRegionManager regionManager, IEventAggregator eventAggregator, ILoginService loginService)
        {
            Title = "R2R Client";
            VersionText = "Version:1.0.0";
            CurrentUser = "Test";
            //CurrentServer = "R2R_Server1";
            EventAggregator.GetEvent<StatusUpdatedEvent>().Subscribe(OnStatusUpdatedEvent);
            EventAggregator.GetEvent<UserLoggedInEvent>().Subscribe(OnUserLoggedIn);
            this._loginService = loginService;
            InitDomin();
        }

        private void OnUserLoggedIn(string userId)
        {
            ClientInfo.CurrentUser = userId;
        }

        private void OnVersionUpdatedEvent(string version)
        {
            VersionText = "Version:" + version;
        }

        private void OnStatusUpdatedEvent(string status)
        {
            StatusText = status;
        }
        #endregion class function

        #region private function
        void ExecuteExitCommand()
        {
            Application.Current.MainWindow.Close();
        }
        void OnNavigateTo(string functionName)
        {
            try
            {
                MyLogger.PerformanceStart();
                RegionManager.Regions[RegionNames.MainRegion].RequestNavigate(functionName, (nr) =>
                {
                    if (nr.Error != null)
                    {
                        MyLogger.Error(nr.Error);
                        MessageBox.Show(nr.Error.ToString(), "Navigation failed!", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                });
            }
            finally
            {
                MyLogger.PerformanceStop();
            }
        }
        private void InitDomin()
        {
            NameValueCollection domains = ConfigurationManager.GetSection("R2R.DOMAIN") as NameValueCollection;
            if (domains == null)
            {
                return;
            }
            for (int i = 0; i < domains.Count; i++)
                this._domainList.Add(domains[(i + 1).ToString()]);
        }
        public bool CheckUser(string password)
        {
            int iResult = this.LoginService.Login(this.UserName, password, this.Domain);
            if (iResult == ReturnCode.LOGINOK)
            {
                this.CurrentUser = this.UserName;
                ClientInfo.CurrentUser = this.CurrentUser;
                ClientInfo.CurrentVersion = this.VersionText;
                return true;
            }
            return false;
        }
        #endregion private function
    }
}
