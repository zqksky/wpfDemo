﻿using System;
using System.Threading.Tasks;
using System.Windows;
using R2R.Client.Common;
using R2R.Client.Framework;
using R2R.Client.Framework.Events;
using R2R.Client.Shell.Views;
using R2R.Common.Data;
using R2R.Common.Library;
using CommonServiceLocator;
using Prism.Events;
using Prism.Ioc;
using Prism.Modularity;
using R2R.Common.DAL;
using R2R.Client.Framework.Interfaces;
using R2R.Service.MainService;
using R2R.Client.LithoModeManagement;
using ConfigurationManagement;

namespace R2R.Client.Shell
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        public App()
        {
            this.DispatcherUnhandledException += App_DispatcherUnhandledException;
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            TaskScheduler.UnobservedTaskException += TaskScheduler_UnobservedTaskException;
            MyLogger.Trace("Application Started.");
        }

        private void TaskScheduler_UnobservedTaskException(object sender, UnobservedTaskExceptionEventArgs e)
        {
            MyLogger.Error(e.Exception, "TaskScheduler_UnobservedTaskException");
            MessageBox.Show(e.Exception.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            ResetStatusText();
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            MyLogger.Fatal(e.ExceptionObject as Exception, "CurrentDomain_UnhandledException");
            Environment.Exit(1);
        }

        private void App_DispatcherUnhandledException(object sender, System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            e.Handled = true;
            MyLogger.Error(e.Exception, "App_DispatcherUnhandledException");
            // TODO: use style message window.
            MessageBox.Show(e.Exception.ToString(), "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            ResetStatusText();
        }

        private static void ResetStatusText()
        {
            var eventAggregator = ServiceLocator.Current.GetInstance<IEventAggregator>();
            eventAggregator.GetEvent<StatusUpdatedEvent>().Publish("Ready.");
        }

        protected override Window CreateShell()
        {
            MyLogger.Trace("Creating Shell...");
            var shell = Container.Resolve<MainWindow>();
            MyLogger.Trace("Shell Created.");
            return shell;
        }
        
        protected override void RegisterTypes(IContainerRegistry containerRegistry)
        {
            MyLogger.Trace();
            
            containerRegistry.RegisterSingleton<IErrorHandler, ErrorHandler>();
            containerRegistry.RegisterSingleton<IEntityTranslator, DataTableEntityTranslator>();
            containerRegistry.RegisterSingleton<IMessageManager, MessageManager>();
            containerRegistry.RegisterSingleton<ILoginService, LoginService>();
        }

        protected override void ConfigureModuleCatalog(IModuleCatalog moduleCatalog)
        {
            MyLogger.Trace();
            moduleCatalog.AddModule<ShellModule>();
            moduleCatalog.AddModule<LithoModeManagementModule>();
            moduleCatalog.AddModule<ConfigurationManagementModule>();
        }

        protected override void OnInitialized()
        {
            base.OnInitialized();
            MyLogger.Trace();
            // TODO: show login form.
            ServiceLocator.Current.GetInstance<IEventAggregator>().GetEvent<UserLoggedInEvent>().Publish("Andy");
        }
        protected override void RegisterRequiredTypes(IContainerRegistry containerRegistry)
        {
            base.RegisterRequiredTypes(containerRegistry);
            MyLogger.Trace();
        }
        
    }
}
