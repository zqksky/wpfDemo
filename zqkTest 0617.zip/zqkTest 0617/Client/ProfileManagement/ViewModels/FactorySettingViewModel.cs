﻿using R2R.Client.Common;
using R2R.Client.Framework;
using R2R.Common.Data;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using R2R.Service.ProfileService;

namespace R2R.Client.ProfileManagement.ViewModels
{
    public class FactorySettingViewModel : ListViewModelBase
    {

        private Factory _SelectedFactory;
        public Factory SelectedFactory
        {
            get { return _SelectedFactory; }
            set
            {
                SetProperty(ref _SelectedFactory, value);
                SelectedEntity = value;
                DeleteCommand.RaiseCanExecuteChanged();
                ModifyCommand.RaiseCanExecuteChanged();
                DisableCommand.RaiseCanExecuteChanged();
                EnableCommand.RaiseCanExecuteChanged();
            }
        }

        private ObservableCollection<Factory> _FactoryList;
        public ObservableCollection<Factory> FactoryList
        {
            get { return _FactoryList; }
            set { SetProperty(ref _FactoryList, value); }
        }

        public IFactoryService FactoryService { get; set; }

        public FactorySettingViewModel(IFactoryService factoryService)
        {
            FactoryService = factoryService;
            Title = "Factory Setting";
            IsShowAll = false;
            OnRefresh();
            EventAggregator.GetEvent<RefreshFactoryListEvent>().Subscribe(s => { OnRefresh();});
        }                

        protected override void OnAdd()
        {
            RegionManager.Regions[RegionNames.FactorySettingsRegion].RequestNavigate("AddFactory");
        }

        protected override void OnDelete()
        {
            FactoryService.DeleteFactory(SelectedFactory.Name);
            OnRefresh();
        }
      

        protected override void OnRefresh()
        {
            try
            {
                SetStatusText("Please wait...");
                List<QueryParameter> queryParameters = new List<QueryParameter>();
                if (!IsShowAll)
                {
                    queryParameters.Add(new QueryParameter(Factory.COL_IS_ENABLED, true));
                }

                OrderSettings orderSettings = new OrderSettings()
                {
                    Order = OrderDirection.ASC,
                    OrderBy = Factory.COL_FACTORY_NAME
                };

                var factoryList = FactoryService.GetFactories(queryParameters, orderSettings);

                string preSelectedFactory = SelectedFactory != null ? SelectedFactory.Name : null;

                FactoryList = new ObservableCollection<Factory>(factoryList);

                if(preSelectedFactory != null)
                {
                    SelectedFactory = FactoryList.FirstOrDefault(f => f.Name == preSelectedFactory);
                }
                SetStatusText("Factory list completed.");
            }
            finally
            {
            }
        }

        protected override void OnModify()
        {
            NavigationParameters navParams = new NavigationParameters();
            navParams.Add("Factory", SelectedFactory);
            RegionManager.Regions[RegionNames.FactorySettingsRegion].RequestNavigate("ModifyFactory", navParams);
        }
        
        protected override void OnDisable()
        {
            FactoryService.DisableFactory(SelectedFactory.Name);
            OnRefresh();
        }

        protected override void OnEnable()
        {
            FactoryService.EnableFactory(SelectedFactory.Name);
            OnRefresh();
        }
    }
}
