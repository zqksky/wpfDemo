﻿using R2R.Client.Common;
using R2R.Client.Framework;
using R2R.Common.Data;
using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace R2R.Client.ProfileManagement.ViewModels
{
    public class ModifyFactoryViewModel : ViewModelBase
    {
        public IProfileService ProfileService { get; set; }
        public ModifyFactoryViewModel(IProfileService profileService)
        {
            this.Title = "Factory Modify";
            ProfileService = profileService;
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value); }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { SetProperty(ref _description, value); }
        }

        public override void OnNavigatedTo(NavigationContext navigationContext)
        {
            base.OnNavigatedTo(navigationContext);
            
            if (navigationContext != null && navigationContext.Parameters.ContainsKey("Factory"))
            {
                Factory factory = navigationContext.Parameters["Factory"] as Factory;
                this.Name = factory.Name;
                this.Description = factory.Description;
            }
        }

        protected override void OnSubmit()
        {
            try
            {
                Factory factory = new Factory();
                factory.Description = this.Description;
                factory.Name = this.Name;
                factory.ModifiedDate = DateTime.Now;
                factory.ModifiedBy = ClientInfo.CurrentUser;

                SetStatusText($"Please wait...");

                ProfileService.ModifyFactory(factory);

                SetStatusText($"Factory {factory.Name} modified.");

                EventAggregator.GetEvent<RefreshFactoryListEvent>().Publish(null);
                CloseView();
            }
            finally
            {

            }
        }
    }
}
