﻿using R2R.Client.Framework;
using R2R.Common.Data;
using Prism.Commands;
using Prism.Mvvm;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace R2R.Client.ProfileManagement.ViewModels
{
    public class AddFactoryViewModel : ViewModelBase
    {
        public IProfileService ProfileService { get; set; }
        public AddFactoryViewModel(IProfileService profileService)
        {
            ProfileService = profileService;
            Title = "Add Factory";
            FactoryItems = new ObservableCollection<Factory>();
        }

        private string _name;
        public string Name
        {
            get { return _name; }
            set { SetProperty(ref _name, value);
                AddCommand.RaiseCanExecuteChanged();
            }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { SetProperty(ref _description, value); }
        }

        private ObservableCollection<Factory> _factoryItems;
        public ObservableCollection<Factory> FactoryItems
        {
            get { return _factoryItems; }
            set
            {
                SetProperty(ref _factoryItems, value);
            }
        }

        private Factory _factorySelected;
        public Factory FactorySelected
        {
            get { return _factorySelected; }
            set
            {
                SetProperty(ref _factorySelected, value);
                DeleteCommand.RaiseCanExecuteChanged();
            }
        }

        private DelegateCommand _addCommand;
        public DelegateCommand AddCommand =>
            _addCommand ?? (_addCommand = new DelegateCommand(OnAddFactory, CanAddFactory));

        void OnAddFactory()
        {
            if (!string.IsNullOrEmpty(this.Name))
            {
                
                if (VerifyFacotryExist(this.Name))
                {
                    //Factory already exists.
                    return;
                }

                Factory factory = new Factory();
                factory.Name = this.Name;
                factory.Description = this.Description;
                factory.IsEnabled = true;
                factory.ModifiedDate = DateTime.Now;
                factory.ModifiedBy = ClientInfo.CurrentUser;

                FactoryItems.Add(factory);
                CleanItem();

                SubmitCommand.RaiseCanExecuteChanged();
            }
        }
        bool CanAddFactory()
        {
            return !string.IsNullOrEmpty(this.Name);
        }

        private DelegateCommand _deleteCommand;
        public DelegateCommand DeleteCommand =>
            _deleteCommand ?? (_deleteCommand = new DelegateCommand(OnDeleteFactory, CanDeleteFactory));

        void OnDeleteFactory()
        {
            FactoryItems.Remove(FactorySelected);
            SubmitCommand.RaiseCanExecuteChanged();
        }
        bool CanDeleteFactory()
        {
            return FactorySelected != null;
        }

        private DelegateCommand _confirmCommand;
        public new DelegateCommand SubmitCommand =>
            _confirmCommand ?? (_confirmCommand = new DelegateCommand(OnConfirmFactory, CanConfirmFactory));

        void OnConfirmFactory()
        {
            if (FactoryItems.Count > 0)
            {
                ProfileService.AddFactory(FactoryItems.ToList());

                CleanItem(true);

                CloseView();

                EventAggregator.GetEvent<RefreshFactoryListEvent>().Publish(null);
            }
            else
            {
                //need to do err message
            }
        }
        bool CanConfirmFactory()
        {
            return FactoryItems.Count > 0 ? true : false;
        }

        private bool VerifyFacotryExist(string factoryName)
        {
            bool alreadyExist = false;
            if(FactoryItems.Count > 0)
            {
                alreadyExist = FactoryItems.Any<Factory>(t => t.Name == factoryName);

                if (alreadyExist) return alreadyExist;
            }

            List<QueryParameter> queryParameters = new List<QueryParameter>()
            {
                new QueryParameter(Factory.COL_FACTORY_NAME, factoryName)
            };

            OrderSettings orderSettings = new OrderSettings()
            {
                Order = OrderDirection.ASC,
                OrderBy = Factory.COL_FACTORY_NAME
            };

            var factoryList = ProfileService.GetFactories(queryParameters, orderSettings);

            alreadyExist = factoryList.Count > 0 ? true : false;
            return alreadyExist;
        }

        private void CleanItem(bool cleanAll = false)
        {
            Name = string.Empty;
            Description = string.Empty;
            if (cleanAll)
            {
                FactoryItems.Clear();
                SubmitCommand.RaiseCanExecuteChanged();
            }
        }
    }
}
