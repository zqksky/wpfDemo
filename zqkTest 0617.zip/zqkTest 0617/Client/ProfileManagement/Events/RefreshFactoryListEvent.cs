﻿using Prism.Events;

namespace R2R.Client.ProfileManagement.ViewModels
{
    internal class RefreshFactoryListEvent : PubSubEvent<string>
    {
    }

    internal class RefreshSystemsListEvent : PubSubEvent<string>
    {
    }
}