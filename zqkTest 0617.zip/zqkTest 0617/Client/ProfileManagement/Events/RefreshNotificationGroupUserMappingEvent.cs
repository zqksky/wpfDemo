﻿using Prism.Events;


namespace R2R.Client.ProfileManagement
{
    public class RefreshNotificationGroupUserMappingEvent : PubSubEvent<string>
    {
    }
}
