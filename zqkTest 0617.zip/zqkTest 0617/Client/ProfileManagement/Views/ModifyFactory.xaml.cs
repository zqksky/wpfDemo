﻿using System.Windows.Controls;

namespace R2R.Client.ProfileManagement.Views
{
    /// <summary>
    /// Interaction logic for ModifyFactory
    /// </summary>
    public partial class ModifyFactory : UserControl
    {
        public ModifyFactory()
        {
            InitializeComponent();
        }
    }
}
