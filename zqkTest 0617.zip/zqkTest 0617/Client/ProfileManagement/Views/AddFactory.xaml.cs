﻿using System.Windows.Controls;

namespace R2R.Client.ProfileManagement.Views
{
    /// <summary>
    /// Interaction logic for AddFactory
    /// </summary>
    public partial class AddFactory : UserControl
    {
        public AddFactory()
        {
            InitializeComponent();
            this.Loaded += AddFactory_Loaded;
        }

        private void AddFactory_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            tbName.Focus();
        }
    }
}
