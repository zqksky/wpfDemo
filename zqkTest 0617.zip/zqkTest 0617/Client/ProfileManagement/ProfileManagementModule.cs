﻿using R2R.Client.ProfileManagement.Views;
using R2R.Common.Data;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;
using R2R.Service.ProfileService;

namespace R2R.Client.ProfileManagement
{
    public class ProfileManagementModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {
 
        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<FactorySetting>();
            containerRegistry.RegisterForNavigation<AddFactory>();
            containerRegistry.RegisterForNavigation<ModifyFactory>();
            containerRegistry.RegisterSingleton<IFactoryService, FactoryService>();
        }
    }
}