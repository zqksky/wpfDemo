﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ParameterConfigOVLViewModel : ViewModelBase
    {
        public ParameterConfigOVLViewModel()
        {

        }



        public void setViewModel(OVLInfoModel dataModel)
        {
            //this.ToolText = dataModel.f;
            //this.ProductText = dataModel.Product;
            //this.LayerText = dataModel.Layer;
            //this.ReticleText = dataModel.Reticle;
            //this.preToolText = dataModel.PreTool;
            //this.preReticleText = dataModel.PreReticle;

            //List<CDParameterModel> cDs = new List<CDParameterModel>();
            //cDs.Add(getObject("Tool", dataModel.Tool));
            //cDs.Add(getObject("Product", dataModel.Product));
            //cDs.Add(getObject("Layer", dataModel.Layer));
            //cDs.Add(getObject("Reticle", dataModel.Reticle));
            //cDs.Add(getObject("PreTool", dataModel.PreTool));
            //cDs.Add(getObject("PreReticle", dataModel.PreReticle));
            //DataList = new ObservableCollection<CDParameterModel>(cDs);
        }

        #region Field
        private string toolText;
        public string ToolText
        {
            get { return this.toolText; }
            set { SetProperty(ref this.toolText, value); }
        }

        private string productText;
        public string ProductText
        {
            get { return this.productText; }
            set { SetProperty(ref this.productText, value); }
        }

        private string layerText;
        public string LayerText
        {
            get { return this.layerText; }
            set { SetProperty(ref this.layerText, value); }
        }

        private string reticleText;
        public string ReticleText
        {
            get { return this.reticleText; }
            set { SetProperty(ref this.reticleText, value); }
        }

        private string preToolText;
        public string PreToolText
        {
            get { return this.preToolText; }
            set { SetProperty(ref this.preToolText, value); }
        }

        private string preReticleText;
        public string PreReticleText
        {
            get { return this.preReticleText; }
            set { SetProperty(ref this.preReticleText, value); }
        }

        private CDParameterModel selectedValue;
        public CDParameterModel SelectedValue
        {
            get { return this.selectedValue; }
            set { this.selectedValue = value; }
        }

        private ObservableCollection<CDParameterModel> _DataList;
        public ObservableCollection<CDParameterModel> DataList
        {
            get { return _DataList; }
            set { SetProperty(ref _DataList, value); }
        }
        #endregion

        private CDParameterModel getObject(string key, string value)
        {
            CDParameterModel cD = new CDParameterModel();
            cD.ParameterName = key;
            cD.FixedValue = value;
            return cD;
        }
    }
}
