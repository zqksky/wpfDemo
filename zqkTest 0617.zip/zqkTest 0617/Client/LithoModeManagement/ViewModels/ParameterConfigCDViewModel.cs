﻿using R2R.Client.Framework;
using R2R.Common.Data;
using R2R.Common.Data.Litho;
using R2R.Service.LithoModeService;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class ParameterConfigCDViewModel : ViewModelBase
    {

        public IParameterConfigCDService ParameterConfigCDService { get; set; }
        public ParameterConfigCDViewModel()
        {


        }


        #region Field
        private string toolText;
        public string ToolText
        {
            get
            {
                return this.toolText;
            }
            set
            {
                SetProperty(ref this.toolText, value);
            }
        }

        private string productText;
        public string ProductText
        {
            get
            {
                return this.productText;
            }
            set
            {
                SetProperty(ref this.productText, value);
            }
        }

        private string layerText;
        public string LayerText
        {
            get
            {
                return this.layerText;          
            }
            set
            {
                SetProperty(ref this.layerText, value);
            }
        }

        private string reticleText;
        public string ReticleText
        {
            get
            {
                return this.reticleText;
            }
            set
            {
                SetProperty(ref this.reticleText, value);
            }
        }

        private float sensitivityText;
        public float SensitivityText
        {
            get
            {
                return this.sensitivityText;
            }
            set
            {
                SetProperty(ref this.sensitivityText, value);
            }
        }

        private string cDTargetText;
        public string CDTargetText
        {
            get
            {
                return this.cDTargetText;
            }
            set
            {
                SetProperty(ref this.cDTargetText, value);
            }
        }

        private string feedbackPointText;
        public string FeedbackPointText
        {
            get
            {
                return this.feedbackPointText;
            }
            set
            {
                SetProperty(ref this.feedbackPointText, value);
            }
        }

        private float lambdaText;
        public float LambdaText
        {
            get
            {
                return this.lambdaText;
            }
            set
            {
                SetProperty(ref this.lambdaText, value);
            }
        }

        private float lambdaPiRunText;
        public float LambdaPiRunText
        {
            get
            {
                return this.lambdaPiRunText;
            }
            set
            {
                SetProperty(ref this.lambdaPiRunText, value);
            }
        }

        private int minPointsFoeAvText;
        public int MinPointsFoeAvText
        {
            get
            {
                return this.minPointsFoeAvText;
            }
            set
            {
                SetProperty(ref this.minPointsFoeAvText, value);
            }
        }

        private string feedbackStageText;
        public string FeedbackStageText
        {
            get
            {
                return this.feedbackStageText;
            }
            set
            {
                SetProperty(ref this.feedbackStageText, value);
            }
        }

        private List<ParameterRow> dataList;
        private List<ParameterRow> DataList
        {
            get
            {
                return this.dataList;
            }
            set
            {
                SetProperty(ref this.dataList, value);
            }
        }


        private CDContextContent contextContent;
        public CDContextContent ContextContent
        {
            get
            {
                return this.contextContent;
            }
            set
            {
                this.contextContent = value;
                this.ToolText = this.contextContent.ToolId;
                this.ProductText = this.contextContent.ProductId;
                this.LayerText = this.contextContent.LayerId;
            }
        }
        #endregion
    }
}
