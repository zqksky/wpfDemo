﻿using R2R.Client.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using R2R.Service.VO;
using System.Collections.ObjectModel;

namespace R2R.Client.LithoModeManagement.ViewModels
{

    public class SpecialJobListViewModel : ViewModelBase
    {
        public SpecialJobListViewModel()
        {

        }
    }
}