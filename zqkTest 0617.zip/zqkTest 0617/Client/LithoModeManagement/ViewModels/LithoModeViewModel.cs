﻿using Prism.Commands;
using R2R.Client.Framework;
using R2R.Client.LithoModeManagement.Views;
using R2R.Common.Data;
using R2R.Common.Library;
using R2R.Service.LithoModeService;
using R2R.Service.VO;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Windows;
using System.Windows.Controls;

namespace R2R.Client.LithoModeManagement.ViewModels
{
    public class LithoModeViewModel : ViewModelBase
    {
        public ILithoService LithoService { get; set; }
        public IParameterConfigCDService ParameterConfigCDService { get; set; }
        public IParameterConfigOVLService ParameterConfigOVLService { get; set; }

        #region Field
        private string selectedProductText;
        public string SelectedProductText
        {
            get { return this.selectedProductText; }
            set { SetProperty(ref this.selectedProductText, value); }
        }

        private string selectedLayerText;
        public string SelectedLayerText
        {
            get { return this.selectedLayerText; }
            set { SetProperty(ref this.selectedLayerText, value); }
        }
        
        private List<string> productList;
        public List<string> ProductList
        {
            get { return this.productList; }
            set { SetProperty(ref this.productList, value); }
        }

        private List<string> layerList;
        public List<string> LayerList
        {
            get { return this.layerList; }
            set { SetProperty(ref this.layerList, value); }
        }

        private string cdEditByText;
        public string CDEditByText
        {
            get { return this.cdEditByText; }
            set { SetProperty(ref this.cdEditByText, value); }
        }

        private string ovlEditByText;
        public string OVLEditByText
        {
            get { return this.ovlEditByText; }
            set { SetProperty(ref this.ovlEditByText, value); }
        }

        private string cdEditTimeText;
        public string CDEditTimeText
        {
            get { return this.cdEditTimeText; }
            set { SetProperty(ref this.cdEditTimeText, value); }
        }

        private string ovlEditTimeText;
        public string OVLEditTimeText
        { 
            get { return this.ovlEditTimeText; }
            set { SetProperty(ref this.ovlEditTimeText, value); }
        }

        private string cdCommentText;
        public string CDCommentText
        {
            get { return this.cdCommentText; }
            set { SetProperty(ref this.cdCommentText, value); }
        }

        private TabItem selectedTabItem;
        public TabItem SelectedTabItem
        {
            get { return this.selectedTabItem; }
            set { SetProperty(ref this.selectedTabItem, value); }
        }
        
        private string ovlCommentText;
        public string OVLCommentText
        {
            get { return this.ovlCommentText; }
            set { SetProperty(ref this.ovlCommentText, value); }
        }

        private bool isShowAll;
        public bool IsShowAll
        {
            get { return this.isShowAll; }
            set { SetProperty(ref this.isShowAll, value); }
        }

        private CDInfoModel selectedCDValue;
        public CDInfoModel SelectedCDValue
        {
            get { return this.selectedCDValue; }
            set { SetProperty(ref this.selectedCDValue, value); }
        }

        private OVLInfoModel selectedOVLValue;
        public OVLInfoModel SelectedOVLValue
        {
            get { return this.selectedOVLValue; }
            set { SetProperty(ref this.selectedOVLValue, value); }
        }

        private DataView _CDDataTable;
        public DataView CDDataTable
        {
            get { return _CDDataTable; }
            set { SetProperty(ref _CDDataTable, value); }
        }

        private DataView _OVLDataTable;
        public DataView OVLDataTable
        {
            get { return _OVLDataTable; }
            set { SetProperty(ref _OVLDataTable, value); }
        }
        #endregion

        #region Event
        private DelegateCommand _queryListCommand;
        public DelegateCommand QueryListCommand =>
            _queryListCommand ?? (_queryListCommand = new DelegateCommand(OnQueryList));      

        private DelegateCommand _cdEditCommand;
        public DelegateCommand CDEditCommand =>
            _cdEditCommand ?? (_cdEditCommand = new DelegateCommand(OnCDEditClick));

        private DelegateCommand _ovlEditCommand;
        public DelegateCommand OVLEditCommand =>
            _ovlEditCommand ?? (_ovlEditCommand = new DelegateCommand(OnOVLEditClick));


        private DelegateCommand _productDropDownCommand;
        public DelegateCommand ProductDropDownCommand =>
            _productDropDownCommand ?? (_productDropDownCommand = new DelegateCommand(OnProductDropDown));

        private DelegateCommand _productSelectionChangedCommand;
        public DelegateCommand ProductSelectionChangedCommand =>
            _productSelectionChangedCommand ?? (_productSelectionChangedCommand = new DelegateCommand(OnProductSelectionChanged));
        
        #endregion

        #region local Function
        void OnQueryList()
        {
            if(this.IsShowAll)
            {
                this.SelectedLayerText = "*";
            }
            if (((string)this.SelectedTabItem.Header).Contains("CD"))
            {
                DataView cdDataView = this.LithoService.GetCDDataList(ClientInfo.CurrentUser, 
                                                                    ClientInfo.CurrentVersion,
                                                                    this.SelectedProductText, 
                                                                    this.SelectedLayerText,
                                                                    "", 
                                                                    "", 
                                                                    CDDataTable.ToTable());
                this.CDDataTable = cdDataView;
                return;
            }
            DataView ovlDataView = this.LithoService.GetOVLDataList(ClientInfo.CurrentUser,
                                                                    ClientInfo.CurrentVersion,
                                                                    this.SelectedProductText,
                                                                    this.SelectedLayerText,
                                                                    "",
                                                                    "",
                                                                    CDDataTable.ToTable());
            this.OVLDataTable = ovlDataView;
        }

        void OnProductDropDown()
        {
            this.ProductList = this.LithoService.GetProductList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
        }
        
        void OnProductSelectionChanged()
        {
            this.LayerList = this.LithoService.GetLayerList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion, this.SelectedProductText);
        }

        void OnCDEditClick()
        {
            var window = new Window();//Windows窗体
            ParameterConfigCD parameter = new ParameterConfigCD();
            ParameterConfigCDViewModel v = (ParameterConfigCDViewModel)parameter.DataContext;
            if(this.SelectedCDValue == null)
            {
                MessageBox.Show("Row is not selected!");
            }
            v.ParameterConfigCDService = this.ParameterConfigCDService;
            v.ContextContent = this.ParameterConfigCDService.GetCDContext(ClientInfo.CurrentUser,
                                                                          ClientInfo.CurrentVersion,
                                                                          this.SelectedCDValue.ProductId,
                                                                          this.SelectedCDValue.LayerId,
                                                                          this.SelectedCDValue.ToolId,
                                                                          this.SelectedCDValue.ReticleId,
                                                                          this.SelectedCDValue.RecipeId,
                                                                          this.SelectedCDValue.Chuck);
            window.Content = parameter;
            window.Show();
        }

        void OnOVLEditClick()
        {
            var window = new Window();//Windows窗体      
            ParameterConfigOVL parameter = new ParameterConfigOVL();
            ParameterConfigOVLViewModel v = (ParameterConfigOVLViewModel)parameter.DataContext;
            v.setViewModel(this.SelectedOVLValue);
            window.Content = parameter;
            window.Show();

        }
        #endregion

        public LithoModeViewModel(ILithoService lithoService, IParameterConfigCDService parameterConfigCDService, IParameterConfigOVLService parameterConfigOVLService)
        {
            this.LithoService = lithoService;
            this.ParameterConfigCDService = parameterConfigCDService;
            this.ParameterConfigOVLService = parameterConfigOVLService;

            Title = "LithoModeView";

            List<DataView> dataViews = this.LithoService.GetLithoColumnList(ClientInfo.CurrentUser, ClientInfo.CurrentVersion);
            this.CDDataTable = dataViews[0];
            this.OVLDataTable = dataViews[1];
        }
    }
}
