﻿using Prism.Ioc;
using Prism.Modularity;
using R2R.Client.LithoModeManagement.Views;
using R2R.Service.LithoModeService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R2R.Client.LithoModeManagement
{
    public class LithoModeManagementModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }


        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<LithoMode>();
            containerRegistry.RegisterForNavigation<SpecialJobList>();
            containerRegistry.RegisterForNavigation<CreateSpecialJob>();
            containerRegistry.RegisterSingleton<ILithoService, LithoService>();
            containerRegistry.RegisterSingleton<IParameterConfigCDService, ParameterConfigCDService>();
            containerRegistry.RegisterSingleton<IParameterConfigOVLService, ParameterConfigOVLService>();
        }
    }
}
