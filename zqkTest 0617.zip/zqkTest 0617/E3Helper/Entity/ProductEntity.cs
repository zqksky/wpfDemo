﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace E3Helper.Message.Entity
{
    public class ProductEntity
    {
        public string ProductId { get; set; }
        public string Category { get; set; }
        public string Technology { get; set; }
        public string ProductType { get; set; }
    }
}
