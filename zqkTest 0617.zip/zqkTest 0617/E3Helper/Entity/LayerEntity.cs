﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E3Helper.Message.Entity
{
    public class LayerEntity
    {
        public int Id { get; set; }
        public string LayerId { get; set; }
        public string LayerName { get; set; }
        public string PreLayer { get; set; }
        public string AlignLayer { get; set; }
    }
}
