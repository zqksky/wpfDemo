﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using E3Helper.Message.Entity;
using E3Helper.Message.Entity.Litho;
namespace E3Helper.Message
{
    public class JasonHelperLitho
    {
        /// <summary>
        /// 
        /// </summary>
        public static string ConvertToColumns4LithoModel(string[] cdHeaders, string[] cdFields, string[] ovlHeaders, string[] ovlFields)
        {
            LithoModelColumnEntity col = new LithoModelColumnEntity();
            col.CDCols = new List<ColumnEntity>();
            col.OVLCols = new List<ColumnEntity>();

            for (int i = 0; i < cdHeaders.Length; i++)
            {
                col.CDCols.Add(new ColumnEntity { ColumnName = cdHeaders[i], FieldName = cdFields[i] });
            }

            for (int i = 0; i < ovlHeaders.Length; i++)
            {
                col.OVLCols.Add(new ColumnEntity { ColumnName = ovlHeaders[i], FieldName = ovlFields[i] });
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(col.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, col);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="layerIds"></param>
        /// <returns></returns>
        public static string ConvertCDRows4LithoModel(string[] toolId, string[] productId, string[] layerId, string[] reticleId, string[] recipeId, string[] mode, string[] ctlFlag, string[] lastEstiTime, string cdName, string focusName, string[] cd, string[] focus)
        {
            List<CDContextRow> rows = new List<CDContextRow>();
            for (int i = 0; i < toolId.Length; i++)
            {
                CDContextRow row = new CDContextRow();
                row.ToolId = toolId[i];
                row.ProductId = productId[i];
                row.LayerId = layerId[i];
                row.ReticleId = reticleId[i];
                row.RecipeId = recipeId[i];
                row.Chuck = "NA";
                row.CtlFlag = ctlFlag[i];
                row.Mode = mode[i];
                row.LastEstiTime = lastEstiTime[i];
                row.Parameters = new List<ParameterEntity>();
                row.Parameters.Add(new ParameterEntity { ParameterName = cdName, ParameterVaue = cd[i] });
                row.Parameters.Add(new ParameterEntity { ParameterName = focusName, ParameterVaue = focus[i] });
                rows.Add(row);
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(rows.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, rows);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertOVLRows4LithoModel(string[] toolId, string[] productId, string[] layerId, string[] reticleId, string[] recipeId, string[] preTool,string[] preReticle,string[] chuckId,string[] mode, string[] ctlFlag, string[] lastEstiTime, string ovlNames,  string[] ovlValues)
        {
            List<OVLContextRow> rows = new List<OVLContextRow>();
            string[] ovls = ovlNames.Split(',');
            for (int i = 0; i < toolId.Length; i++)
            {
                OVLContextRow row = new OVLContextRow();
                row.ToolId = toolId[i];
                row.ProductId = productId[i];
                row.LayerId = layerId[i];
                row.ReticleId = reticleId[i];
                row.RecipeId = recipeId[i];
                row.PreTool = preTool[i];
                row.PreReticle = preReticle[i];
                row.Chuck = chuckId[i];
                row.CtlFlag = ctlFlag[i];
                row.Mode = mode[i];
                row.LastEstiTime = lastEstiTime[i];
                row.Parameters = new List<ParameterEntity>();
                string[] vals = ovlValues[i].Split(',');
                for(int j = 0 ;j < ovls.Length; j++)
                {
                    row.Parameters.Add(new ParameterEntity { ParameterName = ovls[j], ParameterVaue = vals[j] });
                }
            }

            DataContractJsonSerializer serializer = new DataContractJsonSerializer(rows.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, rows);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }
    }
}
