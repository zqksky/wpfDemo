﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Json;
using E3Helper.Message.Entity;

namespace E3Helper.Message
{
    public class JsonHelper
    {
        /// <summary>
        /// to get the products class list when open Litho Model View
        /// </summary>
        /// <param name="productIds"></param>
        /// <returns></returns>
        public static string ConvertToProducts(string[] productIds)
        {
            List<ProductEntity> products = new List<ProductEntity>();
            foreach (string productId in productIds)
            {
                products.Add(new ProductEntity { ProductId = productId });
            }

             
            DataContractJsonSerializer serializer = new DataContractJsonSerializer(products.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, products);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }
             
            return jsonText;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="layerIds"></param>
        /// <returns></returns>
        public static string ConvertToLayers(string[] layerIds)
        {
            List<LayerEntity> layers = new List<LayerEntity>();
            foreach (string layerId in layerIds)
            {
                layers.Add(new LayerEntity { LayerId = layerId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(layers.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, layers);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToTools(string[] toolIds)
        {
            List<ToolEntity> tools = new List<ToolEntity>();
            foreach (string toolId in toolIds)
            {
                tools.Add(new ToolEntity { ToolId = toolId });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(tools.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, tools);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToChambers(string[] chNames)
        {
            List<ChamberEntity> chs = new List<ChamberEntity>();
            foreach (string chName in chNames)
            {
                chs.Add(new ChamberEntity { ChName = chName });
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(chs.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, chs);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }

        public static string ConvertToParameters(string[] parameterNames, string[] parameterVaue, string[] parameterBiasName, string[] parameterValueType, string[] parameterProcessType, int[] precision)
        {
            List<ParameterEntity> paras = new List<ParameterEntity>();
            for(int i = 0; i < parameterNames.Length; i++)
            {
                paras.Add(new ParameterEntity { ParameterName=parameterNames[i],ParameterBiasName=parameterBiasName[i],ParameterProcessType=parameterProcessType[i],ParameterValueType=parameterProcessType[i],ParameterVaue=parameterVaue[i],Precision=precision[i]});
            }


            DataContractJsonSerializer serializer = new DataContractJsonSerializer(paras.GetType());
            string jsonText;
            using (System.IO.MemoryStream stream = new System.IO.MemoryStream())
            {
                serializer.WriteObject(stream, paras);
                jsonText = Encoding.UTF8.GetString(stream.ToArray());
            }

            return jsonText;
        }
    

    }


}
